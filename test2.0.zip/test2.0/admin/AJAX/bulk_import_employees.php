<?php
include('../includes/dbconn.php');

$return_data = array();

if (isset($_FILES['record-file'])) {

    $fileName = $_FILES['record-file']['tmp_name'];

    if ($_FILES['record-file']['size'] > 0) {

        $file = fopen($fileName, 'r');

        $data = array();
        $headers = fgetcsv($file); // Read the first row as column headers
        while (($row = fgetcsv($file)) !== FALSE) {
            $data[] = $row;
        }
        fclose($file);

        $query_starting = "INSERT INTO tblemployees (";
        foreach ($headers as $col_name) {
            $query_starting .= "`" . mysqli_real_escape_string($con, $col_name) . "`, ";
        }
        $query_starting = rtrim($query_starting, ", ") . ") VALUES ";

        $value_queries = [];
        foreach ($data as $row) {
            $escaped_values = array_map(function ($value) use ($con) {
                return "'" . mysqli_real_escape_string($con, $value) . "'";
            }, $row);
            $value_queries[] = "(" . implode(", ", $escaped_values) . ")";
        }

        $final_query = $query_starting . implode(", ", $value_queries);
        $res = mysqli_query($con, $final_query);

        if ($res) {
            $return_data['Status'] = 1;
            $return_data['Message'] = mysqli_affected_rows($con) . " records inserted successfully!";
        } else {
            $return_data['Status'] = 0;
            $return_data['Error'] = "Error inserting data: " . mysqli_error($con);
        }
    } else {
        $return_data['Status'] = 0;
        $return_data['Error'] = 'File empty';
    }
} else {
    $return_data['Status'] = 0;
    $return_data['Error'] = 'File not set';
}

echo json_encode($return_data);
?>
