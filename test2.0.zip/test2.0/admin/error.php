<div class="text-center" style="margin-top:15%;">
<h1>Error</h1>
<h4>You must be logged in to view this page!</h4>
<h5 class="mt-3">Please <a href="index.php">login</a> to continue!</h5>
</div>
