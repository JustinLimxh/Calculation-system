<?php
// Database connection
$host = '127.0.0.1'; // Change as necessary
$dbname = 'test-txt'; // Change as necessary
$username = 'root'; // Change as necessary
$password = ''; // Change as necessary

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
    exit;
}

// Get form data
$refNum = $_POST['refNum'];
$payDesc = $_POST['payDesc'];
$date = $_POST['date']; // The date from the form will be in yyyy-mm-dd format

// Ensure the date is in the correct format
$dateObj = DateTime::createFromFormat('Y-m-d', $date);  // Expecting yyyy-mm-dd
if ($dateObj && $dateObj->format('Y-m-d') === $date) {
    // Format the date as ddmmyyyy (for database insertion)
    $formattedDate = $dateObj->format('dmY');  // Format as ddmmyyyy (e.g., 08012025)
} else {
    echo "Invalid date format. Please enter the date as dd-mm-yyyy.";
    exit;
}

// Fetch company info
$query = "SELECT orgCode, compName FROM companyinfo WHERE id = 1";
$stmt = $pdo->prepare($query);
$stmt->execute();
$company = $stmt->fetch(PDO::FETCH_ASSOC);

// Fetch all staff info
$staffQuery = "SELECT * FROM staffinfo";
$staffStmt = $pdo->prepare($staffQuery);
$staffStmt->execute();

// Prepare data for line 1
$line1 =
    str_pad('01', 2) . // Default
    str_pad(substr($company['orgCode'], 0, 5), 5) . // orgCode (5 characters)
    str_pad(substr($company['compName'], 0, 40), 40) . // compName (40 characters)
    str_pad($formattedDate, 8) . // Date (8 characters in ddmmyyyy format)
    str_repeat('0', 16) . // Default 16 zeros
    str_repeat(' ', 3) . // Default 3 spaces
    PHP_EOL;

// Prepare a file name
$fileName = "BulkPayment" . "_" . $formattedDate . ".txt";

// Open file for writing
$file = fopen($fileName, "w");

// Write line 1 to file (only once)
fwrite($file, $line1);

// Initialize variables for line 3
$totalStaff = 0;
$totalSalary = 0;

// Loop through all staff and prepare line 2 for each
while ($staff = $staffStmt->fetch(PDO::FETCH_ASSOC)) {
    // Ensure salary is rounded to cents and converted to an integer
    $salaryInCents = intval(round($staff['salary'] * 100));

    // Increment total staff count and total salary
    $totalStaff++;
    $totalSalary += $salaryInCents;

    // Prepare refNum (combining refNum and staffid)
    // Ensure refNum and staffid are concatenated properly and truncated to 30 characters
    $refNumWithStaffId = substr($refNum . $staff['staffid'], 0, 30);

    // Prepare line 2 data
    $line2 =
        str_pad('02', 2) . // Default
        str_pad(substr($staff['bankType'], 0, 7), 7, '0', STR_PAD_RIGHT) . // bankType (7 characters with trailing zeros)
        str_pad($staff['accNo'], 16, ' ', STR_PAD_RIGHT) . // accNum (right-padded to 16 characters with spaces)
        str_pad(substr($staff['name'], 0, 40), 40) . // name (40 characters)
        str_pad($salaryInCents, 11, '0', STR_PAD_LEFT) . // Amount in cents (11 characters)
        str_pad($refNum, 18) . // refNum + staffid (30 characters, truncated if necessary)
        str_repeat(' ', 1) . 
        str_pad(substr($staff['staffid'], 0, 11), 11) . 
        str_pad(substr($staff['icNo'], 0, 12), 12) . // icNum (12 characters)
        str_repeat(' ', 8) . // 8 spaces after icNum
        str_pad('2' . substr($payDesc, 0, 19), 20) . // Default '2' and payDesc (20 characters total)
        PHP_EOL;

    // Write line 2 to file for each staff
    fwrite($file, $line2);
}


// Prepare data for line 3
$line3 =
    str_pad('03', 2) . // Default
    str_pad($totalStaff, 6, '0', STR_PAD_LEFT) . // Number of staff (6 characters)
    str_pad($totalSalary, 13, '0', STR_PAD_LEFT) . // Total salary in cents (11 characters)
    PHP_EOL;

// Write line 3 to file
fwrite($file, $line3);

// Close the file after writing all staff data
fclose($file);

// Read the contents of the generated file
$fileContents = file_get_contents($fileName);

// Insert the contents into the database
$query = "INSERT INTO bulkpay (date, file, fileName) VALUES (:date, :file, :fileName)";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':date', $formattedDate);  // Use the formatted date (ddmmyyyy)
$stmt->bindParam(':file', $fileContents, PDO::PARAM_LOB); // Using PDO::PARAM_LOB for BLOB data
$stmt->bindParam(':fileName', $fileName);

// Execute the insert statement
$stmt->execute();

// Redirect to displayFile.php after success
header("Location: displayFile.php");
exit;
