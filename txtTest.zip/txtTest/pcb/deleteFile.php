<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test-txt";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if fileName is provided in the URL
if (isset($_GET['fileName'])) {
    $fileName = $_GET['fileName'];

    // Prepare and execute the delete query
    $sql = "DELETE FROM pcbfile WHERE fileName = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $fileName);  // 's' means string type
    $stmt->execute();

    // Check if deletion was successful
    if ($stmt->affected_rows > 0) {
        // Success message
        echo "<script>
                alert('File deleted successfully!');
                window.location.href = 'displayFile.php';
              </script>";
    } else {
        // If no rows were affected (file not found)
        echo "<script>
                alert('File not found or could not be deleted.');
                window.location.href = 'displayFile.php';
              </script>";
    }

    // Close the statement
    $stmt->close();
} else {
    // If fileName is not set in URL
    echo "<script>
            alert('No file specified for deletion.');
            window.location.href = 'displayFile.php';
          </script>";
}

// Close the connection
$conn->close();
