<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test-txt";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve all records from the payments table (using fileName instead of id)
$sql =
"SELECT fileName, date, fileName FROM epffile ORDER BY id DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Files </title>
    <style>
        table {
            border-collapse: collapse;
            width: 100%;
            margin: 20px 0;
        }

        table th,
        table td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }

        table th {
            background-color: #f4f4f4;
        }
    </style>
</head>

<body>
    <h1>List of PCB Files</h1>

    <?php if ($result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>File Name</th>
                    <th>Delete</th> <!-- Added column for Delete -->
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                    <td>
                        <!-- File name as a link for downloading -->
                        <a href="downloadFile.php?fileName=<?= urlencode($row['fileName']) ?>">
                            <?= htmlspecialchars($row['fileName']) ?>
                        </a>
                    </td>
                    <td>
                        <!-- Delete link -->
                        <a href="deleteFile.php?fileName=<?= urlencode($row['fileName']) ?>"
                            onclick="return confirm('Are you sure you want to delete this file?')">
                            Delete
                        </a>
                    </td>
                    </tr>
                <?php endwhile; ?>

            </tbody>
        </table>
    <?php else: ?>
        <p>No files found.</p>
    <?php endif; ?>

    <?php $conn->close(); ?>
</body>

</html>