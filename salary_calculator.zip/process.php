<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Monthly Salary Calculation</title>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.5.8/angular.min.js"></script>
    <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro" rel="stylesheet" type="text/css">
    <style>
        body {
            font-family: 'Source Sans Pro', sans-serif;
        }

        h1 {
            text-align: center;
            font-size: 45px;
        }

        form {
            margin: 0 auto;
            width: 800px;
            padding: 1em;
            border: 1px solid #CCC;
            border-radius: 1em;
            font-size: 20px;
        }

        form div+div {
            margin-top: 1em;
        }

        label {
            display: inline-block;
            width: 200px;
            text-align: justify;
        }

        input:focus,
        textarea:focus {
            border-color: #000;
        }

        .input-box {
            width: 500px;
            height: 25px;
        }

        #submit-button {
            font-size: 15px;
            margin: 20px auto;
            /* Center the button */
            width: 500px;
            padding: 1em;
            border: 1px solid #CCC;
            border-radius: 3em;
            display: block;
            /* Ensures proper centering */
        }

        table,
        th,
        td {
            padding: 10px 15px;
            /* Improved padding for readability */
            border: 1px solid black;
            text-align: center;
            /* Center text in cells */
            word-wrap: break-word;
            /* Ensures that text breaks within the table cells */
        }

        thead tr {
            background-color: #e6ac00;
            color: #000;
            /* Black text for better contrast */
        }

        table {
            border-collapse: collapse;
        }

        .deleteButton {
            border: 2px solid red;
            margin: auto;
            border-radius: 1em;
        }

        #employee-data {
            width: 100%;
            /* Take full width of the page */
            max-width: 95%;
            /* Limit width to a comfortable size */
            margin: 20px auto;
            /* Center the container */
            overflow-x: auto;
            /* Allow horizontal scrolling if needed */
            padding: 10px;
            display: block;
        }

        #employeeTable {
            width: 100%;
            /* Stretch the table to fill the container */
            table-layout: auto;
            /* Ensure flexible column sizing */
            margin: auto;
            /* Center the table horizontally */
        }


        .group {
            margin-bottom: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .group label.group-title {
            font-weight: bold;
            display: block;
            margin-bottom: 10px;
        }

        .separator {
            font-weight: bold;
            font-size: 1.2em;
            margin: 20px 0 10px;
            padding: 10px 0;
            border-top: 2px solid #ccc;
            border-bottom: 2px solid #ccc;
            background-color: #f9f9f9;
            text-align: center;
        }

        /* Style the select dropdown */
        select {
            width: 100%;
            padding: 10px;
            font-size: 1rem;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #fff;
            appearance: none;
            /* Remove default browser styles */
            outline: none;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        /* Change background color on hover */
        select:hover {
            background-color: #f1f1f1;
        }

        /* Add focus effect */
        select:focus {
            border-color: #007BFF;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }
    </style>
    <script>
        var app = angular.module('basicApp', []);

        app.controller('BasicController', function($timeout) {
            var employee = this;
            employee.employeesList = [];
            employee.totalSalary = 0;
            employee.monthlySalary = 0;

            const eisRates = [{
                    max: 30,
                    eis: 0.05,
                    eisCon: 0.05
                },
                {
                    max: 50,
                    eis: 0.10,
                    eisCon: 0.10
                },
                {
                    max: 70,
                    eis: 0.15,
                    eisCon: 0.15
                },
                {
                    max: 100,
                    eis: 0.20,
                    eisCon: 0.20
                },
                {
                    max: 140,
                    eis: 0.25,
                    eisCon: 0.25
                },
                {
                    max: 200,
                    eis: 0.35,
                    eisCon: 0.35
                },
                {
                    max: 300,
                    eis: 0.50,
                    eisCon: 0.50
                },
                {
                    max: 400,
                    eis: 0.70,
                    eisCon: 0.70
                },
                {
                    max: 500,
                    eis: 0.90,
                    eisCon: 0.90
                },
                {
                    max: 600,
                    eis: 1.10,
                    eisCon: 1.10
                },
                {
                    max: 700,
                    eis: 1.30,
                    eisCon: 1.30
                },
                {
                    max: 800,
                    eis: 1.50,
                    eisCon: 1.50
                },
                {
                    max: 900,
                    eis: 1.70,
                    eisCon: 1.70
                },
                {
                    max: 1000,
                    eis: 1.90,
                    eisCon: 1.90
                },
                {
                    max: 1100,
                    eis: 2.10,
                    eisCon: 2.10
                },
                {
                    max: 1200,
                    eis: 2.30,
                    eisCon: 2.30
                },
                {
                    max: 1300,
                    eis: 2.50,
                    eisCon: 2.50
                },
                {
                    max: 1400,
                    eis: 2.70,
                    eisCon: 2.70
                },
                {
                    max: 1500,
                    eis: 2.90,
                    eisCon: 2.90
                },
                {
                    max: 1600,
                    eis: 3.10,
                    eisCon: 3.10
                },
                {
                    max: 1700,
                    eis: 3.30,
                    eisCon: 3.30
                },
                {
                    max: 1800,
                    eis: 3.50,
                    eisCon: 3.50
                },
                {
                    max: 1900,
                    eis: 3.70,
                    eisCon: 3.70
                },
                {
                    max: 2000,
                    eis: 3.90,
                    eisCon: 3.90
                },
                {
                    max: 2100,
                    eis: 4.10,
                    eisCon: 4.10
                },
                {
                    max: 2200,
                    eis: 4.30,
                    eisCon: 4.30
                },
                {
                    max: 2300,
                    eis: 4.50,
                    eisCon: 4.50
                },
                {
                    max: 2400,
                    eis: 4.70,
                    eisCon: 4.70
                },
                {
                    max: 2500,
                    eis: 4.90,
                    eisCon: 4.90
                },
                {
                    max: 2600,
                    eis: 5.10,
                    eisCon: 5.10
                },
                {
                    max: 2700,
                    eis: 5.30,
                    eisCon: 5.30
                },
                {
                    max: 2800,
                    eis: 5.50,
                    eisCon: 5.50
                },
                {
                    max: 2900,
                    eis: 5.70,
                    eisCon: 5.70
                },
                {
                    max: 3000,
                    eis: 5.90,
                    eisCon: 5.90
                },
                {
                    max: 3100,
                    eis: 6.10,
                    eisCon: 6.10
                },
                {
                    max: 3200,
                    eis: 6.30,
                    eisCon: 6.30
                },
                {
                    max: 3300,
                    eis: 6.50,
                    eisCon: 6.50
                },
                {
                    max: 3400,
                    eis: 6.70,
                    eisCon: 6.70
                },
                {
                    max: 3500,
                    eis: 6.90,
                    eisCon: 6.90
                },
                {
                    max: 3600,
                    eis: 7.10,
                    eisCon: 7.10
                },
                {
                    max: 3700,
                    eis: 7.30,
                    eisCon: 7.30
                },
                {
                    max: 3800,
                    eis: 7.50,
                    eisCon: 7.50
                },
                {
                    max: 3900,
                    eis: 7.70,
                    eisCon: 7.70
                },
                {
                    max: 4000,
                    eis: 7.90,
                    eisCon: 7.90
                },
                {
                    max: 4100,
                    eis: 8.10,
                    eisCon: 8.10
                },
                {
                    max: 4200,
                    eis: 8.30,
                    eisCon: 8.30
                },
                {
                    max: 4300,
                    eis: 8.50,
                    eisCon: 8.50
                },
                {
                    max: 4400,
                    eis: 8.70,
                    eisCon: 8.70
                },
                {
                    max: 4500,
                    eis: 8.90,
                    eisCon: 8.90
                },
                {
                    max: 4600,
                    eis: 9.10,
                    eisCon: 9.10
                },
                {
                    max: 4700,
                    eis: 9.30,
                    eisCon: 9.30
                },
                {
                    max: 4800,
                    eis: 9.50,
                    eisCon: 9.50
                },
                {
                    max: 4900,
                    eis: 9.70,
                    eisCon: 9.70
                },
                {
                    max: 5000,
                    eis: 9.90,
                    eisCon: 9.90
                },
                {
                    max: 5100,
                    eis: 10.10,
                    eisCon: 10.10
                },
                {
                    max: 5200,
                    eis: 10.30,
                    eisCon: 10.30
                },
                {
                    max: 5300,
                    eis: 10.50,
                    eisCon: 10.50
                },
                {
                    max: 5400,
                    eis: 10.70,
                    eisCon: 10.70
                },
                {
                    max: 5500,
                    eis: 10.90,
                    eisCon: 10.90
                },
                {
                    max: 5600,
                    eis: 11.10,
                    eisCon: 11.10
                },
                {
                    max: 5700,
                    eis: 11.30,
                    eisCon: 11.30
                },
                {
                    max: 5800,
                    eis: 11.50,
                    eisCon: 11.50
                },
                {
                    max: 5900,
                    eis: 11.70,
                    eisCon: 11.70
                },
                {
                    max: 6000,
                    eis: 11.90,
                    eisCon: 11.90
                },
                {
                    max: Infinity,
                    eis: 11.90,
                    eisCon: 11.90
                }
            ];


            const socsoRates = [{
                    max: 30,
                    socso: 0.1,
                    socsoCon: 0.4,
                },
                {
                    max: 50,
                    socso: 0.2,
                    socsoCon: 0.7
                },
                {
                    max: 70,
                    socso: 0.3,
                    socsoCon: 1.1
                },
                {
                    max: 100,
                    socso: 0.4,
                    socsoCon: 1.5,
                },
                {
                    max: 140,
                    socso: 0.6,
                    socsoCon: 2.1
                },
                {
                    max: 200,
                    socso: 0.85,
                    socsoCon: 2.95,
                },
                {
                    max: 300,
                    socso: 1.25,
                    socsoCon: 4.35,
                },
                {
                    max: 400,
                    socso: 1.75,
                    socsoCon: 6.15,
                },
                {
                    max: 500,
                    socso: 2.25,
                    socsoCon: 7.85,
                },
                {
                    max: 600,
                    socso: 2.75,
                    socsoCon: 9.65,
                },
                {
                    max: 700,
                    socso: 3.25,
                    socsoCon: 11.35,
                },
                {
                    max: 800,
                    socso: 3.75,
                    socsoCon: 13.15
                },
                {
                    max: 900,
                    socso: 4.25,
                    socsoCon: 14.85,
                },
                {
                    max: 1000,
                    socso: 4.75,
                    socsoCon: 16.65,
                },
                {
                    max: 1100,
                    socso: 5.25,
                    socsoCon: 18.35,
                },
                {
                    max: 1200,
                    socso: 5.75,
                    socsoCon: 20.15,
                },
                {
                    max: 1300,
                    socso: 6.25,
                    socsoCon: 21.85,
                },
                {
                    max: 1400,
                    socso: 6.75,
                    socsoCon: 23.65,
                },
                {
                    max: 1500,
                    socso: 7.25,
                    socsoCon: 25.35,
                },
                {
                    max: 1600,
                    socso: 7.75,
                    socsoCon: 27.15,
                },
                {
                    max: 1700,
                    socso: 8.25,
                    socsoCon: 28.85,
                },
                {
                    max: 1800,
                    socso: 8.75,
                    socsoCon: 30.65,
                },
                {
                    max: 1900,
                    socso: 9.25,
                    socsoCon: 32.35,
                },
                {
                    max: 2000,
                    socso: 9.75,
                    socsoCon: 34.15,
                },
                {
                    max: 2100,
                    socso: 10.25,
                    socsoCon: 35.85,
                },
                {
                    max: 2200,
                    socso: 10.75,
                    socsoCon: 37.65,
                },
                {
                    max: 2300,
                    socso: 11.25,
                    socsoCon: 39.35,
                },
                {
                    max: 2400,
                    socso: 11.75,
                    socsoCon: 41.15,
                },
                {
                    max: 2500,
                    socso: 12.25,
                    socsoCon: 42.85
                },
                {
                    max: 2600,
                    socso: 12.75,
                    socsoCon: 44.65
                },
                {
                    max: 2700,
                    socso: 13.25,
                    socsoCon: 46.35
                },
                {
                    max: 2800,
                    socso: 13.75,
                    socsoCon: 48.15
                },
                {
                    max: 2900,
                    socso: 14.25,
                    socsoCon: 49.85
                },
                {
                    max: 3000,
                    socso: 14.75,
                    socsoCon: 51.65
                },
                {
                    max: 3100,
                    socso: 15.25,
                    socsoCon: 53.35
                },
                {
                    max: 3200,
                    socso: 15.75,
                    socsoCon: 55.15
                },
                {
                    max: 3300,
                    socso: 16.25,
                    socsoCon: 56.85
                },
                {
                    max: 3400,
                    socso: 16.75,
                    socsoCon: 58.65
                },
                {
                    max: 3500,
                    socso: 17.25,
                    socsoCon: 60.35
                },
                {
                    max: 3600,
                    socso: 17.75,
                    socsoCon: 62.15
                },
                {
                    max: 3700,
                    socso: 18.25,
                    socsoCon: 63.85
                },
                {
                    max: 3800,
                    socso: 18.75,
                    socsoCon: 65.65
                },
                {
                    max: 3900,
                    socso: 19.25,
                    socsoCon: 67.35
                },
                {
                    max: 4000,
                    socso: 19.75,
                    socsoCon: 69.15
                },
                {
                    max: 4100,
                    socso: 20.25,
                    socsoCon: 70.85
                },
                {
                    max: 4200,
                    socso: 20.75,
                    socsoCon: 72.65
                },
                {
                    max: 4300,
                    socso: 21.25,
                    socsoCon: 74.35
                },
                {
                    max: 4400,
                    socso: 21.75,
                    socsoCon: 76.15
                },
                {
                    max: 4500,
                    socso: 22.25,
                    socsoCon: 77.85
                },
                {
                    max: 4600,
                    socso: 22.75,
                    socsoCon: 79.65
                },
                {
                    max: 4700,
                    socso: 23.25,
                    socsoCon: 81.35
                },
                {
                    max: 4800,
                    socso: 23.75,
                    socsoCon: 83.15
                },
                {
                    max: 4900,
                    socso: 24.25,
                    socsoCon: 84.85
                },
                {
                    max: 5000,
                    socso: 24.75,
                    socsoCon: 86.65
                },
                {
                    max: 5100,
                    socso: 25.25,
                    socsoCon: 88.35
                },
                {
                    max: 5200,
                    socso: 25.75,
                    socsoCon: 90.15
                },
                {
                    max: 5300,
                    socso: 26.25,
                    socsoCon: 91.85
                },
                {
                    max: 5400,
                    socso: 26.75,
                    socsoCon: 93.65
                },
                {
                    max: 5500,
                    socso: 27.25,
                    socsoCon: 95.35
                },
                {
                    max: 5600,
                    socso: 27.75,
                    socsoCon: 97.15
                },
                {
                    max: 5700,
                    socso: 28.25,
                    socsoCon: 98.85
                },
                {
                    max: 5800,
                    socso: 28.75,
                    socsoCon: 100.65
                },
                {
                    max: 5900,
                    socso: 29.25,
                    socsoCon: 102.35
                },
                {
                    max: Infinity,
                    socso: 29.75,
                    socsoCon: 104.15
                }

            ];


            const epfRates = [{
                    max: 10,
                    epf: 0,
                    epfCon: 0
                },
                {
                    max: 20,
                    epf: 3,
                    epfCon: 3
                },
                {
                    max: 40,
                    epf: 5,
                    epfCon: 6
                },
                {
                    max: 60,
                    epf: 7,
                    epfCon: 8
                },
                {
                    max: 80,
                    epf: 9,
                    epfCon: 11
                },
                {
                    max: 100,
                    epf: 11,
                    epfCon: 13
                },
                {
                    max: 120,
                    epf: 14,
                    epfCon: 16
                },
                {
                    max: 140,
                    epf: 18,
                    epfCon: 19
                },
                {
                    max: 160,
                    epf: 18,
                    epfCon: 21
                },
                {
                    max: 180,
                    epf: 20,
                    epfCon: 24
                },
                {
                    max: 200,
                    epf: 22,
                    epfCon: 26
                },
                {
                    max: 220,
                    epf: 25,
                    epfCon: 29
                },
                {
                    max: 240,
                    epf: 27,
                    epfCon: 32
                },
                {
                    max: 260,
                    epf: 29,
                    epfCon: 34
                },
                {
                    max: 280,
                    epf: 31,
                    epfCon: 37
                },
                {
                    max: 300,
                    epf: 33,
                    epfCon: 39
                },
                {
                    max: 320,
                    epf: 36,
                    epfCon: 42
                },
                {
                    max: 340,
                    epf: 38,
                    epfCon: 45
                },
                {
                    max: 360,
                    epf: 40,
                    epfCon: 47
                },
                {
                    max: 380,
                    epf: 42,
                    epfCon: 50
                },
                {
                    max: 400,
                    epf: 44,
                    epfCon: 52
                },
                {
                    max: 420,
                    epf: 47,
                    epfCon: 55
                },
                {
                    max: 440,
                    epf: 49,
                    epfCon: 58
                },
                {
                    max: 460,
                    epf: 51,
                    epfCon: 60
                },
                {
                    max: 480,
                    epf: 53,
                    epfCon: 63
                },
                {
                    max: 500,
                    epf: 55,
                    epfCon: 65
                },
                {
                    max: 520,
                    epf: 58,
                    epfCon: 68
                },
                {
                    max: 540,
                    epf: 60,
                    epfCon: 71
                },
                {
                    max: 560,
                    epf: 62,
                    epfCon: 73
                },
                {
                    max: 580,
                    epf: 64,
                    epfCon: 76
                },
                {
                    max: 600,
                    epf: 66,
                    epfCon: 78
                },
                {
                    max: 620,
                    epf: 69,
                    epfCon: 81
                },
                {
                    max: 640,
                    epf: 71,
                    epfCon: 84
                },
                {
                    max: 660,
                    epf: 73,
                    epfCon: 86
                },
                {
                    max: 680,
                    epf: 75,
                    epfCon: 89
                },
                {
                    max: 700,
                    epf: 77,
                    epfCon: 91
                },
                {
                    max: 720,
                    epf: 80,
                    epfCon: 94
                },
                {
                    max: 740,
                    epf: 82,
                    epfCon: 97
                },
                {
                    max: 760,
                    epf: 84,
                    epfCon: 99
                },
                {
                    max: 780,
                    epf: 86,
                    epfCon: 102
                },
                {
                    max: 800,
                    epf: 99,
                    epfCon: 104
                },
                {
                    max: 820,
                    epf: 91,
                    epfCon: 107
                },
                {
                    max: 840,
                    epf: 93,
                    epfCon: 110
                },
                {
                    max: 860,
                    epf: 95,
                    epfCon: 112
                },
                {
                    max: 880,
                    epf: 97,
                    epfCon: 115
                },
                {
                    max: 900,
                    epf: 99,
                    epfCon: 117
                },
                {
                    max: 920,
                    epf: 102,
                    epfCon: 120
                },
                {
                    max: 940,
                    epf: 104,
                    epfCon: 123
                },
                {
                    max: 960,
                    epf: 106,
                    epfCon: 125
                },
                {
                    max: 980,
                    epf: 108,
                    epfCon: 128
                },
                {
                    max: 1000,
                    epf: 110,
                    epfCon: 130
                },
                {
                    max: 1020,
                    epf: 113,
                    epfCon: 133
                },
                {
                    max: 1040,
                    epf: 115,
                    epfCon: 136
                },
                {
                    max: 1060,
                    epf: 117,
                    epfCon: 138
                },
                {
                    max: 1080,
                    epf: 119,
                    epfCon: 141
                },
                {
                    max: 1100,
                    epf: 121,
                    epfCon: 143
                },
                {
                    max: 1120,
                    epf: 124,
                    epfCon: 146
                },
                {
                    max: 1140,
                    epf: 126,
                    epfCon: 149
                },
                {
                    max: 1160,
                    epf: 128,
                    epfCon: 151
                },
                {
                    max: 1180,
                    epf: 130,
                    epfCon: 158
                },
                {
                    max: 1200,
                    epf: 132,
                    epfCon: 156
                },
                {
                    max: 1220,
                    epf: 135,
                    epfCon: 159
                },
                {
                    max: 1240,
                    epf: 137,
                    epfCon: 162
                },
                {
                    max: 1260,
                    epf: 139,
                    epfCon: 164
                },
                {
                    max: 1280,
                    epf: 141,
                    epfCon: 167
                },
                {
                    max: 1300,
                    epf: 143,
                    epfCon: 169
                },
                {
                    max: 1320,
                    epf: 146,
                    epfCon: 172
                },
                {
                    max: 1340,
                    epf: 148,
                    epfCon: 175
                },
                {
                    max: 1360,
                    epf: 150,
                    epfCon: 177
                },
                {
                    max: 1380,
                    epf: 152,
                    epfCon: 180
                },
                {
                    max: 1400,
                    epf: 154,
                    epfCon: 182
                },
                {
                    max: 1420,
                    epf: 157,
                    epfCon: 185
                },
                {
                    max: 1440,
                    epf: 159,
                    epfCon: 188
                },
                {
                    max: 1460,
                    epf: 161,
                    epfCon: 190
                },
                {
                    max: 1480,
                    epf: 163,
                    epfCon: 193
                },
                {
                    max: 1500,
                    epf: 165,
                    epfCon: 195
                },
                {
                    max: 1520,
                    epf: 168,
                    epfCon: 198
                },
                {
                    max: 1540,
                    epf: 170,
                    epfCon: 201
                },
                {
                    max: 1560,
                    epf: 172,
                    epfCon: 203
                },
                {
                    max: 1580,
                    epf: 174,
                    epfCon: 206
                },
                {
                    max: 1600,
                    epf: 176,
                    epfCon: 208
                },
                {
                    max: 1620,
                    epf: 179,
                    epfCon: 211
                },
                {
                    max: 1640,
                    epf: 181,
                    epfCon: 214
                },
                {
                    max: 1660,
                    epf: 183,
                    epfCon: 216
                },
                {
                    max: 1680,
                    epf: 185,
                    epfCon: 219
                },
                {
                    max: 1700.00,
                    epf: 187.00,
                    epfCon: 221.00
                },
                {
                    max: 1720.00,
                    epf: 190.00,
                    epfCon: 224.00
                },
                {
                    max: 1740.00,
                    epf: 192.00,
                    epfCon: 227.00
                },
                {
                    max: 1760.00,
                    epf: 194.00,
                    epfCon: 229.00
                },
                {
                    max: 1780.00,
                    epf: 196.00,
                    epfCon: 232.00
                },
                {
                    max: 1800.00,
                    epf: 198.00,
                    epfCon: 234.00
                },
                {
                    max: 1820.00,
                    epf: 201.00,
                    epfCon: 237.00
                },
                {
                    max: 1840.00,
                    epf: 203.00,
                    epfCon: 240.00
                },
                {
                    max: 1860.00,
                    epf: 205.00,
                    epfCon: 242.00
                },
                {
                    max: 1880.00,
                    epf: 207.00,
                    epfCon: 245.00
                },
                {
                    max: 1900.00,
                    epf: 209.00,
                    epfCon: 247.00
                },
                {
                    max: 1920.00,
                    epf: 212.00,
                    epfCon: 250.00
                },
                {
                    max: 1940.00,
                    epf: 214.00,
                    epfCon: 253.00
                },
                {
                    max: 1960.00,
                    epf: 216.00,
                    epfCon: 255.00
                },
                {
                    max: 1980.00,
                    epf: 218.00,
                    epfCon: 258.00
                },
                {
                    max: 2000.00,
                    epf: 220.00,
                    epfCon: 260.00
                },
                {
                    max: 2020.00,
                    epf: 223.00,
                    epfCon: 263.00
                },
                {
                    max: 2040.00,
                    epf: 225.00,
                    epfCon: 266.00
                },
                {
                    max: 2060.00,
                    epf: 227.00,
                    epfCon: 268.00
                },
                {
                    max: 2080.00,
                    epf: 229.00,
                    epfCon: 271.00
                },
                {
                    max: 2100.00,
                    epf: 231.00,
                    epfCon: 273.00
                },
                {
                    max: 2120.00,
                    epf: 234.00,
                    epfCon: 276.00
                },
                {
                    max: 2140.00,
                    epf: 236.00,
                    epfCon: 279.00
                },
                {
                    max: 2160.00,
                    epf: 238.00,
                    epfCon: 281.00
                },
                {
                    max: 2180.00,
                    epf: 240.00,
                    epfCon: 284.00
                },
                {
                    max: 2200.00,
                    epf: 242.00,
                    epfCon: 286.00
                },
                {
                    max: 2220.00,
                    epf: 245.00,
                    epfCon: 289.00
                },
                {
                    max: 2240.00,
                    epf: 247.00,
                    epfCon: 292.00
                },
                {
                    max: 2260.00,
                    epf: 249.00,
                    epfCon: 294.00
                },
                {
                    max: 2280.00,
                    epf: 251.00,
                    epfCon: 297.00
                },
                {
                    max: 2300.00,
                    epf: 253.00,
                    epfCon: 299.00
                },
                {
                    max: 2320.00,
                    epf: 256.00,
                    epfCon: 302.00
                },
                {
                    max: 2340.00,
                    epf: 258.00,
                    epfCon: 305.00
                },
                {
                    max: 2360.00,
                    epf: 260.00,
                    epfCon: 307.00
                },
                {
                    max: 2380.00,
                    epf: 262.00,
                    epfCon: 310.00
                },
                {
                    max: 2400.00,
                    epf: 264.00,
                    epfCon: 312.00
                },
                {
                    max: 2420.00,
                    epf: 267.00,
                    epfCon: 315.00
                },
                {
                    max: 2440.00,
                    epf: 269.00,
                    epfCon: 318.00
                },
                {
                    max: 2460.00,
                    epf: 271.00,
                    epfCon: 320.00
                },
                {
                    max: 2480.00,
                    epf: 273.00,
                    epfCon: 323.00
                },
                {
                    max: 2500.00,
                    epf: 275.00,
                    epfCon: 325.00
                },
                {
                    max: 2520.00,
                    epf: 278.00,
                    epfCon: 328.00
                },
                {
                    max: 2540.00,
                    epf: 280.00,
                    epfCon: 331.00
                },
                {
                    max: 2560.00,
                    epf: 282.00,
                    epfCon: 333.00
                },
                {
                    max: 2580.00,
                    epf: 284.00,
                    epfCon: 336.00
                },
                {
                    max: 2600.00,
                    epf: 286.00,
                    epfCon: 338.00
                },
                {
                    max: 2620.00,
                    epf: 289.00,
                    epfCon: 341.00
                },
                {
                    max: 2640.00,
                    epf: 291.00,
                    epfCon: 344.00
                },
                {
                    max: 2660.00,
                    epf: 293.00,
                    epfCon: 346.00
                },
                {
                    max: 2680.00,
                    epf: 295.00,
                    epfCon: 349.00
                },
                {
                    max: 2700.00,
                    epf: 297.00,
                    epfCon: 351.00
                },
                {
                    max: 2720.00,
                    epf: 300.00,
                    epfCon: 354.00
                },
                {
                    max: 2740.00,
                    epf: 302.00,
                    epfCon: 357.00
                },
                {
                    max: 2760.00,
                    epf: 304.00,
                    epfCon: 359.00
                },
                {
                    max: 2780.00,
                    epf: 306.00,
                    epfCon: 362.00
                },
                {
                    max: 2800.00,
                    epf: 308.00,
                    epfCon: 364.00
                },
                {
                    max: 2820.00,
                    epf: 311.00,
                    epfCon: 367.00
                },
                {
                    max: 2840.00,
                    epf: 313.00,
                    epfCon: 370.00
                },
                {
                    max: 2860.00,
                    epf: 315.00,
                    epfCon: 372.00
                },
                {
                    max: 2880.00,
                    epf: 317.00,
                    epfCon: 375.00
                },
                {
                    max: 2900.00,
                    epf: 319.00,
                    epfCon: 377.00
                },
                {
                    max: 2920.00,
                    epf: 322.00,
                    epfCon: 380.00
                },
                {
                    max: 2940.00,
                    epf: 324.00,
                    epfCon: 383.00
                },
                {
                    max: 2960.00,
                    epf: 326.00,
                    epfCon: 385.00
                },
                {
                    max: 2980.00,
                    epf: 328.00,
                    epfCon: 388.00
                },
                {
                    max: 3000.00,
                    epf: 330.00,
                    epfCon: 390.00
                },
                {
                    max: 3020.00,
                    epf: 333.00,
                    epfCon: 393.00
                },
                {
                    max: 3040.00,
                    epf: 335.00,
                    epfCon: 396.00
                },
                {
                    max: 3060.00,
                    epf: 337.00,
                    epfCon: 398.00
                },
                {
                    max: 3080.00,
                    epf: 339.00,
                    epfCon: 401.00
                },
                {
                    max: 3100.00,
                    epf: 341.00,
                    epfCon: 403.00
                },
                {
                    max: 3120.00,
                    epf: 344.00,
                    epfCon: 406.00
                },
                {
                    max: 3140.00,
                    epf: 346.00,
                    epfCon: 409.00
                },
                {
                    max: 3160.00,
                    epf: 348.00,
                    epfCon: 411.00
                },
                {
                    max: 3180.00,
                    epf: 350.00,
                    epfCon: 414.00
                },
                {
                    max: 3200.00,
                    epf: 352.00,
                    epfCon: 416.00
                },
                {
                    max: 3220.00,
                    epf: 355.00,
                    epfCon: 419.00
                },
                {
                    max: 3240.00,
                    epf: 357.00,
                    epfCon: 422.00
                },
                {
                    max: 3260.00,
                    epf: 359.00,
                    epfCon: 424.00
                },
                {
                    max: 3280.00,
                    epf: 361.00,
                    epfCon: 427.00
                },
                {
                    max: 3300.00,
                    epf: 363.00,
                    epfCon: 429.00
                },
                {
                    max: 3320.00,
                    epf: 366.00,
                    epfCon: 432.00
                },
                {
                    max: 3340.00,
                    epf: 368.00,
                    epfCon: 435.00
                },
                {
                    max: 3360.00,
                    epf: 370.00,
                    epfCon: 437.00
                },
                {
                    max: 3380.00,
                    epf: 372.00,
                    epfCon: 440.00
                },
                {
                    max: 3400.00,
                    epf: 374.00,
                    epfCon: 442.00
                },
                {
                    max: 3420.00,
                    epf: 377.00,
                    epfCon: 445.00
                },
                {
                    max: 3440.00,
                    epf: 379.00,
                    epfCon: 448.00
                },
                {
                    max: 3460.00,
                    epf: 381.00,
                    epfCon: 450.00
                },
                {
                    max: 3480.00,
                    epf: 383.00,
                    epfCon: 453.00
                },
                {
                    max: 3500.00,
                    epf: 385.00,
                    epfCon: 455.00
                },
                {
                    max: 3520.00,
                    epf: 388.00,
                    epfCon: 458.00
                },
                {
                    max: 3540.00,
                    epf: 390.00,
                    epfCon: 461.00
                },
                {
                    max: 3560.00,
                    epf: 392.00,
                    epfCon: 463.00
                },
                {
                    max: 3580.00,
                    epf: 394.00,
                    epfCon: 466.00
                },
                {
                    max: 3600.00,
                    epf: 396.00,
                    epfCon: 468.00
                },
                {
                    max: 3620.00,
                    epf: 399.00,
                    epfCon: 471.00
                },
                {
                    max: 3640.00,
                    epf: 401.00,
                    epfCon: 474.00
                },
                {
                    max: 3660.00,
                    epf: 403.00,
                    epfCon: 476.00
                },
                {
                    max: 3680.00,
                    epf: 405.00,
                    epfCon: 479.00
                },
                {
                    max: 3700.00,
                    epf: 407.00,
                    epfCon: 481.00
                },
                {
                    max: 3720.00,
                    epf: 410.00,
                    epfCon: 484.00
                },
                {
                    max: 3740.00,
                    epf: 412.00,
                    epfCon: 487.00
                },
                {
                    max: 3760.00,
                    epf: 414.00,
                    epfCon: 489.00
                },
                {
                    max: 3780.00,
                    epf: 416.00,
                    epfCon: 492.00
                },
                {
                    max: 3800.00,
                    epf: 418.00,
                    epfCon: 494.00
                },
                {
                    max: 3820.00,
                    epf: 421.00,
                    epfCon: 497.00
                },
                {
                    max: 3840.00,
                    epf: 423.00,
                    epfCon: 500.00
                },
                {
                    max: 3860.00,
                    epf: 425.00,
                    epfCon: 502.00
                },
                {
                    max: 3880.00,
                    epf: 427.00,
                    epfCon: 505.00
                },
                {
                    max: 3900.00,
                    epf: 429.00,
                    epfCon: 507.00
                },
                {
                    max: 3920.00,
                    epf: 432.00,
                    epfCon: 510.00
                },
                {
                    max: 3940.00,
                    epf: 434.00,
                    epfCon: 513.00
                },
                {
                    max: 3960.00,
                    epf: 436.00,
                    epfCon: 515.00
                },
                {
                    max: 3980.00,
                    epf: 438.00,
                    epfCon: 518.00
                },
                {
                    max: 4000.00,
                    epf: 440.00,
                    epfCon: 520.00
                },
                {
                    max: 4020.00,
                    epf: 443.00,
                    epfCon: 523.00
                },
                {
                    max: 4040.00,
                    epf: 445.00,
                    epfCon: 526.00
                },
                {
                    max: 4060.00,
                    epf: 447.00,
                    epfCon: 528.00
                },
                {
                    max: 4080.00,
                    epf: 449.00,
                    epfCon: 531.00
                },
                {
                    max: 4100.00,
                    epf: 451.00,
                    epfCon: 533.00
                },
                {
                    max: 4120.00,
                    epf: 454.00,
                    epfCon: 536.00
                },
                {
                    max: 4140.00,
                    epf: 456.00,
                    epfCon: 539.00
                },
                {
                    max: 4160.00,
                    epf: 458.00,
                    epfCon: 541.00
                },
                {
                    max: 4180.00,
                    epf: 460.00,
                    epfCon: 544.00
                },
                {
                    max: 4200.00,
                    epf: 462.00,
                    epfCon: 546.00
                },
                {
                    max: 4220.00,
                    epf: 465.00,
                    epfCon: 549.00
                },
                {
                    max: 4240.00,
                    epf: 467.00,
                    epfCon: 552.00
                },
                {
                    max: 4260.00,
                    epf: 469.00,
                    epfCon: 554.00
                },
                {
                    max: 4280.00,
                    epf: 471.00,
                    epfCon: 557.00
                },
                {
                    max: 4300.00,
                    epf: 473.00,
                    epfCon: 559.00
                },
                {
                    max: 4320.00,
                    epf: 476.00,
                    epfCon: 562.00
                },
                {
                    max: 4340.00,
                    epf: 478.00,
                    epfCon: 565.00
                },
                {
                    max: 4360.00,
                    epf: 480.00,
                    epfCon: 567.00
                },
                {
                    max: 4380.00,
                    epf: 482.00,
                    epfCon: 570.00
                },
                {
                    max: 4400.00,
                    epf: 484.00,
                    epfCon: 572.00
                },
                {
                    max: 4420.00,
                    epf: 487.00,
                    epfCon: 575.00
                },
                {
                    max: 4440.00,
                    epf: 489.00,
                    epfCon: 578.00
                },
                {
                    max: 4460.00,
                    epf: 491.00,
                    epfCon: 580.00
                },
                {
                    max: 4480.00,
                    epf: 493.00,
                    epfCon: 583.00
                },
                {
                    max: 4500.00,
                    epf: 495.00,
                    epfCon: 585.00
                },
                {
                    max: 4520.00,
                    epf: 498.00,
                    epfCon: 588.00
                },
                {
                    max: 4540.00,
                    epf: 500.00,
                    epfCon: 591.00
                },
                {
                    max: 4560.00,
                    epf: 502.00,
                    epfCon: 593.00
                },
                {
                    max: 4580.00,
                    epf: 504.00,
                    epfCon: 596.00
                },
                {
                    max: 4600.00,
                    epf: 506.00,
                    epfCon: 598.00
                },
                {
                    max: 4620.00,
                    epf: 509.00,
                    epfCon: 601.00
                },
                {
                    max: 4640.00,
                    epf: 511.00,
                    epfCon: 604.00
                },
                {
                    max: 4660.00,
                    epf: 513.00,
                    epfCon: 606.00
                },
                {
                    max: 4680.00,
                    epf: 515.00,
                    epfCon: 609.00
                },
                {
                    max: 4700.00,
                    epf: 517.00,
                    epfCon: 611.00
                },
                {
                    max: 4720.00,
                    epf: 520.00,
                    epfCon: 614.00
                },
                {
                    max: 4740.00,
                    epf: 522.00,
                    epfCon: 617.00
                },
                {
                    max: 4760.00,
                    epf: 524.00,
                    epfCon: 619.00
                },
                {
                    max: 4780.00,
                    epf: 526.00,
                    epfCon: 622.00
                },
                {
                    max: 4800.00,
                    epf: 528.00,
                    epfCon: 624.00
                },
                {
                    max: 4820.00,
                    epf: 531.00,
                    epfCon: 627.00
                },
                {
                    max: 4840.00,
                    epf: 533.00,
                    epfCon: 630.00
                },
                {
                    max: 4860.00,
                    epf: 535.00,
                    epfCon: 632.00
                },
                {
                    max: 4880.00,
                    epf: 537.00,
                    epfCon: 635.00
                },
                {
                    max: 4900.00,
                    epf: 539.00,
                    epfCon: 637.00
                },
                {
                    max: 4920.00,
                    epf: 542.00,
                    epfCon: 640.00
                },
                {
                    max: 4940.00,
                    epf: 544.00,
                    epfCon: 643.00
                },
                {
                    max: 4960.00,
                    epf: 546.00,
                    epfCon: 645.00
                },
                {
                    max: 4980.00,
                    epf: 548.00,
                    epfCon: 648.00
                },
                {
                    max: 5000.00,
                    epf: 550.00,
                    epfCon: 650.00
                },
                {
                    max: 5100.00,
                    epf: 561.00,
                    epfCon: 612.00
                },
                {
                    max: 5200.00,
                    epf: 572.00,
                    epfCon: 624.00
                },
                {
                    max: 5300.00,
                    epf: 583.00,
                    epfCon: 636.00
                },
                {
                    max: 5400.00,
                    epf: 594.00,
                    epfCon: 648.00
                },
                {
                    max: 5500.00,
                    epf: 605.00,
                    epfCon: 660.00
                },
                {
                    max: 5600.00,
                    epf: 616.00,
                    epfCon: 672.00
                },
                {
                    max: 5700.00,
                    epf: 627.00,
                    epfCon: 684.00
                },
                {
                    max: 5800.00,
                    epf: 638.00,
                    epfCon: 696.00
                },
                {
                    max: 5900.00,
                    epf: 649.00,
                    epfCon: 708.00
                },
                {
                    max: 6000.00,
                    epf: 660.00,
                    epfCon: 720.00
                },
                {
                    max: 6100.00,
                    epf: 671.00,
                    epfCon: 732.00
                },
                {
                    max: 6200.00,
                    epf: 682.00,
                    epfCon: 744.00
                },
                {
                    max: 6300.00,
                    epf: 693.00,
                    epfCon: 756.00
                },
                {
                    max: 6400.00,
                    epf: 704.00,
                    epfCon: 768.00
                },
                {
                    max: 6500.00,
                    epf: 715.00,
                    epfCon: 780.00
                },
                {
                    max: 6600.00,
                    epf: 726.00,
                    epfCon: 792.00
                },
                {
                    max: 6700.00,
                    epf: 737.00,
                    epfCon: 804.00
                },
                {
                    max: 6800.00,
                    epf: 748.00,
                    epfCon: 816.00
                },
                {
                    max: 6900.00,
                    epf: 759.00,
                    epfCon: 828.00
                },
                {
                    max: 7000.00,
                    epf: 770.00,
                    epfCon: 840.00
                },
                {
                    max: 7100.00,
                    epf: 781.00,
                    epfCon: 852.00
                },
                {
                    max: 7200.00,
                    epf: 792.00,
                    epfCon: 864.00
                },
                {
                    max: 7300.00,
                    epf: 803.00,
                    epfCon: 876.00
                },
                {
                    max: 7400.00,
                    epf: 814.00,
                    epfCon: 888.00
                },
                {
                    max: 7500.00,
                    epf: 825.00,
                    epfCon: 900.00
                },
                {
                    max: 7600.00,
                    epf: 836.00,
                    epfCon: 912.00
                },
                {
                    max: 7700.00,
                    epf: 847.00,
                    epfCon: 924.00
                },
                {
                    max: 7800.00,
                    epf: 858.00,
                    epfCon: 936.00
                },
                {
                    max: 7900.00,
                    epf: 869.00,
                    epfCon: 948.00
                },
                {
                    max: 8000.00,
                    epf: 880.00,
                    epfCon: 960.00
                },
                {
                    max: 8100.00,
                    epf: 902.00,
                    epfCon: 984.00
                },
                {
                    max: 8200.00,
                    epf: 913.00,
                    epfCon: 996.00
                },
                {
                    max: 8300.00,
                    epf: 924.00,
                    epfCon: 1008.00
                },
                {
                    max: 8400.00,
                    epf: 935.00,
                    epfCon: 1020.00
                },
                {
                    max: 8500.00,
                    epf: 946.00,
                    epfCon: 1032.00
                },
                {
                    max: 8600.00,
                    epf: 957.00,
                    epfCon: 1044.00
                },
                {
                    max: 8700.00,
                    epf: 968.00,
                    epfCon: 1056.00
                },
                {
                    max: 8800.00,
                    epf: 979.00,
                    epfCon: 1068.00
                },
                {
                    max: 8900.00,
                    epf: 990.00,
                    epfCon: 1080.00
                },
                {
                    max: 9000.00,
                    epf: 1001.00,
                    epfCon: 1092.00
                },
                {
                    max: 9100.00,
                    epf: 1012.00,
                    epfCon: 1104.00
                },
                {
                    max: 9200.00,
                    epf: 1023.00,
                    epfCon: 1116.00
                },
                {
                    max: 9300.00,
                    epf: 1034.00,
                    epfCon: 1128.00
                },
                {
                    max: 9400.00,
                    epf: 1045.00,
                    epfCon: 1140.00
                },
                {
                    max: 9500.00,
                    epf: 1056.00,
                    epfCon: 1152.00
                },
                {
                    max: 9600.00,
                    epf: 1067.00,
                    epfCon: 1164.00
                },
                {
                    max: 9700.00,
                    epf: 1078.00,
                    epfCon: 1176.00
                },
                {
                    max: 9800.00,
                    epf: 1089.00,
                    epfCon: 1188.00
                },
                {
                    max: 9900.00,
                    epf: 1100.00,
                    epfCon: 1200.00
                },
                {
                    max: 10000.00,
                    epf: 1111.00,
                    epfCon: 1212.00
                },
                {
                    max: 10100.00,
                    epf: 1122.00,
                    epfCon: 1224.00
                },
                {
                    max: 10200.00,
                    epf: 1133.00,
                    epfCon: 1236.00
                },
                {
                    max: 10300.00,
                    epf: 1144.00,
                    epfCon: 1248.00
                },
                {
                    max: 10400.00,
                    epf: 1155.00,
                    epfCon: 1260.00
                },
                {
                    max: 10500.00,
                    epf: 1166.00,
                    epfCon: 1272.00
                },
                {
                    max: 10600.00,
                    epf: 1177.00,
                    epfCon: 1284.00
                },
                {
                    max: 10700.00,
                    epf: 1188.00,
                    epfCon: 1296.00
                },
                {
                    max: 10800.00,
                    epf: 1199.00,
                    epfCon: 1308.00
                },
                {
                    max: 10900.00,
                    epf: 1210.00,
                    epfCon: 1320.00
                },
                {
                    max: 11000.00,
                    epf: 1221.00,
                    epfCon: 1332.00
                },
                {
                    max: 11100.00,
                    epf: 1232.00,
                    epfCon: 1344.00
                },
                {
                    max: 11200.00,
                    epf: 1243.00,
                    epfCon: 1356.00
                },
                {
                    max: 11300.00,
                    epf: 1254.00,
                    epfCon: 1368.00
                },
                {
                    max: 11400.00,
                    epf: 1265.00,
                    epfCon: 1380.00
                },
                {
                    max: 11500.00,
                    epf: 1276.00,
                    epfCon: 1392.00
                },
                {
                    max: 11600.00,
                    epf: 1287.00,
                    epfCon: 1404.00
                },
                {
                    max: 11700.00,
                    epf: 1298.00,
                    epfCon: 1416.00
                },
                {
                    max: 11800.00,
                    epf: 1309.00,
                    epfCon: 1428.00
                },
                {
                    max: 11900.00,
                    epf: 1320.00,
                    epfCon: 1440.00
                },
                {
                    max: 12000.00,
                    epf: 1331.00,
                    epfCon: 1452.00
                },
                {
                    max: 12100.00,
                    epf: 1342.00,
                    epfCon: 1464.00
                },
                {
                    max: 12200.00,
                    epf: 1353.00,
                    epfCon: 1476.00
                },
                {
                    max: 12300.00,
                    epf: 1364.00,
                    epfCon: 1488.00
                },
                {
                    max: 12400.00,
                    epf: 1375.00,
                    epfCon: 1500.00
                },
                {
                    max: 12500.00,
                    epf: 1386.00,
                    epfCon: 1512.00
                },
                {
                    max: 12600.00,
                    epf: 1397.00,
                    epfCon: 1524.00
                },
                {
                    max: 12700.00,
                    epf: 1408.00,
                    epfCon: 1536.00
                },
                {
                    max: 12800.00,
                    epf: 1419.00,
                    epfCon: 1548.00
                },
                {
                    max: 12900.00,
                    epf: 1430.00,
                    epfCon: 1560.0
                },
                {
                    max: 13000.00,
                    epf: 1441.00,
                    epfCon: 1572.00
                },
                {
                    max: 13100.00,
                    epf: 1452.00,
                    epfCon: 1584.00
                },
                {
                    max: 13200.00,
                    epf: 1463.00,
                    epfCon: 1596.00
                },
                {
                    max: 13300.00,
                    epf: 1474.00,
                    epfCon: 1608.00
                },
                {
                    max: 13400.00,
                    epf: 1485.00,
                    epfCon: 1620.00
                },
                {
                    max: 13500.00,
                    epf: 1496.00,
                    epfCon: 1632.00
                },
                {
                    max: 13600.00,
                    epf: 1507.00,
                    epfCon: 1644.00
                },
                {
                    max: 13700.00,
                    epf: 1518.00,
                    epfCon: 1656.00
                },
                {
                    max: 13800.00,
                    epf: 1529.00,
                    epfCon: 1668.00
                },
                {
                    max: 13900.00,
                    epf: 1540.00,
                    epfCon: 1680.00
                },
                {
                    max: 14000.00,
                    epf: 1551.00,
                    epfCon: 1692.00
                },
                {
                    max: 14100.00,
                    epf: 1562.00,
                    epfCon: 1704.00
                },
                {
                    max: 14200.00,
                    epf: 1573.00,
                    epfCon: 1716.00
                },
                {
                    max: 14300.00,
                    epf: 1584.00,
                    epfCon: 1728.00
                },
                {
                    max: 14400.00,
                    epf: 1595.00,
                    epfCon: 1740.00
                },
                {
                    max: 14500.00,
                    epf: 1606.00,
                    epfCon: 1752.00
                },
                {
                    max: 14600.00,
                    epf: 1617.00,
                    epfCon: 1764.00
                },
                {
                    max: 14700.00,
                    epf: 1628.00,
                    epfCon: 1776.00
                },
                {
                    max: 14800.00,
                    epf: 1639.00,
                    epfCon: 1788.00
                },
                {
                    max: 14900.00,
                    epf: 1650.00,
                    epfCon: 1800.00
                },
                {
                    max: 15000.00,
                    epf: 1661.00,
                    epfCon: 1812.00
                },
                {
                    max: 15100.00,
                    epf: 1672.00,
                    epfCon: 1824.00
                },
                {
                    max: 15200.00,
                    epf: 1683.00,
                    epfCon: 1836.00
                },
                {
                    max: 15300.00,
                    epf: 1694.00,
                    epfCon: 1848.00
                },
                {
                    max: 15400.00,
                    epf: 1705.00,
                    epfCon: 1860.00
                },
                {
                    max: 15500.00,
                    epf: 1716.00,
                    epfCon: 1872.00
                },
                {
                    max: 15600.00,
                    epf: 1727.00,
                    epfCon: 1884.00
                },
                {
                    max: 15700.00,
                    epf: 1738.00,
                    epfCon: 1896.00
                },
                {
                    max: 15800.00,
                    epf: 1749.00,
                    epfCon: 1908.00
                },
                {
                    max: 15900.00,
                    epf: 1760.00,
                    epfCon: 1920.00
                },
                {
                    max: 16000.00,
                    epf: 1771.00,
                    epfCon: 1932.00
                },
                {
                    max: 16100.00,
                    epf: 1782.00,
                    epfCon: 1944.00
                },
                {
                    max: 16200.00,
                    epf: 1793.00,
                    epfCon: 1956.00
                },
                {
                    max: 16300.00,
                    epf: 1804.00,
                    epfCon: 1968.00
                },
                {
                    max: 16400.00,
                    epf: 1815.00,
                    epfCon: 1980.00
                },
                {
                    max: 16500.00,
                    epf: 1826.00,
                    epfCon: 1992.00
                },
                {
                    max: 16600.00,
                    epf: 1837.00,
                    epfCon: 2004.00
                },
                {
                    max: 16700.00,
                    epf: 1848.00,
                    epfCon: 2016.00
                },
                {
                    max: 16800.00,
                    epf: 1859.00,
                    epfCon: 2028.00
                },
                {
                    max: 16900.00,
                    epf: 1870.00,
                    epfCon: 2040.00
                },
                {
                    max: 17000.00,
                    epf: 1881.00,
                    epfCon: 2052.00
                },
                {
                    max: 17100.00,
                    epf: 1892.00,
                    epfCon: 2064.00
                },
                {
                    max: 17200.00,
                    epf: 1903.00,
                    epfCon: 2076.00
                },
                {
                    max: 17300.00,
                    epf: 1914.00,
                    epfCon: 2088.00
                },
                {
                    max: 17400.00,
                    epf: 1925.00,
                    epfCon: 2100.00
                },
                {
                    max: 17500.00,
                    epf: 1936.00,
                    epfCon: 2112.00
                },
                {
                    max: 17600.00,
                    epf: 1947.00,
                    epfCon: 2124.00
                },
                {
                    max: 17700.00,
                    epf: 1958.00,
                    epfCon: 2136.00
                },
                {
                    max: 17800.00,
                    epf: 1969.00,
                    epfCon: 2148.00
                },
                {
                    max: 17900.00,
                    epf: 1980.00,
                    epfCon: 2160.00
                },
                {
                    max: 18000.00,
                    epf: 1991.00,
                    epfCon: 2172.00
                },
                {
                    max: 18100.00,
                    epf: 2002.00,
                    epfCon: 2184.00
                },
                {
                    max: 18200.00,
                    epf: 2013.00,
                    epfCon: 2196.00
                },
                {
                    max: 18300.00,
                    epf: 2024.00,
                    epfCon: 2208.00
                },
                {
                    max: 18400.00,
                    epf: 2035.00,
                    epfCon: 2220.00
                },
                {
                    max: 18500.00,
                    epf: 2046.00,
                    epfCon: 2232.00
                },
                {
                    max: 18600.00,
                    epf: 2057.00,
                    epfCon: 2244.00
                },
                {
                    max: 18700.00,
                    epf: 2068.00,
                    epfCon: 2256.00
                },
                {
                    max: 18800.00,
                    epf: 2079.00,
                    epfCon: 2268.00
                },
                {
                    max: 18900.00,
                    epf: 2090.00,
                    epfCon: 2280.00
                },
                {
                    max: 19000.00,
                    epf: 2101.00,
                    epfCon: 2292.00
                },
                {
                    max: 19100.00,
                    epf: 2112.00,
                    epfCon: 2304.00
                },
                {
                    max: 19200.00,
                    epf: 2123.00,
                    epfCon: 2316.00
                },
                {
                    max: 19300.00,
                    epf: 2134.00,
                    epfCon: 2328.00
                },
                {
                    max: 19400.00,
                    epf: 2145.00,
                    epfCon: 2340.00
                },
                {
                    max: 19500.00,
                    epf: 2156.00,
                    epfCon: 2352.00
                },
                {
                    max: 19600.00,
                    epf: 2167.00,
                    epfCon: 2364.00
                },
                {
                    max: 19700.00,
                    epf: 2178.00,
                    epfCon: 2376.00
                },
                {
                    max: 19800.00,
                    epf: 2189.00,
                    epfCon: 2388.00
                },
                {
                    max: 19900.00,
                    epf: 2200.00,
                    epfCon: 2400.00
                },
                {
                    max: 20000.00,
                    epf: 2200.00,
                    epfCon: 2400.00
                },
                {
                    max: Infinity,
                    epf: function(basicSalary, bonus, allowance, arrears) {
                        // Add bonus and allowance to the basicSalary before calculating EPF
                        const totalIncome = basicSalary + bonus + allowance + arrears;

                        // Calculate EPF contribution (employee rate 11% if above RM20,000)
                        if (totalIncome > 20000) {
                            const epfValue = totalIncome * 0.11; // Employee contribution rate of 11%
                            return Math.ceil(epfValue); // Round up to the next whole dollar
                        }
                        return 0; // Return 0 for totalIncome below RM20,000
                    },
                    epfCon: function(basicSalary, bonus, allowance, arrears) {
                        // Add bonus and allowance to the basicSalary before calculating EPF contribution
                        const totalIncome = basicSalary + bonus + allowance + arrears;

                        // Calculate EPF contribution (employer rate 12% if above RM20,000)
                        if (totalIncome > 20000) {
                            const epfConValue = totalIncome * 0.12; // Employer contribution rate of 12%
                            return Math.ceil(epfConValue); // Round up to the next whole dollar
                        }
                        return 0; // Return 0 for totalIncome below RM20,000
                    }
                }

            ];

            // Months and n calculation
            employee.months = [{
                    number: 0,
                    display: "December"
                },
                {
                    number: 1,
                    display: "November"
                },
                {
                    number: 2,
                    display: "October"
                },
                {
                    number: 3,
                    display: "September"
                },
                {
                    number: 4,
                    display: "August"
                },
                {
                    number: 5,
                    display: "July"
                },
                {
                    number: 6,
                    display: "June"
                },
                {
                    number: 7,
                    display: "May"
                },
                {
                    number: 8,
                    display: "April"
                },
                {
                    number: 9,
                    display: "March"
                },
                {
                    number: 10,
                    display: "February"
                },
                {
                    number: 11,
                    display: "January"
                }
            ];

            employee.updateMonth = function(selectedMonth) {
                employee.list.n = selectedMonth; // Use n directly
            };

            employee.maritalStatuses = [{
                    status: 'Single',
                    relief: 0,
                    category: 'B1'
                },
                {
                    status: 'Spouse Not Working',
                    relief: 4000,
                    category: 'B2'
                },
                {
                    status: 'Spouse Working',
                    relief: 4000,
                    category: 'B3'
                },
            ];

            employee.list = {
                maritalStatus: employee.maritalStatuses[0] // Default marital status
            };

            employee.updateDisabledValue = function(isDisabled) {
                if (isDisabled) {
                    employee.list.disabledValue = 6000; // Set value to 6000 if Yes is selected
                } else {
                    employee.list.disabledValue = 0; // Set value to 0 if No is selected
                }
            };

            employee.updateDisabledHusbandWife = function(isDisabled) {
                if (isDisabled) {
                    employee.list.disabledHusbandWifeValue = 5000; // Set value to 5000 if Yes is selected
                } else {
                    employee.list.disabledHusbandWifeValue = 0; // Set value to 0 if No is selected
                }
            };

            function calculateAnnualTax(p, maritalCategory) {
                // Tax table
                const taxTable = [{
                        max: 20000,
                        M: 5000,
                        R: 0.01,
                        B1_B3: -400,
                        B2: -800
                    },
                    {
                        max: 35000,
                        M: 20000,
                        R: 0.03,
                        B1_B3: -250,
                        B2: -650
                    },
                    {
                        max: 50000,
                        M: 35000,
                        R: 0.06,
                        B1_B3: 600,
                        B2: 600
                    },
                    {
                        max: 70000,
                        M: 50000,
                        R: 0.11,
                        B1_B3: 1500,
                        B2: 1500
                    },
                    {
                        max: 100000,
                        M: 70000,
                        R: 0.19,
                        B1_B3: 3700,
                        B2: 3700
                    },
                    {
                        max: 400000,
                        M: 100000,
                        R: 0.25,
                        B1_B3: 9400,
                        B2: 9400
                    },
                    {
                        max: 600000,
                        M: 400000,
                        R: 0.26,
                        B1_B3: 84400,
                        B2: 84400
                    },
                    {
                        max: 2000000,
                        M: 600000,
                        R: 0.28,
                        B1_B3: 136400,
                        B2: 136400
                    },
                    {
                        max: Infinity,
                        M: 2000000,
                        R: 0.30,
                        B1_B3: 528400,
                        B2: 528400
                    },
                ];

                let tax = 0;

                // Loop through the tax table
                for (let band of taxTable) {
                    if (p <= band.max) {
                        const M = band.M; // Minimum range
                        const R = band.R; // Rate
                        const B = maritalCategory === "B2" ? band.B2 : band.B1_B3; // Choose B based on maritalCategory

                        // Formula: [(P - M) * R + B] - X
                        tax = (p - M) * R + B;
                        tax = Math.max(0, tax); // Ensure tax is not negative
                        break; // Exit loop when band is found
                    }
                }

                return tax.toFixed(2);
            }




            employee.createList = function() {
                const basicSalary = parseFloat(employee.list.basicSalary) || 0;
                const arrears = parseFloat(employee.list.arrears) || 0;
                const bonus = parseFloat(employee.list.bonus) || 0;
                const allowance = parseFloat(employee.list.allowance) || 0;
                const deduction = parseFloat(employee.list.deduction) || 0;
                const otNormal = parseFloat(employee.list.otNormal) || 0;
                const otOffday = parseFloat(employee.list.otOffday) || 0;
                const otPublic = parseFloat(employee.list.otPublic) || 0;
                const n = parseFloat(employee.list.n) || 0;
                const disabledValue = parseFloat(employee.list.disabledValue) || 0;
                const unChild = (parseFloat(employee.list.unChild) || 0) * 2000;
                const ftChild = (parseFloat(employee.list.ftChild) || 0) * 2000;
                const dipChild = (parseFloat(employee.list.dipChild) || 0) * 8000;
                const degChild = (parseFloat(employee.list.degChild) || 0) * 8000;
                const disChild = (parseFloat(employee.list.disChild) || 0) * 6000;
                const dis2Child = (parseFloat(employee.list.dis2Child) || 0) * 14000;
                const maritalRelief = parseFloat(employee.list.maritalStatus?.relief) || 0;
                const maritalCategory = parseFloat(employee.list.maritalStatus?.category) || 0;
                const disabledHusbandWifeValue = parseFloat(employee.list.disabledHusbandWifeValue) || 0;
                const accumulatedRemuneration = parseFloat(employee.list.accumulatedRemuneration) || 0;
                const accumulatedEpf = parseFloat(employee.list.accumulatedEpf) || 0;
                const accumulatedPcb = parseFloat(employee.list.accumulatedPcb) || 0;
                const accumulatedEis = parseFloat(employee.list.accumulatedEis) || 0;
                const accumulatedSocso = parseFloat(employee.list.accumulatedSocso) || 0;

                // Calculate overtime rates and payments
                const {
                    otNormalRate,
                    otOffdayRate,
                    otPublicRate
                } = calculateOvertime(basicSalary);
                const normalPay = parseFloat((otNormal * otNormalRate).toFixed(2));
                const offdayPay = parseFloat((otOffday * otOffdayRate).toFixed(2));
                const publicPay = parseFloat((otPublic * otPublicRate).toFixed(2));

                // Get EPF and SOCSO values
                const {
                    epf,
                    epfCon
                } = getEpf(basicSalary, bonus, allowance, arrears);
                const {
                    socso,
                    socsoCon
                } = getSocso(basicSalary, normalPay, offdayPay, publicPay, allowance, arrears);
                const {
                    eis,
                    eisCon
                } = getEis(basicSalary, normalPay, offdayPay, publicPay, allowance, arrears);

                // Other deductions
                const hrdc = parseFloat(((basicSalary + allowance) * 0.01).toFixed(2));

                // Total income
                const totalIncome = parseFloat((
                    (basicSalary + arrears + bonus + allowance + normalPay + publicPay + offdayPay) - deduction
                ).toFixed(2));

                const remEpf = parseFloat((4000 - accumulatedEpf).toFixed(2));
                const balEpf = parseFloat((remEpf / (n + 1)).toFixed(2));

                const p = Math.max(0, parseFloat((
                    (accumulatedRemuneration - accumulatedEpf) +
                    ((basicSalary+normalPay+offdayPay+publicPay+allowance+bonus) - balEpf) +
                    ((basicSalary * n) - remEpf) -
                    (9000 + disabledValue +
                        disabledHusbandWifeValue +
                        maritalRelief +
                        unChild + ftChild + dipChild + degChild + disChild + dis2Child +
                        (accumulatedEis + accumulatedSocso))
                ).toFixed(2)));


                const annualTax = calculateAnnualTax(p, maritalCategory);
                const pc = parseFloat(annualTax) - accumulatedPcb;
                const b = n + 1;

                // Function to round 'f' part of pcb based on the specified conditions
                const customRound = (value) => {
                    // Ensure value has 2 decimal places
                    const roundedValue = value.toFixed(2);
                    // Split into whole and fractional parts
                    const [whole, fraction] = roundedValue.split('.');
                    const e = parseInt(fraction[0], 10); // First digit of the fractional part
                    const f = parseInt(fraction[1], 10); // Second digit of the fractional part

                    if (f >= 1 && f <= 4) {
                        // Round to `.05`
                        return parseFloat(`${whole}.${e}5`);
                    } else if (f >= 6 && f <= 9) {
                        // Round to `.1`
                        return parseFloat(`${whole}.${e + 1}0`);
                    }

                    // Return original value for other cases (like `.00`)
                    return parseFloat(roundedValue);
                };


                // Calculate the `pcb` value as per the logic
                const pcb = b > 0 ? customRound(parseFloat((pc / b).toFixed(2))) : 0;


                // Net salary
                const netSalary = parseFloat((
                    totalIncome - (
                        epf + socso + eis + pcb
                    )
                ).toFixed(2));




                employee.employeesList.push({
                    basicSalary,
                    maritalRelief,
                    maritalCategory,
                    disabledHusbandWifeValue,
                    arrears,
                    bonus,
                    allowance,
                    deduction,
                    normalPay,
                    offdayPay,
                    publicPay,
                    epf,
                    epfCon,
                    socso,
                    socsoCon,
                    eis,
                    eisCon,
                    hrdc,
                    n,
                    disabledValue,
                    unChild,
                    ftChild,
                    dipChild,
                    degChild,
                    disChild,
                    dis2Child,
                    accumulatedRemuneration,
                    accumulatedEpf,
                    accumulatedPcb,
                    accumulatedEis,
                    accumulatedSocso,
                    remEpf,
                    totalIncome,
                    p,
                    annualTax,
                    pc,
                    b,
                    pcb,
                    netSalary,
                });

                employee.totalSalary += parseFloat(netSalary);
                $timeout(() => {
                    employee.monthlySalary = (employee.totalSalary / 12).toFixed(2);
                });

                employee.list = {};
            };

            function getEpf(basicSalary, bonus, allowance, arrears) {
                // Calculate total income
                const totalIncome = basicSalary + bonus + allowance + arrears;

                // Find the EPF rate based on the total income
                for (let epfRate of epfRates) {
                    if (totalIncome <= epfRate.max) {
                        if (typeof epfRate.epf === 'function') {
                            return {
                                epf: epfRate.epf(basicSalary, bonus, allowance, arrears),
                                epfCon: epfRate.epfCon(basicSalary, bonus, allowance, arrears)
                            };
                        } else {
                            return epfRate; // Return the fixed values if it's not a function
                        }
                    }
                }
            }


            function getSocso(basicSalary, normalPay, offdayPay, publicPay, allowance, arrears) {
                // Calculate total income including overtime and other allowances
                const totalIncome = basicSalary + normalPay + offdayPay + publicPay + allowance + arrears;

                // Loop through SOCSO rates and find the correct rate
                for (let socsoRate of socsoRates) {
                    if (totalIncome <= socsoRate.max) {
                        if (typeof socsoRate.socso === 'function') {
                            return {
                                socso: socsoRate.socso(basicSalary, normalPay, offdayPay, publicPay, allowance, arrears),
                                socsoCon: socsoRate.socsoCon(basicSalary, normalPay, offdayPay, publicPay, allowance, arrears)
                            };
                        } else {
                            return socsoRate; // Return the fixed values if it's not a function
                        }
                    }
                }
            }

            function getEis(basicSalary, normalPay, offdayPay, publicPay, allowance, arrears) {
                // Calculate total income including overtime and other allowances
                const totalIncome = basicSalary + normalPay + offdayPay + publicPay + allowance + arrears;

                for (let eisRate of eisRates) {
                    if (totalIncome <= eisRate.max) {
                        if (typeof eisRate.eis === 'function') {
                            return {
                                eis: eisRate.eis(basicSalary, normalPay, offdayPay, publicPay, allowance, arrears),
                                eisCon: eisRate.eisCon(basicSalary, normalPay, offdayPay, publicPay, allowance, arrears)
                            };
                        } else {
                            return eisRate; // Return the fixed values if it's not a function
                        }
                    }
                }
            }

            // Calculate overtime rates
            function calculateOvertime(basicSalary) {
                var otNormalRate = ((basicSalary / 26) / 8) * 1.5; // Normal overtime rate
                var otOffdayRate = ((basicSalary / 26) / 8) * 2; // Offday overtime rate
                var otPublicRate = ((basicSalary / 26) / 8) * 3; // P.Holiday overtime rate
                return {
                    otNormalRate,
                    otOffdayRate,
                    otPublicRate
                };
            }
        });
    </script>

</head>

<body>
    <main ng-app="basicApp">
        <section ng-controller="BasicController as basic">
            <h1>Monthly Salary Calculation</h1>
            <form id="employeeInfo" ng-submit="basic.createList()">

                <div class="separator">Salary Section</div>

                <div>
                    <label for="basicSalary">Basic Salary:</label>
                    <input type="number" id="basicSalary" class="input-box" ng-model="basic.list.basicSalary" required step="0.01" />
                </div>
                <div class="separator">Overtime Section</div>
                <h5>***Enter Hours Working*** </h5>
                <div>
                    <label for="otNormal">Normal:</label>
                    <input type="number" id="otNormal" class="input-box" ng-model="basic.list.otNormal" step="0.01" />
                </div>
                <div>
                    <label for="otOffday">Off Day:</label>
                    <input type="number" id="otOffday" class="input-box" ng-model="basic.list.otOffday" step="0.01" />
                </div>
                <div>
                    <label for="otPublic">Public Holiday:</label>
                    <input type="number" id="otPublic" class="input-box" ng-model="basic.list.otPublic" step="0.01" />
                </div>
                <div class="separator">Additional Section</div>
                <div>
                    <label for="arrears">Arrears of Wages:</label>
                    <input type="number" id="arrears" class="input-box" ng-model="basic.list.arrears" step="0.01" />
                </div>
                <div>
                    <label for="bonus">Bonus:</label>
                    <input type="number" id="bonus" class="input-box" ng-model="basic.list.bonus" step="0.01" />
                </div>
                <div class="separator">Allowance Section</div>
                <div>
                    <label for="allowance">Total Allowance:</label>
                    <input type="number" id="allowance" class="input-box" ng-model="basic.list.allowance" step="0.01" />
                </div>
                <div class="separator">Deduction Section</div>
                <div>
                    <label for="deduction">Total Deduction:</label>
                    <input type="number" id="deduction" class="input-box" ng-model="basic.list.deduction" step="0.01" />
                </div>
                <div class="separator">PCB Section</div>

                <div>
                    <label for="month">Select Month:</label>
                    <select id="month" ng-model="basic.selectedMonth" ng-change="basic.updateMonth(basic.selectedMonth)" required>
                        <option value="">-- Select Month --</option>
                        <option ng-repeat="month in basic.months" value="{{month.number}}">
                            {{month.display}}
                        </option>
                    </select>
                </div>

                <div>
                    <label for="disabledIndividual">Disabled Individual:</label>
                    <label><input type="radio" ng-model="basic.list.disabledIndividual" ng-value="6000" ng-change="basic.updateDisabledValue(true)" /> Yes</label>
                    <label><input type="radio" ng-model="basic.list.disabledIndividual" ng-value="0" ng-change="basic.updateDisabledValue(false)" /> No</label>
                </div>


                <div>
                    <label for="maritalStatus">Marital Status:</label>
                    <select id="maritalStatus" ng-model="basic.list.maritalStatus" ng-options="status as status.status for status in basic.maritalStatuses" required>
                        <option value="">-- Select Marital Status --</option>
                    </select>
                </div>

                <div>
                    <label for="disabledHusbandWife">Disabled Spouse:</label>
                    <label><input type="radio" ng-model="basic.list.disabledHusbandWife" ng-value="5000" ng-change="basic.updateDisabledHusbandWife(true)" /> Yes</label>
                    <label><input type="radio" ng-model="basic.list.disabledHusbandWife" ng-value="0" ng-change="basic.updateDisabledHusbandWife(false)" /> No</label>
                </div>

                <div>
                    <label for="unChild">Under Aged Child:</label>
                    <input type="number" id="unChild" class="input-box" ng-model="basic.list.unChild" />
                </div>

                <div>
                    <label for="ftChild">Above 18 Full-time Study:</label>
                    <input type="number" id="ftChild" class="input-box" ng-model="basic.list.ftChild" />
                </div>

                <div>
                    <label for="dipChild">Diploma Level:</label>
                    <input type="number" id="dipChild" class="input-box" ng-model="basic.list.dipChild" />
                </div>

                <div>
                    <label for="degChild">Degree Level:</label>
                    <input type="number" id="degChild" class="input-box" ng-model="basic.list.degChild" />
                </div>

                <div>
                    <label for="disChild">Disabled Child:</label>
                    <input type="number" id="disChild" class="input-box" ng-model="basic.list.disChild" />
                </div>

                <div>
                    <label for="dis2Child">Disabled and Study in IPT:</label>
                    <input type="number" id="dis2Child" class="input-box" ng-model="basic.list.dis2Child" />
                </div>

                <div>
                    <label for="accumulatedRemuneration">Accumulated Remuneration:</label>
                    <input type="number" id="accumulatedRemuneration" class="input-box" ng-model="basic.list.accumulatedRemuneration" step="0.01" />
                </div>

                <div>
                    <label for="accumulatedEpf">Accumulated EPF:</label>
                    <input type="number" id="accumulatedEpf" class="input-box" ng-model="basic.list.accumulatedEpf" step="0.01" />
                </div>
                <div>
                    <label for="accumulatedPcb">Accumulated PCB:</label>
                    <input type="number" id="accumulatedPcb" class="input-box" ng-model="basic.list.accumulatedPcb" step="0.01" />
                </div>
                <div>
                    <label for="accumulatedEis">Accumulated EIS:</label>
                    <input type="number" id="accumulatedEis" class="input-box" ng-model="basic.list.accumulatedEis" step="0.01" />
                </div>
                <div>
                    <label for="accumulatedSocso">Accumulated SOCSO:</label>
                    <input type="number" id="accumulatedSocso" class="input-box" ng-model="basic.list.accumulatedSocso" step="0.01" />
                </div>



                <button type="submit" id="submit-button">Submit</button>
            </form>

            <div id="employee-data">
                <!-- Employee Details Table -->
                <table id="employeeTableEmployee">
                    <thead>
                        <tr>
                            <th>Accumulated Remuneration</th>
                            <th>Accumulated EPF</th>
                            <th>Accumulated PCB</th>
                            <th>Accumulated EIS</th>
                            <th>Accumulated SOCSO</th>
                            <th>Basic Salary</th>
                            <th>OT (Normal)</th>
                            <th>OT (Offday)</th>
                            <th>OT (P.Holiday)</th>
                            <th>Arrears of Wages</th>
                            <th>Bonus</th>
                            <th>Total Allowance</th>
                            <th>Total Deduction</th>
                            <th>Total Income</th>
                            <th>Net Salary</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr ng-repeat="list in basic.employeesList track by $index">
                            <td>{{list.accumulatedRemuneration | currency:'RM'}}</td>
                            <td>{{list.accumulatedEpf | currency:'RM'}}</td>
                            <td>{{list.accumulatedPcb | currency:'RM'}}</td>
                            <td>{{list.accumulatedEis | currency:'RM'}}</td>
                            <td>{{list.accumulatedSocso | currency:'RM'}}</td>
                            <td>{{list.basicSalary | currency:'RM'}}</td>
                            <td>{{list.normalPay | currency:'RM'}}</td>
                            <td>{{list.offdayPay | currency:'RM'}}</td>
                            <td>{{list.publicPay | currency:'RM'}}</td>
                            <td>{{list.arrears | currency:'RM'}}</td>
                            <td>{{list.bonus | currency:'RM'}}</td>
                            <td>{{list.allowance | currency:'RM'}}</td>
                            <td>{{list.deduction | currency:'RM'}}</td>
                            <td>{{list.totalIncome | currency:'RM'}}</td>
                            <td>{{list.netSalary | currency:'RM'}}</td>
                        </tr>
                    </tbody>
                </table>

                <div style="height: 30px;"></div> <!-- Spacer between tables -->

                <!-- Employer Contributions Table -->
                <table id="employeeTableEmployer">
                    <thead>
                        <tr>
                            <th>EPF</th>
                            <th>EPF Contribution</th>
                            <th>SOCSO</th>
                            <th>SOCSO Contribution</th>
                            <th>EIS</th>
                            <th>EIS Contribution</th>
                            <th>HRDC</th>
                            <th>Chargeable Income</th>
                            <th>PCB (MTD)</th>
                            <th>Annual Tax</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr ng-repeat="list in basic.employeesList track by $index">
                            <td>{{list.epf | currency:'RM'}}</td>
                            <td>{{list.epfCon | currency:'RM'}}</td>
                            <td>{{list.socso | currency:'RM'}}</td>
                            <td>{{list.socsoCon | currency:'RM'}}</td>
                            <td>{{list.eis | currency:'RM'}}</td>
                            <td>{{list.eisCon | currency:'RM'}}</td>
                            <td>{{list.hrdc | currency:'RM'}}</td>
                            <td>{{list.p | currency:'RM'}}</td>
                            <td>{{list.pcb | currency:'RM'}}</td>
                            <td>{{list.annualTax | currency:'RM'}}</td>
                        </tr>
                    </tbody>
                </table>
            </div>





            <h3>Total Monthly Expense: {{::basic.monthlySalary | currency:'RM'}}</h3>
        </section>
    </main>
</body>

</html>