<?php

include 'navbar_admin.php';

// Database connection
$host = 'localhost';
$db = 'leave1';
$user = 'root';
$pass = '';

$conn = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
$conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

// Get all employees grouped by departments
$staffQuery = $conn->query("
    SELECT department, employee_id, name 
    FROM staff 
    ORDER BY department, name
");
$staff = $staffQuery->fetchAll(PDO::FETCH_ASSOC);

// Get the selected month from the filter
$selectedMonth = isset($_GET['month']) ? $_GET['month'] : date('Y-m');
$startDate = date('Y-m-01', strtotime($selectedMonth));
$endDate = date('Y-m-t', strtotime($selectedMonth));
$dates = [];
$period = new DatePeriod(
    new DateTime($startDate),
    new DateInterval('P1D'),
    (new DateTime($endDate))->modify('+1 day')
);

foreach ($period as $date) {
    $dates[] = $date->format('Y-m-d');
}

// Group staff by departments
$departmentData = [];
foreach ($staff as $employee) {
    $department = $employee['department'];
    if (!isset($departmentData[$department])) {
        $departmentData[$department] = [];
    }
    $departmentData[$department][] = $employee;
}

// Display attendance summary
echo "

<link rel='stylesheet' href='styles.css'>

<style>

        select{
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;

            margin:  0% 15% ;
        }   
        form {
            background-color: #ffffff !important;
            box-shadow: 0 0px 0px 0 rgba(0, 0, 0, 0.2);
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
        }
        th {
            background-color: #f2f2f2;
            text-align: center;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #ddd;
        }
        th, td {
            padding: 6px;
            text-align: left;
        }
        th {
            background-color: #4CAF50;
            color: white;
        }
        .table-container {
            margin: 0% 5% ;
        }
    </style>";

// Month filter form and attendance summary table
echo "
<form method='GET' action='' onchange='this.submit()'>
    <select name='month' id='month'>
        <option value='" . date('Y-m') . "'>" . date('F Y') . "</option>";
for ($i = 1; $i <= 12; $i++) {
    $month = date('Y-m', strtotime("-$i month"));
    echo "<option value='$month'" . ($selectedMonth == $month ? ' selected' : '') . ">" . date('F Y', strtotime($month)) . "</option>";
}
echo "
    </select>
</form>
<div class='table-container'>
    <table>";
foreach ($departmentData as $department => $employees) {
    echo "
    <tr><td colspan='7' style='padding: 10px 0; font-weight: bold; font-size: 1.2em; background-color: #4CAF50; color: white;'>$department</td></tr>
    <tr>
        <th>Employee Name</th>
        <th>Date</th>
        <th>Planned Clock-In</th>
        <th>Clock-In</th>
        <th>Planned Clock-Out</th>
        <th>Clock-Out</th>
        <th>Status</th>
    </tr>";
    foreach ($employees as $employee) {
        $employeeId = $employee['employee_id'];
        $employeeName = $employee['name'];
        foreach ($dates as $date) {
            // Fetch planned clock-in and clock-out times
            $plannedStmt = $conn->prepare("
                SELECT plan_clock_in, plan_clock_out 
                FROM planned_time 
                WHERE employee_id = :employee_id
            ");
            $plannedStmt->execute(['employee_id' => $employeeId]);
            $plannedTimes = $plannedStmt->fetch(PDO::FETCH_ASSOC);
            $plannedClockIn = $plannedTimes['plan_clock_in'] ?? '-';
            $plannedClockOut = $plannedTimes['plan_clock_out'] ?? '-';
            // Check actual attendance for the employee on this date
            $stmt = $conn->prepare("
                SELECT clock_in, clock_out, status 
                FROM attendance 
                WHERE employee_id = :employee_id AND date = :date
            ");
            $stmt->execute(['employee_id' => $employeeId, 'date' => $date]);
            $result = $stmt->fetch(PDO::FETCH_ASSOC);
            $clockIn = $result['clock_in'] ?? '-';
            $clockOut = $result['clock_out'] ?? '-';
            $status = $result['status'] ?? 'absent';
            // Add row for the employee and the date
            echo "
            <tr>
                <td>$employeeName</td>
                <td>$date</td>
                <td>$plannedClockIn</td>
                <td>$clockIn</td>
                <td>$plannedClockOut</td>
                <td>$clockOut</td>
                <td>$status</td>
            </tr>";
        }
    }
}
echo "
    </table>
</div>";
?>