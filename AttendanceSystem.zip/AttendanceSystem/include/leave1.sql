-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 27, 2025 at 03:50 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `leave1`
--
CREATE DATABASE IF NOT EXISTS `leave1` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `leave1`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(10) NOT NULL,
  `name` varchar(100) NOT NULL,
  `Password` varchar(100) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `email` varchar(55) NOT NULL,
  `updationDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `employee_id`, `name`, `Password`, `fullname`, `email`, `updationDate`) VALUES
(1, 'A1010', 'admin', 'd00f5d5217896fb7fd601412cb890830', 'Liam Moore', 'admin@mail.com', '2025-01-21 07:44:17'),
(2, 'A1222', 'bruno', '5f4dcc3b5aa765d61d8327deb882cf99', 'Bruno Den', 'itsbruno@mail.com', '2025-01-21 07:44:22'),
(3, 'A1000', 'greenwood', '5f4dcc3b5aa765d61d8327deb882cf99', 'Johnny Greenwood', 'greenwood@mail.com', '2025-01-21 07:44:26'),
(4, 'A0001', 'admin', '5f4dcc3b5aa765d61d8327deb882cf99', 'Johnny Greenwood', 'admin@gmail.com', '2025-01-21 07:44:31');

-- --------------------------------------------------------

--
-- Table structure for table `admin_leave_applications`
--

CREATE TABLE `admin_leave_applications` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `leave_type` enum('annual_leave','medical_leave','unpaid_leave') NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` text NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_leave_applications`
--

INSERT INTO `admin_leave_applications` (`id`, `admin_id`, `leave_type`, `start_date`, `end_date`, `reason`, `file_path`, `status`) VALUES
(1, 1, 'medical_leave', '2025-01-08', '2025-01-10', 'sick', 'uploads/677ddf28e71d6_Screenshot 2024-12-19 080713.png', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `admin_leave_types`
--

CREATE TABLE `admin_leave_types` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `annual_leave` int(11) DEFAULT 0,
  `medical_leave` int(11) DEFAULT 0,
  `unpaid_leave` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_leave_types`
--

INSERT INTO `admin_leave_types` (`id`, `admin_id`, `annual_leave`, `medical_leave`, `unpaid_leave`) VALUES
(2, 1, 10, 2, 5);

-- --------------------------------------------------------

--
-- Table structure for table `approver`
--

CREATE TABLE `approver` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entity` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parties` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','inactive') CHARACTER SET utf8mb4 DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `approver`
--

INSERT INTO `approver` (`id`, `name`, `email`, `password`, `entity`, `parties`, `created_at`, `status`) VALUES
(1, 'approver', 'ap@gmail.com', '$2y$10$3ZfJBags93rgSdyxaZkPeu84fPyqF3K4rOnwmXan1mmiMp3ZKcJ5C', 'DHL', 'Bayan Lepas', '2025-01-13 02:55:12', 'active'),
(2, 'justin', 'justinlimxh@gmail.com', '$2y$10$CHrF15fR1gX97n8q1Jwrbe8QvrwJHCmNiD1FPWcP5kqUzMhziLD5K', 'DHL', 'Batu Kawan', '2025-01-13 02:55:12', 'active'),
(3, 'approver2', 'ap2@gmail.com', '$2y$10$MNT5oKU8pn/ZOXx69iS.xue6SZ9pdbskN81rAEaG5EqfXXfBemSk2', 'DHL', 'Butterworth', '2025-01-13 10:58:48', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(11) NOT NULL,
  `clock_in` time NOT NULL,
  `clock_out` time NOT NULL,
  `work_time` time NOT NULL,
  `date` date NOT NULL,
  `status` varchar(50) NOT NULL,
  `status_out` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `employee_id`, `clock_in`, `clock_out`, `work_time`, `date`, `status`, `status_out`) VALUES
(564, 'B12340', '00:00:00', '00:00:00', '00:00:00', '2025-01-09', 'Taken Leave', ''),
(565, 'B12340', '00:00:00', '00:00:00', '00:00:00', '2025-01-10', 'Taken Leave', ''),
(566, 'B12345', '00:00:00', '00:00:00', '00:00:00', '2025-01-08', 'Taken Leave', ''),
(567, 'B12340', '00:00:00', '08:36:44', '08:36:44', '2025-01-22', 'Taken Leave', ''),
(568, 'B12340', '00:00:00', '00:00:00', '00:00:00', '2025-01-23', 'Taken Leave', ''),
(569, 'B12340', '00:00:00', '00:00:00', '00:00:00', '2025-01-24', 'Taken Leave', ''),
(570, 'B12345', '10:07:24', '10:07:26', '00:00:02', '2025-01-21', 'clocked in', 'clocked out'),
(571, 'B12340', '11:59:16', '11:59:18', '00:00:02', '2025-01-21', 'clocked in', 'clocked out'),
(572, 'B20000', '13:26:54', '13:26:57', '00:00:03', '2025-01-21', 'clocked in', 'clocked out'),
(596, 'B12345', '08:08:12', '08:08:14', '00:00:02', '2025-01-22', 'clocked in', 'clocked out'),
(602, 'B12349', '08:45:21', '08:45:22', '00:00:01', '2025-01-22', 'clocked in', 'clocked out'),
(603, 'B12344', '08:45:48', '08:45:50', '00:00:02', '2025-01-22', 'clocked in', 'clocked out'),
(604, 'B12348', '08:49:05', '08:49:06', '00:00:01', '2025-01-22', 'clocked in', 'clocked out'),
(605, 'B12346', '08:57:03', '08:57:04', '00:00:01', '2025-01-22', 'clocked in', 'clocked out'),
(606, 'A0001', '09:24:07', '09:24:10', '00:00:03', '2025-01-22', 'clocked in', 'clocked out'),
(607, 'B12343', '09:30:32', '09:30:34', '00:00:02', '2025-01-22', 'clocked in', 'clocked out'),
(608, 'A1010', '09:50:17', '09:50:19', '00:00:02', '2025-01-22', 'clocked in', 'clocked out'),
(609, 'B20000', '09:54:28', '09:54:30', '00:00:02', '2025-01-22', 'clocked in', 'clocked out'),
(610, 'B12340', '00:00:00', '00:00:00', '00:00:00', '2025-02-10', 'Taken Leave', ''),
(611, 'B12340', '00:00:00', '00:00:00', '00:00:00', '2025-02-11', 'Taken Leave', ''),
(612, 'A1222', '10:54:28', '10:54:32', '00:00:04', '2025-01-22', 'clocked in', 'clocked out'),
(639, 'A0001', '10:21:54', '10:21:56', '00:00:02', '2025-01-27', 'late', 'clocked out early'),
(642, 'B12345', '10:23:25', '10:23:28', '00:00:03', '2025-01-27', 'late', 'clocked out early');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `department_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `department_name`) VALUES
(2, 'Secretary '),
(3, 'Finance'),
(4, 'Project Manager'),
(5, 'Marketing');

-- --------------------------------------------------------

--
-- Table structure for table `entity`
--

CREATE TABLE `entity` (
  `id` int(11) NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `entity`
--

INSERT INTO `entity` (`id`, `name`) VALUES
(1, 'DHL'),
(9, 'Maybank'),
(8, 'Shopee');

-- --------------------------------------------------------

--
-- Table structure for table `leave_applications`
--

CREATE TABLE `leave_applications` (
  `id` int(11) NOT NULL,
  `staff_id` varchar(11) NOT NULL,
  `leave_type` varchar(220) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` text NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `approve_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `leave_applications`
--

INSERT INTO `leave_applications` (`id`, `staff_id`, `leave_type`, `start_date`, `end_date`, `reason`, `file_path`, `status`, `approve_date`) VALUES
(1, 'B12340', 'annual_leave', '2025-01-09', '2025-01-10', 'Leave plz', 'uploads/677dddfda4c87_Screenshot 2024-12-19 080713.png', 'Approved', '0000-00-00 00:00:00'),
(2, 'B12345', 'medical_leave', '2025-01-08', '2025-01-08', 'sick', 'uploads/677e195f93e49_Screenshot 2024-12-19 080713.png', 'Approved', '2025-01-10 11:06:15'),
(3, 'B12340', 'annual_leave', '2025-02-10', '2025-02-11', 'sick', 'uploads/677f7c523c222_Screenshot 2024-12-19 080713.png', 'Approved', '2025-01-10 10:19:13'),
(5, 'B12340', 'annual_leave', '2025-01-09', '2025-01-10', '123', 'uploads/677f863e998c4_Screenshot 2024-12-19 080713.png', 'Rejected', '2025-01-10 10:52:38'),
(6, 'B12340', 'annual_leave', '2025-01-22', '2025-01-24', '123', 'uploads/67806d106fc22_Screenshot 2025-01-10 082136.png', 'Approved', '2025-01-10 02:15:02'),
(8, 'B12340', 'annual_leave', '2025-01-10', '2025-01-12', '123', 'uploads/67808e3651181_Screenshot 2025-01-10 082136.png', 'Pending', '2025-01-10 11:16:10'),
(11, 'B12340', 'Half Morning Annual Leave', '2025-01-16', '2025-01-17', '123', 'uploads/6780d2360e195_Screenshot 2025-01-10 082136.png', 'Pending', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `leave_types`
--

CREATE TABLE `leave_types` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `Annual Leave` int(11) DEFAULT 0,
  `Medical Leave` int(11) DEFAULT 0,
  `Unpaid Leave` int(11) DEFAULT 0,
  `Emergency Leave` int(11) DEFAULT 0,
  `Half Morning Annual Leave` int(11) DEFAULT 0,
  `Half Afternoon Annual Leave` int(11) DEFAULT 0,
  `Maternity Leave` int(11) DEFAULT 0,
  `Paternity Leave` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `leave_types`
--

INSERT INTO `leave_types` (`id`, `staff_id`, `Annual Leave`, `Medical Leave`, `Unpaid Leave`, `Emergency Leave`, `Half Morning Annual Leave`, `Half Afternoon Annual Leave`, `Maternity Leave`, `Paternity Leave`) VALUES
(1, 1, 111, 111, 11, 11, 11, 11, 11, 11),
(3, 3, 88, 5, 5, 10, 10, 10, 10, 10),
(4, 4, 73, 5, 5, 0, 0, 0, 0, 0),
(5, 6, 10, 5, 5, 0, 5, 5, 7, 7),
(6, 7, 10, 5, 5, 0, 5, 5, 7, 7),
(7, 8, 10, 5, 5, 0, 5, 5, 7, 7),
(8, 9, 10, 5, 5, 0, 5, 5, 7, 7);

-- --------------------------------------------------------

--
-- Table structure for table `parties`
--

CREATE TABLE `parties` (
  `id` int(11) NOT NULL,
  `party_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `parties`
--

INSERT INTO `parties` (`id`, `party_name`) VALUES
(11, 'Batu Kawan'),
(12, 'GeorgeTown'),
(13, 'Bayan Lepas'),
(15, 'Butterworth');

-- --------------------------------------------------------

--
-- Table structure for table `planned_time`
--

CREATE TABLE `planned_time` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(300) NOT NULL,
  `plan_clock_in` time NOT NULL,
  `plan_clock_out` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `planned_time`
--

INSERT INTO `planned_time` (`id`, `employee_id`, `plan_clock_in`, `plan_clock_out`) VALUES
(181, 'A1010', '09:00:00', '17:00:00'),
(182, 'A1222', '09:00:00', '17:00:00'),
(183, 'A1000', '09:00:00', '17:00:00'),
(194, 'A0001', '09:00:00', '17:00:00'),
(195, 'B20000', '09:00:00', '17:00:00'),
(196, 'B12344', '09:00:00', '17:00:00'),
(197, 'B12345', '09:00:00', '17:00:00'),
(198, 'B12346', '09:00:00', '17:00:00'),
(199, 'B12347', '09:00:00', '17:00:00'),
(200, 'B12343', '09:00:00', '17:00:00'),
(201, 'B12348', '09:00:00', '17:00:00'),
(202, 'B12340', '09:00:00', '17:00:00'),
(203, 'B12349', '09:00:00', '17:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `employee_id` varchar(20) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `entity` varchar(255) NOT NULL,
  `department` varchar(255) DEFAULT NULL,
  `parties` varchar(255) NOT NULL DEFAULT 'internal',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`employee_id`, `name`, `email`, `password`, `entity`, `department`, `parties`, `created_at`, `status`) VALUES
('B12340', 'test6', 'test6@gmail.com', '$2y$10$0/GUfrf7/.cbPu1gc4sMy.p2p5E9t.OunCTbsgv9r6zSx.OW7adV.', 'DHL', 'Finance', 'Batu Kawan', '2025-01-13 00:47:44', ''),
('B12343', 'test4', 'test4@gmail.com', '$2y$10$jcDgTWL9qlwjXQ6fyHqZcuYopZVIbvozM6zO8JEhzGRLXZ3YvEcvu', 'DHL', 'Secretary ', 'Batu Kawan', '2025-01-10 06:01:02', ''),
('B12344', 'Lmao', 'justinlimxh2002@gmail.com', '$2y$10$nADG4Eg9FL/fWz27wMR2OOZB.I0Xomzl2RLRJ8SGoHjLxNKn4r0c.', 'DHL', 'Project Manager', 'Batu Kawan', '2025-01-09 00:20:52', ''),
('B12345', 'test', 'test1@gmail.com', '$2y$10$jcDgTWL9qlwjXQ6fyHqZcuYopZVIbvozM6zO8JEhzGRLXZ3YvEcvu', 'DHL', 'Secretary ', 'Bayan Lepas', '2025-01-09 00:44:59', ''),
('B12346', 'test2', 'test2@gmail.com', '$2y$10$GeBd7BTcrOk4.cm1m1.n5.KS7kySGUME2FgB6of/0SGF2kKAzvf0q', 'DHL', 'Marketing', 'Bayan Lepas', '2025-01-09 00:50:03', ''),
('B12347', 'test3', 'test3@gmail.com', '$2y$10$3GSRu3yw9FX0QdzRuZn37OWMtgfM.u0wh5Q.0XucgEhCFIOY.3wAy', 'DHL', 'Secretary ', 'Batu Kawan', '2025-01-10 06:00:15', 'active'),
('B12348', 'test5', 'test5@gmail.com', '$2y$10$RZFMa/dKTxt/mwgn5D0ga.kdD8pFguS0JyUki6HO94ioF2MHrI9mm', 'DHL', 'Marketing', 'GeorgeTown', '2025-01-13 00:47:06', ''),
('B12349', 'test7', 'test7@gmail.com', '$2y$10$zdt79shUH1jEjDKF95PwQe89.Tl0DB8m921LVM8ZEHaU.2M15.bCq', 'DHL', 'Finance', 'GeorgeTown', '2025-01-13 08:55:52', ''),
('B20000', 'Totally not John Doe', 'fw@gmail.com', '$2y$10$jcDgTWL9qlwjXQ6fyHqZcuYopZVIbvozM6zO8JEhzGRLXZ3YvEcvu', 'DHL', 'Finance', 'GeorgeTown', '2025-01-13 08:55:52', '');

-- --------------------------------------------------------

--
-- Table structure for table `super_admin`
--

CREATE TABLE `super_admin` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `super_admin`
--

INSERT INTO `super_admin` (`id`, `email`, `password`) VALUES
(1, 'limefires.my@gmail.com', '$2y$10$w.muKnjSTgrUmRwjspIHgOoMXZEoWy3NfgxpXYt9YC5zqDG2BzF9W');

-- --------------------------------------------------------

--
-- Table structure for table `tbldepartments`
--

CREATE TABLE `tbldepartments` (
  `id` int(11) NOT NULL,
  `DepartmentName` varchar(150) DEFAULT NULL,
  `DepartmentShortName` varchar(100) NOT NULL,
  `DepartmentCode` varchar(50) DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbldepartments`
--

INSERT INTO `tbldepartments` (`id`, `DepartmentName`, `DepartmentShortName`, `DepartmentCode`, `CreationDate`) VALUES
(1, 'Human Resource', 'HR', 'HR160', '2020-11-01 07:16:25'),
(2, 'Information Technology', 'IT', 'IT807', '2020-11-01 07:19:37'),
(3, 'Operations', 'OP', 'OP640', '2020-12-02 21:28:56'),
(4, 'Volunteer', 'VL', 'VL9696', '2021-03-03 08:27:52'),
(5, 'Marketing', 'MK', 'MK369', '2021-03-03 10:53:52'),
(6, 'Finance', 'FI', 'FI123', '2021-03-03 10:54:27'),
(7, 'Sales', 'SS', 'SS469', '2021-03-03 10:55:24'),
(8, 'Research', 'RS', 'RS666', '2021-03-03 16:39:03');

-- --------------------------------------------------------

--
-- Table structure for table `tblemployees`
--

CREATE TABLE `tblemployees` (
  `id` int(11) NOT NULL,
  `EmpId` varchar(100) NOT NULL,
  `FirstName` varchar(150) NOT NULL,
  `LastName` varchar(150) NOT NULL,
  `EmailId` varchar(200) NOT NULL,
  `Password` varchar(180) NOT NULL,
  `Gender` varchar(100) NOT NULL,
  `Dob` varchar(100) NOT NULL,
  `Department` varchar(255) NOT NULL,
  `Address` varchar(255) NOT NULL,
  `City` varchar(200) NOT NULL,
  `Country` varchar(150) NOT NULL,
  `Phonenumber` char(11) NOT NULL,
  `Status` int(1) NOT NULL,
  `RegDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblemployees`
--

INSERT INTO `tblemployees` (`id`, `EmpId`, `FirstName`, `LastName`, `EmailId`, `Password`, `Gender`, `Dob`, `Department`, `Address`, `City`, `Country`, `Phonenumber`, `Status`, `RegDate`) VALUES
(1, 'ASTR001245', 'Johnny', 'Scott', 'johnny@mail.com', '5f4dcc3b5aa765d61d8327deb882cf99', 'Male', '1996-06-12', 'Information Technology', '49 Arron Smith Drive', 'Honolulu', 'US', '7854785477', 1, '2020-11-10 11:29:59'),
(2, 'ASTR001369', 'Milton', 'Doe', 'milt@mail.com', 'f925916e2754e5e03f75dd58a5733251', 'Male', '1990-02-02', 'Operations', '15 Kincheloe Road', 'Salem', 'US', '8587944255', 1, '2020-11-10 13:40:02'),
(3, 'ASTR004699', 'Shawn', 'Den', 'Shawnden@mail.com', '3b87c97d15e8eb11e51aa25e9a5770e9', 'Male', '1995-03-22', 'Human Resource', '239 Desert Court', 'Wayne', 'US', '7458887169', 1, '2021-03-03 07:24:17'),
(4, 'ASTR002996', 'Carol', 'Reed', 'carol@mail.com', '723e1489a45d2cbaefec82eee410abd5', 'Female', '1989-03-23', 'Volunteer', 'Demo Address', 'Demo City', 'Demo Country', '7854448550', 1, '2021-03-03 10:44:13'),
(5, 'ASTR001439', 'Danny', 'Wood', 'danny@mail.com', 'b7bee6b36bd35b773132d4e3a74c2bb5', 'Male', '1986-03-12', 'Research', '11 Rardin Drive', 'San Francisco', 'US', '4587777744', 1, '2021-03-04 17:14:48'),
(6, 'ASTR006946', 'Shawn', 'Martin', 'shawn@mail.com', 'a3cceba83235dc95f750108d22c14731', 'Male', '1992-08-28', 'Finance', '3259 Ray Court', 'Wilmington', 'US', '8520259670', 1, '2021-03-04 17:46:02'),
(7, 'ASTR000084', 'Jennifer', 'Foltz', 'jennifer@mail.com', '5f4dcc3b5aa765d61d8327deb882cf99', 'Female', '1992-12-11', 'Marketing', '977 Smithfield Avenue', 'Elkins', 'US', '7401256696', 1, '2022-02-09 15:29:00'),
(8, 'ASTR012447', 'Will', 'Williams', 'williams@mail.com', '5f4dcc3b5aa765d61d8327deb882cf99', 'Male', '1992-02-15', 'Research', '366 Cemetery Street', 'Houston', 'US', '7854000065', 1, '2022-02-10 15:52:32'),
(9, '12345678', 'SYAHRUL', 'RONI', 'syah@gmail.com', '25d55ad283aa400af464c76d713c07ad', 'Male', '2001-02-17', 'Information Technology', 'No 18 Kampung Bukit', 'Lenggong', 'Malaysia', '0193960752', 1, '2024-11-29 06:30:46');

-- --------------------------------------------------------

--
-- Table structure for table `tblleaves`
--

CREATE TABLE `tblleaves` (
  `id` int(11) NOT NULL,
  `LeaveType` varchar(110) NOT NULL,
  `ToDate` varchar(120) NOT NULL,
  `FromDate` varchar(120) NOT NULL,
  `Description` mediumtext NOT NULL,
  `PostingDate` timestamp NOT NULL DEFAULT current_timestamp(),
  `AdminRemark` mediumtext DEFAULT NULL,
  `AdminRemarkDate` varchar(120) DEFAULT NULL,
  `Status` int(1) NOT NULL,
  `IsRead` int(1) NOT NULL,
  `empid` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblleaves`
--

INSERT INTO `tblleaves` (`id`, `LeaveType`, `ToDate`, `FromDate`, `Description`, `PostingDate`, `AdminRemark`, `AdminRemarkDate`, `Status`, `IsRead`, `empid`) VALUES
(7, 'Casual Leave', '30/11/2020', '29/10/2020', 'Test Test Demo Test Test Demo Test Test Demo', '2020-11-19 13:11:21', 'A demo Admin Remarks for Testing!', '2020-12-02 23:26:27 ', 2, 1, 1),
(8, 'Medical Leave', '21/10/2020', '25/10/2020', 'Test Test Demo Test Test Demo Test Test Demo Test Test Demo', '2020-11-20 11:14:14', 'A demo Admin Remarks for Testing!', '2020-12-02 23:24:39 ', 1, 1, 1),
(9, 'Medical Leave', '08/12/2020', '12/12/2020', 'This is a demo description for testing purpose', '2020-12-02 18:26:01', 'All good make your time and hope you\'ll be fine and get back to work asap! Best Regards, Admin.', '2021-03-03 11:19:29 ', 1, 1, 2),
(10, 'Restricted Holiday', '25/12/2020', '25/12/2020', 'This is a demo description for testing purpose', '2020-12-03 08:29:07', 'A demo Admin Remarks for Testing!', '2020-12-03 14:06:12 ', 1, 1, 1),
(11, 'Medical Leave', '02/12/2020', '06/12/2020', 'This is a demo description for testing purpose', '2020-04-29 15:01:14', 'A demo Admin Remarks for Testing!', '2020-04-29 20:33:21 ', 1, 1, 1),
(12, 'Casual Leave', '02/02/2020', '03/03/2020', 'This is a demo description for testing purpose', '2020-07-03 08:11:11', 'A demo Admin Remarks for Testing!', '2020-07-03 13:42:05 ', 1, 1, 1),
(14, 'Medical Leave', '2020-03-05', '2020-06-05', 'This is a demo description for testing purpose', '2021-03-02 09:31:01', NULL, NULL, 0, 1, 2),
(15, 'Casual Leave', '2021-03-15', '2021-03-05', 'None, Testing', '2021-03-02 09:32:42', 'casual leave not allowed for a week, the company\'s gotta huge project which should be completed within this week.', '2021-03-03 11:47:33 ', 2, 1, 1),
(17, 'Paternity Leave', '2021-03-03', '2021-03-10', 'Being a father i\'ve got to look after my new borns and spend some time with my families too!', '2021-03-03 10:58:18', NULL, NULL, 0, 1, 3),
(18, 'Medical Leave', '2021-03-04', '2021-03-05', 'i\'ve to go for my body checkup. got an appointment for tommorow', '2021-03-03 12:09:44', 'No comments on it.', '2021-03-04 22:56:24 ', 1, 1, 4),
(19, 'Compensatory Leave', '2021-03-05', '2021-03-06', 'been working over time since last night, so i\'d like a day off', '2021-03-03 12:24:15', 'gg', '2024-12-23 6:48:36 ', 1, 1, 1),
(20, 'Casual Leave', '2022-02-09', '2022-02-12', 'None, Test Mode', '2022-02-09 15:31:15', 'gg', '2024-12-23 6:28:32 ', 1, 1, 7),
(21, 'Self-Quarantine Leave', '2022-02-11', '2022-02-18', 'This is just a demo condition for testing purpose!!', '2022-02-10 16:05:30', 'No comments!!', '2022-02-10 21:37:15 ', 1, 1, 8),
(22, 'Paternity Leave', '2020-03-05', '2020-03-06', '', '2024-11-29 06:31:53', 'test', '2024-11-29 12:03:13 ', 1, 1, 9);

-- --------------------------------------------------------

--
-- Table structure for table `tblleavetype`
--

CREATE TABLE `tblleavetype` (
  `id` int(11) NOT NULL,
  `LeaveType` varchar(200) DEFAULT NULL,
  `Description` mediumtext DEFAULT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tblleavetype`
--

INSERT INTO `tblleavetype` (`id`, `LeaveType`, `Description`, `CreationDate`) VALUES
(1, 'Casual Leave', 'Provided for urgent or unforeseen matters to the employees.', '2020-11-01 12:07:56'),
(2, 'Medical Leave', 'Related to Health Problems of Employee', '2020-11-06 13:16:09'),
(3, 'Restricted Holiday', 'Holiday that is optional', '2020-11-06 13:16:38'),
(5, 'Paternity Leave', 'To take care of newborns', '2021-03-03 10:46:31'),
(6, 'Bereavement Leave', 'Grieve their loss of losing loved ones', '2021-03-03 10:47:48'),
(7, 'Compensatory Leave', 'For Overtime workers', '2021-03-03 10:48:37'),
(8, 'Maternity Leave', 'Taking care of newborn ,recoveries', '2021-03-03 10:50:17'),
(9, 'Religious Holidays', 'Based on employee\'s followed religion', '2021-03-03 10:51:26'),
(10, 'Adverse Weather Leave', 'In terms of extreme weather conditions', '2021-03-03 13:18:26'),
(11, 'Voting Leave', 'For official election day', '2021-03-03 13:19:06'),
(12, 'Self-Quarantine Leave', 'Related to COVID-19 issues', '2021-03-03 13:19:48'),
(13, 'Personal Time Off', 'To manage some private matters', '2021-03-03 13:21:10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_leave_applications`
--
ALTER TABLE `admin_leave_applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `admin_leave_types`
--
ALTER TABLE `admin_leave_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_admin_id` (`admin_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `approver`
--
ALTER TABLE `approver`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_staff_id_attendance` (`employee_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `entity`
--
ALTER TABLE `entity`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `leave_applications`
--
ALTER TABLE `leave_applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_staff_id_leave` (`staff_id`);

--
-- Indexes for table `leave_types`
--
ALTER TABLE `leave_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `leave_types_ibfk_1` (`staff_id`);

--
-- Indexes for table `parties`
--
ALTER TABLE `parties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `planned_time`
--
ALTER TABLE `planned_time`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_staff_id_plan_time` (`employee_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`employee_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `super_admin`
--
ALTER TABLE `super_admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblemployees`
--
ALTER TABLE `tblemployees`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblleaves`
--
ALTER TABLE `tblleaves`
  ADD PRIMARY KEY (`id`),
  ADD KEY `UserEmail` (`empid`);

--
-- Indexes for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `admin_leave_applications`
--
ALTER TABLE `admin_leave_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin_leave_types`
--
ALTER TABLE `admin_leave_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `approver`
--
ALTER TABLE `approver`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=643;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `entity`
--
ALTER TABLE `entity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `leave_applications`
--
ALTER TABLE `leave_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `leave_types`
--
ALTER TABLE `leave_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `parties`
--
ALTER TABLE `parties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `planned_time`
--
ALTER TABLE `planned_time`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=204;

--
-- AUTO_INCREMENT for table `super_admin`
--
ALTER TABLE `super_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbldepartments`
--
ALTER TABLE `tbldepartments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tblemployees`
--
ALTER TABLE `tblemployees`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `tblleaves`
--
ALTER TABLE `tblleaves`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `tblleavetype`
--
ALTER TABLE `tblleavetype`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `leave_applications`
--
ALTER TABLE `leave_applications`
  ADD CONSTRAINT `fk_staff_id_leave` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
