// Set up the scene, camera, and renderer
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
const renderer = new THREE.WebGLRenderer();
renderer.setSize(window.innerWidth, window.innerHeight);
document.body.appendChild(renderer.domElement);

// Create a larger cube
const geometry = new THREE.BoxGeometry(2, 2, 2); // Increase size to make it bigger
const material = new THREE.MeshBasicMaterial({
  color: 0x3498db, // Blue color
  wireframe: true, // Wireframe to make it look cool
});
const cube = new THREE.Mesh(geometry, material);
scene.add(cube);

// Position the camera
camera.position.z = 6; // Adjust camera distance for a larger cube

// Handle mouse movement
let mouseX = 0;
let mouseY = 0;

document.addEventListener('mousemove', (event) => {
  mouseX = (event.clientX / window.innerWidth) * 2 - 1; // Normalize to range [-1, 1]
  mouseY = -(event.clientY / window.innerHeight) * 2 + 1; // Normalize to range [-1, 1]
});

// Animation loop
function animate() {
  requestAnimationFrame(animate);

  // Spin the cube
  cube.rotation.x += 0.01; // Adjust speed as needed
  cube.rotation.y += 0.01;

  // Update cube position based on mouse
  cube.position.x = mouseX * 2; // Adjust the multiplier for sensitivity
  cube.position.y = mouseY * 2;

  renderer.render(scene, camera);
}

animate();

// Handle window resize
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});
