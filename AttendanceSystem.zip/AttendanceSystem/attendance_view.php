<?php
include('navbar_admin.php');
include('db.php');

?>

<?php

$id = ''; // Initialize the variable

$sql = "SELECT employee_id FROM staff WHERE email = '{$_SESSION['email']}'";  
$result = $conn->query($sql);

?>

<DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark Attendance</title>
    <link rel="stylesheet" href="styles.css">

    <style>
        body{
            background-color:rgb(236, 241, 245);
        }

        form{
            background-color: #ffffff;
        }

        td{
            padding: 12px 15px;
            text-align: left;
        }

        th{
            background-color: #34405b;
            color: #ffffff;

            padding: 12px 15px;
        }

        tr{
            background-color:rgb(255, 255, 255);
                border-bottom: 1px solid #dddddd;
        }

        table{
            width: 100%;
            border-collapse: collapse;
        }

        #filter , #date{
            width: 40%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

    </style>
</head>
<body>

        <div>

        <script>
            function setAction(action) {
                const form = document.getElementById('attendance-form');
                if (action === 'clock_in') {
                    form.action = 'process/clock_in.php';
                } else if (action === 'clock_out') {
                    form.action = 'process/clock_out.php';
                }
                document.getElementById('employee_id').disabled = false;
                form.submit();
            }
        </script>
        </div>

        <div>
            <div class="record-container-view">
                <h3 style="padding:2% ; padding-left:0 ; width:100% ; float:left">Attendance Record of all employees</h3>
                <form style="box-shadow: 0 0 0 ; " method="GET" action="">
                    <label for="filter">Filter:</label>
                    <select name="filter" id="filter" onchange="this.form.submit()">
                        <option value="all" <?php if (!isset($_GET['filter']) || $_GET['filter'] == 'all') echo 'selected'; ?>>All</option>
                        <option value="clocked_in" <?php if (isset($_GET['filter']) && $_GET['filter'] == 'clocked_in') echo 'selected'; ?>>Clocked In</option>
                        <option value="leave" <?php if (isset($_GET['filter']) && $_GET['filter'] == 'leave') echo 'selected'; ?>>On Leave</option>
                    </select>
                    <input type="date" name="date" id="date" value="<?php echo isset($_GET['date']) ? $_GET['date'] : ''; ?>" onchange="if(this.value==''){window.location.href='?filter=<?php echo $filter; ?>';}else{this.form.submit();}">
                </form>
                <table>
                    <tr>
                        <th style='border-top-left-radius: 10px;'>Employee ID</th>
                        <th>Clock In</th>
                        <th>Clock Out</th>
                        <th>Work Time</th>
                        <th>Date</th>
                        <th>Status</th>
                        <th style='border-top-right-radius: 10px;'>Action</th>
                    </tr>
                    <?php
                    $records_per_page = 10;
                    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                    $offset = ($page - 1) * $records_per_page;
                    $filter = isset($_GET['filter']) ? $_GET['filter'] : 'all';
                    $date = isset($_GET['date']) ? $_GET['date'] : '';

                    $sql = "SELECT id, employee_id, clock_in, clock_out, work_time, `date`, `status` FROM attendance WHERE 1=1";
                    if ($filter == 'clocked_in') {
                        $sql .= " AND status = 'clocked in'";
                    } elseif ($filter == 'leave') {
                        $sql .= " AND status = 'Taken Leave'";
                    }
                    if (!empty($date)) {
                        $sql .= " AND `date` = '$date'";
                    }
                    $sql .= " LIMIT $records_per_page OFFSET $offset";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            if ($row['status'] == 'clocked in') {
                                echo "
                                    <tr style='background-color:rgb(124, 147, 200)'>
                                        <td>{$row['employee_id']}</td>
                                        <td>{$row['clock_in']}</td>
                                        <td>{$row['clock_out']}</td>
                                        <td>{$row['work_time']}</td>
                                        <td>{$row['date']}</td>
                                        <td>{$row['status']}</td>
                                        <td><a style='color:darkred' href='process/delete_attendance.php?id={$row['id']}'>Delete</a></td>
                                    </tr>";
                            } elseif ($row['status'] == 'Taken Leave') {
                                echo "
                                    <tr style='background-color:rgb(228, 158, 158)'>
                                        <td>{$row['employee_id']}</td>
                                        <td>{$row['clock_in']}</td>
                                        <td>{$row['clock_out']}</td>
                                        <td>{$row['work_time']}</td>
                                        <td>{$row['date']}</td>
                                        <td>{$row['status']}</td>
                                        <td style='color:green'>Approved</td>
                                    </tr>";
                            }
                        }
                    } else {
                        echo "<tr><td colspan='7'>No records present</td></tr>";
                    }

                    // Pagination controls
                    $sql_total = "SELECT COUNT(*) as total FROM attendance WHERE 1=1";
                    if ($filter == 'clocked_in') {
                        $sql_total .= " AND status = 'clocked in'";
                    } elseif ($filter == 'leave') {
                        $sql_total .= " AND status = 'Taken Leave'";
                    }
                    if (!empty($date)) {
                        $sql_total .= " AND `date` = '$date'";
                    }
                    $result_total = $conn->query($sql_total);
                    $total_records = $result_total->fetch_assoc()['total'];
                    $total_pages = ceil($total_records / $records_per_page);

                    echo "<tr><td colspan='7' style='text-align:center;'>";
                    for ($i = 1; $i <= $total_pages; $i++) {
                        echo "<a href='?page=$i&filter=$filter&date=$date'>$i</a> ";
                    }
                    echo "</td></tr>";
                    ?>
                </table>
            </div>





                </table>
            </tr>
        </div>
    </div>
</body>