<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard</title>
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">

    <style>
        html{
            font-family: Arial, sans-serif;
            display: block;
            justify-content: center;

            background-color:rgb(236, 241, 245);
        }

        body{
            margin: 0;
            padding: 0;
            display: block;
            justify-content: center;

            background-color:rgb(236, 241, 245) !important;
        }

        #attendanceChart{
            width: 100%;

            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding:50px;
            border-radius: 15px;

            background-color: #ffffff;
        }

        .dashboard-content-grid{
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 20px;
            
            margin: 3%;
            height: 100%;
        }

        .staff-list{
            background-color: #ffffff;
            border-radius: 15px;
            padding: 50px;

            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        table{
            width: 100%;
            border-collapse: collapse;

            border-color: white;
        }

        td{
            padding: 12px 15px;
            text-align: left;
        }

        th{
            background-color: #34405b;
            color: #ffffff;

            padding: 12px 15px;
        }

        tr{
            background-color:rgb(255, 255, 255);
        }

        .pagination{
            display: flex;
            justify-content: center;
            align-items: center;

            margin-top: 20px;
            text-align: center;
        }

        /* width */
        ::-webkit-scrollbar {
        width: 8px;
        height: 5px;

        margin:2%
        }

        /* Track */
        ::-webkit-scrollbar-track {
            background: transparent;
            box-shadow: inset 0 0 100px #dddddd;
            border-radius: 4px;
            border-left: 1.5px solid transparent;
            border-right: 1.5px solid transparent;
        }

        /* Handle */
        ::-webkit-scrollbar-thumb {
            background:rgb(107, 107, 107);
            border-radius: 4px;
        }
        
    </style>

</head>
<body>
    <div class="staff-dashboard">
    <!-- Include Top Navigation Bar -->
    <?php include('navbar_admin.php'); ?>

    <!-- Dashboard Content -->
    <!--<div class="dashboard-content">
        <h1>Welcome to Your Dashboard!</h1>
        <p>You're successfully logged in to your staff dashboard.</p>
        <p>Logged in as: <?php echo $_SESSION['email']; ?></p>

        <a href="process/staff_logout.php" class="logout-btn">Logout</a>
    </div>-->
    
    <?php
    // Database connection
    include('db.php');

    // Fetch total staff count including admins
    $staffQuery = "SELECT (SELECT COUNT(*) FROM staff) + (SELECT COUNT(*) FROM admin) as totalStaff";
    $staffResult = $conn->query($staffQuery);
    $staffData = $staffResult->fetch_assoc();
    $totalStaff = $staffData['totalStaff'];

    // Fetch clocked in staff count
    $attendanceQuery = "SELECT COUNT(DISTINCT employee_id) as clockedIn FROM attendance WHERE status = 'clocked in' and `date` = CURDATE()";
    $attendanceResult = $conn->query($attendanceQuery);
    $attendanceData = $attendanceResult->fetch_assoc();
    $clockedIn = $attendanceData['clockedIn'];

    // Fetch clocked in staff count
    $leaveQuery = "SELECT COUNT(DISTINCT employee_id) as Leaves FROM attendance WHERE status = 'Taken Leave' and `date` = CURDATE()";
    $leaveResult = $conn->query($leaveQuery);
    $leaveData = $leaveResult->fetch_assoc();
    $Leaves = $leaveData['Leaves'];

    // Calculate no records count
    $noRecords = $totalStaff - $clockedIn - $Leaves;
    ?>
<div class="dashboard-content-grid">
    <!-- Chart.js Library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Graph Container -->
    <div class="graph-container">
        <canvas id="attendanceChart"></canvas>
    </div>

    <div class="staff-list">
    <h2 style="display: inline-block;">Staff Attendance for <?php echo date('Y-m-d') ?></h2>
    <h2 style="display: inline-block; float: right; color:gray"><?php echo $totalStaff ?> Employees</h2>
    <table border="1" cellpadding="10" cellspacing="0">
        <thead>
            <tr>
                <th style='border-top-left-radius: 10px;'>Employee ID</th>
                <th>Name</th>
                <th style='border-top-right-radius: 10px;'>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Fetch all staff and admin details
            $staffDetailsQuery = "SELECT employee_id, name, status FROM (
                                    SELECT s.employee_id, s.name, 
                                    COALESCE(a.status, 'Absent / Have not arrived') as status 
                                    FROM staff s 
                                    LEFT JOIN (
                                        SELECT employee_id, status 
                                        FROM attendance 
                                        WHERE date = CURDATE()
                                    ) a 
                                    ON s.employee_id = a.employee_id
                                    UNION
                                    SELECT ad.employee_id, ad.name, 
                                    COALESCE(a.status, 'Absent / Have not arrived') as status 
                                    FROM admin ad 
                                    LEFT JOIN (
                                        SELECT employee_id, status 
                                        FROM attendance 
                                        WHERE date = CURDATE()
                                    ) a 
                                    ON ad.employee_id = a.employee_id
                                  ) as combined";
            $staffDetailsResult = $conn->query($staffDetailsQuery);

            $rowsPerPage = 8;
            $totalRows = $staffDetailsResult->num_rows;
            $totalPages = ceil($totalRows / $rowsPerPage);

            if (isset($_GET['page']) && is_numeric($_GET['page'])) {
                $currentPage = (int) $_GET['page'];
            } else {
                $currentPage = 1;
            }

            if ($currentPage > $totalPages) {
                $currentPage = $totalPages;
            }

            if ($currentPage < 1) {
                $currentPage = 1;
            }

            $offset = ($currentPage - 1) * $rowsPerPage;

            $staffDetailsQuery .= " LIMIT $offset, $rowsPerPage";
            $staffDetailsResult = $conn->query($staffDetailsQuery);

            while ($row = $staffDetailsResult->fetch_assoc()) {
                if($row['status'] == 'clocked in'){
                    echo "<tr style='background-color:rgb(124, 147, 200)'>
                    <td>" . $row['employee_id'] . "</td>
                    <td>" . $row['name'] . "</td>
                    <td>" . $row['status'] . "</td>
                    </tr>";
            }   elseif($row['status'] == 'Taken Leave'){
                    echo "<tr>
                    <td>" . $row['employee_id'] . "</td>
                    <td>" . $row['name'] . "</td>
                    <td>" . $row['status'] . "</td>
                    </tr>";
            }   else{
                    echo "<tr style='background-color:rgb(228, 158, 158)'>
                    <td>" . $row['employee_id'] . "</td>
                    <td>" . $row['name'] . "</td>
                    <td>" . $row['status'] . "</td>
                    </tr>";
            }
            }
            ?>
        </tbody>
    </table>

    <div class="pagination">
        <?php
        if ($currentPage > 1) {
            echo '<a href="?page=' . ($currentPage - 1) . '" style="margin-right: 10px;">&laquo; Previous</a>';
        }

        for ($i = 1; $i <= $totalPages; $i++) {
            if ($i == $currentPage) {
                echo '<span style="margin: 0 5px; font-weight: bold;">' . $i . '</span>';
            } else {
                echo '<a href="?page=' . $i . '" style="margin: 0 5px;">' . $i . '</a>';
            }
        }

        if ($currentPage < $totalPages) {
            echo '<a href="?page=' . ($currentPage + 1) . '" style="margin-left: 10px;">Next &raquo;</a>';
        }
        ?>
    </div>
        </tbody>
    </table>
</div>

    <script>
        var ctx = document.getElementById('attendanceChart').getContext('2d');
        var attendanceChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Clocked In', 'Absent / Have not arrived' , 'On Leave'],
                datasets: [{
                    label: 'Attendance Status',
                    data: [<?php echo $clockedIn; ?>, <?php echo $noRecords; ?> , <?php echo $Leaves; ?>],
                    backgroundColor: ['#36a2eb', '#ff6384' , '#ffce56'],
                    borderColor: ['#36a2eb', '#ff6384' , '#ffce56'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Today\'s Staff Attendance Status'
                    }
                }
            }
        });
    </script>

    </div>
        <?php
        $conn->close(); // Close database connection
        ?>
        </div>
    </body>
</html>
