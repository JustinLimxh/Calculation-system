<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);
include '../db.php';

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();
date_default_timezone_set('Asia/Kuala_Lumpur'); // Set the default timezone to the user's timezone

$staff_id = $_POST['employee_id'];
$date = date('Y-m-d');
$time = date('H:i:s');

if (!isset($_SESSION['email'])) {
    echo "<script>alert('Error: No email found in session.'); history.back();</script>";
    exit;
}

$email = $_SESSION['email'];

// Check if the staff_id matches the email of the current session
$check_sql = "SELECT employee_id, status FROM staff WHERE email = ?";
$check_stmt = $conn->prepare($check_sql);
if ($check_stmt === false) {
    echo "<script>alert('Error: Failed to prepare statement.'); history.back()</script>";
    exit;
}
$check_stmt->bind_param("s", $email);
$check_stmt->execute();
$check_stmt->bind_result($db_staff_id, $status);
$check_stmt->fetch();
$check_stmt->close();

if ($db_staff_id != $staff_id) {
    echo "<script>alert('Error: Staff ID does not match the email of the current session.'); history.back()</script>";
} elseif ($status == 'Taken Leave') {
    echo "<script>alert('You have already taken leave for today'); history.back()</script>";
} else {
    // Check if the user has already clocked in today
    $check_attendance_sql = "SELECT clock_in, clock_out FROM attendance WHERE employee_id = ? AND date = ?";
    $check_attendance_stmt = $conn->prepare($check_attendance_sql);
    if ($check_attendance_stmt === false) {
        echo "<script>alert('Error: Failed to prepare statement. " . $conn->error . "'); history.back()</script>";
        exit;
    }
    $check_attendance_stmt->bind_param("ss", $staff_id, $date);
    $check_attendance_stmt->execute();
    $check_attendance_stmt->bind_result($clock_in, $clock_out);
    $check_attendance_stmt->fetch();
    $check_attendance_stmt->close();

    if (empty($clock_in)) {
        echo "<script>alert('You have not clocked in today.'); history.back()</script>";
    } elseif (!empty($clock_out) && $clock_out != '00:00:00') {
        echo "<script>alert('You have already clocked out today.'); history.back()</script>";
    } else {
        $sql = "UPDATE attendance SET clock_out = ?, work_time = TIMEDIFF(?, clock_in) WHERE employee_id = ? AND date = ?";
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo "<script>alert('Error: Failed to prepare statement. " . $conn->error . "'); history.back()</script>";
            exit;
        }
        $stmt->bind_param("ssss", $time, $time, $staff_id, $date);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            // Check the planned clock out time
            $planned_time_sql = "SELECT plan_clock_out FROM planned_time WHERE employee_id = ?";
            $planned_time_stmt = $conn->prepare($planned_time_sql);
            if ($planned_time_stmt === false) {
                echo "<script>alert('Error: Failed to prepare statement. " . $conn->error . "'); history.back()</script>";
                exit;
            }
            $planned_time_stmt->bind_param("s", $staff_id);
            $planned_time_stmt->execute();
            $planned_time_stmt->bind_result($plan_clock_out);
            $planned_time_stmt->fetch();
            $planned_time_stmt->close();

            if ($plan_clock_out) {
                if ($time < $plan_clock_out) {
                    // Insert early clock out
                    $status_out = 'clocked out early';
                } else {
                    // Insert clocked out
                    $status_out = 'clocked out';
                }

                // Update the status_out column in attendance
                $update_status_out_sql = "UPDATE attendance SET status_out = ? WHERE employee_id = ? AND date = ?";
                $update_status_out_stmt = $conn->prepare($update_status_out_sql);
                if ($update_status_out_stmt === false) {
                    echo "<script>alert('Error: Failed to prepare statement. " . $conn->error . "'); history.back()</script>";
                    exit;
                }
                $update_status_out_stmt->bind_param("sss", $status_out, $staff_id, $date);
                $update_status_out_stmt->execute();
                $update_status_out_stmt->close();
            }

            // Update the status to 'clocked out'
            $update_status_sql = "UPDATE staff SET status = 'clocked out' WHERE employee_id = ?";
            $update_status_stmt = $conn->prepare($update_status_sql);
            if ($update_status_stmt === false) {
                echo "<script>alert('Error: Failed to prepare statement. " . $conn->error . "'); history.back()</script>";
                exit;
            }
            $update_status_stmt->bind_param("s", $staff_id);
            $update_status_stmt->execute();
            $update_status_stmt->close();

            echo "<script>alert('Clocked out successfully'); history.back()</script>";
        } else {
            echo "<script>alert('Failed to clock out'); history.back() </script>";
        }

        $stmt->close();
    }
}

$conn->close();
?>
