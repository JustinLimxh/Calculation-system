<?php 
include '../db.php';

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();
date_default_timezone_set('Asia/Kuala_Lumpur'); // Set the default timezone to the user's timezone

$staff_id = $_POST['employee_id'];
$date = date('Y-m-d');
$time = date('H:i:s');

if (!isset($_SESSION['email'])) {
    echo "<script>alert('Error: No email found in session.');
    history.back();
    </script>";
    exit;
}

$email = $_SESSION['email'];

// Check if the staff_id matches the email of the current session
$check_sql = "SELECT employee_id FROM admin WHERE email = ?";
$check_stmt = $conn->prepare($check_sql);
if ($check_stmt === false) {
    echo "<script>alert('Error: Failed to prepare statement.'); history.back()</script>";
    exit;
} else {
    $check_stmt->bind_param("s", $email);
    $check_stmt->execute();
    $check_stmt->bind_result($db_staff_id);
    $check_stmt->fetch();
    $check_stmt->close();
}

// Check if the user is on leave today
$leave_check_sql = "SELECT status FROM attendance WHERE employee_id = ? AND date = ? AND status = 'Taken Leave'";
$leave_check_stmt = $conn->prepare($leave_check_sql);
if ($leave_check_stmt === false) {
    echo "<script>alert('Error: Failed to prepare statement.') history.back()</script>";
    exit;
} else {
    $leave_check_stmt->bind_param("ss", $staff_id, $date);
    $leave_check_stmt->execute();
    $leave_check_stmt->bind_result($db_status);
    $leave_check_stmt->fetch();
    $leave_check_stmt->close();
}

if ($db_status == 'Taken Leave') {
    echo "<script>alert('You cannot clock in because you are on leave.'); history.back()</script>";
    exit;
}

if ($db_staff_id != $staff_id) {
    echo "<script>alert('Error: Staff ID does not match the email of the current session.'); history.back()</script>";
} else {
    // Check if the user has already clocked in today
    $check_attendance_sql = "SELECT COUNT(*) FROM attendance WHERE employee_id = ? AND date = ? AND status = 'clocked in'";
    $check_attendance_stmt = $conn->prepare($check_attendance_sql);
    if ($check_attendance_stmt === false) {
        echo "<script>alert('Error: Failed to prepare statement. " . $conn->error . "'); history.back()</script>";
        exit;
    }
    $check_attendance_stmt->bind_param("ss", $staff_id, $date);
    $check_attendance_stmt->execute();
    $check_attendance_stmt->bind_result($attendance_count);
    $check_attendance_stmt->fetch();
    $check_attendance_stmt->close();

    if ($attendance_count > 0) {
        echo "<script>alert('You have already clocked in today.'); history.back()</script>";
    } else {
        $sql = "INSERT INTO attendance (employee_id, date, clock_in, status) VALUES (?, ?, ?, 'clocked in')";
        $stmt = $conn->prepare($sql);
        if ($stmt === false) {
            echo "<script>alert('Error: Failed to prepare statement. " . $conn->error . "'); history.back()</script>";
            exit;
        }
        $stmt->bind_param("sss", $staff_id, $date, $time);
        $stmt->execute();

        if ($stmt->affected_rows > 0) {
            echo "<script>alert('Clocked in successfully'); history.back()</script>";
        } else {
            echo "<script>alert('Failed to clock in'); history.back() </script>";
        }

        $stmt->close();
    }
}

$conn->close();

?>
