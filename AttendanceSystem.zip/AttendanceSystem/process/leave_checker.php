<?php
// Database connection
include('././db.php');

// Fetch leave applications with status 'Approved'
$sql = "SELECT * FROM leave_applications WHERE status = 'Approved'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $staff_id = $row['staff_id'];
        $start_date = $row['start_date'];
        $end_date = $row['end_date'];

        // Loop through each date in the leave period
        $current_date = $start_date;
        while (strtotime($current_date) <= strtotime($end_date)) {
            // Check if the record already exists
            $check_sql = "SELECT * FROM attendance WHERE employee_id = '$staff_id' AND date = '$current_date'";
            $check_result = $conn->query($check_sql);

            if ($check_result->num_rows == 0) {
                // Insert a new row into the attendance table
                $insert_sql = "INSERT INTO attendance (employee_id, date, status) VALUES ('$staff_id', '$current_date', 'Taken Leave')";
                // Execute the insert query
                $conn->query($insert_sql);
            }

            // Move to the next date
            $current_date = date("Y-m-d", strtotime("+1 day", strtotime($current_date)));
        }
    }
} else {
    echo "No approved leave applications found.";
}

$conn->close();
?>