<?php 
error_reporting(E_ALL);
ini_set('display_errors', 1);
include '../db.php';

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();
date_default_timezone_set('Asia/Kuala_Lumpur'); // Set the default timezone to the user's timezone

$staff_id = $_POST['employee_id'];
$date = date('Y-m-d');
$time = date('H:i:s');

if (!isset($_SESSION['email'])) {
    echo "<script>alert('Error: No email found in session.')
    history.back();
    </script>";
    exit;
}

// Check if the user has already clocked in today
$check_attendance_sql = "SELECT clock_in, clock_out FROM attendance WHERE employee_id = ? AND date = ?";
$check_attendance_stmt = $conn->prepare($check_attendance_sql);
if ($check_attendance_stmt === false) {
    echo "<script>alert('Error: Failed to prepare statement. " . $conn->error . "'); history.back()</script>";
    exit;
}
$check_attendance_stmt->bind_param("ss", $staff_id, $date);
$check_attendance_stmt->execute();
$check_attendance_stmt->bind_result($clock_in, $clock_out);
$check_attendance_stmt->fetch();
$check_attendance_stmt->close();

if (empty($clock_in)) {
    echo "<script>alert('The employee has not clocked in today.'); history.back()</script>";
} elseif (!empty($clock_out) && $clock_out != '00:00:00') {
    echo "<script>alert('The employee has already clocked out today.'); history.back()</script>";
} else {
    $sql = "UPDATE attendance SET clock_out = ?, work_time = TIMEDIFF(?, clock_in) WHERE employee_id = ? AND date = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt === false) {
        echo "<script>alert('Error: Failed to prepare statement. " . $conn->error . "'); history.back()</script>";
        exit;
    }
    $stmt->bind_param("ssss", $time, $time, $staff_id, $date);
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        // Check the planned clock out time
        $planned_time_sql = "SELECT plan_clock_out FROM planned_time WHERE employee_id = ?";
        $planned_time_stmt = $conn->prepare($planned_time_sql);
        if ($planned_time_stmt === false) {
            echo "<script>alert('Error: Failed to prepare statement. " . $conn->error . "'); history.back()</script>";
            exit;
        }
        $planned_time_stmt->bind_param("s", $staff_id);
        $planned_time_stmt->execute();
        $planned_time_stmt->bind_result($plan_clock_out);
        $planned_time_stmt->fetch();
        $planned_time_stmt->close();

        if ($plan_clock_out) {
            if ($time < $plan_clock_out) {
                // Insert early clock out
                $status_out = 'clocked out early';
            } else {
                // Insert clocked out
                $status_out = 'clocked out';
            }

            // Update the status_out column in attendance
            $update_status_out_sql = "UPDATE attendance SET status_out = ? WHERE employee_id = ? AND date = ?";
            $update_status_out_stmt = $conn->prepare($update_status_out_sql);
            if ($update_status_out_stmt === false) {
                echo "<script>alert('Error: Failed to prepare statement. " . $conn->error . "'); history.back()</script>";
                exit;
            }
            $update_status_out_stmt->bind_param("sss", $status_out, $staff_id, $date);
            $update_status_out_stmt->execute();
            $update_status_out_stmt->close();
        }

        echo "<script>alert('Clocked out successfully'); history.back()</script>";
    } else {
        echo "<script>alert('Failed to clock out'); history.back() </script>";
    }

    $stmt->close();
}

$conn->close();
?>
