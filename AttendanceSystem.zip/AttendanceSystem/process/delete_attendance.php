<?php

include '../db.php';

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

session_start();

$row_id = $_GET['id'];
$sql = "DELETE FROM attendance WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $row_id);

if ($stmt->execute() == TRUE) {
    echo "<script>alert('Attendance record deleted successfully'); window.location.href='../attendance_view.php';</script>";
} else {
    echo "<script>alert('Failed to delete attendance record'); window.location.href='../attendance_view.php';</script>";
}

echo $row_id;
?>