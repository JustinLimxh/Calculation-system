<?php

include '../db.php';

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $employee_id = $_POST['employee_id'];
    $plan_clock_in = $_POST['plan_clock_in'];
    $plan_clock_out = $_POST['plan_clock_out'];

    // Check if the employee_id already exists
    $sql = "SELECT * FROM planned_time WHERE employee_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $employee_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // Update the existing record
        $sql = "UPDATE planned_time SET plan_clock_in = ?, plan_clock_out = ? WHERE employee_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $plan_clock_in, $plan_clock_out, $employee_id);
    } else {
        // Insert a new record
        $sql = "INSERT INTO planned_time (employee_id, plan_clock_in, plan_clock_out) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sss", $employee_id, $plan_clock_in, $plan_clock_out);
    }

    if ($stmt->execute()) {
        echo "<script>alert('Planned time set successfully.'); window.history.back();</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
    exit;
}

// Fetch employee IDs from admin and staff tables
$employee_ids = [];
$sql = "SELECT id FROM admin UNION SELECT id FROM staff";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $employee_ids[] = $row['id'];
    }
}

$conn->close();
?>
