<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    require_once '../db.php';

    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if email exists
    $sql = "SELECT * FROM admin WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $admin = $result->fetch_assoc();
        
        // Verify password
        if (md5($password) == $admin['Password']) {
            $_SESSION['email'] = $admin['email'];
            $_SESSION['admin_id'] = $admin['employee_id'];
            echo "<script>alert('Login Successful')</script>";

            header("Location: ../admin_dashboard.php"); // Redirect to admin dashboard
            exit();
        } else {
            echo "<script>alert('Incorrect password')</script>";
        }
    } else {
        echo "<script>alert('Email not found')</script>";
    }

    echo "<script>window.history.back()</script>";

    $conn->close();
}
?>
