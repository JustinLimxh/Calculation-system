<?php
include('navbar_staff.php');
include('db.php');

?>

<?php

$id = ''; // Initialize the variable

$sql = "SELECT employee_id FROM `staff` WHERE email = '{$_SESSION['email']}'";  
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $id = $row['employee_id'];
}
?>

<DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mark Attendance</title>
    <link rel="stylesheet" href="styles.css">

    <style>
        body{
            background-color:rgb(236, 241, 245);
        }

        form{
            background-color: #ffffff;
        }

        td{
            padding: 12px 15px;
            text-align: left;
        }

        th{
            background-color: #34405b;
            color: #ffffff;

            padding: 12px 15px;
        }

        tr{
            background-color:rgb(255, 255, 255);
                border-bottom: 1px solid #dddddd;
        }

        table{
            width: 100%;
            border-collapse: collapse;
        }

    </style>
</head>
<body>

<h2 style="padding:2% ; width:100%"></h2>
    <div class="mark-container">
        <div>

        <form style="width:100% ; margin-left:5%" method="post" id="attendance-form">

            <div id="clock-container">
                <div id="clock" style="text-align:center"></div>
            </div>

            <label for="employee_id">Employee ID :</label>
            <input type="text" id="employee_id" name="employee_id" value=<?php echo $id ?> required readonly disabled>

            <br>

            <div class="clock-btn-container">
                <button  id="clock-in" type="submit" onclick="setAction('clock_in')">Clock In</button>
                <button  id="clock-out" type="submit" onclick="setAction('clock_out')">Clock Out</button>
            </div>

        </form>

        <script>
            function setAction(action) {
                const form = document.getElementById('attendance-form');
                if (action === 'clock_in') {
                    form.action = 'process/clock_in.php';
                } else if (action === 'clock_out') {
                    form.action = 'process/clock_out.php';
                }
                document.getElementById('employee_id').disabled = false;
                form.submit();
            }
        </script>
        </div>

        <div>
            <div class="record-container">
            <h3 style="padding:2% ; padding-left:0 ; width:100%">Attendance Record</h3>
                <table>
                <tr>
                    <th style='border-top-left-radius: 10px;'>Employee ID</th>
                    <th>Clock In</th>
                    <th>Clock Out</th>
                    <th>Work Time</th>
                    <th>Date</th>
                    <th style='border-top-right-radius: 10px;'>Status</th>
                </tr>
                    <?php
                    $records_per_page = 8;
                    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
                    $offset = ($page - 1) * $records_per_page;

                    $sql = "SELECT employee_id, clock_in, clock_out, work_time, `date` , `status` FROM attendance WHERE employee_id = '$id' LIMIT $records_per_page OFFSET $offset";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            echo "
                                    <tr>
                                        <td>{$row['employee_id']}</td>
                                        <td>{$row['clock_in']}</td>
                                        <td>{$row['clock_out']}</td>
                                        <td>{$row['work_time']}</td>
                                        <td>{$row['date']}</td>
                                        <td>{$row['status']}</td>
                                    </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='5'>No records found</td></tr>";
                    }

                    // Pagination controls
                    $sql_total = "SELECT COUNT(*) as total FROM attendance WHERE employee_id = '$id'";
                    $result_total = $conn->query($sql_total);
                    $total_records = $result_total->fetch_assoc()['total'];
                    $total_pages = ceil($total_records / $records_per_page);

                    echo "<tr><td colspan='5' style='text-align:center;'>";
                    for ($i = 1; $i <= $total_pages; $i++) {
                        echo "<a href='?page=$i'>$i</a> ";
                    }
                    echo "</td></tr>";
                    ?>


                </table>
            </tr>
        </div>
    </div>

    <script>
        function updateClock() {
            const clockElement = document.getElementById('clock');
            const now = new Date();
            const formattedDate = now.toLocaleDateString(); // Formats the date based on the user's locale
            const formattedTime = now.toLocaleTimeString(); // Formats the time based on the user's locale
            const formattedDay = now.toLocaleDateString(undefined, { weekday: 'long' }); // Formats the day based on the user's locale
            clockElement.textContent = `${formattedDay}, ${formattedDate} ${formattedTime}`;

            // Apply custom styling to the clock element  
            clockElement.innerHTML = ` <br> <span style="font-size:15px">${formattedDate}</span> <br> <span style="font-weight: bold ;font-size:30px">${formattedTime}</span> <p style="font-size:15px">${formattedDay}</p>`;
            clockElement.style.color = '#ffffff';
        }

        // Update the clock every second
        setInterval(updateClock, 1000);

        // Initialize the clock immediately
        updateClock();
    </script>
    <!-- #253241 -->