<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard</title>
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">

    <style>
        html{
            font-family: Arial, sans-serif;
            display: block;
            justify-content: center;

            background-color:rgb(236, 241, 245);
        }

        body{
            margin: 0;
            padding: 0;
            display: block;
            justify-content: center;

            background-color:rgb(236, 241, 245) !important;
        }

        #attendanceChart{
            width: 100%;

            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            padding:50px;
            border-radius: 15px;

            background-color: #ffffff;
        }

        .dashboard-content-grid{
            display: grid;
            grid-template-columns: 1fr 2fr;
            gap: 20px;
            
            margin: 3%;
            height: 100%;
        }

        .staff-list{
            background-color: #ffffff;
            border-radius: 15px;
            padding: 50px;

            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        table{
            width: 100%;
            border-collapse: collapse;

            border-color: white;    
        }

        td{
            padding: 12px 15px;
            text-align: left;
        }

        th{
            background-color: #34405b;
            color: #ffffff;

            padding: 12px 15px;
        }

        tr{
            background-color:rgb(255, 255, 255);
        }

        /* width */
        ::-webkit-scrollbar {
            width: 8px;
            height: 5px;

            margin:2%
        }

        /* Track */
        ::-webkit-scrollbar-track {
            background: transparent;
            box-shadow: inset 0 0 100px #dddddd;
            border-radius: 4px;
            border-left: 1.5px solid transparent;
            border-right: 1.5px solid transparent;
        }

        /* Handle */
        ::-webkit-scrollbar-thumb {
            background:rgb(107, 107, 107);
            border-radius: 4px;
        }

    </style>

</head>
<body>
    <div class="staff-dashboard">
    <!-- Include Top Navigation Bar -->
    <?php include('navbar_staff.php'); ?>

    <!-- Dashboard Content -->
    <!--<div class="dashboard-content">
        <h1>Welcome to Your Dashboard!</h1>
        <p>You're successfully logged in to your staff dashboard.</p>
        <p>Logged in as: <?php echo $_SESSION['email']; ?></p>

        <a href="process/staff_logout.php" class="logout-btn">Logout</a>
    </div>-->
    
    <?php
    // Database connection
    include('db.php');
    // Fetch current staff details by checking email
    $currentEmail = $_SESSION['email']; // Assuming email is stored in session
    $staffIdQuery = "SELECT employee_id FROM staff WHERE email = '$currentEmail'";
    $staffIdResult = $conn->query($staffIdQuery);
    $staffIdData = $staffIdResult->fetch_assoc();
    $currentStaffId = $staffIdData['employee_id'];

    // Fetch clocked in days count for the specific staff
    $clockedInDaysQuery = "SELECT COUNT(*) as clockedInDays FROM attendance WHERE status = 'clocked in' AND employee_id = '$currentStaffId'";
    $clockedInDaysResult = $conn->query($clockedInDaysQuery);
    $clockedInDaysData = $clockedInDaysResult->fetch_assoc();
    $clockedInDays = $clockedInDaysData['clockedInDays'];

    // Fetch leave days count for the specific staff
    $leaveDaysQuery = "SELECT COUNT(*) as leaveDays FROM attendance WHERE status = 'Taken Leave' AND employee_id = '$currentStaffId'";
    $leaveDaysResult = $conn->query($leaveDaysQuery);
    $leaveDaysData = $leaveDaysResult->fetch_assoc();
    $leaveDays = $leaveDaysData['leaveDays'];

    // Fetch late days count for the specific staff
    $lateDaysQuery = "SELECT COUNT(*) as lateDays FROM attendance WHERE status = 'late' AND employee_id = '$currentStaffId'";
    $lateDaysResult = $conn->query($lateDaysQuery);
    $lateDaysData = $lateDaysResult->fetch_assoc();
    $lateDays = $lateDaysData['lateDays'];
?>
<div class="dashboard-content-grid">
    <!-- Chart.js Library -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <!-- Graph Container -->
    <div class="graph-container">
        <canvas id="attendanceChart"></canvas>
    </div>

    <div class="staff-list">
    <h2>Your Attendance for this Week</h2>
    <table border="1" cellpadding="10" cellspacing="0">
        <thead>
            <tr>
                <th style='border-top-left-radius: 10px;'>Employee ID</th>
                <th>Name</th>
                <th>Status</th>
                <th style='border-top-right-radius: 10px;'>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Fetch current staff details by checking email
            $staffDetailsQuery = "SELECT s.employee_id, s.name, a.date, 
                                  IFNULL(a.status, 'Absent / Have not arrived') as status 
                                  FROM staff s 
                                  LEFT JOIN attendance a 
                                  ON s.employee_id = a.employee_id 
                                  AND a.date BETWEEN DATE_SUB(CURDATE(), INTERVAL WEEKDAY(CURDATE()) DAY) AND CURDATE()
                                  WHERE s.employee_id = '$currentStaffId'
                                  ORDER BY a.date";
            $staffDetailsResult = $conn->query($staffDetailsQuery);

            if ($staffDetailsResult->num_rows > 0) {
                while ($row = $staffDetailsResult->fetch_assoc()) {
                    if($row['status'] == 'clocked in'){
                        echo "<tr style='background-color:rgb(124, 147, 200)'>
                        <td>" . $row['employee_id'] . "</td>
                        <td>" . $row['name'] . "</td>
                        <td>" . $row['status'] . "</td>
                        <td>" . $row['date'] . "</td>
                        </tr>";
                    } elseif($row['status'] == 'Taken Leave'){
                        echo "<tr>
                        <td>" . $row['employee_id'] . "</td>
                        <td>" . $row['name'] . "</td>
                        <td>" . $row['status'] . "</td>
                        <td>" . $row['date'] . "</td>
                        </tr>";
                    } else{
                        echo "<tr style='background-color:rgb(228, 158, 158)'>
                        <td>" . $row['employee_id'] . "</td>
                        <td>" . $row['name'] . "</td>
                        <td>" . $row['status'] . "</td>
                        <td>" . $row['date'] . "</td>
                        </tr>";
                    }
                }
            } else {
                echo "<tr>
                <td colspan='4'>No attendance record found for this week.</td>
                </tr>";
            }
            ?>
        </tbody>
    </table>
</div>

    <script>
        var ctx = document.getElementById('attendanceChart').getContext('2d');
        var attendanceChart = new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Clocked In Days', 'Leave Days', 'Late Days'],
                datasets: [{
                    label: 'Attendance Status',
                    data: [<?php echo $clockedInDays; ?>, <?php echo $leaveDays; ?>, <?php echo $lateDays; ?>],
                    backgroundColor: ['#36a2eb', '#ffce56', '#ff6384'],
                    borderColor: ['#36a2eb', '#ffce56', '#ff6384'],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                plugins: {
                    legend: {
                        position: 'top',
                    },
                    title: {
                        display: true,
                        text: 'Total Clocked In, Leave, and Late Days'
                    }
                }
            }
        });
    </script>

    </div>
        <?php
        $conn->close(); // Close database connection
        ?>
        </div>
    </body>
</html>
