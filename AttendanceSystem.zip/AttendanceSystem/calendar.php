<?php include('navbar_admin.php'); ?>

<?php
include('././db.php'); 
// Fetch leave data
$sql = "SELECT employee_id,`date` FROM attendance WHERE status = 'Taken Leave'";
$result = $conn->query($sql);

$leaves = [];
while ($row = $result->fetch_assoc()) {
    $leaves[$row['date']][] = $row['employee_id'];
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Calendar</title>
    <link src="scrollbar.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            display: block;
            justify-content: center;

            background-color: #f8f9fa;
        }

        /* width */
        ::-webkit-scrollbar {
            width: 8px;
            height: 5px;

            margin:2%
        }

        /* Track */
        ::-webkit-scrollbar-track {
            background: transparent;
            box-shadow: inset 0 0 100px #dddddd;
            border-radius: 4px;
            border-left: 1.5px solid transparent;
            border-right: 1.5px solid transparent;
        }

        /* Handle */
        ::-webkit-scrollbar-thumb {
            background:rgb(107, 107, 107);
            border-radius: 4px;
        }

        table{
            border-style: hidden;
        }

        .calendar {
            border-collapse: collapse;
            width: 50%;
            margin: 15 auto;
            background-color: white;
            padding:20px;

            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-radius: 15px;
        }
        .calendar th {
            background-color: #102f53 ;
            color: white;
            padding: 10px;
        }
        .calendar td {
            width: 14.28%;
            height: 100px;
            text-align: center;
            vertical-align: top;
            border: 1px solid #ccc;
            position: relative;
        }
        .calendar td.leave .leave-item {
            position: relative;
            background-color: rgba(0, 0, 0, 0.6);
            color: white;
            padding: 2px 5px;
            border-radius: 3px;
            margin-bottom: 2px;
        }
        .date-controls {
            display: flex;
            justify-content: center;
            align-items: center;
        }

        #submit-btn{
            padding: 10px;
            margin: 10px ;
            border: 1px solid #ccc;
            background-color: #34405b;
            color: white;
            border-radius: 5px;
            box-sizing: border-box;

            cursor: pointer;
        }

        form{

            display: flex;
            justify-content: center;
            align-items: center;

            width: 60%;
            max-width:60%;
        }

        select{
            width: 20%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }
    </style>
</head>
<body>
    <table class="calendar">
        <thead>
            <tr>
                <th style="border-top-left-radius: 15px;background-color:#cc0000 ">Sun</th>
                <th>Mon</th>
                <th>Tue</th>
                <th>Wed</th>
                <th>Thu</th>
                <th>Fri</th>
                <th style="border-top-right-radius: 15px;background-color:#cc0000 ">Sat</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $year = isset($_GET['year']) ? (int)$_GET['year'] : date('Y');
            $month = isset($_GET['month']) ? (int)$_GET['month'] : date('m');
            $daysInMonth = cal_days_in_month(CAL_GREGORIAN, $month, $year);

            $firstDayOfMonth = date('w', strtotime("$year-$month-01"));
            $day = 1;
            $today = date('Y-m-d');

            for ($week = 0; $week < 6; $week++) {
                echo '<tr>';
                for ($dayOfWeek = 0; $dayOfWeek < 7; $dayOfWeek++) {
                    if ($week === 0 && $dayOfWeek < $firstDayOfMonth || $day > $daysInMonth) {
                        echo '<td></td>';
                    } else {
                        $date = sprintf("%04d-%02d-%02d", $year, $month, $day);
                        $users = $leaves[$date] ?? [];
                        $isToday = ($date === $today) ? 'style="background-color: rgb(211, 233, 255);"' : '';
                        echo '<td class="' . (!empty($users) ? 'leave' : '') . '" ' . $isToday . '>';
                        echo $day;
                        foreach ($users as $user) {
                            $color = '#' . substr(md5($user), 0, 6);
                            echo '<div class="leave-item" style="background-color: ' . $color . '">' . htmlspecialchars($user) . '</div>';
                        }
                        echo '</td>';
                        $day++;
                    }
                }
                echo '</tr>';
                if ($day > $daysInMonth) break;
            }
            ?>
            </tbody>
        </table>
        <div class="date-controls">
            <form method="GET" action="">
                    <select name="month" id="month">
                        <?php for ($m = 1; $m <= 12; $m++): ?>
                            <option value="<?php echo $m; ?>" <?php if ($m == $month) echo 'selected'; ?>>
                                <?php echo date('F', mktime(0, 0, 0, $m, 10)); ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                    <select name="year" id="year">
                        <?php for ($y = $year - 5; $y <= $year + 5; $y++): ?>
                            <option value="<?php echo $y; ?>" <?php if ($y == $year) echo 'selected'; ?>>
                                <?php echo $y; ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                <button id="submit-btn" type="submit">Go</button>
            </form>
        </div>

    </body>
</html>
