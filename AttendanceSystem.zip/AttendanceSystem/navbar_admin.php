<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css">
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" ></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.12.9/dist/umd/popper.min.js" ></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" ></script>

<?php require_once 'db.php'; ?>

<?php
session_start();

// Check if the staff is logged in
if (!isset($_SESSION['email'])) {
  header("Location: index.php"); // Redirect to login page if not logged in
  exit();
}

// Get the logged-in staff's email
$staff_email = $_SESSION['email'];

// Fetch the entity of the logged-in staff
$sql_staff = "SELECT entity FROM staff WHERE email = ?";
$stmt = $conn->prepare($sql_staff);
$stmt->bind_param("s", $staff_email);
$stmt->execute();
$stmt->bind_result($staff_entity);
$stmt->fetch();
$stmt->close();

// Check if the user is in the admin table
$sql_admin = "SELECT COUNT(*) FROM admin WHERE email = ?";
$stmt = $conn->prepare($sql_admin);
$stmt->bind_param("s", $staff_email);
$stmt->execute();
$stmt->bind_result($is_admin);
$stmt->fetch();
$stmt->close();

if ($is_admin == 0) {
  // Redirect to an error page or show an error message
  header("Location: index.php");
  exit();
}
?>

<nav class="navbar sticky-top navbar-expand-lg navbar-light bg-white" style="box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
  <img src="images/logo.png" alt="Logo" width="30" height="30" style="margin-right: 10px;">   
  <a class="navbar-brand" href="admin_dashboard.php">Attendance System</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
  <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarText">
  <ul class="navbar-nav mr-auto">
    <li class="nav-item active">
      <a class="nav-link" href="admin_dashboard.php">Home <span class="sr-only">(current)</span></a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="attendance_view.php">Attendance History</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="attendance_mark.php">Mark Attendance</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="time_set.php">Set Time</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="calendar.php">Calendar</a>
    </li>
  </ul>
  <span class="navbar-text">
    <?php
    include 'db.php';
    
    if (isset($_SESSION['email'])) {
      $user_id = $_SESSION['email'];
      $query = "SELECT name FROM `admin` WHERE email = ?";
      $stmt = $conn->prepare($query);
      $stmt->bind_param("s", $user_id);
      $stmt->execute();
      $stmt->bind_result($name);
      $stmt->fetch();
      $stmt->close();

      if ($name) {
      echo "Welcome <b>" . htmlspecialchars($name) . "</b>"; 
      } else {
      echo "Name not found";
      }
    } else {
      echo "Not logged in";
    }

    include 'process/leave_checker.php';
    ?>

    <a href="process/staff_logout.php" style="color:red" class="logout-btn">Logout</a>
  </span>
  </div>
</nav>