<?php

include 'db.php';

// Fetch employee IDs from admin and staff tables
$employee_ids = [];
$sql = "SELECT employee_id FROM admin UNION SELECT employee_id FROM staff";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $employee_ids[] = $row['employee_id'];
    }
}

// Pagination logic
$limit = 8; // Number of rows per page
$page = isset($_GET['page']) ? $_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Fetch planned times for all employees with pagination
$planned_times = [];
$sql = "SELECT employee_id, plan_clock_in, plan_clock_out FROM planned_time LIMIT $limit OFFSET $offset";
$result = $conn->query($sql);
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $planned_times[] = $row;
    }
}

// Get total number of rows for pagination
$sql = "SELECT COUNT(*) AS total FROM planned_time";
$result = $conn->query($sql);
$total_rows = $result->fetch_assoc()['total'];
$total_pages = ceil($total_rows / $limit);

// Set default planned times for employees with no planned time
foreach ($employee_ids as $id) {
    $sql = "SELECT COUNT(*) AS count FROM planned_time WHERE employee_id = '$id'";
    $result = $conn->query($sql);
    $count = $result->fetch_assoc()['count'];
    if ($count == 0) {
        $default_in = '09:00:00';
        $default_out = '17:00:00';
        $sql = "INSERT INTO planned_time (employee_id, plan_clock_in, plan_clock_out) VALUES ('$id', '$default_in', '$default_out')";
        $conn->query($sql);
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <title>Set Planned Time</title>
    <link rel="stylesheet" href="styles.css">
    <?php include 'navbar_admin.php'; ?>

    <style>
        body {
            background-color: rgb(236, 241, 245);
        }

        select{
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        .grid-layout {
            display: grid;
            grid-template-columns: 1fr 2.5fr;
            grid-gap: 3% 3%;

            padding: 2%;
        }

        form {
            background-color: #ffffff !important;
        }

        td{
            padding: 12px 15px;
            text-align: left;
        }

        th{
            background-color: #34405b;
            color: #ffffff;

            padding: 12px 15px;
        }

        tr{
            background-color:rgb(255, 255, 255);
                border-bottom: 1px solid #dddddd;
        }

        table{
            width: 100%;
            border-collapse: collapse;
        }


        #planned-times-table {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 25px;

            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        #submit-btn{
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border: none;
            border-radius: 5px;
            background-color: #102f53;
            color: #fff;
            cursor: pointer;

            transition-duration: 0.4s;
        }

        #submit-btn:hover{
            background-color: #1c5291;

            transition-duration: 0.4s;
        }
    </style>
</head>
<body>
    <h2 style="padding:2% ; width:100%"></h2>
    <div class="grid-layout">
        <div>
            <form method="post" action="process/time_set_process.php">
                Employee ID: 
                <select name="employee_id" id="employee_id" required>
                    <?php foreach ($employee_ids as $id): ?>
                        <option value="<?php echo $id; ?>"><?php echo $id; ?></option>
                    <?php endforeach; ?>
                </select><br>
                Plan Clock In: <input type="time" name="plan_clock_in" id="plan_clock_in" step="1" required><br>
                Plan Clock Out: <input type="time" name="plan_clock_out" id="plan_clock_out" step="1" required><br>
                <input style="margin-top:5%" id="submit-btn" type="submit" value="Submit">
            </form>
        </div>
        <div id="planned-times-table">
            <h2>Planned Times</h2>
            <table>
                <tr>
                    <th style='border-top-left-radius: 10px;'>Employee ID</th>
                    <th>Plan Clock In</th>
                    <th style='border-top-right-radius: 10px;'>Plan Clock Out</th>
                </tr>
                <?php foreach ($planned_times as $time): ?>
                    <tr>
                        <td><?php echo $time['employee_id']; ?></td>
                        <td><?php echo $time['plan_clock_in']; ?></td>
                        <td><?php echo $time['plan_clock_out']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </table>
            <div style="display: flex; justify-content: center; margin-top: 20px;">
                <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                    <a href="?page=<?php echo $i; ?>"> <?php echo $i; ?></a>
                <?php endfor; ?>
            </div>
        </div>
    </div>
</body>
</html>
