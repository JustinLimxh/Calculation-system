<?php
session_start();
session_destroy();

include 'db.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance System</title>
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="logins.css">
</head>

    <body style="overflow-y: hidden;">
        <div class="container" id="fade-in">
            <form action="process/login.php" method="post">
            <h2 class="sub-title" style="text-align: center">FW Attendance System - Staff</h2>
            <label for="email">Email :</label>
            <input type="email" name="email"  required>
            <br>
            <label for="password">Password :</label>
            <input type="password" name="password" required>
            <button type="submit" name="login">Submit</button>
            </form>
        </div>

        <script>
            document.addEventListener("DOMContentLoaded", function() {
            const fadeInElement = document.getElementById('fade-in');
            fadeInElement.style.opacity = 0;
            fadeInElement.style.transform = 'translateY(20px)';
            fadeInElement.style.transition = 'opacity 1s ease-out, transform 1s ease-out';

            setTimeout(() => {
                fadeInElement.style.opacity = 1;
                fadeInElement.style.transform = 'translateY(0)';
            }, 100);
            });
        </script>

        <div style="position:absolute; bottom: 0; right: 0; margin: 10px;"> 
            <a href="admin_login.php">
                <button type="button">Admin Login</button>
            </a>
        </div>
        
    </body>
</html>