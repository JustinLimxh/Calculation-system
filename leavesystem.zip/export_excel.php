<?php
require 'vendor/autoload.php'; // Include PhpSpreadsheet library

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Database connection
require_once 'config.php';

// Check if the party filter is selected
$selected_party = isset($_POST['party']) ? $_POST['party'] : ''; // Default is empty (show all)

// Modify the SQL query to fetch data including staff email, employee_id, leave data, and parties
$sql = "SELECT la.staff_id, s.employee_id, s.email, s.parties, la.leave_type, la.start_date, la.end_date, la.reason, la.status, la.approve_date
        FROM leave_applications la
        JOIN staff s ON la.staff_id = s.id"; 

// If a party is selected, modify the SQL query to filter by the selected party
if ($selected_party !== '') {
    $sql .= " WHERE s.parties = ?";
}

// Prepare and execute the SQL query
$stmt = $conn->prepare($sql);

// If a party is selected, bind the party parameter
if ($selected_party !== '') {
    $stmt->bind_param("s", $selected_party);
}

$stmt->execute();
$result = $stmt->get_result();

// Check if there are any records
if ($result->num_rows > 0) {
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Set header row
    $sheet->setCellValue('A1', 'Staff ID');
    $sheet->setCellValue('B1', 'Employee ID');
    $sheet->setCellValue('C1', 'Email');
    $sheet->setCellValue('D1', 'Parties'); // Added new column for parties
    $sheet->setCellValue('E1', 'Leave Type');
    $sheet->setCellValue('F1', 'Start Date');
    $sheet->setCellValue('G1', 'End Date');
    $sheet->setCellValue('H1', 'Reason');
    $sheet->setCellValue('I1', 'Status');
    $sheet->setCellValue('J1', 'Approve Date'); // Adjusted the column for approve date

    // Populate data rows
    $row = 2;
    while ($data = $result->fetch_assoc()) {
        $sheet->setCellValue('A' . $row, $data['staff_id']);
        $sheet->setCellValue('B' . $row, $data['employee_id']);
        $sheet->setCellValue('C' . $row, $data['email']);
        $sheet->setCellValue('D' . $row, $data['parties']); // Adding parties to the new column
        $sheet->setCellValue('E' . $row, $data['leave_type']);
        $sheet->setCellValue('F' . $row, $data['start_date']);
        $sheet->setCellValue('G' . $row, $data['end_date']);
        $sheet->setCellValue('H' . $row, $data['reason']);
        $sheet->setCellValue('I' . $row, $data['status']);
        $sheet->setCellValue('J' . $row, $data['approve_date']);
        $row++;
    }

    // Set filename and download headers
    $filename = "leave_applications_" . date('Ymd_His') . ".xlsx";

    // Ensure no output before sending headers
    ob_clean(); // Clear any output buffer before sending the file

    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0'); // No cache

    // Write the spreadsheet to the output
    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
} else {
    echo "No records found.";
}
?>
