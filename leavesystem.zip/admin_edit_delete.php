<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if the admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

require_once 'config.php';

// Fetch the logged-in admin's entity from session
$admin_entity = $_SESSION['admin_entity'];  // Retrieve the entity stored in the session

// Handle delete operation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    $sql = "DELETE FROM staff WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $delete_id);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Staff account deleted successfully!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error deleting staff account.";
        $_SESSION['message_type'] = "error";
    }
    $stmt->close();
}

// Handle status update (activate/deactivate)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['status_id'])) {
    $status_id = $_POST['status_id'];
    $new_status = $_POST['new_status'] == 'active' ? 'inactive' : 'active';
    
    $sql = "UPDATE staff SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("si", $new_status, $status_id);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Staff account status updated successfully!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error updating status.";
        $_SESSION['message_type'] = "error";
    }
    $stmt->close();
}

// Check if a party is selected
$selected_party = isset($_GET['party']) ? $_GET['party'] : ''; // Default is empty (show all)
$selected_status = isset($_GET['status']) ? $_GET['status'] : ''; // Default is empty (show all)

// Fetch staff accounts based on the logged-in admin's entity, selected party, and status
if ($selected_party && $selected_status) {
    $sql = "SELECT id, name, email, entity, employee_id, parties, department, status FROM staff WHERE entity = ? AND parties = ? AND status = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $admin_entity, $selected_party, $selected_status);
} elseif ($selected_party) {
    $sql = "SELECT id, name, email, entity, employee_id, parties, department, status FROM staff WHERE entity = ? AND parties = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $admin_entity, $selected_party);
} elseif ($selected_status) {
    $sql = "SELECT id, name, email, entity, employee_id, parties, department, status FROM staff WHERE entity = ? AND status = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $admin_entity, $selected_status);
} else {
    $sql = "SELECT id, name, email, entity, employee_id, parties, department, status FROM staff WHERE entity = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $admin_entity);
}

$stmt->execute();
$result = $stmt->get_result();
$stmt->close();

// Fetch all unique parties from the parties table
$party_sql = "SELECT DISTINCT party_name FROM parties";
$party_result = $conn->query($party_sql);

// Fetch all unique statuses (active, inactive)
$status_sql = "SELECT DISTINCT status FROM staff WHERE entity = ?";
$status_stmt = $conn->prepare($status_sql);
$status_stmt->bind_param("s", $admin_entity);
$status_stmt->execute();
$status_result = $status_stmt->get_result();
$status_stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit/Delete Staff</title>
    <link rel="stylesheet" href="css/admin_edit_delete.css">
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/admin_top_nav.css">
    <script src="js/admin_top_nav.js"></script>
</head>
<body>
    <?php include 'admin_top_nav.php'; ?>
    
    <!-- Success/Error Message -->
    <?php if (isset($_SESSION['message'])): ?>
        <div class="message <?php echo $_SESSION['message_type']; ?>">
            <?php
                echo $_SESSION['message'];
                unset($_SESSION['message']);
                unset($_SESSION['message_type']);
            ?>
        </div>
    <?php endif; ?>

    <div class="edit-delete-container">
    <h2>Edit/Delete Staff Accounts</h2>

    <!-- Party Filter Dropdown -->
    <div class="party-filter">
        <form method="GET" action="">
            <label for="party">Filter by Party:</label>
            <select name="party" id="party" onchange="this.form.submit()">
                <option value="">-- Select Party --</option>
                <?php while ($party_row = $party_result->fetch_assoc()): ?>
                    <option value="<?php echo htmlspecialchars($party_row['party_name']); ?>"
                        <?php echo ($selected_party === $party_row['party_name']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($party_row['party_name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </form>
    </div>

    <!-- Status Filter Dropdown -->
    <div class="status-filter">
        <form method="GET" action="">
            <label for="status">Filter by Status:</label>
            <select name="status" id="status" onchange="this.form.submit()">
                <option value="">-- Select Status --</option>
                <?php while ($status_row = $status_result->fetch_assoc()): ?>
                    <option value="<?php echo htmlspecialchars($status_row['status']); ?>"
                        <?php echo ($selected_status === $status_row['status']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($status_row['status']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </form>
    </div>

    <!-- Table Container -->
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Employee ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Entity</th>
                    <th>Parties</th>
                    <th>Department</th>
                    <th>Status</th> <!-- Status Column -->
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <form method="POST">
                            <td><?php echo htmlspecialchars($row['id']); ?></td>
                            <td><?php echo htmlspecialchars($row['employee_id']); ?></td>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['entity']); ?></td>
                            <td><?php echo htmlspecialchars($row['parties']); ?></td>
                            <td><?php echo htmlspecialchars($row['department']); ?></td>
                            <td>
                                <?php echo htmlspecialchars($row['status']); ?>
                                <button type="submit" name="status_id" value="<?php echo $row['id']; ?>" class="btn status-btn">
                                    <?php echo ($row['status'] == 'active') ? 'Deactive' : 'Activate'; ?>
                                </button>
                                <input type="hidden" name="new_status" value="<?php echo $row['status']; ?>">
                            </td>
                            <td class="actions">
                                <a href="admin_edit_staff.php?id=<?php echo $row['id']; ?>" class="btn edit-btn">Edit</a>
                                <button type="submit" name="delete_id" value="<?php echo $row['id']; ?>" class="btn delete-btn">Delete</button>
                            </td>
                        </form>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

</body>
</html>
