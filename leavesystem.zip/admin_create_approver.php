<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if the admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

// Database connection
require_once 'config.php';

// Retrieve admin's entity
$admin_email = $_SESSION['email'];
$sql = "SELECT entity FROM admin WHERE email=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$stmt->bind_result($admin_entity);
$stmt->fetch();
$stmt->close();

// Retrieve parties for dropdown
$parties_query = "SELECT party_name FROM parties";
$parties_result = $conn->query($parties_query);

// Handle approver creation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password
    $entity = $admin_entity; // Set entity to admin's entity
    $party_name = $_POST['party_name']; // Selected party

    // Check if email already exists
    $sql = "SELECT * FROM approver WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Approver with this email already exists!');</script>";
    } else {
        // Insert new approver account
        $stmt = $conn->prepare("INSERT INTO approver (name, email, password, entity, parties) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $name, $email, $password, $entity, $party_name);

        if ($stmt->execute()) {
            echo "<script>alert('New approver registered successfully.');</script>";
            echo "<script>window.location.href = 'admin_create_approver.php';</script>";
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Approver Account</title>
    <link rel="stylesheet" href="css/admin_create_approver.css">
     <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/admin_top_nav.css">
            <script src="js/admin_top_nav.js"></script> 
</head>
<body class="admin-create">
    <!-- Include Top Navigation Bar -->
    <?php include 'admin_top_nav.php'; ?>

    <div class="admin-create-form">
        <h2>Create Approver Account</h2>
        <form method="POST" action="admin_create_approver.php">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <label for="entity">Entity:</label>
            <input type="text" id="entity" value="<?php echo htmlspecialchars($admin_entity); ?>" disabled>
            <input type="hidden" name="entity" value="<?php echo htmlspecialchars($admin_entity); ?>">

            <label for="party_name">Party:</label>
            <select id="party_name" name="party_name" required>
                <?php while ($party = $parties_result->fetch_assoc()) { ?>
                    <option value="<?php echo htmlspecialchars($party['party_name']); ?>">
                        <?php echo htmlspecialchars($party['party_name']); ?>
                    </option>
                <?php } ?>
            </select>

            <button type="submit" name="register">Create Account</button>
        </form>
    </div>
</body>
</html>
