<!-- staff_top_nav.php -->
<div class="top-nav-container">
    <div class="top-nav">
        <!-- Logo beside the navigation bar -->
        <div class="logo-container" id="logo-container">
            <img src="images/logo.jpg" alt="Logo" class="logo">
        </div>
        <!-- Menu items -->
        <ul class="nav-links" id="nav-links">
            <li><a href="staff_dashboard.php">Dashboard</a></li>
            <li><a href="apply_leave.php">Apply Leave</a></li>
            <li><a href="leave_balance.php">Leave Balance</a></li>
            <li><a href="leave_history.php">Leave History</a></li>
            <li><a href="staff_profile.php">Profile</a></li>
        </ul>
        <!-- Hamburger Button for Mobile -->
        <button class="hamburger-menu" id="hamburger-btn">&#9776;</button>
    </div>
</div>

<!-- Mobile Menu (Initially hidden) -->
<div class="mobile-menu">
    <ul>
<li><a href="staff_dashboard.php">Dashboard</a></li>
            <li><a href="apply_leave.php">Apply Leave</a></li>
            <li><a href="leave_balance.php">Leave Balance</a></li>
            <li><a href="leave_history.php">Leave History</a></li>
            <li><a href="staff_profile.php">Profile</a></li>
    </ul>
</div>
