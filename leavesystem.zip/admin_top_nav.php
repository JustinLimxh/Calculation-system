<!-- Staff Top Navigation -->
<div class="top-nav-container">
    <div class="top-nav">
        <!-- Logo beside the navigation bar -->
        <div class="logo-container" id="logo-container">
            <img src="images/logo.jpg" alt="Logo" class="logo">
        </div>
        <!-- Navigation Links -->
        <ul class="nav-links" id="nav-links">
            <li><a href="admin_dashboard.php">Dashboard</a></li>
            <li><a href="admin_create.php">Create Staff</a></li>
            <li><a href="admin_edit_delete.php">Edit/Delete Staff</a></li>
            <li><a href="admin_create_approver.php">Create Approver</a></li>
            <li><a href="admin_edit_delete_approver.php">Edit/Delete Approver</a></li>
            <li><a href="admin_manage_leave.php">Manage Leave</a></li>
            <li><a href="admin_edit_leave.php">Manage Edit</a></li>
        </ul>
        <!-- Hamburger Button for Mobile -->
        <button class="hamburger-menu" id="hamburger-btn">&#9776;</button>
    </div>
</div>

<!-- Mobile Menu (Initially hidden) -->
<div class="mobile-menu">
    <ul>
        <li><a href="admin_dashboard.php">Dashboard</a></li>
        <li><a href="admin_create.php">Create Staff</a></li>
        <li><a href="admin_edit_delete.php">Edit/Delete Staff</a></li>
        <li><a href="admin_create_approver.php">Create Approver</a></li>
        <li><a href="admin_edit_delete_approver.php">Edit/Delete Approver</a></li>
        <li><a href="admin_manage_leave.php">Manage Leave</a></li>
        <li><a href="admin_edit_leave.php">Manage Edit</a></li>
    </ul>
</div>
