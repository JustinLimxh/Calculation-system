<?php
// config.php: Database connection configuration

$host = 'srv1151.hstgr.io';
$dbname = 'u337860726_leave_system';
$username = 'u337860726_leave_system';
$password = 'Limefires@20210101';

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
