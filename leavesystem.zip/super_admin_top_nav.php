<!-- staff_top_nav.php -->
<div class="top-nav-container">
    <div class="top-nav">
        <!-- Logo beside the navigation bar -->
        <div class="logo-container" id="logo-container">
            <img src="images/logo.jpg" alt="Logo" class="logo">
        </div>
        <!-- Navigation Links -->
        <ul class="nav-links" id="nav-links">
             <li><a href="super_admin_dashboard.php">Dashboard</a></li>
            <li><a href="super_admin_create.php">Create Account</a></li>
            <li><a href="super_admin_edit_delete.php">Edit/Delete Accounts</a></li>
            <li><a href="super_admin_manage.php">Manage Records</a></li>
            <!-- <li><a href="super_admin_manage_leave.php">Manage Leave</a></li>
             <li><a href="super_admin_edit_leave.php">Edit Leave</a></li> -->
        </ul>
   <!-- Hamburger Button for Mobile -->
        <button class="hamburger-menu" id="hamburger-btn">&#9776;</button>
    </div>
</div>

<!-- Mobile Menu (Initially hidden) -->
<div class="mobile-menu">
    <ul class="nav-links" id="nav-links">
             <li><a href="super_admin_dashboard.php">Dashboard</a></li>
            <li><a href="super_admin_create.php">Create Account</a></li>
            <li><a href="super_admin_edit_delete.php">Edit/Delete Accounts</a></li>
            <li><a href="super_admin_manage.php">Manage Records</a></li>
            <!-- <li><a href="super_admin_manage_leave.php">Manage Leave</a></li>
             <li><a href="super_admin_edit_leave.php">Edit Leave</a></li> -->
        </ul>
</div>