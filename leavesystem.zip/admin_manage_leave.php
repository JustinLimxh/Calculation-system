<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Check if the admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

require_once 'config.php';

// Get the admin's entity
$admin_email = $_SESSION['email'];
$admin_entity_query = "SELECT entity FROM admin WHERE email = ?";
$stmt = $conn->prepare($admin_entity_query);
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$stmt->bind_result($admin_entity);
$stmt->fetch();
$stmt->close();

// Handle leave application actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $application_id = $_POST['application_id'];
    $action = $_POST['action'];
    $staff_id = $_POST['staff_id'];
    $leave_type = $_POST['leave_type'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Calculate the number of leave days
    $days_requested = (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24) + 1;

    // Update the leave application status and deduct leave balance if approved
    if ($action === 'approve') {
        $status = 'Approved';

        // Deduct the leave balance for the staff
        $balance_column = $leave_type; // annual_leave, medical_leave, unpaid_leave

        // Fetch the current leave balance to ensure no negative deduction
        $balance_query = "SELECT $balance_column FROM leave_types WHERE staff_id = ?";
        $stmt = $conn->prepare($balance_query);
        $stmt->bind_param("i", $staff_id);
        $stmt->execute();
        $stmt->bind_result($current_balance);
        $stmt->fetch();
        $stmt->close();

        // Check if the staff has enough balance
        if ($current_balance >= $days_requested) {
            // Update leave balance
            $update_balance_sql = "UPDATE leave_types SET $balance_column = $balance_column - ? WHERE staff_id = ?";
            $stmt = $conn->prepare($update_balance_sql);
            $stmt->bind_param("ii", $days_requested, $staff_id);
            $stmt->execute();
            $stmt->close();
        } else {
            $message = "Error: Insufficient $leave_type balance for staff ID $staff_id.";
            header("Location: admin_manage_leave.php?error=" . urlencode($message));
            exit();
        }
    } elseif ($action === 'reject') {
        $status = 'Rejected';
    } else {
        $status = 'Pending';
    }

    // Update leave application status
    $update_sql = "UPDATE leave_applications SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("si", $status, $application_id);

    if ($stmt->execute()) {
        // Fetch staff email for sending the email
        $email_query = "SELECT email FROM staff WHERE id = ?";
        $stmt2 = $conn->prepare($email_query);
        $stmt2->bind_param("i", $staff_id);
        $stmt2->execute();
        $stmt2->bind_result($staff_email);
        $stmt2->fetch();
        $stmt2->close();

        // Email staff about the leave application decision
        $subject = "Leave Application Status Update";
        $message = "
        <html>
        <head>
            <title>Leave Application Update</title>
        </head>
        <body>
            <p>Dear Staff,</p>
            <p>Your leave application has been <strong>{$status}</strong>.</p>
            <p><strong>Details:</strong></p>
            <ul>
                <li><strong>Leave Type:</strong> {$leave_type}</li>
                <li><strong>Start Date:</strong> {$start_date}</li>
                <li><strong>End Date:</strong> {$end_date}</li>
                <li><strong>Status:</strong> {$status}</li>
            </ul>
            <p>Thank you!</p>
        </body>
        </html>
        ";

        // Email headers
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: no-reply@nasiandsambal.com" . "\r\n";

        mail($staff_email, $subject, $message, $headers);
        $message = "Leave application has been $status successfully, and the staff has been notified via email.";
    } else {
        $message = "Error updating leave application.";
    }
    $stmt->close();

    header("Location: admin_manage_leave.php?message=" . urlencode($message));
    exit();
}

// Check if a party is selected
$selected_party = isset($_GET['party']) ? $_GET['party'] : ''; // Default is empty (show all)

// Fetch all unique parties from the parties table
$party_sql = "SELECT DISTINCT party_name FROM parties";
$party_result = $conn->query($party_sql);

// Fetch leave applications with filtering by party
$allApplicationsSql = "SELECT la.id, la.staff_id, la.leave_type, la.start_date, la.end_date, la.reason, la.file_path, la.status, la.approve_date, s.email, s.employee_id, s.parties 
                       FROM leave_applications la 
                       INNER JOIN staff s ON la.staff_id = s.id
                       WHERE s.entity = ?";

// If a party is selected, filter the results based on the selected party
if (!empty($selected_party)) {
    $allApplicationsSql .= " AND s.parties = ?";
}

$stmt = $conn->prepare($allApplicationsSql);
if (!empty($selected_party)) {
    $stmt->bind_param("ss", $admin_entity, $selected_party);
} else {
    $stmt->bind_param("s", $admin_entity);
}
$stmt->execute();
$allApplicationsResult = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Staff Leave</title>
    <link rel="stylesheet" href="css/admin_manage_leave.css">
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/admin_top_nav.css"> 
    <script src="js/admin_top_nav.js"></script> 
</head>
<body>
    <?php include 'admin_top_nav.php'; ?>
    
    <h2>All Leave Applications</h2>
    
    <!-- Party Filter Dropdown -->
    <div class="party-filter">
        <form method="GET" action="">
            <label for="party">Filter by Party:</label>
            <select name="party" id="party" onchange="this.form.submit()">
                <option value="">-- Select Party --</option>
                <?php while ($party_row = $party_result->fetch_assoc()): ?>
                    <option value="<?php echo htmlspecialchars($party_row['party_name']); ?>"
                        <?php echo ($selected_party === $party_row['party_name']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($party_row['party_name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </form>
    </div>

    <table>
        <thead>
            <tr>
                <th>Email</th>
                <th>Employee ID</th>
                <th>Parties</th>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason</th>
                <th>File</th>
                <th>Status</th>
                <th>Approve Date</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $allApplicationsResult->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo htmlspecialchars($row['employee_id']); ?></td>
                    <td><?php echo htmlspecialchars($row['parties']); ?></td>
                    <td><?php echo htmlspecialchars($row['leave_type']); ?></td>
                    <td><?php echo htmlspecialchars($row['start_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['end_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['reason']); ?></td>
                    <td>
                        <?php if (!empty($row['file_path'])): ?>
                            <a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank">View File</a>
                        <?php else: ?>
                            No File
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                    <td><?php echo htmlspecialchars($row['approve_date']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Export to Excel -->
    <form method="post" action="export_excel.php">
    <input type="hidden" name="party" value="<?php echo htmlspecialchars($selected_party); ?>" />
    <button type="submit">Export as Excel</button>
</form>

</body>
</html>
