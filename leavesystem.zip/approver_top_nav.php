<!-- Staff Top Navigation -->
<div class="top-nav-container">
    <div class="top-nav">
        <!-- Logo beside the navigation bar -->
        <div class="logo-container" id="logo-container">
            <img src="images/logo.jpg" alt="Logo" class="logo">
        </div>
        <!-- Navigation Links -->
        <ul class="nav-links" id="nav-links">
            <li><a href="approver_dashboard.php">Dashboard</a></li>
                <li><a href="approver_logout.php" class="logout-btn">Logout</a></li>
        </ul>
        <!-- Hamburger Button for Mobile -->
        <button class="hamburger-menu" id="hamburger-btn">&#9776;</button>
    </div>
</div>

<!-- Mobile Menu (Initially hidden) -->
<div class="mobile-menu">
    <ul>
        <li><a href="approver_dashboard.php">Dashboard</a></li>
            <li><a href="approver_logout.php" class="logout-btn">Logout</a></li>
    </ul>
</div>
