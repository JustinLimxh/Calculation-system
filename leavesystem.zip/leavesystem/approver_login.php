<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
?>

<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    require_once 'config.php';

    // Sanitize and validate inputs
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];

    // Check if email is valid
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format.";
        exit();
    }

    // Check if email exists in approver table
    $sql = "SELECT * FROM approver WHERE email=? AND status='active'";  // Check for active status
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $approver = $result->fetch_assoc();

        // Verify password
        if (password_verify($password, $approver['password'])) {
            // Regenerate session ID to prevent session fixation
            session_regenerate_id(true);

            // Store session variables for approver
            $_SESSION['email'] = $approver['email'];
            $_SESSION['approver_id'] = $approver['id'];  // Store the approver's ID
            $_SESSION['approver_entity'] = $approver['entity'];  // Store the approver's entity

            header("Location: approver_dashboard.php"); // Redirect to approver's dashboard
            exit();
        } else {
            echo "Invalid login credentials.";
        }
    } else {
        echo "Invalid login credentials.";
    }

    // Close the connection
    $conn->close();
}
?>
