<?php
session_start();
require_once 'config.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if the admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

// Check if approver ID is provided in the URL
if (isset($_GET['id'])) {
    $approver_id = $_GET['id'];
    $sql = "SELECT * FROM approver WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $approver_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $approver = $result->fetch_assoc();
    $stmt->close();

    if (!$approver) {
        echo "approver not found.";
        exit();
    }
} else {
    echo "Invalid approver ID.";
    exit();
}

// Fetch all parties and departments from the database
$parties_sql = "SELECT id, party_name FROM parties";
$parties_result = $conn->query($parties_sql);


// Handle form submission to update approver details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $parties = $_POST['parties'];  // Party name

    // Check if new password is provided and matches the confirm password
    if (!empty($_POST['new_password']) && $_POST['new_password'] === $_POST['confirm_password']) {
        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);  // Hash the new password

        // Update approver details with new password
        $sql = "UPDATE approver SET name = ?, email = ?, parties = ?, password = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssi", $name, $email, $parties, $new_password, $_POST['id']);
    } else {
        // Update approver details without changing the password
        $sql = "UPDATE approver SET name = ?, email = ?, parties = ? = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $name, $email, $parties, $_POST['id']);
    }

    if ($stmt->execute()) {
        $_SESSION['message'] = "approver details updated successfully!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error updating approver details.";
        $_SESSION['message_type'] = "error";
    }
    $stmt->close();
    header("Location: admin_edit_delete_approver.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit approver</title>
    <link rel="stylesheet" href="css/admin_edit_approver.css">
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/admin_top_nav.css">
      <script src="js/admin_top_nav.js"></script> 
</head>
<body>
    <?php include 'admin_top_nav.php'; ?>
    
    <div class="edit-delete-container">
        <!-- Success/Error Message -->
        <?php if (isset($_SESSION['message'])): ?>
            <div class="message <?php echo $_SESSION['message_type']; ?>">
                <?php
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    unset($_SESSION['message_type']);
                ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="approver-edit-form"> 
            <h2>Edit approver Details</h2>
            <input type="hidden" name="id" value="<?php echo $approver['id']; ?>">

            <label for="name">Name</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($approver['name']); ?>" required>

            <label for="email">Email</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($approver['email']); ?>" required>

           <!-- Parties Dropdown -->
<label for="parties">Parties</label>
<div class="select-container">
    <select name="parties" required>
        <option value="">Select Party</option>
        <?php if ($parties_result->num_rows > 0): ?>
            <?php while ($party = $parties_result->fetch_assoc()): ?>
                <option value="<?php echo $party['party_name']; ?>" <?php echo ($party['party_name'] == $approver['parties']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($party['party_name']); ?>
                </option>
            <?php endwhile; ?>
        <?php else: ?>
            <option value="">No parties available</option>
        <?php endif; ?>
    </select>
</div>

            <!-- Password Fields -->
            <label for="new_password">New Password</label>
            <input type="password" name="new_password" placeholder="Enter new password">

            <label for="confirm_password">Confirm New Password</label>
            <input type="password" name="confirm_password" placeholder="Confirm new password">

            <button type="submit" class="btn edit-btn">Update</button>
        </form>
    </div>

    <script>
        // Client-side validation to check if passwords match
        document.querySelector('.approver-edit-form').addEventListener('submit', function(event) {
            const newPassword = document.querySelector('[name="new_password"]').value;
            const confirmPassword = document.querySelector('[name="confirm_password"]').value;

            // Check if both passwords match
            if (newPassword !== confirmPassword) {
                alert('The new password and confirm password do not match.');
                event.preventDefault(); // Prevent form submission
            }
        });
    </script>
</body>
</html>

