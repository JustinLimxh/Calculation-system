document.addEventListener('DOMContentLoaded', () => {
    // Select the hamburger icon and mobile menu
    const hamburgerIcon = document.querySelector('.hamburger-menu');
    const mobileMenu = document.querySelector('.mobile-menu');

    if (hamburgerIcon && mobileMenu) {
        // Toggle the mobile menu when the hamburger icon is clicked
        hamburgerIcon.addEventListener('click', () => {
            mobileMenu.classList.toggle('open'); // Toggle 'open' class to show/hide menu
        });

        // Close the menu if clicking outside of it
        document.addEventListener('click', (event) => {
            if (!mobileMenu.contains(event.target) && !hamburgerIcon.contains(event.target)) {
                mobileMenu.classList.remove('open'); // Close the menu if clicked outside
            }
        });
    }
});
