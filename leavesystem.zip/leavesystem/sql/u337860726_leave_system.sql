-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Jan 13, 2025 at 05:48 AM
-- Server version: 10.11.10-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `u337860726_leave_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `entity` varchar(255) NOT NULL,
  `status` varchar(10) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `entity`, `status`) VALUES
(1, 'lim', 'p23015413@student.newinti.edu.my', '$2y$10$eLyQzAxXA06VGhaPk22WPekk4PSHN3VFNAs/hKHiEiQlY1fI0Fky6', 'DHL', 'active'),
(2, 'lim', 'lim@gmail.com', '$2y$10$OzRT.ALRzSF8omFXmF2h6.7wB1f/Cj/fw10OShj3nf53TnX8QTKn.', 'Maybank', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `admin_leave_applications`
--

CREATE TABLE `admin_leave_applications` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `leave_type` enum('annual_leave','medical_leave','unpaid_leave') NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` text NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_leave_applications`
--

INSERT INTO `admin_leave_applications` (`id`, `admin_id`, `leave_type`, `start_date`, `end_date`, `reason`, `file_path`, `status`) VALUES
(1, 1, 'medical_leave', '2025-01-08', '2025-01-10', 'sick', 'uploads/677ddf28e71d6_Screenshot 2024-12-19 080713.png', 'Approved');

-- --------------------------------------------------------

--
-- Table structure for table `admin_leave_types`
--

CREATE TABLE `admin_leave_types` (
  `id` int(11) NOT NULL,
  `admin_id` int(11) NOT NULL,
  `annual_leave` int(11) DEFAULT 0,
  `medical_leave` int(11) DEFAULT 0,
  `unpaid_leave` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_leave_types`
--

INSERT INTO `admin_leave_types` (`id`, `admin_id`, `annual_leave`, `medical_leave`, `unpaid_leave`) VALUES
(2, 1, 10, 2, 5);

-- --------------------------------------------------------

--
-- Table structure for table `approver`
--

CREATE TABLE `approver` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `entity` varchar(100) NOT NULL,
  `parties` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','inactive') CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `approver`
--

INSERT INTO `approver` (`id`, `name`, `email`, `password`, `entity`, `parties`, `created_at`, `status`) VALUES
(1, 'approver', 'ap@gmail.com', '$2y$10$3ZfJBags93rgSdyxaZkPeu84fPyqF3K4rOnwmXan1mmiMp3ZKcJ5C', 'DHL', 'Bayan Lepas', '2025-01-13 02:55:12', 'active'),
(2, 'justin', 'justinlimxh@gmail.com', '$2y$10$CHrF15fR1gX97n8q1Jwrbe8QvrwJHCmNiD1FPWcP5kqUzMhziLD5K', 'DHL', 'Batu Kawan', '2025-01-13 02:55:12', 'active'),
(3, 'approver2', 'ap2@gmail.com', '$2y$10$MNT5oKU8pn/ZOXx69iS.xue6SZ9pdbskN81rAEaG5EqfXXfBemSk2', 'DHL', 'Butterworth', '2025-01-13 10:58:48', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `id` int(11) NOT NULL,
  `department_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`id`, `department_name`) VALUES
(2, 'Secretary '),
(3, 'Finance'),
(4, 'Project Manager'),
(5, 'Marketing');

-- --------------------------------------------------------

--
-- Table structure for table `entity`
--

CREATE TABLE `entity` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `entity`
--

INSERT INTO `entity` (`id`, `name`) VALUES
(1, 'DHL'),
(9, 'Maybank'),
(8, 'Shopee');

-- --------------------------------------------------------

--
-- Table structure for table `leave_applications`
--

CREATE TABLE `leave_applications` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `leave_type` varchar(220) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `reason` text NOT NULL,
  `file_path` varchar(255) DEFAULT NULL,
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `approve_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leave_applications`
--

INSERT INTO `leave_applications` (`id`, `staff_id`, `leave_type`, `start_date`, `end_date`, `reason`, `file_path`, `status`, `approve_date`) VALUES
(1, 1, 'annual_leave', '2025-01-09', '2025-01-10', 'Leave plz', 'uploads/677dddfda4c87_Screenshot 2024-12-19 080713.png', 'Approved', '0000-00-00 00:00:00'),
(2, 1, 'medical_leave', '2025-01-08', '2025-01-08', 'sick', 'uploads/677e195f93e49_Screenshot 2024-12-19 080713.png', 'Approved', '2025-01-10 11:06:15'),
(3, 3, 'annual_leave', '2025-01-10', '2025-01-11', 'sick', 'uploads/677f7c523c222_Screenshot 2024-12-19 080713.png', 'Rejected', '2025-01-10 10:19:13'),
(5, 4, 'annual_leave', '2025-01-09', '2025-01-17', '123', 'uploads/677f863e998c4_Screenshot 2024-12-19 080713.png', 'Approved', '2025-01-10 10:52:38'),
(6, 3, 'annual_leave', '2025-01-22', '2025-01-24', '123', 'uploads/67806d106fc22_Screenshot 2025-01-10 082136.png', 'Approved', '2025-01-10 02:15:02'),
(8, 1, 'annual_leave', '2025-01-10', '2025-01-12', '123', 'uploads/67808e3651181_Screenshot 2025-01-10 082136.png', 'Pending', '2025-01-10 11:16:10'),
(11, 1, 'Half Morning Annual Leave', '2025-01-16', '2025-01-17', '123', 'uploads/6780d2360e195_Screenshot 2025-01-10 082136.png', 'Pending', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `leave_types`
--

CREATE TABLE `leave_types` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `Annual Leave` int(11) DEFAULT 0,
  `Medical Leave` int(11) DEFAULT 0,
  `Unpaid Leave` int(11) DEFAULT 0,
  `Emergency Leave` int(11) DEFAULT 0,
  `Half Morning Annual Leave` int(11) DEFAULT 0,
  `Half Afternoon Annual Leave` int(11) DEFAULT 0,
  `Maternity Leave` int(11) DEFAULT 0,
  `Paternity Leave` int(11) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `leave_types`
--

INSERT INTO `leave_types` (`id`, `staff_id`, `Annual Leave`, `Medical Leave`, `Unpaid Leave`, `Emergency Leave`, `Half Morning Annual Leave`, `Half Afternoon Annual Leave`, `Maternity Leave`, `Paternity Leave`) VALUES
(1, 1, 111, 111, 11, 11, 11, 11, 11, 11),
(3, 3, 88, 5, 5, 10, 10, 10, 10, 10),
(4, 4, 73, 5, 5, 0, 0, 0, 0, 0),
(5, 6, 10, 5, 5, 0, 5, 5, 7, 7),
(6, 7, 10, 5, 5, 0, 5, 5, 7, 7),
(7, 8, 10, 5, 5, 0, 5, 5, 7, 7),
(8, 9, 10, 5, 5, 0, 5, 5, 7, 7);

-- --------------------------------------------------------

--
-- Table structure for table `parties`
--

CREATE TABLE `parties` (
  `id` int(11) NOT NULL,
  `party_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `parties`
--

INSERT INTO `parties` (`id`, `party_name`) VALUES
(11, 'Batu Kawan'),
(12, 'GeorgeTown'),
(13, 'Bayan Lepas'),
(15, 'Butterworth');

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `employee_id` varchar(20) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `entity` varchar(255) NOT NULL,
  `department` varchar(255) DEFAULT NULL,
  `parties` varchar(255) NOT NULL DEFAULT 'internal',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `employee_id`, `name`, `email`, `password`, `entity`, `department`, `parties`, `created_at`, `status`) VALUES
(1, 'B12344', 'lim', 'justinlimxh2002@gmail.com', '$2y$10$nADG4Eg9FL/fWz27wMR2OOZB.I0Xomzl2RLRJ8SGoHjLxNKn4r0c.', 'DHL', 'Project Manager', 'Batu Kawan', '2025-01-09 00:20:52', 'active'),
(3, 'B12345', 'test', 'test1@gmail.com', '$2y$10$jcDgTWL9qlwjXQ6fyHqZcuYopZVIbvozM6zO8JEhzGRLXZ3YvEcvu', 'DHL', 'Secretary ', 'Bayan Lepas', '2025-01-09 00:44:59', 'active'),
(4, 'B12346', 'test2', 'test2@gmail.com', '$2y$10$GeBd7BTcrOk4.cm1m1.n5.KS7kySGUME2FgB6of/0SGF2kKAzvf0q', 'DHL', 'Marketing', 'Bayan Lepas', '2025-01-09 00:50:03', 'active'),
(5, 'B12347', 'test3', 'test3@gmail.com', '$2y$10$3GSRu3yw9FX0QdzRuZn37OWMtgfM.u0wh5Q.0XucgEhCFIOY.3wAy', 'DHL', 'Secretary ', 'Batu Kawan', '2025-01-10 06:00:15', 'active'),
(6, 'B12347', 'test4', 'test4@gmail.com', '$2y$10$ZREWj0oZCk.pSOxi8ljHtuE9UUFOKuAoYz//nfN0YZr4ABDd/b3.G', 'DHL', 'Secretary ', 'Batu Kawan', '2025-01-10 06:01:02', 'active'),
(7, 'B12348', 'test5', 'test5@gmail.com', '$2y$10$RZFMa/dKTxt/mwgn5D0ga.kdD8pFguS0JyUki6HO94ioF2MHrI9mm', 'DHL', 'Marketing', 'GeorgeTown', '2025-01-13 00:47:06', 'active'),
(8, 'B12348', 'test6', 'test6@gmail.com', '$2y$10$0/GUfrf7/.cbPu1gc4sMy.p2p5E9t.OunCTbsgv9r6zSx.OW7adV.', 'DHL', 'Finance', 'Batu Kawan', '2025-01-13 00:47:44', 'active'),
(9, 'B12349', 'test7', 'test7@gmail.com', '$2y$10$zdt79shUH1jEjDKF95PwQe89.Tl0DB8m921LVM8ZEHaU.2M15.bCq', 'DHL', 'Finance', 'GeorgeTown', '2025-01-13 08:55:52', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `super_admin`
--

CREATE TABLE `super_admin` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `super_admin`
--

INSERT INTO `super_admin` (`id`, `email`, `password`) VALUES
(1, 'limefires.my@gmail.com', '$2y$10$w.muKnjSTgrUmRwjspIHgOoMXZEoWy3NfgxpXYt9YC5zqDG2BzF9W');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `admin_leave_applications`
--
ALTER TABLE `admin_leave_applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `admin_leave_types`
--
ALTER TABLE `admin_leave_types`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_admin_id` (`admin_id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Indexes for table `approver`
--
ALTER TABLE `approver`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `entity`
--
ALTER TABLE `entity`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `leave_applications`
--
ALTER TABLE `leave_applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_id` (`staff_id`);

--
-- Indexes for table `leave_types`
--
ALTER TABLE `leave_types`
  ADD PRIMARY KEY (`id`),
  ADD KEY `leave_types_ibfk_1` (`staff_id`);

--
-- Indexes for table `parties`
--
ALTER TABLE `parties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `super_admin`
--
ALTER TABLE `super_admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `admin_leave_applications`
--
ALTER TABLE `admin_leave_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admin_leave_types`
--
ALTER TABLE `admin_leave_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `approver`
--
ALTER TABLE `approver`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `entity`
--
ALTER TABLE `entity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `leave_applications`
--
ALTER TABLE `leave_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `leave_types`
--
ALTER TABLE `leave_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `parties`
--
ALTER TABLE `parties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `super_admin`
--
ALTER TABLE `super_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `admin_leave_applications`
--
ALTER TABLE `admin_leave_applications`
  ADD CONSTRAINT `admin_leave_applications_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admin_leave_types` (`admin_id`) ON DELETE CASCADE;

--
-- Constraints for table `admin_leave_types`
--
ALTER TABLE `admin_leave_types`
  ADD CONSTRAINT `admin_leave_types_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `admin` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `leave_applications`
--
ALTER TABLE `leave_applications`
  ADD CONSTRAINT `leave_applications_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `leave_types` (`staff_id`) ON DELETE CASCADE;

--
-- Constraints for table `leave_types`
--
ALTER TABLE `leave_types`
  ADD CONSTRAINT `leave_types_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
