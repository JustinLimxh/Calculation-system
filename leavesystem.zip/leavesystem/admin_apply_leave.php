<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

require_once 'config.php';

// Fetch logged-in admin's email
$admin_email = $_SESSION['email'];

// Fetch admin_id from the admin table
$sql = "SELECT id FROM admin WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$stmt->bind_result($admin_id);
$stmt->fetch();
$stmt->close();

if (!$admin_id) {
    die("admin record not found.");
}

// Fetch all leave balances from the leave_types table dynamically
$sql = "SELECT * FROM admin_leave_types WHERE admin_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$leave_data = $result->fetch_assoc();
$stmt->close();

if (!$leave_data) {
    die("Leave record not found.");
}

$admin_leave_types = array_filter(array_keys($leave_data), function ($key) {
    return $key !== 'admin_id';
});

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $leave_type = $_POST['leave_type'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $reason = trim($_POST['reason']);
    $file_path = null;

    // Validate selected leave type
    if (!array_key_exists($leave_type, $leave_data)) {
        $error_message = "Invalid leave type selected.";
    } else {
        $current_balance = (int)$leave_data[$leave_type];

        // Calculate number of leave days
        $days_requested = (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24) + 1;

        if ($current_balance < $days_requested) {
            $error_message = "Insufficient $leave_type balance.";
        } else {
            // File upload handling
            if (isset($_FILES['supporting_file']) && $_FILES['supporting_file']['error'] == UPLOAD_ERR_OK) {
                $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
                $file_type = mime_content_type($_FILES['supporting_file']['tmp_name']);

                if (in_array($file_type, $allowed_types)) {
                    $target_dir = "uploads/";
                    if (!is_dir($target_dir)) {
                        mkdir($target_dir, 0777, true);
                    }
                    $file_name = uniqid() . "_" . basename($_FILES['supporting_file']['name']);
                    $target_file = $target_dir . $file_name;

                    if (move_uploaded_file($_FILES['supporting_file']['tmp_name'], $target_file)) {
                        $file_path = $target_file;
                    } else {
                        $error_message = "Failed to upload file. Please try again.";
                    }
                } else {
                    $error_message = "Invalid file type. Only JPEG, PNG, or PDF files are allowed.";
                }
            }

            if (empty($error_message)) {
                // Insert leave application using admin_id instead of admin_email
                $sql = "INSERT INTO admin_leave_applications (admin_id, leave_type, start_date, end_date, reason, file_path, status) 
                        VALUES (?, ?, ?, ?, ?, ?, 'Pending')";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssss", $admin_id, $leave_type, $start_date, $end_date, $reason, $file_path);

                if ($stmt->execute()) {
                    $success_message = "Leave application submitted successfully.";

                    // Fetch all super admin emails from the database
                    $super_admin_emails = [];
                    $super_admin_query = "SELECT email FROM super_admin";
                    $result = $conn->query($super_admin_query);

                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $super_admin_emails[] = $row['email'];
                        }
                    }

                    // Send success email to admin
                    $to_admin = $admin_email;
                    $subject_admin = "Leave Application Confirmation";
                    $message_admin = "
                    <html>
                    <head>
                        <title>Leave Application Submitted</title>
                    </head>
                    <body>
                        <p>Dear admin,</p>
                        <p>Your leave application has been successfully submitted.</p>
                        <p><strong>Details:</strong></p>
                        <ul>
                            <li><strong>Leave Type:</strong> {$leave_type}</li>
                            <li><strong>Start Date:</strong> {$start_date}</li>
                            <li><strong>End Date:</strong> {$end_date}</li>
                            <li><strong>Reason:</strong> {$reason}</li>
                        </ul>
                        <p>Status: <strong>Pending</strong></p>
                        <p>Thank you!</p>
                    </body>
                    </html>
                    ";

                    // Email headers
                    $headers = "MIME-Version: 1.0" . "\r\n";
                    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                    $headers .= "From: no-reply@nasiandsambal.com" . "\r\n";

                    // Send email to admin
                    mail($to_admin, $subject_admin, $message_admin, $headers);

                    // Send success email to all super admins
                    foreach ($super_admin_emails as $to_super_admin) {
                        $subject_super_admin = "New Leave Application Submitted";
                        $message_super_admin = "
                        <html>
                        <head>
                            <title>New Leave Application</title>
                        </head>
                        <body>
                            <p>Dear Super Admin,</p>
                            <p>A new leave application has been submitted by <strong>{$admin_email}</strong>.</p>
                            <p><strong>Details:</strong></p>
                            <ul>
                                <li><strong>Leave Type:</strong> {$leave_type}</li>
                                <li><strong>Start Date:</strong> {$start_date}</li>
                                <li><strong>End Date:</strong> {$end_date}</li>
                                <li><strong>Reason:</strong> {$reason}</li>
                            </ul>
                            <p>Status: <strong>Pending</strong></p>
                            <p>Thank you!</p>
                        </body>
                        </html>
                        ";

                        // Send email to super admin
                        mail($to_super_admin, $subject_super_admin, $message_super_admin, $headers);
                    }
                } else {
                    $error_message = "Error submitting leave application. Please try again.";
                }
                $stmt->close();
            }
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply Leave</title>
    <link rel="stylesheet" href="css/apply_leave.css">
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/admin_top_nav.css">
            <script src="js/admin_top_nav.js"></script> 
</head>
<body>

    <?php include('admin_top_nav.php'); ?>
    <div class="profile-container">
        <h1>Apply for Leave</h1>

        <?php if ($error_message): ?>
            <p class="error"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>
        <?php if ($success_message): ?>
            <p class="success"><?php echo htmlspecialchars($success_message); ?></p>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <label for="leave_type">Leave Type:</label>
            <select name="leave_type" id="leave_type" required>
                <?php
                $isFirst = true;
                foreach ($admin_leave_types as $type):
                    if ($isFirst) {
                        $isFirst = false;
                        continue;
                    }
                ?>
                    <option value="<?php echo htmlspecialchars($type); ?>">
                        <?php echo ucfirst(str_replace('_', ' ', $type)); ?> 
                        (Remaining: <?php echo htmlspecialchars($leave_data[$type]); ?> days)
                    </option>
                <?php endforeach; ?>
            </select>

            <label for="start_date">Start Date:</label>
            <input type="date" id="start_date" name="start_date" required>

            <label for="end_date">End Date:</label>
            <input type="date" id="end_date" name="end_date" required>

            <label for="reason">Reason:</label>
            <textarea id="reason" name="reason" rows="4" required></textarea>

            <label for="supporting_file">Supporting File (JPEG, PNG, or PDF):</label>
            <input type="file" id="supporting_file" name="supporting_file" accept="image/jpeg, image/png, application/pdf">

            <button type="submit">Submit</button>
        </form>
    </div>
</body>
</html>
