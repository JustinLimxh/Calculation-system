<?php
session_start();
require_once 'config.php';

// Check if the admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

// Check if staff ID is provided in the URL
if (isset($_GET['id'])) {
    $staff_id = $_GET['id'];
    $sql = "SELECT * FROM staff WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $staff_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $staff = $result->fetch_assoc();
    $stmt->close();

    if (!$staff) {
        echo "Staff not found.";
        exit();
    }
} else {
    echo "Invalid staff ID.";
    exit();
}

// Fetch all parties and departments from the database
$parties_sql = "SELECT id, party_name FROM parties";
$parties_result = $conn->query($parties_sql);

$department_sql = "SELECT id, department_name FROM department";
$department_result = $conn->query($department_sql);
// Handle form submission to update staff details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $employee_id = $_POST['employee_id'];
    $parties = $_POST['parties'];  // Party name
    $department = $_POST['department'];  // Department name

    // Check if new password is provided and matches the confirm password
    if (!empty($_POST['new_password']) && $_POST['new_password'] === $_POST['confirm_password']) {
        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);  // Hash the new password

        // Update staff details with new password
        $sql = "UPDATE staff SET name = ?, email = ?, employee_id = ?, parties = ?, department = ?, password = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssi", $name, $email, $employee_id, $parties, $department, $new_password, $_POST['id']);
    } else {
        // Update staff details without changing the password
        $sql = "UPDATE staff SET name = ?, email = ?, employee_id = ?, parties = ?, department = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssi", $name, $email, $employee_id, $parties, $department, $_POST['id']);
    }

    if ($stmt->execute()) {
        $_SESSION['message'] = "Staff details updated successfully!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error updating staff details.";
        $_SESSION['message_type'] = "error";
    }
    $stmt->close();
    header("Location: admin_edit_delete.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Staff</title>
    <link rel="stylesheet" href="css/admin_edit_staff.css">
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/admin_top_nav.css">
      <script src="js/admin_top_nav.js"></script> 
</head>
<body>
    <?php include 'admin_top_nav.php'; ?>
    
    <div class="edit-delete-container">
        <!-- Success/Error Message -->
        <?php if (isset($_SESSION['message'])): ?>
            <div class="message <?php echo $_SESSION['message_type']; ?>">
                <?php
                    echo $_SESSION['message'];
                    unset($_SESSION['message']);
                    unset($_SESSION['message_type']);
                ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="staff-edit-form"> 
            <h2>Edit Staff Details</h2>
            <input type="hidden" name="id" value="<?php echo $staff['id']; ?>">

            <label for="name">Name</label>
            <input type="text" name="name" value="<?php echo htmlspecialchars($staff['name']); ?>" required>

            <label for="email">Email</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($staff['email']); ?>" required>

            <label for="staff_id">Staff ID</label>
            <input type="text" name="employee_id" value="<?php echo htmlspecialchars($staff['employee_id']); ?>" required>

           <!-- Parties Dropdown -->
<label for="parties">Parties</label>
<div class="select-container">
    <select name="parties" required>
        <option value="">Select Party</option>
        <?php if ($parties_result->num_rows > 0): ?>
            <?php while ($party = $parties_result->fetch_assoc()): ?>
                <option value="<?php echo $party['party_name']; ?>" <?php echo ($party['party_name'] == $staff['parties']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($party['party_name']); ?>
                </option>
            <?php endwhile; ?>
        <?php else: ?>
            <option value="">No parties available</option>
        <?php endif; ?>
    </select>
</div>

<!-- Department Dropdown -->
<label for="department">Department</label>
<div class="select-container">
    <select name="department" required>
        <option value="">Select Department</option>
        <?php if ($department_result->num_rows > 0): ?>
            <?php while ($department = $department_result->fetch_assoc()): ?>
                <option value="<?php echo $department['department_name']; ?>" <?php echo ($department['department_name'] == $staff['department']) ? 'selected' : ''; ?>>
                    <?php echo htmlspecialchars($department['department_name']); ?>
                </option>
            <?php endwhile; ?>
        <?php else: ?>
            <option value="">No departments available</option>
        <?php endif; ?>
    </select>
</div>



            <!-- Password Fields -->
            <label for="new_password">New Password</label>
            <input type="password" name="new_password" placeholder="Enter new password">

            <label for="confirm_password">Confirm New Password</label>
            <input type="password" name="confirm_password" placeholder="Confirm new password">

            <button type="submit" class="btn edit-btn">Update</button>
        </form>
    </div>

    <script>
        // Client-side validation to check if passwords match
        document.querySelector('.staff-edit-form').addEventListener('submit', function(event) {
            const newPassword = document.querySelector('[name="new_password"]').value;
            const confirmPassword = document.querySelector('[name="confirm_password"]').value;

            // Check if both passwords match
            if (newPassword !== confirmPassword) {
                alert('The new password and confirm password do not match.');
                event.preventDefault(); // Prevent form submission
            }
        });
    </script>
</body>
</html>

