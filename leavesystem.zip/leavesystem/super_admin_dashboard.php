<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: super_admin_login.html"); // Redirect to login if not logged in
    exit();
}

// Database configuration
require_once 'config.php';

// Fetch total number of admin accounts
$sql = "SELECT COUNT(*) AS total_admins FROM admin";
$result = $conn->query($sql);
$total_admins = 0;

if ($result && $row = $result->fetch_assoc()) {
    $total_admins = $row['total_admins'];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard</title>
    <link rel="stylesheet" href="css/super_admin_dashboard.css">
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
     <link rel="stylesheet" href="css/super_admin_top_nav.css"> 
         <script src="js/super_admin_top_nav.js"></script> 
</head>
<body class="admin-dashboard">
    <!-- Include Top Navigation Bar -->
    <?php include 'super_admin_top_nav.php'; ?>

    <!-- Dashboard Content -->
    <div class="dashboard-content">
        <h1>Welcome, Super Admin!</h1>
        <p>You're successfully logged in to the super admin dashboard.</p>
        <p>Logged in as: <?php echo $_SESSION['email']; ?></p>

        <a href="logout.php" class="logout-btn">Logout</a>
    </div>
    
    <?php
    $conn->close(); // Close database connection
    ?>
</body>
</html>
