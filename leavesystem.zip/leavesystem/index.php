<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave System</title>
     <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <style>
        /* Reset and body styling */
        body {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            min-height: 100vh;
            background-color: #f4f4f4;
            font-family: Arial, sans-serif;
        }

        /* Logo section */
        .logo-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .logo-container img {
            max-width: 150px;
            height: auto;
        }

        /* Button container styling */
        .login-btn-container {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 15px;
            margin-top: 20px;
        }

        /* Button styling */
        .login-btn {
            padding: 10px 20px;
            font-size: 16px;
            font-weight: bold;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            color: white;
            width: 200px;
            text-align: center;
        }

        .staff-login-btn {
            background-color: #102f53; /* Dark Blue */
        }

        .staff-login-btn:hover {
            background-color: #081a31;
        }

        .admin-login-btn {
            background-color: #cc0000; /* Red */
        }

        .admin-login-btn:hover {
            background-color: #a50000;
        }

        .super-admin-login-btn {
            background-color: #102f53; /* Dark Blue */
        }

        .super-admin-login-btn:hover {
            background-color: #081a31;
        }
        
         .approver-login-btn {
            background-color: #cc0000; /* Dark Blue */
        }

        .approver-login-btn:hover {
            background-color: #a50000;
        }


        /* Register link styling */
        .register-link {
            margin-top: 30px;
            color: #102f53; /* Dark Blue */
            text-decoration: none;
            font-size: 14px;
        }

        .register-link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <!-- Logo Section -->
    <div class="logo-container">
        <img src="images/logo.png" alt="Logo">
    </div>

    <!-- Login Buttons -->
    <div class="login-btn-container">
        <button type="button" class="login-btn staff-login-btn" onclick="window.location.href='staff_login.html'">Staff Login</button>
        <button type="button" class="login-btn admin-login-btn" onclick="window.location.href='admin_login.html'">Admin Login</button>
        <button type="button" class="login-btn super-admin-login-btn" onclick="window.location.href='super_admin_login.html'">Super Admin Login</button>
        <button type="button" class="login-btn approver-login-btn" onclick="window.location.href='approver_login.html'">Approver Login</button>
    </div>

</body>
</html>
