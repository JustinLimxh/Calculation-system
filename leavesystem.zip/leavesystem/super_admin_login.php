<?php
session_start();

require_once 'config.php';

if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Prepare SQL statement
    $sql = "SELECT * FROM super_admin WHERE email='$email'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Check if password matches
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            // Set session and redirect to the admin dashboard
            $_SESSION['email'] = $email;
            header("Location: super_admin_dashboard.php"); // Create a dashboard page
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No user found with that email.";
    }
}

$conn->close();
?>
