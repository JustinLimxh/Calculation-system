
// Get the admin's entity
$admin_email = $_SESSION['email'];
$admin_entity_query = "SELECT entity FROM admin WHERE email = ?";
$stmt = $conn->prepare($admin_entity_query);
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$stmt->bind_result($admin_entity);
$stmt->fetch();
$stmt->close();

// Fetch pending leave applications for the admin's entity
$sql = "SELECT la.id, la.staff_id, la.leave_type, la.start_date, la.end_date, la.reason, la.file_path, la.status, s.name, lt.annual_leave, lt.medical_leave, lt.unpaid_leave 
        FROM leave_applications la 
        INNER JOIN staff s ON la.staff_id = s.id 
        INNER JOIN leave_types lt ON la.staff_id = lt.staff_id
        WHERE la.status = 'Pending' AND s.entity = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $admin_entity);
$stmt->execute();
$result = $stmt->get_result();

// Handle leave application actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $application_id = $_POST['application_id'];
    $action = $_POST['action'];
    $staff_id = $_POST['staff_id'];
    $leave_type = $_POST['leave_type'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Calculate the number of leave days
    $days_requested = (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24) + 1;

    // Update the leave application status and deduct leave balance if approved
    if ($action === 'approve') {
        $status = 'Approved';

        // Deduct the leave balance for the staff
        $balance_column = $leave_type; // annual_leave, medical_leave, unpaid_leave

        // Fetch the current leave balance to ensure no negative deduction
        $balance_query = "SELECT $balance_column FROM leave_types WHERE staff_id = ?";
        $stmt = $conn->prepare($balance_query);
        $stmt->bind_param("i", $staff_id);
        $stmt->execute();
        $stmt->bind_result($current_balance);
        $stmt->fetch();
        $stmt->close();

        // Check if the staff has enough balance
        if ($current_balance >= $days_requested) {
            // Update leave balance
            $update_balance_sql = "UPDATE leave_types SET $balance_column = $balance_column - ? WHERE staff_id = ?";
            $stmt = $conn->prepare($update_balance_sql);
            $stmt->bind_param("ii", $days_requested, $staff_id);
            $stmt->execute();
            $stmt->close();
        } else {
            $message = "Error: Insufficient $leave_type balance for staff ID $staff_id.";
            header("Location: admin_manage_leave.php?error=" . urlencode($message));
            exit();
        }
    } elseif ($action === 'reject') {
        $status = 'Rejected';
    } else {
        $status = 'Pending';
    }

    // Update leave application status
    $update_sql = "UPDATE leave_applications SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("si", $status, $application_id);

    if ($stmt->execute()) {
        // Fetch staff email for sending the email
        $email_query = "SELECT email FROM staff WHERE id = ?";
        $stmt2 = $conn->prepare($email_query);
        $stmt2->bind_param("i", $staff_id);
        $stmt2->execute();
        $stmt2->bind_result($staff_email);
        $stmt2->fetch();
        $stmt2->close();

        // Email staff about the leave application decision
        $subject = "Leave Application Status Update";
        $message = "
        <html>
        <head>
            <title>Leave Application Update</title>
        </head>
        <body>
            <p>Dear Staff,</p>
            <p>Your leave application has been <strong>{$status}</strong>.</p>
            <p><strong>Details:</strong></p>
            <ul>
                <li><strong>Leave Type:</strong> {$leave_type}</li>
                <li><strong>Start Date:</strong> {$start_date}</li>
                <li><strong>End Date:</strong> {$end_date}</li>
                <li><strong>Status:</strong> {$status}</li>
            </ul>
            <p>Thank you!</p>
        </body>
        </html>
        ";

        // Email headers
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: no-reply@nasiandsambal.com" . "\r\n";

        mail($staff_email, $subject, $message, $headers);
        $message = "Leave application has been $status successfully, and the staff has been notified via email.";
    } else {
        $message = "Error updating leave application.";
    }
    $stmt->close();

    header("Location: admin_manage_leave.php?message=" . urlencode($message));
    exit();
}
<h1>Manage Staff Leave Applications</h1>
    <?php if (isset($_GET['message'])): ?>
        <p class="message"><?php echo htmlspecialchars($_GET['message']); ?></p>
    <?php endif; ?>

    <!-- Pending Leave Applications -->
    <table>
        <thead>
            <tr>
                <th>Staff Name</th>
                <th>Staff ID</th>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason</th>
                <th>File</th>
                <th>Current Balance</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['staff_id']); ?></td>
                    <td><?php echo htmlspecialchars($row['leave_type']); ?></td>
                    <td><?php echo htmlspecialchars($row['start_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['end_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['reason']); ?></td>
                    <td>
                        <?php if (!empty($row['file_path'])): ?>
                            <a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank">View File</a>
                        <?php else: ?>
                            No File
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php
                        if ($row['leave_type'] === 'annual_leave') {
                            echo htmlspecialchars($row['annual_leave']) . " days";
                        } elseif ($row['leave_type'] === 'medical_leave') {
                            echo htmlspecialchars($row['medical_leave']) . " days";
                        } else {
                            echo htmlspecialchars($row['unpaid_leave']) . " days";
                        }
                        ?>
                    </td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="application_id" value="<?php echo $row['id']; ?>">
                            <input type="hidden" name="staff_id" value="<?php echo $row['staff_id']; ?>">
                            <input type="hidden" name="leave_type" value="<?php echo $row['leave_type']; ?>">
                            <input type="hidden" name="start_date" value="<?php echo $row['start_date']; ?>">
                            <input type="hidden" name="end_date" value="<?php echo $row['end_date']; ?>">
                            <button type="submit" name="action" value="approve">Approve</button>
                            <button type="submit" name="action" value="reject">Reject</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
     `Annual Leave`, `Medical Leave`, `Unpaid Leave`, `Emergency Leave`, `Half Morning Annual Leave`,  `Half Afternoon Annual Leave`,  `Maternity Leave`,  `Paternity Leave`   
    
    
    lt.Annual Leave, lt.Medical Leave, lt.Unpaid Leave, lt.Emergency Leave, lt.Half Morning Annual Leave, lt.Half Afternoon Annual Leave, lt.Maternity Leave, lt.Paternity Leave  

