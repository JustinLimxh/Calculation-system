<?php
session_start();


if (!isset($_SESSION['email'])) {
    header("Location: staff_login.html");
    exit();
}

require_once 'config.php';

$staff_email = $_SESSION['email'];

// Fetch staff_id based on email
$sql = "SELECT id FROM staff WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $staff_email);
$stmt->execute();
$stmt->bind_result($staff_id);
$stmt->fetch();
$stmt->close();

// Fetch all leave types for the logged-in staff
$sql = "SELECT * FROM leave_types WHERE staff_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $staff_id);
$stmt->execute();
$result = $stmt->get_result();
$leave_data = $result->fetch_assoc();
$stmt->close();
$conn->close();

// Remove staff_id and id from the leave data
unset($leave_data['staff_id']);
unset($leave_data['id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Balance</title>
    <link rel="stylesheet" href="css/leave_balance.css">
     <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/staff_top_nav.css">
    <script src="js/staff_top_nav.js"></script> 
</head>
<body>
     <!-- Include Top Navigation Bar -->
    <?php include('staff_top_nav.php'); ?>

    <div>
        <h2>Your Leave Balance</h2>
        <table>
            <tr>
                <th>Leave Type</th>
                <th>Available</th>
            </tr>
            <?php foreach ($leave_data as $leave_type => $balance): ?>
                <tr>
                    <td><?php echo ucfirst(str_replace('_', ' ', $leave_type)); ?></td>
                    <td><?php echo $balance; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
        <a href="staff_dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
