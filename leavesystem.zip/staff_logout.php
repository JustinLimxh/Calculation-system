<?php
session_start();
session_destroy(); // Destroy the session
header("Location: staff_login.html"); // Redirect to the login page
exit();
?>
