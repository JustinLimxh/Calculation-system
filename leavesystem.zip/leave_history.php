<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

if (!isset($_SESSION['email'])) {
    header("Location: staff_login.html");
    exit();
}

require_once 'config.php';

$staff_email = $_SESSION['email'];

// Fetch staff_id based on email
$sql = "SELECT id FROM staff WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $staff_email);
$stmt->execute();
$stmt->bind_result($staff_id);
$stmt->fetch();
$stmt->close();

// Fetch leave history using staff_id
$sql = "SELECT leave_type, start_date, end_date, reason, status FROM leave_applications WHERE staff_id = ?";
$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Error preparing statement: " . $conn->error);
}

$stmt->bind_param("i", $staff_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if there is any leave data
if ($result->num_rows === 0) {
    $leave_history_message = "No leave history found.";
} else {
    $leave_history_message = "";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave History</title>
    <link rel="stylesheet" href="css/leave_history.css">
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/staff_top_nav.css">
    <script src="js/staff_top_nav.js"></script> 
</head>
<body>
    <!-- Include Top Navigation Bar -->
    <?php include('staff_top_nav.php'); ?>

    <div class="container">
        <h2>Your Leave History</h2>

        <!-- Display a message if no leave history exists -->
        <?php if ($leave_history_message): ?>
            <p><?php echo $leave_history_message; ?></p>
        <?php else: ?>
            <table>
                <tr>
                    <th>Type</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Reason</th>
                    <th>Status</th>
                </tr>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo $row['leave_type']; ?></td>
                        <td><?php echo $row['start_date']; ?></td>
                        <td><?php echo $row['end_date']; ?></td>
                        <td><?php echo $row['reason']; ?></td>
                        <td><?php echo $row['status']; ?></td>
                    </tr>
                <?php endwhile; ?>
            </table>
        <?php endif; ?>

        <a href="staff_dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
