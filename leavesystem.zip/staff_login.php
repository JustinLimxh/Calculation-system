<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['login'])) {
    require_once 'config.php';

    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if email exists
    $sql = "SELECT * FROM staff WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $staff = $result->fetch_assoc();
        
        // Verify password
        if (password_verify($password, $staff['password'])) {
            $_SESSION['email'] = $staff['email'];
            $_SESSION['staff_id'] = $staff['id'];
            header("Location: staff_dashboard.php"); // Redirect to dashboard
            exit();
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "No staff found with this email.";
    }

    $conn->close();
}
?>
