<?php
// Include the database connection
include('config.php');
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Handle the form submission to update leave balances
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_leave'])) {
    // Get the updated leave balances and admin ID from the form
    $admin_id = $_POST['admin_id'];
    $annual_leave = $_POST['annual_leave'];
    $medical_leave = $_POST['medical_leave'];
    $unpaid_leave = $_POST['unpaid_leave'];

    // Update the leave balances in the database
    $update_sql = "UPDATE admin_leave_types SET annual_leave = ?, medical_leave = ?, unpaid_leave = ? WHERE admin_id = ?";
    $stmt = $conn->prepare($update_sql);
    if ($stmt) {
        $stmt->bind_param("iiii", $annual_leave, $medical_leave, $unpaid_leave, $admin_id);

        if ($stmt->execute()) {
            $message = "Leave balances updated successfully for admin ID $admin_id.";
        } else {
            $message = "Error updating leave balances.";
        }

        // Close the statement
        $stmt->close();
    } else {
        $message = "Error preparing update statement.";
    }
}

// Fetch admin leave data if admin_id is provided in the URL
if (isset($_GET['admin_id'])) {
    $admin_id = $_GET['admin_id'];

    // Query the leave_types table for the selected admin
    $sql = "SELECT * FROM admin_leave_types WHERE admin_id = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("i", $admin_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Fetch the data for the admin
            $leave_data = $result->fetch_assoc();
        } else {
            $message = "No leave data found for admin ID $admin_id.";
        }

        // Close the statement
        $stmt->close();
    } else {
        $message = "Error fetching leave data.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Edit Leave</title>
    <link rel="stylesheet" href="css/super_admin_edit_leave.css">
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/super_admin_top_nav.css">
        <script src="js/super_admin_top_nav.js"></script> 
        
</head>
<body>
    <!-- Include Top Navigation Bar -->
    <?php include('super_admin_top_nav.php'); ?>
    <div class="container">
        <h1>Super Admin: Edit Leave Balances</h1>

        <!-- Display success or error message -->
        <?php if (isset($message)): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>

        <!-- Search form for admin ID -->
        <form action="super_admin_edit_leave.php" method="GET" class="search-form">
            <label for="admin_id">Enter Admin ID:</label>
            <input type="number" name="admin_id" id="admin_id" required>
            <button type="submit">Search</button>
        </form>

        <!-- Display admin leave data in an editable form -->
        <?php if (isset($leave_data)): ?>
            <h2>Edit Leave Balances for admin ID: <?php echo $admin_id; ?></h2>
            <form action="super_admin_edit_leave.php" method="POST">
                <input type="hidden" name="admin_id" value="<?php echo $admin_id; ?>">

                <label for="annual_leave">Annual Leave:</label>
                <input type="number" name="annual_leave" id="annual_leave" value="<?php echo $leave_data['annual_leave']; ?>" required>

                <label for="medical_leave">Medical Leave:</label>
                <input type="number" name="medical_leave" id="medical_leave" value="<?php echo $leave_data['medical_leave']; ?>" required>

                <label for="unpaid_leave">Unpaid Leave:</label>
                <input type="number" name="unpaid_leave" id="unpaid_leave" value="<?php echo $leave_data['unpaid_leave']; ?>" required>

                <button type="submit" name="update_leave">Update Leave Balances</button>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>
