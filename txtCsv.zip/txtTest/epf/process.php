<?php
// Database connection
$host = '127.0.0.1'; // Change as necessary
$dbname = 'test-txt'; // Change as necessary
$username = 'root'; // Change as necessary
$password = ''; // Change as necessary

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
    exit;
}

// Get form data
$date = $_POST['date']; // The date from the form will be in yyyy-mm-dd format

// Ensure the date is in the correct format
$dateObj = DateTime::createFromFormat('Y-m-d', $date);
if ($dateObj && $dateObj->format('Y-m-d') === $date) {
    $formattedDate = $dateObj->format('Y-m'); // Format as YYYYmm
} else {
    echo "Invalid date format. Please enter the date as yyyy-mm-dd.";
    exit;
}


// Fetch all staff info
$staffQuery = "SELECT * FROM staffinfo";
$staffStmt = $pdo->prepare($staffQuery);
$staffStmt->execute();

// Prepare the file for writing
$fileName = $formattedDate . " " . "EPF" . ".csv";
$file = fopen($fileName, "w");

if (!$file) {
    echo "Unable to create file.";
    exit;
}

// Write the header row manually (without quotes)
$header = [
    'Member EPF No.',
    'Member IC No.',
    'Member Name',
    'Member Wage',
    'Employer Contribution Amount',
    'Member Contribution Amount',
];
fwrite($file, implode(',', $header) . PHP_EOL);

// Loop through all staff and write their data to the CSV
$totalStaff = 0;
$totalSalary = 0;

while ($staff = $staffStmt->fetch(PDO::FETCH_ASSOC)) {
    $totalStaff++;

    // Write staff data without quotes around names
    $row = [
        $staff['epfNo'],
        $staff['icNo'],
        str_replace('"', '', $staff['name']), // Remove any quotes from the name
        $staff['salary'],
        $staff['epfCon'],
        $staff['epf'],
    ];
    // Manually write the row without quotes
    fwrite($file, implode(',', $row) . PHP_EOL);
}

// Close the file after writing all staff data
fclose($file);

// Read the contents of the generated file
$fileContents = file_get_contents($fileName);

// Format the date as DDMMYYYY
$generateDate = $dateObj->format('dmY');

// Insert the file contents into the database
$query = "INSERT INTO epffile (date, file, fileName) VALUES (:date, :file, :fileName)";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':date', $formattedDate);
$stmt->bindParam(':file', $fileContents, PDO::PARAM_LOB);
$stmt->bindParam(':fileName', $fileName);

$stmt->execute();

// Redirect to displayFile.php
header("Location: displayFile.php");
exit;
