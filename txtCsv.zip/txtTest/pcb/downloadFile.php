<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "test-txt";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get the fileName (not ID) of the file to be downloaded
$fileName = $_GET['fileName'];

// Retrieve the file data from the database
$sql = "SELECT fileName, file FROM pcbfile WHERE fileName = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $fileName); // Bind the fileName parameter
$stmt->execute();
$stmt->bind_result($fileName, $fileData);
$stmt->fetch();
$stmt->close();

// Check if the file data exists
if ($fileData) {
    // Ensure the file is downloaded as a .txt file
    $fileName = pathinfo($fileName, PATHINFO_FILENAME) . ".txt"; // Ensure the file extension is .txt

    // Set headers to trigger the download as a .txt file
    header('Content-Type: text/plain'); // Specify content type as plain text
    header('Content-Disposition: attachment; filename="' . $fileName . '"'); // Specify the filename with .txt extension
    header('Content-Length: ' . strlen($fileData)); // Set the content length for the download

    // Output the file content
    echo $fileData;
} else {
    echo "File not found.";
}

$conn->close();
