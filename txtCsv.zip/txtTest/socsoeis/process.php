<?php
// Database connection
$host = '127.0.0.1'; // Change as necessary
$dbname = 'test-txt'; // Change as necessary
$username = 'root'; // Change as necessary
$password = ''; // Change as necessary

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    echo 'Connection failed: ' . $e->getMessage();
    exit;
}

// Get form data
$date = $_POST['date']; // The date from the form will be in yyyy-mm-dd format

// Ensure the date is in the correct format
$dateObj = DateTime::createFromFormat('Y-m-d', $date);
if ($dateObj && $dateObj->format('Y-m-d') === $date) {
    $formattedDate = $dateObj->format('mY'); // Format as YYYYmm
} else {
    echo "Invalid date format. Please enter the date as yyyy-mm-dd.";
    exit;
}

// Fetch company info
$query = "SELECT socsoNo, regNo2 FROM companyinfo WHERE id = 1";
$stmt = $pdo->prepare($query);
$stmt->execute();
$company = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$company) {
    echo "Company info not found.";
    exit;
}

// Fetch all staff info
$staffQuery = "SELECT * FROM staffinfo";
$staffStmt = $pdo->prepare($staffQuery);
$staffStmt->execute();

// Initialize variables for totals
$totalStaff = 0;
$totalSalary = 0;

// Prepare the file for writing
$fileName = "SOCSO_". "EIS_" . $date . ".txt";
$file = fopen($fileName, "w");

if (!$file) {
    echo "Unable to create file.";
    exit;
}

// Loop through all staff and prepare line 2 for each
while ($staff = $staffStmt->fetch(PDO::FETCH_ASSOC)) {
    $salaryInCents = intval(round($staff['salary'] * 100));
    $socsoConInCents = intval(round($staff['socsoCon']*100));
    $socsoInCents = intval(round($staff['socso'] * 100));
    $eisConInCents = intval(round($staff['eisCon']*100));
    $eisInCents = intval(round($staff['eis']*100));
    $totalStaff++;
    $totalSalary += $salaryInCents;

    // Prepare line 2
    $line2 =
        str_pad(substr($company['socsoNo'], 0, 12), 12, '0', STR_PAD_RIGHT) .
        str_pad(substr($company['regNo2'], 0, 20), 20) .
        str_pad(substr($staff['icNo'], 0, 12), 12) .
        str_pad(substr($staff['name'], 0, 150), 150) .
        str_pad($formattedDate, 6) .
        str_pad($salaryInCents, 14, ' ', STR_PAD_LEFT) .
        str_pad($socsoConInCents, 6, ' ', STR_PAD_LEFT) .
        str_pad($socsoInCents, 6, ' ', STR_PAD_LEFT) .
        str_pad($eisConInCents, 6, ' ', STR_PAD_LEFT) .
        str_pad($eisInCents, 6, ' ', STR_PAD_LEFT) .
        str_repeat(' ', 40) .
        PHP_EOL;

    fwrite($file, $line2); // Write staff data
}
// Close the file after writing all staff data
fclose($file);

// Read the contents of the generated file
$fileContents = file_get_contents($fileName);

// Format the date as DDMMYYYY
$generateDate = $dateObj->format('dmY');

// Insert the file contents into the database
$query = "INSERT INTO socsoeisfile (date, generate_date, file, fileName) VALUES (:date, :generate_date, :file, :fileName)";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':date', $formattedDate);
$stmt->bindParam(':generate_date', $generateDate);
$stmt->bindParam(':file', $fileContents, PDO::PARAM_LOB);
$stmt->bindParam(':fileName', $fileName);

$stmt->execute();

// Redirect to displayFile.php
header("Location: displayFile.php");
exit;
