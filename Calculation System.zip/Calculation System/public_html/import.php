<?php
include 'config.php';

if (isset($_POST["Import"])) {
    echo $filename = $_FILES["file"]["tmp_name"];

    if ($_FILES["file"]["size"] > 0) {
        $file = fopen($filename, "r");

        while (($emapData = fgetcsv($file, 10000, ",")) !== FALSE) {
            // Hash the password before saving it
            $hashedPassword = password_hash($emapData[4], PASSWORD_BCRYPT);

            // Insert data into the `staff` table with the `entity` column
            $sql = "INSERT INTO staff (`id`, `name`, `email`, `password`, `entity`) 
                    VALUES ('$emapData[1]', '$emapData[2]', '$emapData[3]', '$hashedPassword', '$emapData[5]')";

            $result = mysqli_query($conn, $sql);

            if (!$result) {
                echo "<script type=\"text/javascript\">
                        alert(\"Invalid File: Please Upload a Proper CSV File.\");
                        window.location = \"bulk_upload.php\";
                      </script>";
                exit;
            }
        }
        fclose($file);

        // Success message
        echo "<script type=\"text/javascript\">
                alert(\"CSV File has been successfully Imported.\");
                window.location = \"bulk_upload.php\";
              </script>";
    }
    mysqli_close($conn);
}
?>
