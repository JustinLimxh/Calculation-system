<?php
// config.php: Database connection configuration

$host = 'localhost';
$dbname = 'calculation_system';
$username = 'username';
$password = 'password';

$conn = new mysqli($host, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
