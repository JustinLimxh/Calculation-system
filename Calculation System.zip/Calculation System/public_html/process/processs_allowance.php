<?php
// Include your database connection file
include('config.php'); // Adjust the path based on where your db.php is located

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $allowanceType = $_POST['allowanceType'];
    $amount = $_POST['amount'];

    // Example: Get the staff ID from session or other methods (Ensure staff is logged in)
    session_start();
    $staffId = isset($_SESSION['staff_id']) ? $_SESSION['staff_id'] : 1; // Default to 1 for now

    // Check if all necessary fields are filled
    if (!empty($allowanceType) && !empty($amount)) {

        // Ensure amount is a valid number
        if (!filter_var($amount, FILTER_VALIDATE_FLOAT)) {
            echo "<script>
                alert('Invalid amount. Please enter a valid number.');
                window.history.back();
            </script>";
            exit();
        }

        // Define valid allowance types
        $valid_allowance_types = [
            'attendance',
            'mobile',
            'childCare',
            'eduAllow',
            'houseAllow',
            'internAllow',
            'mealAllow',
            'otherAllow',
            'parkingAllow',
            'shiftAllow',
            'travelOAllow',
            'travelPAllow'
        ];

        // Ensure the allowance type is valid
        if (in_array($allowanceType, $valid_allowance_types)) {
            // Check if the allowance already exists in the `allowance` table
            $sql_check = "SELECT * FROM allowance WHERE staff_id = ?";
            if ($stmt_check = $conn->prepare($sql_check)) {
                $stmt_check->bind_param("i", $staffId);
                $stmt_check->execute();
                $result_check = $stmt_check->get_result();

                if ($result_check->num_rows > 0) {
                    // Update the existing allowance in the `allowance` table
                    $sql_update = "UPDATE allowance SET `$allowanceType` = ? WHERE staff_id = ?";
                    if ($stmt_update = $conn->prepare($sql_update)) {
                        $stmt_update->bind_param("di", $amount, $staffId);
                        if ($stmt_update->execute()) {
                            echo "<script>
                                alert('Allowance updated successfully.');
                                window.history.back();
                            </script>";
                        } else {
                            echo "<script>
                                alert('Error updating allowance: " . $stmt_update->error . "');
                                window.history.back();
                            </script>";
                        }
                        $stmt_update->close();
                    } else {
                        echo "<script>
                            alert('Error preparing the update query: " . $conn->error . "');
                            window.history.back();
                        </script>";
                    }
                } else {
                    // Insert the allowance if the staff does not exist in the `allowance` table
                    $sql_insert = "INSERT INTO allowance (staff_id, `$allowanceType`) VALUES (?, ?)";
                    if ($stmt_insert = $conn->prepare($sql_insert)) {
                        $stmt_insert->bind_param("id", $staffId, $amount);
                        if ($stmt_insert->execute()) {
                            echo "<script>
                                alert('Allowance inserted successfully.');
                                window.history.back();
                            </script>";
                        } else {
                            echo "<script>
                                alert('Error inserting allowance: " . $stmt_insert->error . "');
                                window.history.back();
                            </script>";
                        }
                        $stmt_insert->close();
                    } else {
                        echo "<script>
                            alert('Error preparing the insert query: " . $conn->error . "');
                            window.history.back();
                        </script>";
                    }
                }

                $stmt_check->close();
            } else {
                echo "<script>
                    alert('Error preparing the check query: " . $conn->error . "');
                    window.history.back();
                </script>";
            }
        } else {
            echo "<script>
                alert('Invalid allowance type selected.');
                window.history.back();
            </script>";
        }
    } else {
        echo "<script>
            alert('Please fill in all fields.');
            window.history.back();
        </script>";
    }
}

// Close database connection
$conn->close();
