<?php
// Include your database connection file
include('config.php'); // Adjust the path based on where your db.php is located

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $bikType = $_POST['bikType'];
    $amount = $_POST['amount'];

    // Example: Get the staff ID from session or other methods (Ensure staff is logged in)
    session_start();
    $staffId = isset($_SESSION['staff_id']) ? $_SESSION['staff_id'] : 1; // Default to 1 for now

    // Helper function for displaying alerts
    function showAlertAndGoBack($message)
    {
        echo "<script>
            alert('$message');
            window.history.back();
        </script>";
        exit();
    }

    // Check if all necessary fields are filled
    if (!empty($bikType) && !empty($amount)) {

        // Ensure amount is a valid number
        if (!filter_var($amount, FILTER_VALIDATE_FLOAT)) {
            showAlertAndGoBack('Invalid amount. Please enter a valid number.');
        }

        // Define valid benefit types
        $valid_benefit_types = [
            'consumeDiscBik',
            'dentalBik',
            'driverBik',
            'fulfillDutiBik',
            'foodDrinkBik',
            'garmentBik',
            'hElectrikBik',
            'hEntertainBik',
            'hFurniturBik',
            'hGardenBik',
            'hKitchenBik',
            'hServantBik',
            'hTelephoneBik',
            'hUtilitiBik',
            'travelMalayBik',
            'travelOverBik',
            'liviAccoBik',
            'medicalBik',
            'otherBik',
            'clubMemberBik',
            'serviceDiscBik',
            'transportBik',
            'motorcarBik',
            'workAccidentBik',
        ];

        // Ensure the benefit type is valid
        if (in_array($bikType, $valid_benefit_types)) {
            // Check if the benefit already exists in the `benefit` table
            $sql_check = "SELECT * FROM benefit WHERE staff_id = ?";
            if ($stmt_check = $conn->prepare($sql_check)) {
                $stmt_check->bind_param("i", $staffId);
                $stmt_check->execute();
                $result_check = $stmt_check->get_result();

                if ($result_check->num_rows > 0) {
                    // Update the existing benefit in the `benefit` table
                    $sql_update = "UPDATE benefit SET `$bikType` = ? WHERE staff_id = ?";
                    if ($stmt_update = $conn->prepare($sql_update)) {
                        $stmt_update->bind_param("di", $amount, $staffId);
                        if ($stmt_update->execute()) {
                            showAlertAndGoBack('Benefit updated successfully.');
                        } else {
                            showAlertAndGoBack('Error updating benefit: ' . $stmt_update->error);
                        }
                        $stmt_update->close();
                    } else {
                        showAlertAndGoBack('Error preparing the update query: ' . $conn->error);
                    }
                } else {
                    // Insert the benefit if the staff does not exist in the `benefit` table
                    $sql_insert = "INSERT INTO benefit (staff_id, `$bikType`) VALUES (?, ?)";
                    if ($stmt_insert = $conn->prepare($sql_insert)) {
                        $stmt_insert->bind_param("id", $staffId, $amount);
                        if ($stmt_insert->execute()) {
                            showAlertAndGoBack('Benefit inserted successfully.');
                        } else {
                            showAlertAndGoBack('Error inserting benefit: ' . $stmt_insert->error);
                        }
                        $stmt_insert->close();
                    } else {
                        showAlertAndGoBack('Error preparing the insert query: ' . $conn->error);
                    }
                }

                $stmt_check->close();
            } else {
                showAlertAndGoBack('Error preparing the check query: ' . $conn->error);
            }
        } else {
            showAlertAndGoBack('Invalid benefit type selected.');
        }
    } else {
        showAlertAndGoBack('Please fill in all fields.');
    }
}

// Close database connection
$conn->close();
