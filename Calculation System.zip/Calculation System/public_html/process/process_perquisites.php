<?php
// Include your database connection
include('config.php'); // Adjust the path based on where your db.php is located

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Start session to get the staff ID
    session_start();
    $staffId = $_SESSION['staff_id'] ?? 1; // Default to 1 for now

    // Get form data
    $perquisitesType = $_POST['perquisitesType'] ?? '';
    $amount = $_POST['amount'] ?? '';

    // Validate input
    if (empty($perquisitesType) || empty($amount)) {
        echo "<script>
            alert('Please fill in all fields.');
            window.history.back();
        </script>";
        exit();
    }

    if (!filter_var($amount, FILTER_VALIDATE_FLOAT)) {
        echo "<script>
            alert('Invalid amount. Please enter a valid number.');
            window.history.back();
        </script>";
        exit();
    }

    // List of valid perquisites types
    $validPerquisitesTypes = [
        'mobilePerk',
        'carPerk',
        'creditcardPerk',
        'voucherPerk',
        'houseUtilsPerk',
        'houseLoanPerk',
        'parkingPerk',
        'computerPerk',
        'proSubscriptPerk',
        'clubMemberPerk',
        'roadtaxPerk',
        'awardPerk',
        'shareSchemePerk'
    ];

    if (!in_array($perquisitesType, $validPerquisitesTypes, true)) {
        echo "<script>
            alert('Invalid perquisites type.');
            window.history.back();
        </script>";
        exit();
    }

    // Check if the perquisites record already exists
    $sql_check = "SELECT * FROM perquisites WHERE staff_id = ? AND {$perquisitesType} IS NOT NULL";

    if ($stmt_check = $conn->prepare($sql_check)) {
        $stmt_check->bind_param("i", $staffId);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows > 0) {
            // Update existing record
            $sql_update = "UPDATE perquisites SET {$perquisitesType} = ? WHERE staff_id = ?";

            if ($stmt_update = $conn->prepare($sql_update)) {
                $stmt_update->bind_param("di", $amount, $staffId);

                if ($stmt_update->execute()) {
                    echo "<script>
                        alert('Perquisites updated successfully.');
                        window.history.back();
                    </script>";
                } else {
                    echo "<script>
                        alert('Error updating perquisites: {$stmt_update->error}');
                        window.history.back();
                    </script>";
                }
                $stmt_update->close();
            } else {
                echo "<script>
                    alert('Error preparing the update query: {$conn->error}');
                    window.history.back();
                </script>";
            }
        } else {
            // Insert new record
            $sql_insert = "INSERT INTO perquisites (staff_id, {$perquisitesType}) VALUES (?, ?)";

            if ($stmt_insert = $conn->prepare($sql_insert)) {
                $stmt_insert->bind_param("id", $staffId, $amount);

                if ($stmt_insert->execute()) {
                    echo "<script>
                        alert('Perquisites added successfully.');
                        window.history.back();
                    </script>";
                } else {
                    echo "<script>
                        alert('Error inserting perquisites: {$stmt_insert->error}');
                        window.history.back();
                    </script>";
                }
                $stmt_insert->close();
            } else {
                echo "<script>
                    alert('Error preparing the insert query: {$conn->error}');
                    window.history.back();
                </script>";
            }
        }

        $stmt_check->close();
    } else {
        echo "<script>
            alert('Error preparing the check query: {$conn->error}');
            window.history.back();
        </script>";
    }
}

// Close database connection
$conn->close();
