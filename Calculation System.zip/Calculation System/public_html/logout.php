<?php
session_start();
session_unset();
session_destroy();
header("Location: super_admin_login.html"); // Redirect to login after logout
exit();
?>
