<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html"); // Redirect to login page if not logged in
    exit();
}

// Database connection
require_once 'config.php';

// Retrieve admin's entity
$admin_email = $_SESSION['email'];
$sql = "SELECT entity FROM admin WHERE email=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$stmt->bind_result($admin_entity);
$stmt->fetch();
$stmt->close();

// Retrieve parties for dropdown
$parties_query = "SELECT party_name FROM parties";
$parties_result = $conn->query($parties_query);

// Handle staff creation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password
    $entity = $admin_entity; // Set entity to admin's entity
    $party = $_POST['party']; // Selected party

    // Check if email already exists
    $sql = "SELECT * FROM staff WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Staff with this email already exists!');</script>";
    } else {
        // Insert new staff account
        $stmt = $conn->prepare("INSERT INTO staff (name, email, password, entity, parties) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $name, $email, $password, $entity, $party);

        if ($stmt->execute()) {
            echo "<script>alert('New staff registered successfully.');</script>";
            header("Location: admin_dashboard.php"); // Redirect after success
            exit();
        } else {
            echo "Error: " . $stmt->error; // Debug error if insertion fails
        }
    }

    $stmt->close();
}

// Handle adding new party
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_party'])) {
    $new_party = $_POST['new_party'];
    $add_party_sql = "INSERT INTO parties (party_name) VALUES (?)";
    $stmt = $conn->prepare($add_party_sql);
    $stmt->bind_param("s", $new_party);

    if ($stmt->execute()) {
        echo "<script>alert('New party added successfully.');</script>";
        header("Location: admin_create.php");
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Handle deleting a party
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_party'])) {
    $party_id = $_POST['party_id'];

    if (!empty($party_id)) {
        // Check if the party being deleted is 'internal'
        $check_sql = "SELECT party_name FROM parties WHERE id = ?";
        $stmt = $conn->prepare($check_sql);
        $stmt->bind_param("i", $party_id);
        $stmt->execute();
        $stmt->bind_result($party_name);
        $stmt->fetch();
        $stmt->close();

        // Prevent deletion of 'internal' party
        if ($party_name === 'internal') {
            echo "<script>alert('The default party \"internal\" cannot be deleted.');</script>";
        } else {
            // Proceed to delete the party
            $delete_party_sql = "DELETE FROM parties WHERE id = ?";
            $stmt = $conn->prepare($delete_party_sql);
            $stmt->bind_param("i", $party_id);

            if ($stmt->execute()) {
                echo "<script>alert('Party deleted successfully.');</script>";
                header("Location: admin_create.php");
                exit();
            } else {
                echo "Error: " . $stmt->error;
            }
            $stmt->close();
        }
    }
}

// Refresh parties for display
$parties_result_display = $conn->query("SELECT id, party_name FROM parties");

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Staff Account</title>
    <link rel="stylesheet" href="css/admin_create.css">
</head>
<body class="admin-create">

    <!-- Top Navigation Bar -->
    <div class="top-nav">
        <ul>
            <li><a href="admin_dashboard.php">Admin Dashboard</a></li>
            <li><a href="admin_create.php">Create</a></li>
            <li><a href="admin_edit_delete.php">Edit/Delete</a></li>
            <li><a href="bulk_upload.php">Bulk Upload</a></li>
            <li><a href="generate_payslip.php">Generate Payslip</a></li>
            <li><a href="invoicing_portal.php">Invoicing Portal</a></li>
            <li><a href="attendance_summary.php">Attendance Summary</a></li>
            <li><a href="banking_format.php">Banking Format</a></li>
            <li><a href="salary_calculator.php">Salary Calculator</a></li>
        </ul>
    </div>

    <!-- Forms Container: Staff Creation Form and Manage Parties Form -->
    <div class="forms-container">
        <!-- Create Staff Form -->
        <div class="admin-create-form">
            <h2>Create Staff Account</h2>
            <form method="POST" action="admin_create.php">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" required>

                <label for="email">Email:</label>
                <input type="email" id="email" name="email" required>

                <label for="password">Password:</label>
                <input type="password" id="password" name="password" required>

                <label for="entity">Entity:</label>
                <input type="text" id="entity" value="<?php echo htmlspecialchars($admin_entity); ?>" disabled>
                <input type="hidden" name="entity" value="<?php echo htmlspecialchars($admin_entity); ?>">

                <label for="party">Party:</label>
                <select id="party" name="party" required>
                    <?php while ($party = $parties_result->fetch_assoc()) { ?>
                        <option value="<?php echo htmlspecialchars($party['party_name']); ?>">
                            <?php echo htmlspecialchars($party['party_name']); ?>
                        </option>
                    <?php } ?>
                </select>

                <button type="submit" name="register">Create Account</button>
            </form>
        </div>

        <!-- Manage Parties Form -->
        <div class="manage-parties-form">
            <h2>Manage Parties</h2>
            <form method="POST" action="admin_create.php">
                <label for="new_party">Add New Party:</label>
                <input type="text" id="new_party" name="new_party" required>
                <button type="submit" name="add_party">Add Party</button>
            </form>

            <h3>Current Available Parties</h3>
            <ul>
                <?php while ($party = $parties_result_display->fetch_assoc()) { ?>
                    <li>
                        <?php echo htmlspecialchars($party['party_name']); ?>
                        <?php if ($party['party_name'] != 'internal') { ?>
                            <!-- Delete button -->
                            <form method="POST" style="display:inline;">
                                <input type="hidden" name="party_id" value="<?php echo $party['id']; ?>">
                                <button type="submit" name="delete_party" onclick="return confirm('Are you sure you want to delete this party?')">Delete</button>
                            </form>
                        <?php } ?>
                    </li>
                <?php } ?>
            </ul>
        </div>
    </div>

</body>
</html>
