<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html"); // Redirect to login page if not logged in
    exit();
}

// Database connection
require_once 'config.php';

// Retrieve admin's entity
$admin_email = $_SESSION['email'];
$sql = "SELECT entity FROM admin WHERE email=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$stmt->bind_result($admin_entity);
$stmt->fetch();
$stmt->close();

// Handle staff creation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password
    $entity = $admin_entity; // Set entity to admin's entity

    // Check if email already exists
    $sql = "SELECT * FROM staff WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Staff with this email already exists!');</script>";
    } else {
        // Insert new staff account
        $stmt = $conn->prepare("INSERT INTO staff (name, email, password, entity) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $password, $entity);

        if ($stmt->execute()) {
            echo "<script>alert('New staff registered successfully.');</script>";
            header("Location: admin_dashboard.php"); // Redirect after success
            exit();
        } else {
            echo "Error: " . $stmt->error; // Debug error if insertion fails
        }
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Staff Account</title>
    <link rel="stylesheet" href="css/admin_create.css">
</head>
<body class="admin-create">

    <!-- Top Navigation Bar -->
    <div class="top-nav">
        <ul>
            <li><a href="admin_dashboard.php">Admin Dashboard</a></li> <!-- Added Admin Dashboard link -->
            <li><a href="admin_create.php">Create</a></li>
            <li><a href="admin_edit_delete.php">Edit/Delete</a></li>
            <li><a href="bulk_upload.php">Bulk Upload</a></li>
            <li><a href="generate_payslip.php">Generate Payslip</a></li>
            <li><a href="invoicing_portal.php">Invoicing Portal</a></li>
            <li><a href="attendance_summary.php">Attendance Summary</a></li>
            <li><a href="banking_format.php">Banking Format</a></li>
            <li><a href="salary_calculator.php">Salary Calculator</a></li>
        </ul>
    </div>

    <!-- Create Staff Form -->
    <div class="admin-create-form">
        <h2>Create Staff Account</h2>

        <form method="POST" action="admin_create.php">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <!-- Display Entity (Readonly) -->
            <label for="entity">Entity:</label>
            <input type="text" id="entity" value="<?php echo htmlspecialchars($admin_entity); ?>" disabled>
            <input type="hidden" name="entity" value="<?php echo htmlspecialchars($admin_entity); ?>">

            <button type="submit" name="register">Create Account</button>
        </form>

        <a href="admin_dashboard.php">Back to Dashboard</a>
    </div>

</body>
</html>
