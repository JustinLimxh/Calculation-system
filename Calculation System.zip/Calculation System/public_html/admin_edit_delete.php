<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

require_once 'config.php';

// Fetch the logged-in admin's entity from session
$admin_entity = $_SESSION['admin_entity'];  // Retrieve the entity stored in the session

// Handle delete operation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $delete_id = $_POST['delete_id'];
    $sql = "DELETE FROM staff WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $delete_id);
    if ($stmt->execute()) {
        $_SESSION['message'] = "Staff account deleted successfully!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error deleting staff account.";
        $_SESSION['message_type'] = "error";
    }
    $stmt->close();
}

// Handle edit operation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_id'])) {
    $edit_id = $_POST['edit_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password']; // Get the new password

    if (!empty($password)) {
        // Hash the password before saving to the database
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        $sql = "UPDATE staff SET name = ?, email = ?, password = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $name, $email, $hashed_password, $edit_id);
    } else {
        // Update only name and email if password is not provided
        $sql = "UPDATE staff SET name = ?, email = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssi", $name, $email, $edit_id);
    }

    if ($stmt->execute()) {
        $_SESSION['message'] = "Staff account updated successfully!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error updating staff account.";
        $_SESSION['message_type'] = "error";
    }

    $stmt->close();
}

// Fetch staff accounts based on the logged-in admin's entity
$sql = "SELECT id, name, email, entity FROM staff WHERE entity = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $admin_entity);  // Use the admin's entity to filter staff
$stmt->execute();
$result = $stmt->get_result();
$stmt->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit/Delete Staff</title>
    <link rel="stylesheet" href="css/admin_edit_delete.css">
</head>
<body>
    <div class="top-nav">
        <ul>
            <li><a href="admin_dashboard.php">Admin Dashboard</a></li>
            <li><a href="admin_create.php">Create</a></li>
            <li><a href="admin_edit_delete.php">Edit/Delete</a></li>
            <li><a href="bulk_upload.php">Bulk Upload</a></li>
            <li><a href="generate_payslip.php">Generate Payslip</a></li>
            <li><a href="invoicing_portal.php">Invoicing Portal</a></li>
            <li><a href="attendance_summary.php">Attendance Summary</a></li>
            <li><a href="banking_format.php">Banking Format</a></li>
            <li><a href="salary_calculator.php">Salary Calculator</a></li>
        </ul>
    </div>

    <!-- Success/Error Message -->
    <?php if (isset($_SESSION['message'])): ?>
        <div class="message <?php echo $_SESSION['message_type']; ?>">
            <?php
                echo $_SESSION['message'];
                unset($_SESSION['message']);
                unset($_SESSION['message_type']);
            ?>
        </div>
    <?php endif; ?>

    <div class="edit-delete-container">
        <h2>Edit/Delete Staff Accounts</h2>

        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Entity</th>
                    <th>Password</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <form method="POST">
                            <td>
                                <input type="text" name="name" value="<?php echo htmlspecialchars($row['name']); ?>" required>
                            </td>
                            <td>
                                <input type="email" name="email" value="<?php echo htmlspecialchars($row['email']); ?>" required>
                            </td>
                            <td>
                                <input type="text" name="entity" value="<?php echo htmlspecialchars($row['entity']); ?>" disabled>
                            </td>
                            <td>
                                <input type="password" name="password" placeholder="New Password (optional)">
                            </td>
                            <td class="actions">
                                <button type="submit" name="edit_id" value="<?php echo $row['id']; ?>" class="btn edit-btn">Edit</button>
                                <button type="submit" name="delete_id" value="<?php echo $row['id']; ?>" class="btn delete-btn">Delete</button>
                            </td>
                        </form>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
