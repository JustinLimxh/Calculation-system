<?php
session_start();

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    require_once 'config.php';

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password']; // Password entered by user
    $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash password
    $entity = $_POST['entity'];

    // Check if email already exists in the staff table
    $sql = "SELECT * FROM staff WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // If email already exists, show an error
        echo "Staff with this email already exists!";
    } else {
        // Insert new staff into the database without the status column
        $stmt = $conn->prepare("INSERT INTO staff (name, email, password, entity) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $hashed_password, $entity);
        
        if ($stmt->execute()) {
            echo "New staff registered successfully. <a href='staff_login.html'>Login now</a>";
            // Redirect to the login page
            header("Location: staff_login.html");
            exit();
        } else {
            echo "Error: " . $stmt->error; // Display SQL error if any
        }
    }

    $conn->close();
}
?>
