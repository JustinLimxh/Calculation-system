<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Salary</title>
    <link rel="stylesheet" href="css/view_salary.css"> 
</head>
<body>
    <!-- Top Navigation Bar -->
    <div class="top-nav">
        <ul>
            <li><a href="staff_dashboard.php">Dashboard</a></li>
            <li><a href="apply_leave.php" class="active">Apply Leave</a></li>
            <li><a href="view_salary.php">View Salary</a></li>
            <li><a href="staff_profile.php">Profile</a></li>
        </ul>
    </div>

    <div>
        <h1>View Salary</h1>
    </div>

    <a href="staff_logout.php" class="logout-btn">Logout</a>
    
</body>
</html>
