<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: super_admin_login.html"); // Redirect to login if not logged in
    exit();
}

require_once 'config.php';

$message = ''; // Initialize message variable

// Handle form submission
if (isset($_POST['create_admin'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password
    $entity = $_POST['entity'];

    $sql = "INSERT INTO admin (name, email, password, entity, status) VALUES ('$name', '$email', '$password', '$entity', 'active')";

    if ($conn->query($sql) === TRUE) {
        $message = '<div class="success-msg">New admin account created successfully.</div>';
    } else {
        $message = '<div class="error-msg">Error: ' . $conn->error . '</div>';
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Admin Account</title>
    <link rel="stylesheet" href="css/super_admin_create.css">
    <style>
        /* Add some styles for the success and error messages */
        .success-msg {
            color: green;
            background-color: #e8f5e9;
            border: 1px solid #4caf50;
            padding: 10px;
            margin-top: 20px;
            text-align: center;
            border-radius: 5px;
        }

        .error-msg {
            color: red;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            padding: 10px;
            margin-top: 20px;
            text-align: center;
            border-radius: 5px;
        }
    </style>
</head>
<body class="super-admin-create">

    <h2 class="super-admin-create-title">Create New Admin Account</h2>

    <form class="super-admin-create-form" action="super_admin_create.php" method="POST">
        <label for="name">Name:</label>
        <input type="text" name="name" required><br>

        <label for="email">Email:</label>
        <input type="email" name="email" required><br>

        <label for="password">Password:</label>
        <input type="password" name="password" required><br>

        <label for="entity">Entity:</label>
        <select name="entity" required>
            <option value="Fairwork">Fairwork</option>
            <option value="SPX">SPX</option>
        </select><br>

        <button type="submit" name="create_admin">Create Admin</button>
    </form>

    <?php
    // Display message below the form if set
    if ($message) {
        echo $message;
    }
    ?>

    <a class="back-btn" href="super_admin_dashboard.php">Back to Dashboard</a>
</body>
</html>
