<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: super_admin_login.html"); // Redirect to login if not logged in
    exit();
}

// Database configuration
require_once 'config.php';

// Fetch total number of admin accounts
$sql = "SELECT COUNT(*) AS total_admins FROM admin";
$result = $conn->query($sql);
$total_admins = 0;

if ($result && $row = $result->fetch_assoc()) {
    $total_admins = $row['total_admins'];
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard</title>
    <link rel="stylesheet" href="css/super_admin_dashboard.css">
</head>
<body>
    <h2>Welcome, Super Admin!</h2>
    
    <!-- Top Navigation Bar -->
    <nav>
        <ul>
            <li><a href="super_admin_create.php">Create Account</a></li>
            <li><a href="super_admin_edit_delete.php">Edit/Delete Accounts</a></li>
            <li><a href="super_admin_manage.php">Manage Admin Records</a></li>
        </ul>
    </nav>

    <!-- Total Admin Accounts -->
    <div class="dashboard-stats">
        <h3>Total Admin Accounts: <?php echo $total_admins; ?></h3>
    </div>

    <!-- Logout Button -->
    <a href="logout.php">Logout</a>
</body>
</html>
