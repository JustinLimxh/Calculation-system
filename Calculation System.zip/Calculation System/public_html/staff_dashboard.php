<?php
session_start();

// Check if the staff is logged in
if (!isset($_SESSION['email'])) {
    header("Location: staff_login.html"); // Redirect to login page if not logged in
    exit();
}

// Database connection
require_once 'config.php';

// Get the logged-in staff's email
$staff_email = $_SESSION['email'];

// Fetch the entity of the logged-in staff
$sql_staff = "SELECT entity FROM staff WHERE email = ?";
$stmt = $conn->prepare($sql_staff);
$stmt->bind_param("s", $staff_email);
$stmt->execute();
$stmt->bind_result($staff_entity);
$stmt->fetch();
$stmt->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard</title>
    <link rel="stylesheet" href="css/staff_dashboard.css">
</head>
<body class="staff-dashboard">
    <!-- Top Navigation Bar -->
    <div class="top-nav">
        <ul>
            <li><a href="staff_dashboard.php">Dashboard</a></li>
            <li><a href="apply_leave.php">Apply Leave</a></li>
            <li><a href="view_salary.php">View Salary</a></li>
            <li><a href="staff_profile.php">Profile</a></li>
        </ul>
    </div>

    <!-- Dashboard Content -->
    <div class="dashboard-content">
        <h1>Welcome to Your Dashboard!</h1>
        <p>You're successfully logged in to your staff dashboard.</p>
        <p>Logged in as: <?php echo $_SESSION['email']; ?></p>

        <a href="staff_logout.php" class="logout-btn">Logout</a>
    </div>
    
    <?php
    $conn->close(); // Close database connection
    ?>
</body>
</html>
