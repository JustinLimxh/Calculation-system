<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: super_admin_login.html"); // Redirect to login if not logged in
    exit();
}

require_once 'config.php';

$success_message = "";

// Handle deactivation
if (isset($_GET['deactivate'])) {
    $admin_id = $_GET['deactivate'];
    $sql = "UPDATE admin SET status='inactive' WHERE id=$admin_id";
    if ($conn->query($sql) === TRUE) {
        $success_message = "Account deactivated successfully.";
    } else {
        $success_message = "Error deactivating account: " . $conn->error;
    }
}

// Handle activation
if (isset($_GET['activate'])) {
    $admin_id = $_GET['activate'];
    $sql = "UPDATE admin SET status='active' WHERE id=$admin_id";
    if ($conn->query($sql) === TRUE) {
        $success_message = "Account activated successfully.";
    } else {
        $success_message = "Error activating account: " . $conn->error;
    }
}

// Fetch all admins to display
$sql = "SELECT * FROM admin";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Admin Records</title>
    <link rel="stylesheet" href="css/super_admin_manage.css">
</head>
<body>
    <h2 class="page-title">Admin Records</h2>
    
    <table class="admin-table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Entity</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['entity']; ?></td>
                    <td><?php echo ucfirst($row['status']); ?></td>
                    <td>
                        <?php if ($row['status'] == 'active') { ?>
                            <a class="action-link" href="?deactivate=<?php echo $row['id']; ?>">Deactivate</a>
                        <?php } else { ?>
                            <a class="action-link" href="?activate=<?php echo $row['id']; ?>">Activate</a>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <!-- Display Success/Failure Message -->
    <?php if ($success_message != "") { ?>
        <div class="success-message"><?php echo $success_message; ?></div>
    <?php } ?>

    <a class="back-btn" href="super_admin_dashboard.php">Back to Dashboard</a>
</body>
</html>

<?php $conn->close(); ?>
