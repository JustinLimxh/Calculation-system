<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Banking Format</title>
    <link rel="stylesheet" href="css/generate_payslip.css">
</head>
<body>
    <!-- Navigation Bar -->
    <div class="top-nav">
        <ul>
            <li><a href="admin_dashboard.php">Admin Dashboard</a></li>
            <li><a href="admin_create.php">Create</a></li>
            <li><a href="admin_edit_delete.php">Edit/Delete</a></li>
            <li><a href="bulk_upload.php">Bulk Upload</a></li>
            <li><a href="generate_payslip.php">Generate Payslip</a></li>
            <li><a href="invoicing_portal.php">Invoicing Portal</a></li>
            <li><a href="attendance_summary.php">Attendance Summary</a></li>
            <li><a href="banking_format.php" class="active">Banking Format</a></li>
            <li><a href="salary_calculator.php">Salary Calculator</a></li>
        </ul>
    </div>

    <!-- Empty Content Section -->
    <div class="container">
        <h1>Banking Format</h1>
        <p>This section is under construction.</p>
    </div>
</body>
</html>
