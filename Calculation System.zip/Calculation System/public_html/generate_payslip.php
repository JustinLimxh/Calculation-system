<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generate Payslip</title>
    <link rel="stylesheet" href="css/generate_payslip.css">
    <style>
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ccc;
        }

        th {
            background-color: #f4f4f4;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .view-button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }

        .view-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <!-- Navigation Bar -->
    <div class="top-nav">
        <ul>
            <li><a href="admin_dashboard.php">Admin Dashboard</a></li>
            <li><a href="admin_create.php">Create</a></li>
            <li><a href="admin_edit_delete.php">Edit/Delete</a></li>
            <li><a href="bulk_upload.php">Bulk Upload</a></li>
            <li><a href="generate_payslip.php" class="active">Generate Payslip</a></li>
            <li><a href="invoicing_portal.php">Invoicing Portal</a></li>
            <li><a href="attendance_summary.php">Attendance Summary</a></li>
            <li><a href="banking_format.php">Banking Format</a></li>
            <li><a href="salary_calculator.php">Salary Calculator</a></li>
        </ul>
    </div>

    <!-- Content Section -->
    <div class="container">
        <h1>Generate Payslip</h1>
        <p>Select a staff member to generate their payslip:</p>
        
        <!-- Staff List Table -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                // Database connection
                $conn = mysqli_connect("localhost", "root", "", "calculation_system");

                if (!$conn) {
                    die("Database connection failed: " . mysqli_connect_error());
                }

                // Fetch staff data
                $sql = "SELECT id, name, email FROM staff";
                $result = mysqli_query($conn, $sql);

                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td>{$row['id']}</td>
                                <td>{$row['name']}</td>
                                <td>{$row['email']}</td>
                                <td><a href='view_staff.php?id={$row['id']}' class='view-button'>Generate Payslip</a></td>
                              </tr>";
                    }
                } else {
                    echo "<tr>
                            <td colspan='4' style='text-align: center;'>No staff found</td>
                          </tr>";
                }

                mysqli_close($conn);
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
