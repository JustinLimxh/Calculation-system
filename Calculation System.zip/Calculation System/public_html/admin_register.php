<?php
session_start();

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    require_once 'config.php';

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password']; // Password entered by user
    $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash password
    $entity = $_POST['entity'];

    // Check if email already exists in the admin table
    $sql = "SELECT * FROM admin WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // If email already exists, show an error
        echo "Admin with this email already exists!";
    } else {
        // Insert new admin into the database
        $stmt = $conn->prepare("INSERT INTO admin (name, email, password, entity, status) VALUES (?, ?, ?, ?, ?)");
        $status = 'active'; // Default status
        $stmt->bind_param("sssss", $name, $email, $hashed_password, $entity, $status);
        
        if ($stmt->execute()) {
            echo "New admin registered successfully. <a href='admin_login.html'>Login now</a>";
            // Redirect to the login page
            header("Location: admin_login.html");
            exit();
        } else {
            echo "Error: " . $stmt->error; // Display SQL error if any
        }
    }

    $conn->close();
}
?>
