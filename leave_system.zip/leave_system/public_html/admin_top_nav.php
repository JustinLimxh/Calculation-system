<!-- Top Navigation Bar -->
<div class="top-nav-container">
<div class="top-nav">
 <!-- Logo beside the navigation bar -->
 <div class="logo-container">
  <img src="images/logo.jpg" alt="Logo" class="logo">
   </div>
    <ul>
        <li><a href="admin_dashboard.php">Admin Dashboard</a></li>
        <li><a href="admin_create.php">Create</a></li>
        <li><a href="admin_edit_delete.php">Edit/Delete</a></li>
        <li><a href="admin_apply_leave.php">Apply Leave</a></li>
        <li><a href="admin_leave_balance.php">Leave Balance</a></li>
        <li><a href="admin_leave_history.php">Leave History</a></li>
        <li><a href="admin_manage_leave.php">Manage Leave</a></li>
    </ul>
</div>
</div>