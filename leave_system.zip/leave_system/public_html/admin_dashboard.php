<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html"); // Redirect to login page if not logged in
    exit();
}

// Database connection
require_once 'config.php';

// Fetch the count of all staff members from the database
$sql = "SELECT COUNT(*) AS staff_count FROM staff"; // Assuming 'staff' is your table name
$result = $conn->query($sql);

// Error handling for query
if ($result === false) {
    die("Error in query: " . $conn->error); // Output the error if query fails
}

$row = $result->fetch_assoc();
$staff_count = $row['staff_count'];

// Get the logged-in admin's email
$admin_email = $_SESSION['email'];

// Fetch the entity of the logged-in admin
$sql_admin = "SELECT entity FROM staff WHERE email = ?";
$stmt = $conn->prepare($sql_admin);
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$stmt->bind_result($admin_entity);
$stmt->fetch();
$stmt->close();

// Fetch the count of staff members from the same entity as the admin
$sql_entity = "SELECT entity, COUNT(*) AS entity_staff_count 
               FROM staff 
               GROUP BY entity"; // This will group staff by their entity
$stmt = $conn->prepare($sql_entity);
$stmt->execute();
$stmt->bind_result($entity, $entity_staff_count);

// Store the results in an array for later use
$entity_counts = [];
while ($stmt->fetch()) {
    $entity_counts[$entity] = $entity_staff_count;
}
$stmt->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="css/admin_dashboard.css">
     <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
     <link rel="stylesheet" href="css/admin_top_nav.css"> 
</head>
<body class="admin-dashboard">
    <!-- Include Top Navigation Bar -->
    <?php include 'admin_top_nav.php'; ?>

    <!-- Dashboard Content -->
    <div class="dashboard-content">
        <h1>Welcome, Admin!</h1>
        <p>You're successfully logged in to the admin dashboard.</p>
        <p>Logged in as: <?php echo $_SESSION['email']; ?></p>

        <!-- Display Total Staff Count -->
        <h2>Total Staff Count: <?php echo $staff_count; ?></h2>

        <!-- Display Staff Count for Each Entity -->
        <h3>Staff Count by Company:</h3>
        <ul>
            <?php
            foreach ($entity_counts as $entity_name => $count) {
                echo "<li><strong>$entity_name</strong>: $count staff members</li>";
            }
            ?>
        </ul>

        <a href="admin_logout.php" class="logout-btn">Logout</a>
    </div>
    
    <?php
    $conn->close(); // Close database connection
    ?>
</body>
</html>
