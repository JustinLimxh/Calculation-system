

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="css/admin_login.css">
</head>
<body class="admin-login">
    
    <!-- Admin Login Button at Bottom Right -->
    <div class="login-btn-container">
        <button type="button" class="staff-login-btn" onclick="window.location.href='staff_login.html'">Staff Login</button>
        <button type="button" class="super-admin-login-btn" onclick="window.location.href='super_admin_login.html'">Super Admin Login</button>
    </div>

    <a class="register-link" href="admin_register.html">Don't have an account? Register here</a>
</body>
</html>
