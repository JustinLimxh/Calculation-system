<?php
session_start();

// Enable error reporting for debugging
ini_set('display_errors', 1);
error_reporting(E_ALL);

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    require_once 'config.php';

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password']; // Password entered by user
    $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hash password
    $entity = $_POST['entity'];

    // Check if email already exists in the staff, admin, or super_admin table
    $sql = "SELECT email FROM staff WHERE email=? UNION SELECT email FROM admin WHERE email=? UNION SELECT email FROM super_admin WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sss", $email, $email, $email); // Bind the email for all 3 checks
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        // If email already exists in any of the tables, show an error
        echo "This email is already in use. Please use a different email.";
    } else {
        // Insert new staff into the database
        $stmt = $conn->prepare("INSERT INTO staff (name, email, password, entity) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("ssss", $name, $email, $hashed_password, $entity);

        if ($stmt->execute()) {
            echo "New staff registered successfully. <a href='staff_login.html'>Login now</a>";
            // Redirect to the login page
            header("Location: staff_login.html");
            exit();
        } else {
            echo "Error: " . $stmt->error; // Display SQL error if any
        }
    }

    $conn->close();
}
?>
