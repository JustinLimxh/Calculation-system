<?php
session_start();

// Check if the staff is logged in
if (!isset($_SESSION['email'])) {
    header("Location: staff_login.html");
    exit();
}

require_once 'config.php';

$email = $_SESSION['email'];
$message = "";

// Fetch current name
$sql = "SELECT name FROM staff WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($current_name);
$stmt->fetch();
$stmt->close();

// Change password
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate passwords
    if (!empty($new_password) && !empty($confirm_password)) {
        if ($new_password === $confirm_password) {
            // Update new password
            $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $sql = "UPDATE staff SET password = ? WHERE email = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $new_hashed_password, $email);
            if ($stmt->execute()) {
                $message = "Password changed successfully!";
            } else {
                $message = "Error changing password.";
            }
            $stmt->close();
        } else {
            $message = "New passwords do not match.";
        }
    } else {
        $message = "All password fields are required.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Profile</title>
    <link rel="stylesheet" href="css/staff_profile.css">
      <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/staff_top_nav.css">
</head>
<body>
     <!-- Include Top Navigation Bar -->
    <?php include('staff_top_nav.php'); ?>
    
    <div class="profile-container">
        <h1>Staff Profile</h1>
        <p class="message"><?php echo $message; ?></p>

        <!-- Current Name -->
        <h2>Current Name: <?php echo htmlspecialchars($current_name); ?></h2>

        <!-- Change Password Form -->
        <form method="POST" class="profile-form">
            <h3>Change Password</h3>
            <label for="new_password">New Password:</label>
            <input type="password" name="new_password" id="new_password" required>
            <label for="confirm_password">Confirm New Password:</label>
            <input type="password" name="confirm_password" id="confirm_password" required>
            <button type="submit" name="change_password">Change Password</button>
        </form>

        <a href="staff_dashboard.php" class="back-link">Back to Dashboard</a>
    </div>
</body>
</html>
