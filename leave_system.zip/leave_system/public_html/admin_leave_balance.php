<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

require_once 'config.php';

$admin_email = $_SESSION['email'];

// Fetch leave balances
$sql = "SELECT annual_leave, medical_leave FROM admin WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$stmt->bind_result($annual_leave, $medical_leave);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Balance</title>
    <link rel="stylesheet" href="css/leave_balance.css">
        <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
     <link rel="stylesheet" href="css/admin_top_nav.css"> 
</head>
<body>
     <!-- Include Top Navigation Bar -->
    <?php include 'admin_top_nav.php'; ?>

      <div class="container">
        <h2>Your Leave Balance</h2>
        <table>
            <tr>
                <th>Leave Type</th>
                <th>Available</th>
            </tr>
            <tr>
                <td>Annual Leave</td>
                <td><?php echo $annual_leave; ?></td>
            </tr>
            <tr>
                <td>Medical Leave</td>
                <td><?php echo $medical_leave; ?></td>
            </tr>
        </table>
        <a href="admin_dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
