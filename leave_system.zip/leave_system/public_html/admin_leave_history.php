<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

require_once 'config.php';

$admin_email = $_SESSION['email'];

// Fetch leave history
$sql = "SELECT leave_type, start_date, end_date, reason, status FROM admin_leave_applications WHERE admin_email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave History</title>
    <link rel="stylesheet" href="css/admin_leave_history.css">
        <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
     <link rel="stylesheet" href="css/admin_top_nav.css"> 
</head>
<body>
       <!-- Include Top Navigation Bar -->
    <?php include 'admin_top_nav.php'; ?>


    <h1>Leave History</h1>
    <table>
        <thead>
            <tr>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['leave_type']; ?></td>
                    <td><?php echo $row['start_date']; ?></td>
                    <td><?php echo $row['end_date']; ?></td>
                    <td><?php echo $row['reason']; ?></td>
                    <td><?php echo $row['status']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
</body>
</html>
