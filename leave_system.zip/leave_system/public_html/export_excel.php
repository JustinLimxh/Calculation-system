<?php
require 'vendor/autoload.php'; // Include PhpSpreadsheet library

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Database connection
require_once 'config.php';

$sql = "SELECT staff_email, leave_type, start_date, end_date, reason, file_path, status FROM leave_applications";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Set header row
    $sheet->setCellValue('A1', 'Email');
    $sheet->setCellValue('B1', 'Leave Type');
    $sheet->setCellValue('C1', 'Start Date');
    $sheet->setCellValue('D1', 'End Date');
    $sheet->setCellValue('E1', 'Reason');
    $sheet->setCellValue('F1', 'File Path');
    $sheet->setCellValue('G1', 'Status');

    // Populate data rows
    $row = 2;
    while ($data = $result->fetch_assoc()) {
        $sheet->setCellValue('A' . $row, $data['staff_email']);
        $sheet->setCellValue('B' . $row, $data['leave_type']);
        $sheet->setCellValue('C' . $row, $data['start_date']);
        $sheet->setCellValue('D' . $row, $data['end_date']);
        $sheet->setCellValue('E' . $row, $data['reason']);
        $sheet->setCellValue('F' . $row, $data['file_path']);
        $sheet->setCellValue('G' . $row, $data['status']);
        $row++;
    }

    // Set filename and download headers
    $filename = "leave_applications_" . date('Ymd_His') . ".xlsx";
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');

    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
} else {
    echo "No records found.";
}
?>
