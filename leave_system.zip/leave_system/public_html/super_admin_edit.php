<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: super_admin_login.html"); // Redirect to login if not logged in
    exit();
}

require_once 'config.php';

// Fetch the admin details for editing
if (isset($_GET['id'])) {
    $admin_id = $_GET['id'];
    $sql = "SELECT * FROM admin WHERE id=$admin_id";
    $result = $conn->query($sql);
    $admin = $result->fetch_assoc();
}

// Update admin details if form is submitted
if (isset($_POST['update'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password']; // New password, if provided
    $entity = $_POST['entity'];
    $status = $_POST['status'];

    // If no new password is provided, keep the old password
    if (empty($password)) {
        $password = $admin['password']; // Retain the old hashed password
    } else {
        // If password is provided, hash it
        $password = password_hash($password, PASSWORD_DEFAULT);
    }

    // Use prepared statements to avoid SQL injection
    $stmt = $conn->prepare("UPDATE admin SET name=?, email=?, password=?, entity=?, status=? WHERE id=?");
    $stmt->bind_param("sssssi", $name, $email, $password, $entity, $status, $admin_id);

    if ($stmt->execute()) {
        header("Location: super_admin_edit_delete.php"); // Redirect to the list page after update
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Admin Account</title>
    <link rel="stylesheet" href="css/super_admin_edit.css">
</head>
<body class="super-admin-edit">

    <h2 class="super-admin-edit-title">Edit Admin Account</h2>

    <form class="super-admin-edit-form" method="POST" action="super_admin_edit.php?id=<?php echo $admin['id']; ?>">
        <label for="name">Name:</label>
        <input type="text" id="name" name="name" value="<?php echo $admin['name']; ?>" required>

        <label for="email">Email:</label>
        <input type="email" id="email" name="email" value="<?php echo $admin['email']; ?>" required>

        <label for="entity">Entity:</label>
        <input type="text" id="entity" name="entity" value="<?php echo $admin['entity']; ?>" readonly>

        <label for="status">Status:</label>
        <select name="status" id="status">
            <option value="active" <?php if ($admin['status'] == 'active') echo 'selected'; ?>>Active</option>
            <option value="inactive" <?php if ($admin['status'] == 'inactive') echo 'selected'; ?>>Inactive</option>
        </select>

        <label for="password">Password:</label>
        <input type="text" id="password" name="password" placeholder="Leave empty to keep the current password">

        <button type="submit" name="update">Update</button>
    </form>

    <a class="back-btn" href="super_admin_edit_delete.php">Back to Edit/Delete Page</a>
</body>
</html>

<?php $conn->close(); ?>
