<?php
session_start();

// Check if the admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

require_once 'config.php';

// Fetch pending leave applications
$sql = "SELECT la.id, la.staff_email, la.leave_type, la.start_date, la.end_date, la.reason, la.file_path, la.status, s.name, s.annual_leave, s.medical_leave 
        FROM leave_applications la 
        INNER JOIN staff s ON la.staff_email = s.email 
        WHERE la.status = 'Pending'";
$result = $conn->query($sql);

// Handle leave application actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $application_id = $_POST['application_id'];
    $action = $_POST['action'];
    $staff_email = $_POST['staff_email'];
    $leave_type = $_POST['leave_type'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Calculate the number of leave days
    $days_requested = (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24) + 1;

    // Update the leave application status and deduct leave balance if approved
    if ($action === 'approve') {
        $status = 'Approved';

        // Deduct the leave balance for the staff
        $balance_column = ($leave_type === 'Annual Leave') ? 'annual_leave' : 'medical_leave';

        // Fetch the current leave balance to ensure no negative deduction
        $balance_query = "SELECT $balance_column FROM staff WHERE email = ?";
        $stmt = $conn->prepare($balance_query);
        $stmt->bind_param("s", $staff_email);
        $stmt->execute();
        $stmt->bind_result($current_balance);
        $stmt->fetch();
        $stmt->close();

        // Check if the staff has enough balance
        if ($current_balance >= $days_requested) {
            $update_balance_sql = "UPDATE staff SET $balance_column = $balance_column - ? WHERE email = ?";
            $stmt = $conn->prepare($update_balance_sql);
            $stmt->bind_param("is", $days_requested, $staff_email);
            $stmt->execute();
            $stmt->close();
        } else {
            // If balance is insufficient, set error message and skip status update
            $message = "Error: Insufficient $leave_type balance for $staff_email.";
            header("Location: admin_manage_leave.php?error=" . urlencode($message));
            exit();
        }
    } elseif ($action === 'reject') {
        $status = 'Rejected';
    } else {
        $status = 'Pending';
    }

    // Update leave application status
    $update_sql = "UPDATE leave_applications SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("si", $status, $application_id);

    if ($stmt->execute()) {
        // Email staff about the leave application decision
        $subject = "Leave Application Status Update";
        $message = "
        <html>
        <head>
            <title>Leave Application Update</title>
        </head>
        <body>
            <p>Dear Staff,</p>
            <p>Your leave application has been <strong>{$status}</strong>.</p>
            <p><strong>Details:</strong></p>
            <ul>
                <li><strong>Leave Type:</strong> {$leave_type}</li>
                <li><strong>Start Date:</strong> {$start_date}</li>
                <li><strong>End Date:</strong> {$end_date}</li>
                <li><strong>Status:</strong> {$status}</li>
            </ul>
            <p>Thank you!</p>
        </body>
        </html>
        ";

        // Email headers
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: no-reply@nasiandsambal.com" . "\r\n";

        // Send the email to staff
        mail($staff_email, $subject, $message, $headers);

        $message = "Leave application has been $status successfully, and the staff has been notified via email.";
    } else {
        $message = "Error updating leave application.";
    }
    $stmt->close();

    // Refresh the page to see updated data
    header("Location: admin_manage_leave.php?message=" . urlencode($message));
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Staff Leave</title>
    <link rel="stylesheet" href="css/admin_manage_leave.css">
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/admin_top_nav.css"> 
</head>
<body>
    <!-- Include Top Navigation Bar -->
    <?php include 'admin_top_nav.php'; ?>
    <h1>Manage Staff Leave Applications</h1>
    <?php if (isset($_GET['message'])): ?>
        <p class="message"><?php echo htmlspecialchars($_GET['message']); ?></p>
    <?php endif; ?>

    <!-- First Table: Pending Leave Applications -->
    <table>
        <thead>
            <tr>
                <th>Staff Name</th>
                <th>Email</th>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason</th>
                <th>File</th>
                <th>Current Balance</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['staff_email']); ?></td>
                    <td><?php echo htmlspecialchars($row['leave_type']); ?></td>
                    <td><?php echo htmlspecialchars($row['start_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['end_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['reason']); ?></td>
                    <td>
                        <?php if (!empty($row['file_path'])): ?>
                            <a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank">View File</a>
                        <?php else: ?>
                            No File
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php echo $row['leave_type'] === 'Annual Leave' 
                            ? $row['annual_leave'] 
                            : $row['medical_leave']; ?> days
                    </td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="application_id" value="<?php echo $row['id']; ?>">
                            <input type="hidden" name="staff_email" value="<?php echo $row['staff_email']; ?>">
                            <input type="hidden" name="leave_type" value="<?php echo $row['leave_type']; ?>">
                            <input type="hidden" name="start_date" value="<?php echo $row['start_date']; ?>">
                            <input type="hidden" name="end_date" value="<?php echo $row['end_date']; ?>">
                            <button type="submit" name="action" value="approve">Approve</button>
                            <button type="submit" name="action" value="reject">Reject</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Second Table: All Leave Applications -->
    <h2>All Leave Applications</h2>
    <?php
    // Fetch all leave applications from the database
    $allApplicationsSql = "SELECT id, staff_email, leave_type, start_date, end_date, reason, file_path, status FROM leave_applications";
    $allApplicationsResult = $conn->query($allApplicationsSql);
    ?>
    <table>
        <thead>
            <tr>
                <th>Email</th>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason</th>
                <th>File</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $allApplicationsResult->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['staff_email']); ?></td>
                    <td><?php echo htmlspecialchars($row['leave_type']); ?></td>
                    <td><?php echo htmlspecialchars($row['start_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['end_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['reason']); ?></td>
                    <td>
                        <?php if (!empty($row['file_path'])): ?>
                            <a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank">View File</a>
                        <?php else: ?>
                            No File
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Export to Excel Button -->
    <form method="post" action="export_excel.php">
        <button type="submit">Export as Excel</button>
    </form>
</body>
</html>
