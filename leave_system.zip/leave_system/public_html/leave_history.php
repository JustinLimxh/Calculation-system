<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: staff_login.html");
    exit();
}

require_once 'config.php';

$staff_email = $_SESSION['email'];

// Fetch leave history
$sql = "SELECT leave_type, start_date, end_date, reason, status FROM leave_applications WHERE staff_email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $staff_email);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave History</title>
    <link rel="stylesheet" href="css/leave_history.css">
      <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/staff_top_nav.css">
</head>
<body>
    <!-- Include Top Navigation Bar -->
    <?php include('staff_top_nav.php'); ?>

    <div class="container">
        <h2>Your Leave History</h2>
        <table>
            <tr>
                <th>Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason</th>
                <th>Status</th>
            </tr>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['leave_type']; ?></td>
                    <td><?php echo $row['start_date']; ?></td>
                    <td><?php echo $row['end_date']; ?></td>
                    <td><?php echo $row['reason']; ?></td>
                    <td><?php echo $row['status']; ?></td>
                </tr>
            <?php endwhile; ?>
        </table>
        <a href="staff_dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
<?php $stmt->close(); $conn->close(); ?>
