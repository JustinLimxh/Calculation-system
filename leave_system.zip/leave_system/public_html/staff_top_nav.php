<!-- staff_top_nav.php -->
<div class="top-nav-container">
    <div class="top-nav">
        <!-- Logo beside the navigation bar -->
        <div class="logo-container">
            <img src="images/logo.jpg" alt="Logo" class="logo">
        </div>
        <ul>
            <li><a href="staff_dashboard.php">Dashboard</a></li>
            <li><a href="apply_leave.php">Apply Leave</a></li>
            <li><a href="leave_balance.php">Leave Balance</a></li>
            <li><a href="leave_history.php">Leave History</a></li>
            <li><a href="staff_profile.php">Profile</a></li>
        </ul>
    </div>
</div>
