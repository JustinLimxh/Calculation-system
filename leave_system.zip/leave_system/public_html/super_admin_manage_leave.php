<?php
session_start();

// Check if the super admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: super_admin_login.html");
    exit();
}

// Database configuration
require_once 'config.php';

// Fetch pending leave applications for admins
$sql = "SELECT la.id, la.admin_email, la.leave_type, la.start_date, la.end_date, la.reason, la.status, 
               a.name, a.annual_leave, a.medical_leave, la.file_path
        FROM admin_leave_applications la 
        INNER JOIN admin a ON la.admin_email = a.email 
        WHERE la.status = 'Pending'";
$result = $conn->query($sql);

// Handle leave application actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $application_id = $_POST['application_id'];
    $action = $_POST['action'];
    $admin_email = $_POST['admin_email'];
    $leave_type = $_POST['leave_type'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $reason = $_POST['reason'];

    // Calculate the number of leave days
    $days_requested = (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24) + 1;

    // Update the leave application status and deduct leave balance if approved
    if ($action === 'approve') {
        $status = 'Approved';

        // Determine which leave balance to update
        $balance_column = ($leave_type === 'Annual Leave') ? 'annual_leave' : 'medical_leave';

        // Fetch the current leave balance to ensure no negative deduction
        $balance_query = "SELECT $balance_column FROM admin WHERE email = ?";
        $stmt = $conn->prepare($balance_query);
        $stmt->bind_param("s", $admin_email);
        $stmt->execute();
        $stmt->bind_result($current_balance);
        $stmt->fetch();
        $stmt->close();

        // Check if the admin has enough balance
        if ($current_balance >= $days_requested) {
            $update_balance_sql = "UPDATE admin SET $balance_column = $balance_column - ? WHERE email = ?";
            $stmt = $conn->prepare($update_balance_sql);
            $stmt->bind_param("is", $days_requested, $admin_email);
            $stmt->execute();
            $stmt->close();
        } else {
            // If balance is insufficient, set error message and skip status update
            $message = "Error: Insufficient $leave_type balance for $admin_email.";
            header("Location: super_admin_manage_leave.php?error=" . urlencode($message));
            exit();
        }
    } elseif ($action === 'reject') {
        $status = 'Rejected';
    } else {
        $status = 'Pending';
    }

    // Update leave application status
    $update_sql = "UPDATE admin_leave_applications SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("si", $status, $application_id);

    if ($stmt->execute()) {
        $message = "Leave application has been $status successfully.";
    } else {
        $message = "Error updating leave application.";
    }
    $stmt->close();

    // Send email to admin
    $subject = "Leave Application Status: $status";
    $body = "
        <h3>Dear Admin,</h3>
        <p>Your leave application has been <strong>$status</strong>.</p>
        <p><strong>Leave Type:</strong> $leave_type</p>
        <p><strong>Start Date:</strong> $start_date</p>
        <p><strong>End Date:</strong> $end_date</p>
        <p><strong>Reason:</strong> $reason</p>
        <p><strong>Status:</strong> $status</p>
        <br>
        <p>If you have any questions, please contact the Super Admin.</p>
        <p>Best regards,<br>Super Admin Team</p>
    ";

    // To send HTML mail, the Content-type header must be set
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8" . "\r\n";
    $headers .= "From: superadmin@yourdomain.com" . "\r\n";  // Replace with your email

    // Send the email
    if (mail($admin_email, $subject, $body, $headers)) {
        // Successfully sent the email
    } else {
        // Handle error in sending email
        $message .= " However, there was an issue sending the email.";
    }

    // Refresh the page to see updated data
    header("Location: super_admin_manage_leave.php?message=" . urlencode($message));
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin - Manage Admin Leave</title>
    <link rel="stylesheet" href="css/super_admin_manage_leave.css">
    <!---->    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
     <link rel="stylesheet" href="css/super_admin_top_nav.css"> 
</head>
<body>
     <!-- Include Top Navigation Bar -->
    <?php include 'super_admin_top_nav.php'; ?>

    <h2>Manage Admin Leave Applications</h2>

    <?php if (isset($_GET['message'])): ?>
        <p class="message"><?php echo htmlspecialchars($_GET['message']); ?></p>
    <?php endif; ?>

    <!-- Display Leave Applications -->
    <table>
        <thead>
            <tr>
                <th>Admin Name</th>
                <th>Email</th>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason</th>
                <th>Current Balance</th>
                <th>Status</th>
                <th>Actions</th>
                <th>Attachment</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['admin_email']); ?></td>
                    <td><?php echo htmlspecialchars($row['leave_type']); ?></td>
                    <td><?php echo htmlspecialchars($row['start_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['end_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['reason']); ?></td>
                    <td>
                        <?php echo $row['leave_type'] === 'Annual Leave' 
                            ? $row['annual_leave'] 
                            : $row['medical_leave']; ?> days
                    </td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="application_id" value="<?php echo $row['id']; ?>">
                            <input type="hidden" name="admin_email" value="<?php echo $row['admin_email']; ?>">
                            <input type="hidden" name="leave_type" value="<?php echo $row['leave_type']; ?>">
                            <input type="hidden" name="start_date" value="<?php echo $row['start_date']; ?>">
                            <input type="hidden" name="end_date" value="<?php echo $row['end_date']; ?>">
                            <button type="submit" name="action" value="approve">Approve</button>
                            <button type="submit" name="action" value="reject">Reject</button>
                        </form>
                    </td>
                    <td>
                        <?php if ($row['file_path']): ?>
                            <a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank">View File</a>
                        <?php else: ?>
                            No Attachment
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>
    
    <!-- Second Table: All Leave Applications -->
    <h2>All Admin Leave Applications</h2>
    <?php
    // Fetch all leave applications from the database
    $allApplicationsSql = "SELECT id, admin_email, leave_type, start_date, end_date, reason, file_path, status FROM admin_leave_applications";
    $allApplicationsResult = $conn->query($allApplicationsSql);
    ?>
    <table>
        <thead>
            <tr>
                <th>Email</th>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason</th>
                <th>File</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $allApplicationsResult->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['admin_email']); ?></td>
                    <td><?php echo htmlspecialchars($row['leave_type']); ?></td>
                    <td><?php echo htmlspecialchars($row['start_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['end_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['reason']); ?></td>
                    <td>
                        <?php if (!empty($row['file_path'])): ?>
                            <a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank">View File</a>
                        <?php else: ?>
                            No File
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Export to Excel Button -->
    <form method="post" action="export_excel_admin.php">
        <button type="submit">Export as Excel</button>
    </form>
</body>
</html>
