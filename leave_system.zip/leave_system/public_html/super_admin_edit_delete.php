<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: super_admin_login.html"); // Redirect to login if not logged in
    exit();
}

require_once 'config.php';

$message = ''; // Initialize message variable

// Handle deletion
if (isset($_GET['delete'])) {
    $admin_id = $_GET['delete'];
    $sql = "DELETE FROM admin WHERE id=$admin_id";
    if ($conn->query($sql) === TRUE) {
        $message = '<div class="success-msg">Account deleted successfully.</div>';
    } else {
        $message = '<div class="error-msg">Error deleting account: ' . $conn->error . '</div>';
    }
}

// Fetch all admins to display
$sql = "SELECT * FROM admin";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit/Delete Admin Accounts</title>
    <link rel="stylesheet" href="css/super_admin_edit_delete.css">
        <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
     <link rel="stylesheet" href="css/super_admin_top_nav.css"> 
    <style>
        /* Add styles for the success and error messages */
        .success-msg {
            color: green;
            background-color: #e8f5e9;
            border: 1px solid #4caf50;
            padding: 10px;
            margin-top: 20px;
            text-align: center;
            border-radius: 5px;
        }

        .error-msg {
            color: red;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            padding: 10px;
            margin-top: 20px;
            text-align: center;
            border-radius: 5px;
        }
    </style>
</head>
<body class="super-admin-edit-delete">
        <!-- Include Top Navigation Bar -->
    <?php include 'super_admin_top_nav.php'; ?>
    <h2 class="super-admin-edit-delete-title">Edit/Delete Admin Accounts</h2>

    <!-- Display message after deletion -->
    <?php if ($message) { echo $message; } ?>

    <table class="super-admin-edit-delete-table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Entity</th>
                <th>Status</th>
                <th>Password</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()) { ?>
                <tr>
                    <td><?php echo $row['name']; ?></td>
                    <td><?php echo $row['email']; ?></td>
                    <td><?php echo $row['entity']; ?></td>
                    <td><?php echo $row['status']; ?></td>
                    <td><?php echo substr($row['password'], 0, 10); ?>...</td> <!-- Truncated password -->
                    <td>
                        <a class="super-admin-edit-delete-link" href="super_admin_edit.php?id=<?php echo $row['id']; ?>">Edit</a> |
                        <a class="super-admin-edit-delete-link" href="?delete=<?php echo $row['id']; ?>">Delete</a>
                    </td>
                </tr>
            <?php } ?>
        </tbody>
    </table>

    <a class="back-btn" href="super_admin_dashboard.php">Back to Dashboard</a>
</body>
</html>
