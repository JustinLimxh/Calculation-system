<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Check if admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

require_once 'config.php';

// Fetch logged-in admin's email
$admin_email = $_SESSION['email'];

// Fetch admin's current leave balances
$sql = "SELECT annual_leave, medical_leave FROM admin WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$stmt->bind_result($annual_leave_balance, $mc_leave_balance);
$stmt->fetch();
$stmt->close();

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $leave_type = $_POST['leave_type'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $reason = trim($_POST['reason']);
    $file_path = null;

    // File upload handling
    if (isset($_FILES['supporting_file']) && $_FILES['supporting_file']['error'] == UPLOAD_ERR_OK) {
        $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
        $file_type = mime_content_type($_FILES['supporting_file']['tmp_name']);

        if (in_array($file_type, $allowed_types)) {
            $target_dir = "uploads/";
            if (!is_dir($target_dir)) {
                mkdir($target_dir, 0777, true); // Create directory if it doesn't exist
            }
            $file_name = uniqid() . "_" . basename($_FILES['supporting_file']['name']);
            $target_file = $target_dir . $file_name;

            if (move_uploaded_file($_FILES['supporting_file']['tmp_name'], $target_file)) {
                $file_path = $target_file;
            } else {
                $error_message = "Failed to upload file. Please try again.";
            }
        } else {
            $error_message = "Invalid file type. Only JPEG, PNG, or PDF files are allowed.";
        }
    }

    // Validate other inputs
    if (empty($start_date) || empty($end_date) || empty($reason)) {
        $error_message = "All fields are required.";
    } elseif (strtotime($end_date) < strtotime($start_date)) {
        $error_message = "End date cannot be earlier than the start date.";
    } else {
        // Calculate number of leave days
        $days_requested = (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24) + 1;

        // Check leave balance based on type
        if ($leave_type == 'Annual Leave' && $annual_leave_balance < $days_requested) {
            $error_message = "Insufficient Annual Leave balance.";
        } elseif ($leave_type == 'Medical Leave' && $mc_leave_balance < $days_requested) {
            $error_message = "Insufficient Medical Leave balance.";
        } else {
            // Insert the leave application
            $sql = "INSERT INTO admin_leave_applications (admin_email, leave_type, start_date, end_date, reason, file_path, status) 
                    VALUES (?, ?, ?, ?, ?, ?, 'Pending')";
            $stmt = $conn->prepare($sql);

            if ($stmt) {
                $stmt->bind_param("ssssss", $admin_email, $leave_type, $start_date, $end_date, $reason, $file_path);

                if ($stmt->execute()) {
                    $success_message = "Leave application submitted successfully.";

                    // Fetch all super admin emails from the database
                    $super_admin_emails = [];
                    $admin_query = "SELECT email FROM super_admin";
                    $result = $conn->query($admin_query);

                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $super_admin_emails[] = $row['email'];
                        }
                    }

                    // Send success email to admin
                    $to_admin = $admin_email;
                    $subject_admin = "Leave Application Confirmation";
                    $message_admin = "
                    <html>
                    <head>
                        <title>Leave Application Submitted</title>
                    </head>
                    <body>
                        <p>Dear Admin,</p>
                        <p>Your leave application has been successfully submitted.</p>
                        <p><strong>Details:</strong></p>
                        <ul>
                            <li><strong>Leave Type:</strong> {$leave_type}</li>
                            <li><strong>Start Date:</strong> {$start_date}</li>
                            <li><strong>End Date:</strong> {$end_date}</li>
                            <li><strong>Reason:</strong> {$reason}</li>
                        </ul>
                        <p>Status: <strong>Pending</strong></p>
                        <p>Thank you!</p>
                    </body>
                    </html>
                    ";

                    // Email headers
                    $headers = "MIME-Version: 1.0" . "\r\n";
                    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                    $headers .= "From: no-reply@nasiandsambal.com" . "\r\n";

                    // Send email to admin
                    mail($to_admin, $subject_admin, $message_admin, $headers);

                    // Send success email to all super admins
                    foreach ($super_admin_emails as $to_super_admin) {
                        $subject_super_admin = "New Leave Application Submitted";
                        $message_super_admin = "
                        <html>
                        <head>
                            <title>New Leave Application</title>
                        </head>
                        <body>
                            <p>Dear Super Admin,</p>
                            <p>A new leave application has been submitted by <strong>{$admin_email}</strong>.</p>
                            <p><strong>Details:</strong></p>
                            <ul>
                                <li><strong>Leave Type:</strong> {$leave_type}</li>
                                <li><strong>Start Date:</strong> {$start_date}</li>
                                <li><strong>End Date:</strong> {$end_date}</li>
                                <li><strong>Reason:</strong> {$reason}</li>
                            </ul>
                            <p>Status: <strong>Pending</strong></p>
                            <p>Thank you!</p>
                        </body>
                        </html>
                        ";

                        // Send email to super admin
                        mail($to_super_admin, $subject_super_admin, $message_super_admin, $headers);
                    }
                } else {
                    $error_message = "Error submitting leave application. Please try again.";
                }
                $stmt->close();
            } else {
                $error_message = "Database error: " . $conn->error;
            }
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply Leave</title>
    <link rel="stylesheet" href="css/apply_leave.css">
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/admin_top_nav.css">
</head>
<body>

    <!-- Include Top Navigation Bar -->
    <?php include('admin_top_nav.php'); ?>

    <div class="profile-container">
    <h1>Apply for Leave</h1>

    <?php if ($error_message): ?>
        <p class="error"><?php echo htmlspecialchars($error_message); ?></p>
    <?php endif; ?>
    <?php if ($success_message): ?>
        <p class="success"><?php echo htmlspecialchars($success_message); ?></p>
    <?php endif; ?>

    <form method="POST" enctype="multipart/form-data">
        <label for="leave_type">Leave Type:</label>
        <select name="leave_type" id="leave_type" required>
            <option value="Annual Leave">Annual Leave (Remaining: <?php echo htmlspecialchars($annual_leave_balance); ?> days)</option>
            <option value="Medical Leave">Medical Leave (Remaining: <?php echo htmlspecialchars($mc_leave_balance); ?> days)</option>
        </select>

        <label for="start_date">Start Date:</label>
        <input type="date" id="start_date" name="start_date" required>

        <label for="end_date">End Date:</label>
        <input type="date" id="end_date" name="end_date" required>

        <label for="reason">Reason:</label>
        <textarea id="reason" name="reason" rows="4" required></textarea>

        <label for="supporting_file">Supporting File (JPEG, PNG, or PDF):</label>
        <input type="file" id="supporting_file" name="supporting_file" accept="image/jpeg, image/png, application/pdf">

        <button type="submit">Submit</button>
    </form>
    </div>
</body>
</html>
