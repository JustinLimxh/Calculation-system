<!-- Top Navigation Bar -->
<div class="top-nav-container">
<div class="top-nav">
 <!-- Logo beside the navigation bar -->
 <div class="logo-container">
  <img src="images/logo.jpg" alt="Logo" class="logo">
   </div>
    <ul>
             <li><a href="super_admin_dashboard.php">Dashboard</a></li>
            <li><a href="super_admin_create.php">Create Account</a></li>
            <li><a href="super_admin_edit_delete.php">Edit/Delete Accounts</a></li>
            <li><a href="super_admin_manage.php">Manage Admin Records</a></li>
             <li><a href="super_admin_manage_leave.php">Manage Admin Leave</a></li>
        </ul>
</div>
</div>