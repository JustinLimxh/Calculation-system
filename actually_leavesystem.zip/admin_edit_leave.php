<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// admin_login.php or equivalent
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Assuming you have a database check here
    $admin_entity = $_POST['user_entity'];  // Or whatever your entity value is
    $_SESSION['user_entity'] = $admin_entity;  // Set the session variable

    // Redirect to the admin dashboard or the page you want
    header('Location: admin_dashboard.php');
    exit();
}

require_once 'config.php';

$admin_entity = $_SESSION['user_entity'];

// Handle the form submission to update leave balances
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_leave'])) {
    // Get the updated leave balances and staff ID from the form
    $staff_id = $_POST['staff_id'];
    $annual_leave = $_POST['annual_leave'];
    $medical_leave = $_POST['medical_leave'];
    $unpaid_leave = $_POST['unpaid_leave'];
    $emergency_leave = $_POST['emergency_leave'];
    $half_morning_annual_leave = $_POST['half_morning_annual_leave'];
    $half_afternoon_annual_leave = $_POST['half_afternoon_annual_leave'];
    $maternity_leave = $_POST['maternity_leave'];
    $paternity_leave = $_POST['paternity_leave'];

    // Update the leave balances in the database
    $update_sql = "
        UPDATE leave_types 
        SET `Annual Leave`= ?, `Medical Leave`= ?, `Unpaid Leave`= ?, `Emergency Leave`= ?, `Half Morning Annual Leave`= ?, `Half Afternoon Annual Leave`= ?, `Maternity Leave`= ?, `Paternity Leave`= ? 
        WHERE staff_id = ? AND staff_id IN (SELECT id FROM staff WHERE entity = ?)";
    $stmt = $conn->prepare($update_sql);
    if ($stmt) {
        $stmt->bind_param("iiiiiiiiii", $annual_leave, $medical_leave, $unpaid_leave, $emergency_leave, $half_morning_annual_leave, $half_afternoon_annual_leave, $maternity_leave, $paternity_leave, $staff_id, $admin_entity);

        if ($stmt->execute()) {
            $message = "Leave balances updated successfully for Staff ID $staff_id.";
        } else {
            $message = "Error updating leave balances.";
        }

        // Close the statement
        $stmt->close();
    } else {
        $message = "Error preparing update statement.";
    }
}

// Fetch staff leave data if staff_id is provided in the URL
if (isset($_GET['staff_id'])) {
    $staff_id = $_GET['staff_id'];

    // Query the leave_types table for the selected staff in the admin's entity
    $sql = "
        SELECT staff.gender, leave_types.* 
        FROM leave_types 
        JOIN staff ON leave_types.staff_id = staff.id 
        WHERE staff.id = ? AND staff.entity = ?";
    $stmt = $conn->prepare($sql);
    if ($stmt) {
        $stmt->bind_param("ii", $staff_id, $admin_entity);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // Fetch the data for the staff
            $leave_data = $result->fetch_assoc();
            $staff_gender = $leave_data['gender']; // Store the gender of the staff
        } else {
            $message = "No leave data found for Staff ID $staff_id in your entity.";
        }

        // Close the statement
        $stmt->close();
    } else {
        $message = "Error fetching leave data.";
    }
}

// Handle the staff search by employee_id or name
if (isset($_GET['search_staff'])) {
    $search_value = $_GET['search_staff'];

    // Query the staff table by employee_id or name
    $search_sql = "
        SELECT id, name, email, gender 
        FROM staff 
        WHERE (employee_id LIKE ? OR name LIKE ?) AND entity = ?";
    $stmt = $conn->prepare($search_sql);
    if ($stmt) {
        $like_search_value = '%' . $search_value . '%';
        $stmt->bind_param("ssi", $like_search_value, $like_search_value, $admin_entity);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $staff_list = [];
            while ($row = $result->fetch_assoc()) {
                $staff_list[] = $row;
            }
        } else {
            $message = "No staff found matching the search criteria.";
        }

        // Close the statement
        $stmt->close();
    } else {
        $message = "Error searching for staff.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Edit Leave</title>
    <link rel="stylesheet" href="css/admin_edit_leave.css">
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/admin_top_nav.css">
    <script src="js/admin_top_nav.js"></script>
</head>
<body>
    <!-- Include Top Navigation Bar -->
    <?php include('admin_top_nav.php'); ?>

    <div class="container">
        <h1 class="mb-4">Admin: Edit Leave Balances</h1>

        <!-- Display success or error message -->
        <?php if (isset($message)): ?>
            <div class="alert alert-info"><?php echo $message; ?></div>
        <?php endif; ?>

        <!-- Wrapper for centering the search form -->
        <div class="search-wrapper">
            <!-- Search form for employee_id or Name -->
            <form action="admin_edit_leave.php" method="GET" class="mb-4 search-form">
                <div class="input-group">
                    <label for="search_staff" class="input-group-text">Search by Employee ID or Name:</label>
                    <input type="text" name="search_staff" id="search_staff" class="form-control" required>
                    <button style=" width: 100px;" type="submit" class="btn">Search</button>
                </div>
            </form>
        </div>

        <!-- Display search results -->
        <?php if (isset($staff_list) && !empty($staff_list)): ?>
            <h2 style="  text-align: center">Staff Found:</h2>
            <ul class="list-group">
                <?php foreach ($staff_list as $staff): ?>
                    <li class="list-group-item">
                        <a href="admin_edit_leave.php?staff_id=<?php echo $staff['id']; ?>">
                            <?php echo $staff['name']; ?> (Staff ID: <?php echo $staff['id']; ?>)
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>

        <!-- Display staff leave data in an editable form if a staff ID is selected -->
<?php if (isset($leave_data)): ?>
    <h2 class="mt-5" style="  text-align: center">Edit Leave Balances for Staff ID: <?php echo $staff_id; ?> </h2>
    <form action="admin_edit_leave.php" method="POST">
        <input type="hidden" name="staff_id" value="<?php echo $staff_id; ?>">

        <div class="mb-3">
            <label for="annual_leave" class="form-label">Annual Leave:</label>
            <input type="number" name="annual_leave" id="annual_leave" class="form-control" value="<?php echo $leave_data['Annual Leave']; ?>" required>
        </div>

        <div class="mb-3">
            <label for="medical_leave" class="form-label">Medical Leave:</label>
            <input type="number" name="medical_leave" id="medical_leave" class="form-control" value="<?php echo $leave_data['Medical Leave']; ?>" required>
        </div>
        
        <div class="mb-3">
            <label for="unpaid_leave" class="form-label">Unpaid Leave:</label>
            <input type="number" name="unpaid_leave" id="unpaid_leave" class="form-control" value="<?php echo $leave_data['Unpaid Leave']; ?>" required>
        </div>
        
        <div class="mb-3">
            <label for="emergency_leave" class="form-label">Emergency Leave:</label>
            <input type="number" name="emergency_leave" id="emergency_leave" class="form-control" value="<?php echo $leave_data['Emergency Leave']; ?>" required>
        </div>
        
        <div class="mb-3">
            <label for="half_morning_annual_leave" class="form-label">Half Morning Annual Leave:</label>
            <input type="number" name="half_morning_annual_leave" id="half_morning_annual_leave" class="form-control" value="<?php echo $leave_data['Half Morning Annual Leave']; ?>" required>
        </div>
        
        <div class="mb-3">
            <label for="half_afternoon_annual_leave" class="form-label">Half Afternoon Annual Leave:</label>
            <input type="number" name="half_afternoon_annual_leave" id="half_afternoon_annual_leave" class="form-control" value="<?php echo $leave_data['Half Afternoon Annual Leave']; ?>" required>
        </div>
        
        <?php if ($staff_gender == 'Female'): ?>
            <div class="mb-3">
                <label for="maternity_leave" class="form-label">Maternity Leave:</label>
                <input type="number" name="maternity_leave" id="maternity_leave" class="form-control" value="<?php echo $leave_data['Maternity Leave']; ?>" required>
            </div>
        <?php endif; ?>
        
        <?php if ($staff_gender == 'Male'): ?>
            <div class="mb-3">
                <label for="paternity_leave" class="form-label">Paternity Leave:</label>
                <input type="number" name="paternity_leave" id="paternity_leave" class="form-control" value="<?php echo $leave_data['Paternity Leave']; ?>" required>
            </div>
        <?php endif; ?>

        <button style=" width: 300px;" type="submit" name="update_leave" class="btn btn-success">Update Leave Balances</button>
    </form>
<?php endif; ?>

    </div>
</body>
</html>
