<?php
session_start();
require_once 'config.php';

// Check if the admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

// Check if staff ID is provided in the URL
if (isset($_GET['id'])) {
    $staff_id = $_GET['id'];
    $sql = "SELECT * FROM staff WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $staff_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $staff = $result->fetch_assoc();
    $stmt->close();

    if (!$staff) {
        echo "Staff not found.";
        exit();
    }
} else {
    echo "Invalid staff ID.";
    exit();
}

// Fetch all parties and departments from the database
$parties_sql = "SELECT id, party_name FROM parties";
$parties_result = $conn->query($parties_sql);

$department_sql = "SELECT id, department_name FROM department";
$department_result = $conn->query($department_sql);
// Handle form submission to update staff details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $employee_id = $_POST['employee_id'];
    $parties = $_POST['parties'];  // Party name
    $department = $_POST['department'];  // Department name

    // Check if new password is provided and matches the confirm password
    if (!empty($_POST['new_password']) && $_POST['new_password'] === $_POST['confirm_password']) {
        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);  // Hash the new password

        // Update staff details with new password
        $sql = "UPDATE staff SET name = ?, email = ?, employee_id = ?, parties = ?, department = ?, password = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssi", $name, $email, $employee_id, $parties, $department, $new_password, $_POST['id']);
    } else {
        // Update staff details without changing the password
        $sql = "UPDATE staff SET name = ?, email = ?, employee_id = ?, parties = ?, department = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssi", $name, $email, $employee_id, $parties, $department, $_POST['id']);
    }

    if ($stmt->execute()) {
        $_SESSION['message'] = "Staff details updated successfully!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error updating staff details.";
        $_SESSION['message_type'] = "error";
    }
    $stmt->close();
    header("Location: admin_edit_delete.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Staff</title>
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/admin_top_nav.css">
    <script src="js/admin_top_nav.js"></script>
    <style>
        /* Override the default Bootstrap btn-primary color */
form .btn-primary {
    background-color: #102f53 !important; /* Custom blue color */
    color: white !important; /* Text color set to white */
    padding: 12px 20px !important; /* Add some padding for a bigger button */
    font-size: 16px !important; /* Increase font size for better readability */
    border: none !important; /* Remove border */
    border-radius: 5px !important; /* Ensure the button has rounded corners */
    transition: background-color 0.3s ease; /* Smooth transition for hover effect */
}

/* Button hover effect */
form .btn-primary:hover {
    background-color: #0e2744 !important; /* Darker shade of blue when hovering */
    color: white !important; /* Maintain white text color on hover */
}

/* Button focus effect */
form .btn-primary:focus {
    outline: none !important; /* Remove the default outline */
    box-shadow: 0 0 0 0.2rem rgba(16, 47, 83, 0.5) !important; /* Add custom blue shadow on focus */
}

    </style>
</head>
<body>
    <?php include 'admin_top_nav.php'; ?>

    <div class="container mt-5">
        <!-- Success/Error Message -->
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert <?php echo $_SESSION['message_type'] === 'success' ? 'alert-success' : 'alert-danger'; ?> alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?php
                    unset($_SESSION['message']);
                    unset($_SESSION['message_type']);
                ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="card p-4 shadow">
            <h2 class="text-center mb-4">Edit Staff Details</h2>
            <input type="hidden" name="id" value="<?php echo $staff['id']; ?>">

            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($staff['name']); ?>" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($staff['email']); ?>" required>
            </div>

            <div class="mb-3">
                <label for="staff_id" class="form-label">Staff ID</label>
                <input type="text" name="employee_id" class="form-control" value="<?php echo htmlspecialchars($staff['employee_id']); ?>" required>
            </div>

            <!-- Parties Dropdown -->
            <div class="mb-3">
                <label for="parties" class="form-label">Parties</label>
                <select name="parties" class="form-select" required>
                    <option value="">Select Party</option>
                    <?php if ($parties_result->num_rows > 0): ?>
                        <?php while ($party = $parties_result->fetch_assoc()): ?>
                            <option value="<?php echo $party['party_name']; ?>" <?php echo ($party['party_name'] == $staff['parties']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($party['party_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <option value="">No parties available</option>
                    <?php endif; ?>
                </select>
            </div>

            <!-- Department Dropdown -->
            <div class="mb-3">
                <label for="department" class="form-label">Department</label>
                <select name="department" class="form-select" required>
                    <option value="">Select Department</option>
                    <?php if ($department_result->num_rows > 0): ?>
                        <?php while ($department = $department_result->fetch_assoc()): ?>
                            <option value="<?php echo $department['department_name']; ?>" <?php echo ($department['department_name'] == $staff['department']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($department['department_name']); ?>
                            </option>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <option value="">No departments available</option>
                    <?php endif; ?>
                </select>
            </div>

            <!-- Password Fields -->
            <div class="mb-3">
                <label for="new_password" class="form-label">New Password</label>
                <input type="password" name="new_password" class="form-control" placeholder="Enter new password">
            </div>

            <div class="mb-3">
                <label for="confirm_password" class="form-label">Confirm New Password</label>
                <input type="password" name="confirm_password" class="form-control" placeholder="Confirm new password">
            </div>

            <div class="text-center">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>

    <script>
        // Client-side validation to check if passwords match
        document.querySelector('.card').addEventListener('submit', function(event) {
            const newPassword = document.querySelector('[name="new_password"]').value;
            const confirmPassword = document.querySelector('[name="confirm_password"]').value;

            // Check if both passwords match
            if (newPassword !== confirmPassword) {
                alert('The new password and confirm password do not match.');
                event.preventDefault(); // Prevent form submission
            }
        });
    </script>
</body>
</html>

