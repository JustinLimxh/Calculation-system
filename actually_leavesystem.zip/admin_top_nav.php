<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Example: Assume the username is stored in session as 'name'
$name = isset($_SESSION['user_name']) ? $_SESSION['user_name'] : "Guest";
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- Bootstrap Icons CDN -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

<style>
    /* Override Bootstrap navbar color */
    .navbar.navbar-expand-lg.navbar-dark.bg-primary {
        background-color: #102f53 !important; /* Dark blue background for navbar */
    }

    .navbar-dark .navbar-nav .nav-link {
        color: #ffffff !important; /* White links */
    }

    /* Change hover color */
    .navbar-dark .navbar-nav .nav-link:hover {
        background-color: #000000 !important; /* Darker blue for hover */
        border-radius: 5px; /* Optional: rounded hover effect */
    }

    /* Navbar brand color */
    .navbar-dark .navbar-brand {
        color: #ffffff !important; /* White for the logo text or brand */
    }

    /* Logout button style */
    .navbar-dark .btn-danger {
        background-color: #cc0000 !important; /* Custom red for logout button */
        border-color: #cc0000 !important;
    }

    .navbar-dark .btn-danger:hover {
        background-color: #a00000 !important; /* Darker red on hover */
        border-color: #a00000 !important;
    }

    .navbar-text {
        color: #ADD8E6 !important;
    }
    
    /* Profile Dropdown Button */
.d-flex.align-items-center.ms-3 .dropdown {
    position: relative; /* Ensure the dropdown is positioned relative to its container */
}

.d-flex.align-items-center.ms-3 .dropdown-toggle {
    background-color: transparent !important; /* Remove background */
    border: none !important; /* Remove border */
    color: #fff !important; /* White text color */
    font-size: 20px !important; /* Icon size */
    padding: 10px 15px; /* Adjust padding to match navigation items */
    border-radius: 5px; /* Rounded corners */
    cursor: pointer; /* Pointer cursor for the button */
    transition: background-color 0.3s ease-in-out; /* Smooth hover effect */
}

.d-flex.align-items-center.ms-3 .dropdown-toggle i {
    font-size: 25px !important; /* Profile icon size */
}

/* Profile Dropdown Menu */
.d-flex.align-items-center.ms-3 .dropdown-menu {
    position: absolute !important;
    top: 100% !important; /* Position the dropdown just below the button */
    right: 0 !important; /* Align the dropdown to the right */
    background-color: #102f53 !important; /* Dark blue background */
    border-radius: 5px !important; /* Rounded corners */
    box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1) !important; /* Soft shadow for depth */
    display: none !important; /* Hidden by default */
    min-width: 200px !important; /* Minimum width */
    max-width: 250px !important; /* Set max width to avoid overflowing */
    z-index: 1000 !important; /* Ensure the dropdown is above other content */
    overflow-x: auto !important; /* Allow scrolling horizontally if needed */
}

/* Dropdown Menu Items */
.d-flex.align-items-center.ms-3 .dropdown-menu li {
    padding: 0; /* Remove padding from the list items */
}

.d-flex.align-items-center.ms-3 .dropdown-menu li a, 
.d-flex.align-items-center.ms-3 .dropdown-menu li span {
    color: #fff !important; /* White text */
    text-decoration: none !important; /* Remove underline */
    padding: 10px 15px; /* Padding around each item */
    display: block; /* Block-level for easier clicking */
    font-weight: bold; /* Bold text for emphasis */
    transition: background-color 0.3s ease; /* Smooth hover effect */
}

/* Hover effect for dropdown items */
.d-flex.align-items-center.ms-3 .dropdown-menu li a:hover,
.d-flex.align-items-center.ms-3 .dropdown-menu li span:hover {
    background-color: #0e2744 !important; /* Darker shade for hover */
    cursor: pointer; /* Pointer cursor for clickable items */
}

/* Special styling for the "Welcome" item */
.d-flex.align-items-center.ms-3 .dropdown-menu li span {
    font-size: 14px !important; /* Smaller text for the welcome message */
    font-weight: normal !important; /* Less emphasis on the welcome text */
}

/* Show the dropdown when active */
.d-flex.align-items-center.ms-3 .dropdown-menu.show {
    display: block !important; /* Make the menu visible when the 'show' class is added */
}

/* Prevent the dropdown from overflowing the screen */
.d-flex.align-items-center.ms-3 .dropdown-menu {
    right: 0 !important; /* Keep it aligned to the right edge */
    left: auto !important; /* Ensure it doesn’t overflow to the left */
    max-width: 250px !important; /* Set max width to avoid cutting off */
    width: 100% !important; /* Make the dropdown take the available width */
}

/* Mobile-specific adjustments */
@media screen and (max-width: 768px) {
    /* Hide the profile icon on mobile */
    .d-flex.align-items-center.ms-3 .dropdown-toggle {
        display: none !important; /* Hide profile icon */
    }

    /* Display the profile content normally on mobile */
    .profile-content {
        display: block !important; /* Make profile content visible */
        color: #fff;
        padding: 10px;
        background-color: #102f53; /* Dark blue background for profile section */
        border-radius: 5px;
        text-align: center;
    }

    /* Adjust the dropdown menu positioning for mobile */
    .d-flex.align-items-center.ms-3 .dropdown-menu {
        position: relative !important; /* Make dropdown menu display normally */
        right: auto !important;
        left: auto !important;
        box-shadow: none; /* Remove box-shadow for mobile */
        background-color: #102f53;
        border-radius: 5px;
        display: block; /* Always visible */
    }

    /* Style for profile content in dropdown on mobile */
    .profile-content a {
        color: #fff;
        font-weight: bold;
        text-decoration: none;
        padding: 8px 12px;
        display: block;
        transition: background-color 0.3s;
    }

    .profile-content a:hover {
        background-color: #0e2744; /* Darker shade of blue for hover */
    }
}


</style>

<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container-fluid">
        <!-- Logo -->
        <a class="navbar-brand" href="admin_dashboard.php">
            <img src="images/logo.jpg" alt="Logo" class="d-inline-block align-top logo" height="40">
        </a>
        <!-- Hamburger Menu -->
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <!-- Navbar Content -->
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item"><a class="nav-link" href="admin_dashboard.php">Dashboard</a></li>
                <li class="nav-item"><a class="nav-link" href="admin_create.php">Create Staff</a></li>
                <li class="nav-item"><a class="nav-link" href="admin_edit_delete.php">Edit/Delete Staff</a></li>
                <li class="nav-item"><a class="nav-link" href="admin_create_approver.php">Create Approver</a></li>
                <li class="nav-item"><a class="nav-link" href="admin_edit_delete_approver.php">Edit/Delete Approver</a></li>
                <li class="nav-item"><a class="nav-link" href="admin_manage_leave.php">Manage Leave</a></li>
                <li class="nav-item"><a class="nav-link" href="admin_edit_leave.php">Manage Edit</a></li>
            </ul>
<div class="d-flex align-items-center ms-3">
    <!-- Profile Button on Desktop -->
    <div class="dropdown">
        <button class="btn btn-secondary dropdown-toggle" type="button" id="profileDropdown" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="bi bi-person-circle"></i> <!-- Profile Icon -->
        </button>
        <ul class="dropdown-menu" aria-labelledby="profileDropdown">
            <li><span class="dropdown-item">Welcome, <b><?php echo htmlspecialchars($name); ?></b></span></li>
            <li><a href="staff_logout.php" class="dropdown-item">Logout</a></li>
        </ul>
    </div>
    <!-- Profile Content on Mobile (Visible without the icon) -->
    <div class="profile-content" style="display: none;">
        <span>Welcome, <b><?php echo htmlspecialchars($name); ?></b></span>
        <a href="staff_logout.php">Logout</a>
    </div>
</div>

        </div>
    </div>
</nav>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
