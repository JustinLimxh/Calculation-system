<?php
session_start();

// Check if the staff is logged in
if (!isset($_SESSION['email'])) {
    header("Location: staff_login.html"); // Redirect to login page if not logged in
    exit();
}

// Database connection
require_once 'config.php';

// Get the logged-in staff's email
$staff_email = $_SESSION['email'];

// Fetch the entity of the logged-in staff
$sql_staff = "SELECT entity FROM staff WHERE email = ?";
$stmt = $conn->prepare($sql_staff);
$stmt->bind_param("s", $staff_email);
$stmt->execute();
$stmt->bind_result($staff_entity);
$stmt->fetch();
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard</title>
    <link rel="stylesheet" href="css/staff_dashboard.css">
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/staff_top_nav.css">
     <script src="js/staff_top_nav.js"></script> 
     
</head>
<body class="staff-dashboard">
    <!-- Include Top Navigation Bar -->
    <?php include('staff_top_nav.php'); ?>

    <!-- Dashboard Content -->
    <div class="container mt-5">
    <div class="text-center">
        <h1 class="display-4">Welcome to Your Dashboard!</h1>
        <p class="lead">You're successfully logged in to your staff dashboard.</p>
        <p>Logged in as: <strong><?php echo $_SESSION['email']; ?></strong></p>
        <a href="staff_logout.php" class="btn btn-danger">Logout</a>
    </div>
</div>

    
    <?php
    $conn->close(); // Close database connection
    ?>


</body>
</html>
