<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
date_default_timezone_set('Asia/Kuala_Lumpur'); // Set timezone to Malaysia

// Check if the admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html"); // Redirect to login page if not logged in
    exit();
}

// Database connection
require_once 'config.php';

// Retrieve admin's entity
$admin_email = $_SESSION['email'];
$sql = "SELECT entity FROM admin WHERE email=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$stmt->bind_result($admin_entity);
$stmt->fetch();
$stmt->close();

// Retrieve parties for dropdown
$parties_query = "SELECT party_name FROM parties";
$parties_result = $conn->query($parties_query);

// Retrieve departments for dropdown
$departments_query = "SELECT department_name FROM department";
$departments_result = $conn->query($departments_query);

// Handle staff creation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $staff_id = $_POST['staff_id']; // Get staff ID
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password
    $entity = $admin_entity; // Set entity to admin's entity
    $party = $_POST['party']; // Selected party
    $department = $_POST['department']; // Selected department
    $ic_number = $_POST['ic_number']; // IC Number
    $gender = $_POST['gender']; // Gender
    $created_at = date("Y-m-d H:i:s"); // Current Malaysia time

    // Check if email already exists
    $sql = "SELECT * FROM staff WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Staff with this email already exists!');</script>";
    } else {
        // Insert new staff account with staff_id, IC number, and gender
        $stmt = $conn->prepare("INSERT INTO staff (employee_id, name, email, password, entity, parties, department, ic_number, gender, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssssss", $staff_id, $name, $email, $password, $entity, $party, $department, $ic_number, $gender, $created_at);

        if ($stmt->execute()) {
            // Get the last inserted staff ID
            $staff_id = $stmt->insert_id;

            // Insert default leave data for the newly registered staff
            $leave_stmt = $conn->prepare("INSERT INTO leave_types (staff_id, `Annual Leave`, `Medical Leave`, `Unpaid Leave`, `Emergency Leave`, `Half Morning Annual Leave`, `Half Afternoon Annual Leave`, `Maternity Leave`, `Paternity Leave`) VALUES (?, 0, 5, 5, 0, 5, 5, 7, 7)");
            $leave_stmt->bind_param("i", $staff_id);

            if ($leave_stmt->execute()) {
                echo "<script>alert('New staff registered successfully.');</script>";
                echo "<script>window.location.href = 'admin_create.php';</script>";
                exit();
            } else {
                echo "Error inserting default leave: " . $leave_stmt->error; // Display SQL error if any
            }

            $leave_stmt->close();
        } else {
            echo "Error: " . $stmt->error; // Display SQL error if any
        }
    }
    $ic_number = $_POST['ic_number']; // IC Number

if (strlen($ic_number) > 12) {
    echo "<script>alert('Exceeded number, please enter a correct IC number.');</script>";
    exit();
}


    $stmt->close();
    $conn->close();
}

// Handle adding new party
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_party'])) {
    $new_party = $_POST['new_party'];
    $add_party_sql = "INSERT INTO parties (party_name) VALUES (?)";
    $stmt = $conn->prepare($add_party_sql);
    $stmt->bind_param("s", $new_party);

    if ($stmt->execute()) {
        echo "<script>alert('New party added successfully.');</script>";
        echo "<script>window.location.href = 'admin_createf.php';</script>";
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Handle adding new department
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_department'])) {
    $new_department = $_POST['new_department'];
    $add_department_sql = "INSERT INTO department (department_name) VALUES (?)";
    $stmt = $conn->prepare($add_department_sql);
    $stmt->bind_param("s", $new_department);

    if ($stmt->execute()) {
        echo "<script>alert('New department added successfully.');</script>";
        echo "<script>window.location.href = 'admin_create.php';</script>";
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

// Handle deleting a party
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_party'])) {
    $party_id = $_POST['party_id'];
    $delete_party_sql = "DELETE FROM parties WHERE id=?";
    $stmt = $conn->prepare($delete_party_sql);
    $stmt->bind_param("i", $party_id);

    if ($stmt->execute()) {
        echo "<script>alert('Party deleted successfully.');</script>";
        echo "<script>window.location.href = 'admin_create.php';</script>";
        exit();
    } else {
        echo "Error deleting party: " . $stmt->error;
    }
    $stmt->close();
}

// Handle deleting a department
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_department'])) {
    $department_id = $_POST['department_id'];
    $delete_department_sql = "DELETE FROM department WHERE id=?";
    $stmt = $conn->prepare($delete_department_sql);
    $stmt->bind_param("i", $department_id);

    if ($stmt->execute()) {
        echo "<script>alert('Department deleted successfully.');</script>";
        echo "<script>window.location.href = 'admin_create.php';</script>";
        exit();
    } else {
        echo "Error deleting department: " . $stmt->error;
    }
    $stmt->close();
}

// Refresh parties and departments for display
$parties_result_display = $conn->query("SELECT id, party_name FROM parties");
$departments_result_display = $conn->query("SELECT id, department_name FROM department");

$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Staff Account</title>
    <link rel="stylesheet" href="css/admin_create.css">
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/admin_top_nav.css">
    <script src="js/admin_top_nav.js"></script>
</head>
<body class="admin-create">

    <!-- Include Top Navigation Bar -->
    <?php include 'admin_top_nav.php'; ?>

    <!-- Forms Container: Staff Creation Form and Manage Parties Form -->
    <div class="container mt-5">
        <div class="row g-4">

            <!-- Create Staff Form -->
            <div class="col-lg-6">
                <div class="card p-4 shadow-sm">
                    <h2 class="text-center mb-4 text-primary">Create Staff Account</h2>
                    <form method="POST" action="admin_create.php">
                        <div class="mb-3">
                            <label for="staff_id" class="form-label">Staff ID:</label>
                            <input type="text" class="form-control" id="staff_id" name="staff_id" required>
                        </div>

                        <div class="mb-3">
                            <label for="name" class="form-label">Name:</label>
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>

                        <div class="mb-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>

                        <div class="mb-3">
                            <label for="password" class="form-label">Password:</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>

                        <div class="mb-3">
                            <label for="entity" class="form-label">Entity:</label>
                            <input type="text" class="form-control" id="entity" value="<?php echo htmlspecialchars($admin_entity); ?>" disabled>
                            <input type="hidden" name="entity" value="<?php echo htmlspecialchars($admin_entity); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="party" class="form-label">Location:</label>
                            <select id="party" class="form-select" name="party" required>
                                <?php while ($party = $parties_result->fetch_assoc()) { ?>
                                    <option value="<?php echo htmlspecialchars($party['party_name']); ?>">
                                        <?php echo htmlspecialchars($party['party_name']); ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="department" class="form-label">Department:</label>
                            <select id="department" class="form-select" name="department" required>
                                <?php while ($department = $departments_result->fetch_assoc()) { ?>
                                    <option value="<?php echo htmlspecialchars($department['department_name']); ?>">
                                        <?php echo htmlspecialchars($department['department_name']); ?>
                                    </option>
                                <?php } ?>
                            </select>
                        </div>

                        <div class="mb-3">
                            <label for="ic_number" class="form-label">IC Number:</label>
                            <input type="text" class="form-control" id="ic_number" name="ic_number" maxlength="12" required oninput="validateICNumber(this)">
                            <span id="icNumberError" class="text-danger" style="font-size: 12px;"></span>
                        </div>

                        <div class="mb-3">
                            <label for="gender" class="form-label">Gender:</label>
                            <select id="gender" class="form-select" name="gender" required>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                            </select>
                        </div>

                        <div class="d-grid gap-2">
                            <button type="submit" class="btn btn-primary" name="register">Create Account</button>
                        </div>
                    </form>
                </div>
            </div>

               <!-- Manage Location and Manage Departments Forms -->
            <div class="col-lg-6">
                <div class="row g-4">
                    <!-- Manage Parties Form (Location) -->
                    <div class="col-md-6">
                        <div class="card p-4 shadow-sm">
                            <h2 class="text-center mb-4 text-primary">Manage Location</h2>
                            <form method="POST" action="admin_create.php">
                                <div class="mb-3">
                                    <label for="new_party" class="form-label">Add New Location:</label>
                                    <input type="text" class="form-control" id="new_party" name="new_party" required>
                                </div>
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-secondary" name="add_party">Add Location</button>
                                </div>
                            </form>

                            <h3 class="mt-4">Current Available Locations</h3>
                            <ul class="list-group">
                                <?php while ($party = $parties_result_display->fetch_assoc()) { ?>
                                    <li class="list-group-item">
                                        <?php echo htmlspecialchars($party['party_name']); ?>
                                    </li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>

                    <!-- Manage Departments Form -->
                    <div class="col-md-6">
                        <div class="card p-4 shadow-sm">
                            <h2 class="text-center mb-4 text-primary">Manage Departments</h2>
                            <form method="POST" action="admin_create.php">
                                <div class="mb-3">
                                    <label for="new_department" class="form-label">Add New Department:</label>
                                    <input type="text" class="form-control" id="new_department" name="new_department" required>
                                </div>
                                <div class="d-grid gap-2">
                                    <button type="submit" class="btn btn-secondary" name="add_department">Add Department</button>
                                </div>
                            </form>

                            <h3 class="mt-4">Current Available Departments</h3>
                            <ul class="list-group">
                                <?php while ($department = $departments_result_display->fetch_assoc()) { ?>
                                    <li class="list-group-item">
                                        <?php echo htmlspecialchars($department['department_name']); ?>
                                    </li>
                                <?php } ?>
                            </ul>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

</body>
</html>