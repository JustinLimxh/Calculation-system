<?php
session_start();

// Check if the staff is logged in
if (!isset($_SESSION['email'])) {
    header("Location: staff_login.html");
    exit();
}

require_once 'config.php';

$email = $_SESSION['email'];
$message = "";

// Fetch current name and entity
$sql = "SELECT name, entity FROM staff WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->bind_result($current_name, $entity);
$stmt->fetch();
$stmt->close();

// Change password
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['change_password'])) {
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Validate passwords
    if (!empty($new_password) && !empty($confirm_password)) {
        if ($new_password === $confirm_password) {
            // Update new password
            $new_hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
            $sql = "UPDATE staff SET password = ? WHERE email = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $new_hashed_password, $email);

            if ($stmt->execute()) {
                // Success message
                $message = "<span class='success'>Password changed successfully!</span>";

                // Fetch admin email associated with the same entity
                $sql = "SELECT email FROM admin WHERE entity = ?";
                $admin_stmt = $conn->prepare($sql);
                $admin_stmt->bind_param("s", $entity);
                $admin_stmt->execute();
                $admin_stmt->bind_result($admin_email);
                $admin_stmt->fetch();
                $admin_stmt->close();

                if ($admin_email) {
                    // Send an email to the admin with plaintext password
                    $subject = "Password Change Notification";
                    $body = "Dear Admin,\n\nThe password for the staff member with the email '$email' has been successfully changed.\n\nNew Password: $new_password\n\nPlease ensure this change was authorized.\n\nRegards,\nYour System";
                    $headers = "From: noreply@yourdomain.com";

                    if (mail($admin_email, $subject, $body, $headers)) {
                        $message .= "<br><span class='success'>Admin notified successfully.</span>";
                    } else {
                        $message .= "<br><span class='error'>Failed to notify admin.</span>";
                    }
                } else {
                    $message .= "<br><span class='error'>Admin email not found.</span>";
                }
            } else {
                $message = "<span class='error'>Error changing password.</span>";
            }

            $stmt->close();
        } else {
            $message = "New passwords do not match.";
        }
    } else {
        $message = "All password fields are required.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Profile</title>
    <link rel="stylesheet" href="css/staff_profile.css">
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/staff_top_nav.css">
    <script src="js/staff_top_nav.js"></script> 
</head>
<body>
    <!-- Include Top Navigation Bar -->
    <?php include('staff_top_nav.php'); ?>
    
    <div class="container mt-4">
        <h1 class="text-center text-primary mb-4">Staff Profile</h1>
        <p class="alert alert-info text-center"><?php echo $message; ?></p>

        <!-- Current Name -->
        <h2 class="text-center mb-4">Current Name: <?php echo htmlspecialchars($current_name); ?></h2>

        <!-- Change Password Form -->
        <form method="POST" class="profile-form">
            <h3 class="text-center mb-3">Change Password</h3>
            <div class="mb-3">
                <label for="new_password" class="form-label">New Password:</label>
                <input type="password" name="new_password" id="new_password" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="confirm_password" class="form-label">Confirm New Password:</label>
                <input type="password" name="confirm_password" id="confirm_password" class="form-control" required>
            </div>
            <button type="submit" name="change_password" class="btn btn-primary w-100">Change Password</button>
        </form>

    </div>
</body>
</html>
