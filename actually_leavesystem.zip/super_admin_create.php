<?php
session_start();

// Check if the super admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: super_admin_login.html");
    exit();
}

require_once 'config.php';

$message = ''; // Initialize message variable

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add_entity'])) {
        // Add new entity
        $entity_name = trim($_POST['entity_name']);

        if (!empty($entity_name)) {
            $stmt = $conn->prepare("INSERT INTO entity (name) VALUES (?)");
            $stmt->bind_param("s", $entity_name);
            if ($stmt->execute()) {
                echo "<script>alert('New entity added successfully.');</script>";
            } else {
                echo "<script>alert('Error adding entity: " . htmlspecialchars($stmt->error) . "');</script>";
            }
            $stmt->close();
        } else {
            echo "<script>alert('Entity name cannot be empty.');</script>";
        }
    } elseif (isset($_POST['delete_entity'])) {
        // Delete entity
        $entity_id = intval($_POST['entity_id']);
        
        if ($entity_id > 0) {
            $stmt = $conn->prepare("DELETE FROM entity WHERE id = ?");
            $stmt->bind_param("i", $entity_id);
            if ($stmt->execute()) {
                echo "<script>alert('Entity deleted successfully.');</script>";
            } else {
                echo "<script>alert('Error deleting entity: " . htmlspecialchars($stmt->error) . "');</script>";
            }
            $stmt->close();
        } else {
            echo "<script>alert('Invalid entity ID.');</script>";
        }
    } elseif (isset($_POST['create_admin'])) {
        // Create new admin
        $name = trim($_POST['name']);
        $email = trim($_POST['email']);
        $password = trim($_POST['password']);
        $entity = trim($_POST['entity']);
        $status = 'active';

        if (!empty($name) && !empty($email) && !empty($password) && !empty($entity)) {
            $password_hashed = password_hash($password, PASSWORD_BCRYPT);

            // Check for duplicate email
            $stmt = $conn->prepare("SELECT id FROM admin WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $stmt->store_result();

            if ($stmt->num_rows > 0) {
                echo "<script>alert('Email already exists. Please use a different email.');</script>";
            } else {
                // Insert new admin
                $stmt = $conn->prepare("INSERT INTO admin (name, email, password, entity, status) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("sssss", $name, $email, $password_hashed, $entity, $status);
                if ($stmt->execute()) {
                    echo "<script>alert('New admin created successfully.');</script>";
                } else {
                    echo "<script>alert('Error creating admin: " . htmlspecialchars($stmt->error) . "');</script>";
                }
            }
            $stmt->close();
        } else {
            echo "<script>alert('All fields are required.');</script>";
        }
    }
}

// Fetch all entities
$entity_query = "SELECT * FROM entity";
$entities_result = $conn->query($entity_query);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Admin and Manage Entities</title>
    <link rel="stylesheet" href="css/super_admin_create.css">
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/super_admin_top_nav.css">
    <script src="js/super_admin_top_nav.js"></script>
</head>
<body class="super-admin-create">
    <!-- Include Top Navigation Bar -->
    <?php include 'super_admin_top_nav.php'; ?>

    <div class="container mt-5">
        <h2 class="text-center mb-4">Manage Admins and Entities</h2>

        <div class="row g-4">
            <!-- Admin Creation Form -->
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h3 class="card-title mb-4">Create New Admin</h3>
                        <form action="super_admin_create.php" method="POST">
                            <div class="mb-3">
                                <label for="name" class="form-label">Name:</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="email" name="email" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password:</label>
                                <input type="password" name="password" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label for="entity" class="form-label">Entity:</label>
                                <select name="entity" class="form-select" required>
                                    <option value="" disabled selected>Select Entity</option>
                                    <?php
                                    $entities_result->data_seek(0); // Reset pointer for reuse
                                    while ($entity = $entities_result->fetch_assoc()) {
                                        echo "<option value='" . htmlspecialchars($entity['name']) . "'>" . htmlspecialchars($entity['name']) . "</option>";
                                    }
                                    ?>
                                </select>
                            </div>
                            <button type="submit" name="create_admin" class="btn btn-primary w-100">Create Admin</button>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Entity Management Form -->
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-body">
                        <h3 class="card-title mb-4">Manage Entities</h3>
                        <form action="super_admin_create.php" method="POST">
                            <!-- Add New Entity -->
                            <div class="mb-3">
                                <label for="entity_name" class="form-label">Entity Name:</label>
                                <input type="text" name="entity_name" class="form-control" placeholder="Enter new entity name">
                            </div>
                            <button type="submit" name="add_entity" class="btn btn-success w-100 mb-4">Add Entity</button>
                        </form>

                        <h4 class="mb-3">Existing Entities</h4>
                        <table class="table table-striped table-bordered">
                            <thead class="table-dark">
                                <tr>
                                    <th>Entity Name</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $entities_result->data_seek(0); // Reset pointer for display ?>
                                <?php while ($entity = $entities_result->fetch_assoc()) : ?>
                                    <tr>
                                        <td><?= htmlspecialchars($entity['name']); ?></td>
                                        <td>
                                            <form action="super_admin_create.php" method="POST" style="display:inline;">
                                                <input type="hidden" name="entity_id" value="<?= $entity['id']; ?>">
                                                <button type="submit" name="delete_entity" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this entity?');">Delete</button>
                                            </form>
                                        </td>
                                    </tr>
        </div>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
    </div>
</body>
</html>
