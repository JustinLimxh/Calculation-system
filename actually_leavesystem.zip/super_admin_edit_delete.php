<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: super_admin_login.html"); // Redirect to login if not logged in
    exit();
}

require_once 'config.php';

$message = ''; // Initialize message variable

// Handle deletion
if (isset($_GET['delete'])) {
    $admin_id = $_GET['delete'];
    $sql = "DELETE FROM admin WHERE id=$admin_id";
    if ($conn->query($sql) === TRUE) {
        $message = '<div class="success-msg">Account deleted successfully.</div>';
    } else {
        $message = '<div class="error-msg">Error deleting account: ' . $conn->error . '</div>';
    }
}

// Fetch all admins to display
$sql = "SELECT * FROM admin";
$result = $conn->query($sql);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit/Delete Admin Accounts</title>
    <link rel="stylesheet" href="css/super_admin_top_nav.css">
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <script src="js/super_admin_top_nav.js"></script>
</head>
<body class="bg-light">

    <!-- Include Top Navigation Bar -->
    <?php include 'super_admin_top_nav.php'; ?>

    <div class="container mt-4">
        <h2 class="text-center" style="color: #102f53;">Edit/Delete Admin Accounts</h2>

        <!-- Display message after deletion -->
        <?php if (isset($message)) { ?>
            <div class="<?php echo strpos($message, 'successfully') !== false ? 'success-msg' : 'error-msg'; ?>">
                <?php echo $message; ?>
            </div>
        <?php } ?>

        <div class="table-responsive table-container">
            <table class="table table-bordered table-hover super-admin-edit-delete-table">
                <thead class="table-primary" style="background-color: #102f53; color: #fff;">
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Entity</th>
                        <th>Status</th>
                        <th>Password</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()) { ?>
                        <tr>
                            <td><?php echo htmlspecialchars($row['name']); ?></td>
                            <td><?php echo htmlspecialchars($row['email']); ?></td>
                            <td><?php echo htmlspecialchars($row['entity']); ?></td>
                            <td><?php echo htmlspecialchars($row['status']); ?></td>
                            <td><?php echo htmlspecialchars(substr($row['password'], 0, 10)); ?>...</td>
                            <td>
                                <a href="super_admin_edit.php?id=<?php echo $row['id']; ?>" class="btn btn-sm" style="background-color: #102f53; color: #fff;">Edit</a>
                                <a href="?delete=<?php echo $row['id']; ?>" 
                                   class="btn btn-sm" style="background-color: #d32f2f; color: #fff;"
                                   onclick="return confirm('Are you sure you want to delete this admin?');">Delete</a>
                            </td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>

