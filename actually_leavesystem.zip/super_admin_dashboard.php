<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: super_admin_login.html"); // Redirect to login if not logged in
    exit();
}

// Database configuration
require_once 'config.php';

// Fetch total number of admin accounts
$sql = "SELECT COUNT(*) AS total_admins FROM admin";
$result = $conn->query($sql);
$total_admins = 0;

if ($result && $row = $result->fetch_assoc()) {
    $total_admins = $row['total_admins'];
}

$conn->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Dashboard</title>
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/super_admin_dashboard.css">
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/super_admin_top_nav.css">
    <script src="js/super_admin_top_nav.js"></script>
</head>

<body class="admin-dashboard">
    <!-- Include Top Navigation Bar -->
    <?php include 'super_admin_top_nav.php'; ?>

    <!-- Dashboard Content -->
    <div class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-8 text-center">
                <h1 class="mb-4">Welcome, Super Admin!</h1>
                <p class="lead">You're successfully logged in to the super admin dashboard.</p>
                <p>Logged in as: <strong><?php echo $_SESSION['email']; ?></strong></p>
                <a href="logout.php" class="btn btn-danger mt-3">Logout</a>
            </div>
        </div>
    </div>
    <?php
    $conn->close(); // Close database connection
    ?>
</body>

</html>
