<?php
// Predefined location (latitude and longitude)
$officeLat = 5.337451; // Example: Office latitude
$officeLng = 100.307869; // Example: Office longitude
$allowedRadius = 100; // Allowed radius in meters (adjusted for GPS accuracy)

// Function to calculate the distance between two coordinates
function getDistance($lat1, $lng1, $lat2, $lng2)
{
    $earthRadius = 6371000; // Earth radius in meters
    $latDelta = deg2rad($lat2 - $lat1);
    $lngDelta = deg2rad($lng2 - $lng1);

    $a = sin($latDelta / 2) * sin($latDelta / 2) +
        cos(deg2rad($lat1)) * cos(deg2rad($lat2)) *
        sin($lngDelta / 2) * sin($lngDelta / 2);
    $c = 2 * atan2(sqrt($a), sqrt(1 - $a));

    return round($earthRadius * $c, 2); // Round to 2 decimal places
}

// Get user's location (example: retrieved from frontend via POST request)
$userLat = $_POST['latitude'] ?? null;
$userLng = $_POST['longitude'] ?? null;

// Check if location data is available
if ($userLat !== null && $userLng !== null) {
    $distance = getDistance($officeLat, $officeLng, $userLat, $userLng);

    if ($distance <= $allowedRadius) {
        // User is within the allowed radius
        echo "You are within the location. Clock-in successful! Distance: {$distance} meters.";
        // Add your database logic to save the clock-in
    } else {
        // User is outside the allowed radius
        echo "You are not within the allowed location to clock in. Distance: {$distance} meters.";
    }
} else {
    echo "Location data is not available.";
}
