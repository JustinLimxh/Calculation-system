<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: staff_login.html");
    exit();
}

require_once 'config.php';

$staff_email = $_SESSION['email'];

// Fetch staff_id and gender based on email
$sql = "SELECT id, gender FROM staff WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $staff_email);
$stmt->execute();
$stmt->bind_result($staff_id, $gender);
$stmt->fetch();
$stmt->close();

// Fetch all leave types for the logged-in staff
$sql = "SELECT * FROM leave_types WHERE staff_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $staff_id);
$stmt->execute();
$result = $stmt->get_result();
$leave_data = $result->fetch_assoc();
$stmt->close();
$conn->close();

// Remove unnecessary fields
unset($leave_data['staff_id']);
unset($leave_data['id']);
unset($leave_data['last_updated_date']);
unset($leave_data['last_increment_date']);

// Calculate Emergency Leave as the sum of Annual Leave and Unpaid Leave
if (isset($leave_data['Annual Leave'], $leave_data['Unpaid Leave'])) {
    $leave_data['Emergency Leave'] = $leave_data['Annual Leave'] + $leave_data['Unpaid Leave'];
}
$leave_data['Half Morning Annual Leave'] = $leave_data['Annual Leave'];
$leave_data['Half Afternoon Annual Leave'] = $leave_data['Annual Leave'];

// Filter leave types based on gender
if ($gender == 'Male') {
    unset($leave_data['Maternity Leave']); // Remove Maternity Leave for male staff
} elseif ($gender == 'Female') {
    unset($leave_data['Paternity Leave']); // Remove Paternity Leave for female staff
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Balance</title>
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <!-- Your custom CSS files -->
    <link rel="stylesheet" href="css/staff_top_nav.css">
    <link rel="stylesheet" href="css/leave_balance.css">
    <script src="js/staff_top_nav.js"></script>
</head>
<body>
    <!-- Include Top Navigation Bar -->
    <?php include('staff_top_nav.php'); ?>

    <div class="container mt-4">
        <h2 class="text-center">Your Leave Balance</h2>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Leave Type</th>
                    <th>Available</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($leave_data as $leave_type => $balance): ?>
                    <?php if ($leave_type == 'Emergency Leave'): ?>
                        <tr>
                            <td><?php echo ucfirst(strtolower(str_replace(' ', ' ', $leave_type))); ?></td>
                            <td><?php echo $balance; ?></td>
                        </tr>
                    <?php elseif (!in_array($leave_type, ['last_updated_date', 'last_increment_date'])): ?>
                        <tr>
                            <td><?php echo ucfirst(strtolower(str_replace(' ', ' ', $leave_type))); ?></td>
                            <td><?php echo $balance; ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
