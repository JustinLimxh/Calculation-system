<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

require_once 'config.php';

// Handle form submission
if (isset($_POST['submit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate the form inputs
    if (empty($email) || empty($password)) {
        echo "Please fill in all fields.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format.";
    } else {
        // Hash the password before storing it
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare SQL statement using prepared statements to prevent SQL injection
        $sql = "INSERT INTO super_admin (email, password) VALUES (?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $email, $hashed_password);

        // Execute the statement
        if ($stmt->execute()) {
            // Redirect to login page after successful registration
            header("Location: super_admin_login.html");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        // Close the statement
        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Super Admin Registration</title>
    <link rel="stylesheet" href="css/super_admin_register.css">
     <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
</head>
<body>
    <div class="super-admin-register">
        <h2 class="super-admin-register-title">Super Admin Registration</h2>
        <form action="super_admin_register.php" method="POST" class="super-admin-register-form">
            <label for="email">Email</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password</label>
            <input type="password" id="password" name="password" required>
            
            <button type="submit" name="submit">Register</button>
        </form>
        <a href="super_admin_login.html" class="login-link">Already have an account? Login here</a>
    </div>
</body>
</html>
