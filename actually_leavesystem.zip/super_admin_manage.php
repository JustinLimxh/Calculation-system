<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: super_admin_login.html"); // Redirect to login if not logged in
    exit();
}

require_once 'config.php';

$success_message = "";

// Handle deactivation
if (isset($_GET['deactivate'])) {
    $admin_id = $_GET['deactivate'];
    $sql = "UPDATE admin SET status='inactive' WHERE id=$admin_id";
    if ($conn->query($sql) === TRUE) {
        $success_message = "Account deactivated successfully.";
    } else {
        $success_message = "Error deactivating account: " . $conn->error;
    }
}

// Handle activation
if (isset($_GET['activate'])) {
    $admin_id = $_GET['activate'];
    $sql = "UPDATE admin SET status='active' WHERE id=$admin_id";
    if ($conn->query($sql) === TRUE) {
        $success_message = "Account activated successfully.";
    } else {
        $success_message = "Error activating account: " . $conn->error;
    }
}

// Fetch all admins to display
$sql = "SELECT * FROM admin";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Admin Records</title>
    <!-- Custom CSS for the page -->
    <link rel="stylesheet" href="css/super_admin_manage.css">
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/super_admin_top_nav.css">
    <script src="js/super_admin_top_nav.js"></script>
</head>
<body class="bg-light">
    <!-- Include Top Navigation Bar -->
    <?php include 'super_admin_top_nav.php'; ?>

    <div class="container mt-4">
        <!-- Page Title -->
        <h2 class="text-center custom-blue-text">Admin Records</h2>
        
        <!-- Admin Table -->
        <table class="table table-bordered table-hover">
            <thead class="table-primary">
                <tr>
                    <th>ID</th> <!-- New Column for Admin ID -->
                    <th>Name</th>
                    <th>Email</th>
                    <th>Entity</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()) { ?>
                    <tr>
                        <td><?php echo $row['id']; ?></td> <!-- Display Admin ID -->
                        <td><?php echo $row['name']; ?></td>
                        <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['entity']; ?></td>
                        <td><?php echo ucfirst($row['status']); ?></td>
                        <td>
                            <?php if ($row['status'] == 'active') { ?>
                                <a class="btn btn-warning btn-sm" href="?deactivate=<?php echo $row['id']; ?>">Deactivate</a>
                            <?php } else { ?>
                                <a class="btn btn-success btn-sm" href="?activate=<?php echo $row['id']; ?>">Activate</a>
                            <?php } ?>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>

        <!-- Display Success/Failure Message -->
        <?php if ($success_message != "") { ?>
            <div class="alert alert-success mt-3"><?php echo $success_message; ?></div>
        <?php } ?>
    </div>

</body>
</html>

<?php $conn->close(); ?>

