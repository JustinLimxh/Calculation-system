<?php
session_start();
ini_set('display_errors', 1);
error_reporting(E_ALL);

// Check if the super super admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: super_admin_login.html");
    exit();
}

require_once 'config.php';

// Fetch pending leave applications
$sql = "SELECT la.id, la.admin_id, la.leave_type, la.start_date, la.end_date, la.reason, la.file_path, la.status, s.name, lt.annual_leave, lt.medical_leave, lt.unpaid_leave 
        FROM admin_leave_applications la 
        INNER JOIN admin s ON la.admin_id = s.id 
        INNER JOIN admin_leave_types lt ON la.admin_id = lt.admin_id
        WHERE la.status = 'Pending'";
$result = $conn->query($sql);

// Handle leave application actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $application_id = $_POST['application_id'];
    $action = $_POST['action'];
    $admin_id = $_POST['admin_id'];
    $leave_type = $_POST['leave_type'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Calculate the number of leave days
    $days_requested = (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24) + 1;

    // Update the leave application status and deduct leave balance if approved
    if ($action === 'approve') {
        $status = 'Approved';

        // Deduct the leave balance for the admin
        $balance_column = $leave_type; // annual_leave, medical_leave, unpaid_leave

        // Fetch the current leave balance to ensure no negative deduction
        $balance_query = "SELECT $balance_column FROM admin_leave_types WHERE admin_id = ?";
        $stmt = $conn->prepare($balance_query);
        if ($stmt) {
            $stmt->bind_param("i", $admin_id);
            $stmt->execute();
            $stmt->bind_result($current_balance);
            $stmt->fetch();
            // Close the statement after fetching the result
            $stmt->close();
        }

        // Check if the admin has enough balance
        if ($current_balance >= $days_requested) {
            // Update leave balance
            $update_balance_sql = "UPDATE admin_leave_types SET $balance_column = $balance_column - ? WHERE admin_id = ?";
            $stmt = $conn->prepare($update_balance_sql);
            if ($stmt) {
                $stmt->bind_param("ii", $days_requested, $admin_id);
                $stmt->execute();
                $stmt->close(); // Close after execution
            }
        } else {
            // If balance is insufficient, set error message and skip status update
            $message = "Error: Insufficient $leave_type balance for admin ID $admin_id.";
            header("Location: super_admin_manage_leave.php?error=" . urlencode($message));
            exit();
        }
    } elseif ($action === 'reject') {
        $status = 'Rejected';
    } else {
        $status = 'Pending';
    }

    // Update leave application status
    $update_sql = "UPDATE admin_leave_applications SET status = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    if ($stmt) {
        $stmt->bind_param("si", $status, $application_id);

        if ($stmt->execute()) {
            // Fetch admin email for sending the email
            $email_query = "SELECT email FROM admin WHERE id = ?";
            $stmt2 = $conn->prepare($email_query);
            if ($stmt2) {
                $stmt2->bind_param("i", $admin_id);
                $stmt2->execute();
                $stmt2->bind_result($admin_email);
                $stmt2->fetch();
                $stmt2->close(); // Close the second statement
            }

            // Email admin about the leave application decision
            $subject = "Leave Application Status Update";
            $message = "
            <html>
            <head>
                <title>Leave Application Update</title>
            </head>
            <body>
                <p>Dear admin,</p>
                <p>Your leave application has been <strong>{$status}</strong>.</p>
                <p><strong>Details:</strong></p>
                <ul>
                    <li><strong>Leave Type:</strong> {$leave_type}</li>
                    <li><strong>Start Date:</strong> {$start_date}</li>
                    <li><strong>End Date:</strong> {$end_date}</li>
                    <li><strong>Status:</strong> {$status}</li>
                </ul>
                <p>Thank you!</p>
            </body>
            </html>
            ";

            // Email headers
            $headers = "MIME-Version: 1.0" . "\r\n";
            $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $headers .= "From: no-reply@nasiandsambal.com" . "\r\n";

            // Send the email to admin
            mail($admin_email, $subject, $message, $headers);

            $message = "Leave application has been $status successfully, and the admin has been notified via email.";
        } else {
            $message = "Error updating leave application.";
        }

        // Close the statement after executing the update
        $stmt->close();
    }

    // Refresh the page to see updated data
    header("Location: super_admin_manage_leave.php?message=" . urlencode($message));
    exit();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage admin Leave</title>
    <link rel="stylesheet" href="css/super_admin_manage_leave.css">
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/super_admin_top_nav.css"> 
        <script src="js/super_admin_top_nav.js"></script> 
</head>
<body>
    <!-- Include Top Navigation Bar -->
    <?php include 'super_admin_top_nav.php'; ?>
    <h1>Manage admin Leave Applications</h1>
    <?php if (isset($_GET['message'])): ?>
        <p class="message"><?php echo htmlspecialchars($_GET['message']); ?></p>
    <?php endif; ?>

    <!-- First Table: Pending Leave Applications -->
    <table>
        <thead>
            <tr>
                <th>admin Name</th>
                <th>admin ID</th>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason</th>
                <th>File</th>
                <th>Current Balance</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $result->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['name']); ?></td>
                    <td><?php echo htmlspecialchars($row['admin_id']); ?></td>
                    <td><?php echo htmlspecialchars($row['leave_type']); ?></td>
                    <td><?php echo htmlspecialchars($row['start_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['end_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['reason']); ?></td>
                    <td>
                        <?php if (!empty($row['file_path'])): ?>
                            <a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank">View File</a>
                        <?php else: ?>
                            No File
                        <?php endif; ?>
                    </td>
                    <td>
                        <?php
                            // Display current leave balance for the leave type
                            if ($row['leave_type'] === 'annual_leave') {
                                echo htmlspecialchars($row['annual_leave']) . " days";
                            } elseif ($row['leave_type'] === 'medical_leave') {
                                echo htmlspecialchars($row['medical_leave']) . " days";
                            } else {
                                echo htmlspecialchars($row['unpaid_leave']) . " days";
                            }
                        ?>
                    </td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                    <td>
                        <form method="POST">
                            <input type="hidden" name="application_id" value="<?php echo $row['id']; ?>">
                            <input type="hidden" name="admin_id" value="<?php echo $row['admin_id']; ?>">
                            <input type="hidden" name="leave_type" value="<?php echo $row['leave_type']; ?>">
                            <input type="hidden" name="start_date" value="<?php echo $row['start_date']; ?>">
                            <input type="hidden" name="end_date" value="<?php echo $row['end_date']; ?>">
                            <button type="submit" name="action" value="approve">Approve</button>
                            <button type="submit" name="action" value="reject">Reject</button>
                        </form>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <!-- Second Table: All Leave Applications -->
    <h2>All Leave Applications</h2>
    <?php
    // Fetch all leave applications from the database
    $allApplicationsSql = "SELECT la.id, la.admin_id, la.leave_type, la.start_date, la.end_date, la.reason, la.file_path, la.status, s.email 
                            FROM admin_leave_applications la 
                            INNER JOIN admin s ON la.admin_id = s.id";
    $allApplicationsResult = $conn->query($allApplicationsSql);
    ?>
    <table>
        <thead>
            <tr>
                <th>Email</th>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>Reason</th>
                <th>File</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $allApplicationsResult->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo htmlspecialchars($row['leave_type']); ?></td>
                    <td><?php echo htmlspecialchars($row['start_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['end_date']); ?></td>
                    <td><?php echo htmlspecialchars($row['reason']); ?></td>
                    <td>
                        <?php if (!empty($row['file_path'])): ?>
                            <a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank">View File</a>
                        <?php else: ?>
                            No File
                        <?php endif; ?>
                    </td>
                    <td><?php echo htmlspecialchars($row['status']); ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
        
    <!-- Export to Excel Button -->
    <form method="post" action="export_excel_admin.php">
        <button type="submit">Export as Excel</button>
    </form>
</body>
</html>
