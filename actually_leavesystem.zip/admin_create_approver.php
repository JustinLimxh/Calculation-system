<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if the admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

// Database connection
require_once 'config.php';

// Set timezone to Malaysia
date_default_timezone_set('Asia/Kuala_Lumpur');

// Retrieve admin's entity
$admin_email = $_SESSION['email'];
$sql = "SELECT entity FROM admin WHERE email=?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$stmt->bind_result($admin_entity);
$stmt->fetch();
$stmt->close();

// Retrieve parties for dropdown
$parties_query = "SELECT party_name FROM parties";
$parties_result = $conn->query($parties_query);

// Handle approver creation
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password
    $entity = $admin_entity; // Set entity to admin's entity
    $party_name = $_POST['party_name']; // Selected party
    $created_at = date('Y-m-d H:i:s'); // Get current time in Malaysian timezone

    // Check if email already exists
    $sql = "SELECT * FROM approver WHERE email=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        echo "<script>alert('Approver with this email already exists!');</script>";
    } else {
        // Insert new approver account
        $stmt = $conn->prepare("INSERT INTO approver (name, email, password, entity, parties, created_at) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $name, $email, $password, $entity, $party_name, $created_at);

        if ($stmt->execute()) {
            echo "<script>alert('New approver registered successfully.');</script>";
            echo "<script>window.location.href = 'admin_create_approver.php';</script>";
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Approver Account</title>
    <link rel="stylesheet" href="css/admin_top_nav.css">
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <script src="js/admin_top_nav.js"></script> 
    <style>
                /* Override the default Bootstrap btn-primary color */
form .btn-primary {
    background-color: #102f53 !important; /* Custom blue color */
    color: white !important; /* Text color set to white */
    padding: 12px 20px !important; /* Add some padding for a bigger button */
    font-size: 16px !important; /* Increase font size for better readability */
    border: none !important; /* Remove border */
    border-radius: 5px !important; /* Ensure the button has rounded corners */
    transition: background-color 0.3s ease; /* Smooth transition for hover effect */
}

/* Button hover effect */
form .btn-primary:hover {
    background-color: #0e2744 !important; /* Darker shade of blue when hovering */
    color: white !important; /* Maintain white text color on hover */
}

/* Button focus effect */
form .btn-primary:focus {
    outline: none !important; /* Remove the default outline */
    box-shadow: 0 0 0 0.2rem rgba(16, 47, 83, 0.5) !important; /* Add custom blue shadow on focus */
}

    </style>
</head>
<body class="admin-create">

    <!-- Include Top Navigation Bar -->
    <?php include 'admin_top_nav.php'; ?>

    <div class="container mt-5">
        <div class="card p-4 shadow-sm">
            <h2 class="text-center mb-4">Create Approver Account</h2>
            <form method="POST" action="admin_create_approver.php">
                <div class="mb-3">
                    <label for="name" class="form-label">Name:</label>
                    <input type="text" id="name" name="name" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="email" class="form-label">Email:</label>
                    <input type="email" id="email" name="email" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="password" class="form-label">Password:</label>
                    <input type="password" id="password" name="password" class="form-control" required>
                </div>

                <div class="mb-3">
                    <label for="entity" class="form-label">Entity:</label>
                    <input type="text" id="entity" value="<?php echo htmlspecialchars($admin_entity); ?>" class="form-control" disabled>
                    <input type="hidden" name="entity" value="<?php echo htmlspecialchars($admin_entity); ?>">
                </div>

                <div class="mb-3">
                    <label for="party_name" class="form-label">Party:</label>
                    <select id="party_name" name="party_name" class="form-select" required>
                        <?php while ($party = $parties_result->fetch_assoc()) { ?>
                            <option value="<?php echo htmlspecialchars($party['party_name']); ?>">
                                <?php echo htmlspecialchars($party['party_name']); ?>
                            </option>
                        <?php } ?>
                    </select>
                </div>

                <div class="text-center">
                    <button type="submit" name="register" class="btn btn-primary">Create Account</button>
                </div>
            </form>
        </div>
    </div>

</body>
</html>
