<?php
session_start();


if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

require_once 'config.php';

$admin_email = $_SESSION['email'];

// Fetch admin_id based on email
$sql = "SELECT id FROM admin WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $admin_email);
$stmt->execute();
$stmt->bind_result($admin_id);
$stmt->fetch();
$stmt->close();

// Fetch all admin leave types for the logged-in admin
$sql = "SELECT * FROM admin_leave_types WHERE admin_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$result = $stmt->get_result();
$leave_data = $result->fetch_assoc();
$stmt->close();
$conn->close();

// Remove admin_id and id from the leave data
unset($leave_data['admin_id']);
unset($leave_data['id']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Leave Balance</title>
    <link rel="stylesheet" href="css/leave_balance.css">
     <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/admin_top_nav.css">
            <script src="js/admin_top_nav.js"></script> 
</head>
<body>
     <!-- Include Top Navigation Bar -->
    <?php include('admin_top_nav.php'); ?>

    <div>
        <h2>Your Leave Balance</h2>
        <table>
            <tr>
                <th>Leave Type</th>
                <th>Available</th>
            </tr>
            <?php foreach ($leave_data as $leave_type => $balance): ?>
                <tr>
                    <td><?php echo ucfirst(str_replace('_', ' ', $leave_type)); ?></td>
                    <td><?php echo $balance; ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
        <a href="admin_dashboard.php">Back to Dashboard</a>
    </div>
</body>
</html>
