<?php
session_start();

// Check if staff is logged in
if (!isset($_SESSION['email'])) {
    header("Location: staff_login.html");
    exit();
}

require_once 'config.php';

// Fetch logged-in staff's email
$staff_email = $_SESSION['email'];

// Fetch staff_id and gender from the staff table
$sql = "SELECT id, gender FROM staff WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $staff_email);
$stmt->execute();
$stmt->bind_result($staff_id, $staff_gender);
$stmt->fetch();
$stmt->close();

if (!$staff_id) {
    die("Staff record not found.");
}

// Fetch all leave balances from the leave_types table dynamically
$sql = "SELECT * FROM leave_types WHERE staff_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $staff_id);
$stmt->execute();
$result = $stmt->get_result();
$leave_data = $result->fetch_assoc();
$stmt->close();

if (!$leave_data) {
    die("Leave record not found.");
}

// Dynamically calculate Emergency Leave, Half Morning Annual Leave, and Half Afternoon Annual Leave
$leave_data['Emergency Leave'] = $leave_data['Annual Leave'] + $leave_data['Unpaid Leave'];
$leave_data['Half Morning Annual Leave'] = $leave_data['Annual Leave'];
$leave_data['Half Afternoon Annual Leave'] = $leave_data['Annual Leave'];

// Get leave types dynamically while excluding "Maternity Leave" for males and "Paternity Leave" for females
$leave_types = array_filter(array_keys($leave_data), function ($key) use ($staff_gender) {
    if ($key === 'Maternity Leave' && strtolower($staff_gender) === 'male') {
        return false;
    }
    if ($key === 'Paternity Leave' && strtolower($staff_gender) === 'female') {
        return false;
    }
    return $key !== 'staff_id';
});

$error_message = '';
$success_message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $leave_type = $_POST['leave_type'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];
    $reason = trim($_POST['reason']);
    $file_path = null;

    // Validate selected leave type
    if (!array_key_exists($leave_type, $leave_data)) {
        $error_message = "Invalid leave type selected.";
    } else {
        $current_balance = (int)$leave_data[$leave_type];

        // Calculate number of leave days
        $days_requested = (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24) + 1;

        if ($current_balance < $days_requested) {
            $error_message = "Insufficient $leave_type balance.";
        } else {
            // File upload handling for specific leave types
            if (in_array($leave_type, ['Annual Leave', 'Emergency Leave', 'Unpaid Leave'])) {
                if (isset($_FILES['supporting_file']) && $_FILES['supporting_file']['error'] == UPLOAD_ERR_OK) {
                    $allowed_types = ['image/jpeg', 'image/png', 'application/pdf'];
                    $file_type = mime_content_type($_FILES['supporting_file']['tmp_name']);

                    if (in_array($file_type, $allowed_types)) {
                        $target_dir = "uploads/";
                        if (!is_dir($target_dir)) {
                            mkdir($target_dir, 0777, true);
                        }
                        $file_name = uniqid() . "_" . basename($_FILES['supporting_file']['name']);
                        $target_file = $target_dir . $file_name;

                        if (move_uploaded_file($_FILES['supporting_file']['tmp_name'], $target_file)) {
                            $file_path = $target_file;
                        } else {
                            $error_message = "Failed to upload file. Please try again.";
                        }
                    } else {
                        $error_message = "Invalid file type. Only JPEG, PNG, or PDF files are allowed.";
                    }
                } else {
                    $error_message = "Supporting file is required for $leave_type.";
                }
            }

            if (empty($error_message)) {
                // Insert leave application using staff_id instead of staff_email
                $sql = "INSERT INTO leave_applications (staff_id, leave_type, start_date, end_date, reason, file_path, status) 
                        VALUES (?, ?, ?, ?, ?, ?, 'Pending')";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssssss", $staff_id, $leave_type, $start_date, $end_date, $reason, $file_path);

                if ($stmt->execute()) {
                    $success_message = "Leave application submitted successfully.";
                    // Fetch all admin emails from the database
                    $admin_emails = [];
                    $admin_query = "SELECT email FROM admin";
                    $result = $conn->query($admin_query);

                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $admin_emails[] = $row['email'];
                        }
                    }

                    // Send success email to staff
                    $to_staff = $staff_email;
                    $subject_staff = "Leave Application Confirmation";
                    $message_staff = "
                    <html>
                    <head>
                        <title>Leave Application Submitted</title>
                    </head>
                    <body>
                        <p>Dear Staff,</p>
                        <p>Your leave application has been successfully submitted.</p>
                        <p><strong>Details:</strong></p>
                        <ul>
                            <li><strong>Leave Type:</strong> {$leave_type}</li>
                            <li><strong>Start Date:</strong> {$start_date}</li>
                            <li><strong>End Date:</strong> {$end_date}</li>
                            <li><strong>Reason:</strong> {$reason}</li>
                        </ul>
                        <p>Status: <strong>Pending</strong></p>
                        <p>Thank you!</p>
                    </body>
                    </html>
                    ";

                    // Email headers
                    $headers = "MIME-Version: 1.0" . "\r\n";
                    $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
                    $headers .= "From: no-reply@nasiandsambal.com" . "\r\n";

                    // Send email to staff
                    mail($to_staff, $subject_staff, $message_staff, $headers);

                    // Send success email to all admins
                    foreach ($admin_emails as $to_admin) {
                        $subject_admin = "New Leave Application Submitted";
                        $message_admin = "
                        <html>
                        <head>
                            <title>New Leave Application</title>
                        </head>
                        <body>
                            <p>Dear Admin,</p>
                            <p>A new leave application has been submitted by <strong>{$staff_email}</strong>.</p>
                            <p><strong>Details:</strong></p>
                            <ul>
                                <li><strong>Leave Type:</strong> {$leave_type}</li>
                                <li><strong>Start Date:</strong> {$start_date}</li>
                                <li><strong>End Date:</strong> {$end_date}</li>
                                <li><strong>Reason:</strong> {$reason}</li>
                            </ul>
                            <p>Status: <strong>Pending</strong></p>
                            <p>Thank you!</p>
                        </body>
                        </html>
                        ";

                        // Send email to admin
                        mail($to_admin, $subject_admin, $message_admin, $headers);
                    }

                    // Fetch approvers' emails
                    $approver_emails = [];
                    $approver_query = "SELECT email FROM approver WHERE status = 'active'";
                    $result = $conn->query($approver_query);

                    if ($result && $result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $approver_emails[] = $row['email'];
                        }
                    }

                    // Send leave application details to approvers
                    foreach ($approver_emails as $to_approver) {
                        $subject_approver = "Leave Application for Approval";
                        $message_approver = "
                        <html>
                        <head>
                            <title>Leave Application for Approval</title>
                        </head>
                        <body>
                            <p>Dear Approver,</p>
                            <p>A new leave application has been submitted by <strong>{$staff_email}</strong>.</p>
                            <p><strong>Details:</strong></p>
                            <table border='1' cellpadding='5'>
                                <tr><th>Leave Type</th><td>{$leave_type}</td></tr>
                                <tr><th>Start Date</th><td>{$start_date}</td></tr>
                                <tr><th>End Date</th><td>{$end_date}</td></tr>
                                <tr><th>Reason</th><td>{$reason}</td></tr>
                                <tr><th>Status</th><td>Pending</td></tr>
                            </table>
                            <p>Please review and approve/reject the leave application.</p>
                            <p>Thank you!</p>
                        </body>
                        </html>
                        ";

                        // Send email to approver
                        mail($to_approver, $subject_approver, $message_approver, $headers);
                    }
 } else {
                    $error_message = "Error submitting leave application. Please try again.";
                }
                $stmt->close();
            }
        }
    }
}

$conn->close();
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply Leave</title>
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/staff_top_nav.css">
    <link rel="stylesheet" href="css/apply_leave.css">
    <script src="js/staff_top_nav.js"></script> 
</head>
<body>
    <?php include('staff_top_nav.php'); ?>
    <div class="container mt-5">
        <h1 class="text-center mb-4">Apply for Leave</h1>

        <?php if ($error_message): ?>
            <p class="alert alert-danger"><?php echo htmlspecialchars($error_message); ?></p>
        <?php endif; ?>
        <?php if ($success_message): ?>
            <p class="alert alert-success"><?php echo htmlspecialchars($success_message); ?></p>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data" class="bg-white p-4 shadow-sm rounded">
            <div class="form-group">
                <label for="leave_type">Leave Type:</label>
                <select name="leave_type" id="leave_type" class="form-control" required>
                    <?php
                    $isFirst = true;
                    foreach ($leave_types as $type):
                        if ($isFirst) {
                            $isFirst = false;
                            continue;
                        }
                        if (in_array($type, ['last_updated_date', 'last_increment_date'])) {
                            continue;
                        }
                    ?>
                        <option value="<?php echo htmlspecialchars($type); ?>">
                            <?php echo ucfirst(str_replace('_', ' ', $type)); ?> 
                            (Remaining: <?php echo htmlspecialchars($leave_data[$type]); ?> days)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="form-group">
                <label for="start_date">Start Date:</label>
                <input type="date" id="start_date" name="start_date" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="end_date">End Date:</label>
                <input type="date" id="end_date" name="end_date" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="reason">Reason:</label>
                <textarea id="reason" name="reason" rows="4" class="form-control" required></textarea>
            </div>

            <div class="form-group">
                <label for="supporting_file">Supporting File (JPEG, PNG, or PDF):</label>
                <input type="file" id="supporting_file" name="supporting_file" class="form-control-file" accept="image/jpeg, image/png, application/pdf">
            </div>

            <button type="submit" class="btn btn-primary btn-block">Submit</button>
        </form>
    </div>

</body>
</html>
