<?php
session_start();

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


date_default_timezone_set('Asia/Kuala_Lumpur');

// Check if the approver is logged in
if (!isset($_SESSION['email'])) {
    header("Location: approver_login.html");
    exit();
}

require_once 'config.php';

// Get the approver's entity and party
$approver_email = $_SESSION['email'];
$approver_entity_query = "SELECT entity, parties FROM approver WHERE email = ?";
$stmt = $conn->prepare($approver_entity_query);
$stmt->bind_param("s", $approver_email);
$stmt->execute();
$stmt->bind_result($approver_entity, $approver_party);
$stmt->fetch();
$stmt->close();

// Fetch pending leave applications for the approver's entity and party
$sql = "SELECT la.id, la.staff_id, la.leave_type, la.start_date, la.end_date, la.reason, la.file_path, la.status, s.name, s.employee_id, `Annual Leave`, `Medical Leave`, `Unpaid Leave`, `Half Morning Annual Leave`, `Half Afternoon Annual Leave`, `Maternity Leave`, `Paternity Leave`   
        FROM leave_applications la 
        INNER JOIN staff s ON la.staff_id = s.id 
        INNER JOIN leave_types lt ON la.staff_id = lt.staff_id
        WHERE la.status = 'Pending' AND s.entity = ? AND s.parties = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ss", $approver_entity, $approver_party);
$stmt->execute();
$result = $stmt->get_result();

// Handle leave application actions
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action'])) {
    $application_id = $_POST['application_id'];
    $action = $_POST['action'];
    $staff_id = $_POST['staff_id'];
    $leave_type = $_POST['leave_type'];
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Calculate the number of leave days
    $days_requested = (strtotime($end_date) - strtotime($start_date)) / (60 * 60 * 24) + 1;
    
     // Special handling for half-day leave
    if ($leave_type === 'Half Morning Annual Leave' || $leave_type === 'Half Afternoon Annual Leave') {
        $leave_type = 'Annual Leave';
        $days_requested = 0.5; // Half-day leave deduction
    }

    // Get current date and time for approve_date
    $approve_date = date("Y-m-d H:i:s");

error_log("Processing leave type: " . $leave_type);

    // Update the leave application status and deduct leave balance if approved
    if ($action === 'approve') {
        $status = 'Approved';

        if ($leave_type === 'Emergency Leave') {
            // Deduct from Annual Leave and Unpaid Leave
            $balance_query = "SELECT `Annual Leave`, `Unpaid Leave` FROM leave_types WHERE staff_id = ?";
            $stmt = $conn->prepare($balance_query);
            $stmt->bind_param("i", $staff_id);
            $stmt->execute();
            $stmt->bind_result($annual_leave_balance, $unpaid_leave_balance);
            $stmt->fetch();
            $stmt->close();

           if ($annual_leave_balance >= $days_requested) {
        // Deduct fully from Annual Leave
        $update_balance_sql = "UPDATE leave_types SET `Annual Leave` = `Annual Leave` - ? WHERE staff_id = ?";
        $stmt = $conn->prepare($update_balance_sql);
        $stmt->bind_param("di", $days_requested, $staff_id);
        $stmt->execute();
        $stmt->close();
    } elseif (($annual_leave_balance + $unpaid_leave_balance) >= $days_requested) {
        // Deduct remaining from Unpaid Leave
        $remaining_days = $days_requested - $annual_leave_balance;
        $update_balance_sql = "UPDATE leave_types SET `Annual Leave` = 0, `Unpaid Leave` = `Unpaid Leave` - ? WHERE staff_id = ?";
        $stmt = $conn->prepare($update_balance_sql);
        $stmt->bind_param("di", $remaining_days, $staff_id);
        $stmt->execute();
        $stmt->close();
    } else {
        $message = "Error: Insufficient leave balance for Emergency Leave.";
        header("Location: approver_manage_leave.php?error=" . urlencode($message));
        exit();
    }
} elseif ($leave_type === 'Half Morning Annual Leave' || $leave_type === 'Half Afternoon Annual Leave') {
    // Debug: Log leave type
    echo "Leave type: " . $leave_type . "<br>";
    error_log("Leave type: " . $leave_type);

    // Fetch the current Annual Leave balance
    $balance_query = "SELECT `Annual Leave` FROM leave_types WHERE staff_id = ?";
    $stmt = $conn->prepare($balance_query);
    if (!$stmt) {
        error_log("Error preparing balance query: " . $conn->error);
    }
    $stmt->bind_param("i", $staff_id);
    if (!$stmt->execute()) {
        error_log("Error executing balance query: " . $stmt->error);
    }
    $stmt->bind_result($annual_leave_balance);
    $stmt->fetch();
    $stmt->close();

    // Debug: Log fetched Annual Leave balance
    error_log("Fetched Annual Leave balance: " . $annual_leave_balance);

    if ($annual_leave_balance >= 0.5) {
        // Deduct 0.5 days
        $update_balance_sql = "UPDATE leave_types SET `Annual Leave` = `Annual Leave` - 0.5 WHERE staff_id = ?";
        $stmt = $conn->prepare($update_balance_sql);
        if (!$stmt) {
            error_log("Error preparing update query: " . $conn->error);
        }
        $stmt->bind_param("i", $staff_id);
        if (!$stmt->execute()) {
            error_log("Error executing update query: " . $stmt->error);
        }

        // Check if the update was successful
        if ($stmt->affected_rows > 0) {
            // Debug: Log successful deduction
            error_log("Annual Leave balance successfully updated.");
            $stmt->close();
        } else {
            error_log("Error: No rows affected during update.");
            $message = "Error: Could not update Annual Leave balance.";
            header("Location: approver_manage_leave.php?error=" . urlencode($message));
            exit();
        }
    } else {
        // Debug: Log insufficient balance
        error_log("Insufficient Annual Leave balance for half-day leave. Current balance: " . $annual_leave_balance);
        $message = "Error: Insufficient Annual Leave balance for half-day leave.";
        header("Location: approver_manage_leave.php?error=" . urlencode($message));
        exit();
    }
}
 else {
      // Deduct for other leave types
           $balance_column = $leave_type;
           $balance_query = "SELECT `$balance_column` FROM leave_types WHERE staff_id = ?";
           $stmt = $conn->prepare($balance_query);
           $stmt->bind_param("i", $staff_id);
           $stmt->execute();
           $stmt->bind_result($current_balance);
           $stmt->fetch();
           $stmt->close();
           if ($current_balance >= $days_requested) {
    $update_balance_sql = "UPDATE leave_types SET `$balance_column` = `$balance_column` - ? WHERE staff_id = ?";
    $stmt = $conn->prepare($update_balance_sql);
    $stmt->bind_param("ii", $days_requested, $staff_id);
    $stmt->execute();
    $stmt->close();
               
           } else {
    $message = "Error: Insufficient $leave_type balance for staff ID $staff_id.";
    header("Location: approver_manage_leave.php?error=" . urlencode($message));
    exit();
}
}

        // Fetch staff email for sending the email
        $email_query = "SELECT email FROM staff WHERE id = ?";
        $stmt2 = $conn->prepare($email_query);
        $stmt2->bind_param("i", $staff_id);
        $stmt2->execute();
        $stmt2->bind_result($staff_email);
        $stmt2->fetch();
        $stmt2->close();

        // Prepare the email content for staff
        $subject = "Leave Application Status Update";
        $message = "
        <html>
        <head>
            <title>Leave Application Update</title>
        </head>
        <body>
            <p>Dear Staff,</p>
            <p>Your leave application has been <strong>{$status}</strong>.</p>
            <p><strong>Details:</strong></p>
            <ul>
                <li><strong>Leave Type:</strong> {$leave_type}</li>
                <li><strong>Start Date:</strong> {$start_date}</li>
                <li><strong>End Date:</strong> {$end_date}</li>
                <li><strong>Status:</strong> {$status}</li>
            </ul>
            <p>Thank you!</p>
        </body>
        </html>
        ";

        // Email headers
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: no-reply@nasiandsambal.com" . "\r\n";

        // Send email to staff
        mail($staff_email, $subject, $message, $headers);
    } elseif ($action === 'reject') {
        $status = 'Rejected';
    } else {
        $status = 'Pending';
    }

    // Update leave application status and approve_date
    $update_sql = "UPDATE leave_applications SET status = ?, approve_date = ? WHERE id = ?";
    $stmt = $conn->prepare($update_sql);
    $stmt->bind_param("ssi", $status, $approve_date, $application_id);

    if ($stmt->execute()) {
        // Email admin about the leave application approval
        if ($action === 'approve') {
            // Fetch admin email
            $admin_email_query = "SELECT email FROM admin WHERE id = 1";  // Assuming there's a single admin with id = 1
            $stmt = $conn->prepare($admin_email_query);
            $stmt->execute();
            $stmt->bind_result($admin_email);
            $stmt->fetch();

            // Prepare the email content for admin
            $admin_subject = "Leave Application Approved";
            $admin_message = "
            <html>
            <head>
                <title>Leave Application Approved</title>
            </head>
            <body>
                <p>Dear Admin,</p>
                <p>The following leave application has been approved:</p>
                <p><strong>Staff Details:</strong></p>
                <ul>
                    <li><strong>Staff Email:</strong> {$staff_email}</li>
                    <li><strong>Leave Type:</strong> {$leave_type}</li>
                    <li><strong>Start Date:</strong> {$start_date}</li>
                    <li><strong>End Date:</strong> {$end_date}</li>
                    <li><strong>Status:</strong> {$status}</li>
                </ul>
                <p><strong>Approver Details:</strong></p>
                <ul>
                    <li><strong>Approver Email:</strong> {$approver_email}</li>
                </ul>
                <p>Thank you!</p>
            </body>
            </html>
            ";

            // Email headers
            $admin_headers = "MIME-Version: 1.0" . "\r\n";
            $admin_headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
            $admin_headers .= "From: no-reply@nasiandsambal.com" . "\r\n";

            // Send email to admin
            mail($admin_email, $admin_subject, $admin_message, $admin_headers);
        }
        $message = "Leave application has been $status successfully, and the staff has been notified via email.";
    } else {
        $message = "Error updating leave application.";
    }
    $stmt->close();

    // Refresh the page
    echo "<script>
            window.location.href = window.location.href;
          </script>";
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Staff Leave</title>
    <link rel="icon" type="image/jpeg" href="images/logo.png">
     <link rel="stylesheet" href="css/approver_dashboard.css"> 
    <link rel="stylesheet" href="css/approver_top_nav.css"> 
    <script src="js/approver_top_nav.js"></script>
  
</head>
<body>
    <?php include 'approver_top_nav.php'; ?>

    <div class="container mt-4">
        <h1>Manage Staff Leave Applications</h1>
        
        <?php if (isset($_GET['message'])): ?>
            <div class="alert alert-info"><?php echo htmlspecialchars($_GET['message']); ?></div>
        <?php endif; ?>

        <!-- Pending Leave Applications -->
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>Staff Name</th>
                    <th>Employee ID</th>
                    <th>Staff ID</th>
                    <th>Leave Type</th>
                    <th>Start Date</th>
                    <th>End Date</th>
                    <th>Reason</th>
                    <th>File</th>
                    <th>Current Balance</th>
                    <th>Status</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($row['name']); ?></td>
                        <td><?php echo htmlspecialchars($row['employee_id']); ?></td>
                        <td><?php echo htmlspecialchars($row['staff_id']); ?></td>
                        <td><?php echo htmlspecialchars($row['leave_type']); ?></td>
                        <td><?php echo htmlspecialchars($row['start_date']); ?></td>
                        <td><?php echo htmlspecialchars($row['end_date']); ?></td>
                        <td><?php echo htmlspecialchars($row['reason']); ?></td>
                        <td>
                            <?php if (!empty($row['file_path'])): ?>
                                <a href="<?php echo htmlspecialchars($row['file_path']); ?>" target="_blank" class="btn btn-info btn-sm">View File</a>
                            <?php else: ?>
                                No File
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php
                            // Display current balance based on leave type
                            if ($row['leave_type'] === 'Annual Leave') {
                                echo htmlspecialchars($row['Annual Leave']) . " days";
                            } elseif ($row['leave_type'] === 'Medical Leave') {
                                echo htmlspecialchars($row['Medical Leave']) . " days";
                            } elseif ($row['leave_type'] === 'Unpaid Leave') {
                                echo htmlspecialchars($row['Unpaid Leave']) . " days";
                            } elseif ($row['leave_type'] === 'Emergency Leave') {
                                echo "Annual Leave: " . htmlspecialchars($row['Annual Leave']) . " days<br>";
                                echo "Unpaid Leave: " . htmlspecialchars($row['Unpaid Leave']) . " days";
                            } elseif ($row['leave_type'] === 'Half Morning Annual Leave' || $row['leave_type'] === 'Half Afternoon Annual Leave') {
                                echo htmlspecialchars($row['Annual Leave']) . " days";
                            } elseif ($row['leave_type'] === 'Maternity Leave') {
                                echo htmlspecialchars($row['Maternity Leave']) . " days";
                            } else {
                                echo htmlspecialchars($row['Paternity Leave']) . " days";
                            }
                            ?>
                        </td>
                        <td><?php echo htmlspecialchars($row['status']); ?></td>
                        <td>
                            <form method="POST" class="d-inline">
                                <input type="hidden" name="application_id" value="<?php echo $row['id']; ?>">
                                <input type="hidden" name="staff_id" value="<?php echo $row['staff_id']; ?>">
                                <input type="hidden" name="leave_type" value="<?php echo $row['leave_type']; ?>">
                                <input type="hidden" name="start_date" value="<?php echo $row['start_date']; ?>">
                                <input type="hidden" name="end_date" value="<?php echo $row['end_date']; ?>">
                                <button type="submit" name="action" value="approve" class="btn btn-info btn-sm">Approve</button>
                                <button type="submit" name="action" value="reject" class="btn btn-danger btn-sm">Reject</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

</body>
</html>
