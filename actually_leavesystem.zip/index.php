<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Tables to check for login
    $tables = ["admin", "staff", "super_admin", "approver"];
    $redirects = [
        "admin" => "admin_dashboard.php",
        "staff" => "staff_dashboard.php",
        "super_admin" => "super_admin_dashboard.php",
        "approver" => "approver_dashboard.php",
    ];

    $error = null;

    foreach ($tables as $table) {
        $sql = "SELECT * FROM `$table` WHERE email = ?";
        $stmt = $conn->prepare($sql);

        if (!$stmt) {
            die("SQL Error: " . $conn->error);
        }

        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result && $result->num_rows > 0) {
            $user = $result->fetch_assoc();

            // Check if status is active
            if ($user['status'] !== 'active') {
                $error = "Your account is not active.";
                break;
            }

            // If status is active, verify password
            if (password_verify($password, $user['password'])) {
                // Save session variables
                $_SESSION['email'] = $user['email'];
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_entity'] = $user['entity'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['table'] = $table; // Optional: Save the table/role for further distinction

                // Redirect to the appropriate dashboard
                header("Location: " . $redirects[$table]);
                exit();
            } else {
                $error = "Invalid password.";
                break;
            }
        }
        $stmt->close();
    }

    $conn->close();

    // If email/password doesn't match any active user
    if (!isset($_SESSION['email'])) {
        $error = "Invalid email or password or your account had been deactivated.";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <style>
        /* Basic reset for margin and padding */
 body {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
            min-height: 100vh;
            background-color: #f4f4f4;
            font-family: Arial, sans-serif;
        }
.admin-login-form {
     max-width: 400px;
    width: 100%;
    margin: 0 auto;
    background-color: #fff;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    display: flex;
    flex-direction: column;
    align-items: center;
}

.admin-login-title {
    font-size: 24px;
    margin-bottom: 20px;
    color: #102f53; /* Updated to blue */
    text-align: center;
}
.admin-login-form label {
    font-weight: bold;
    margin-bottom: 8px;
    font-size: 16px;
    align-self: flex-start;
}

.admin-login-form input {
    margin-bottom: 15px;
    padding: 12px;
    border-radius: 5px;
    border: 1px solid #ccc;
    font-size: 16px;
    width: 100%;
}

.admin-login-form button {
    padding: 12px;
    border-radius: 5px;
    border: 1px solid #102f53; /* Updated to blue */
    background-color: #102f53; /* Updated to blue */
    color: #fff;
    cursor: pointer;
    font-size: 16px;
    width: 100%;
}

.admin-login-form button:hover {
    background-color: #0e2744; /* Updated to darker blue */
}

.register-container {
    text-align: center;
    margin-top: 15px;
}

.register-text {
    font-size: 14px;
}

.register-text a {
    text-decoration: none;
    color: #102f53; /* Updated to blue */
}

.register-text a:hover {
    text-decoration: underline;
}

/* Container for Staff and Super Admin Login Buttons at Bottom Right */
.login-btn-container {
    position: absolute;
    bottom: 20px;
    right: 20px;
    display: flex;
    flex-direction: column;
    gap: 10px;
}


.back-button {
    display: inline-block;
    padding: 10px 20px;
    background-color: #102f53;
    color: #fff;
    text-decoration: none;
    font-weight: bold;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}

.back-button:hover {
    background-color: #0e2744;
}

/* Logo section */
        .logo-container {
            text-align: center;
            margin-bottom: 20px;
        }

        .logo-container img {
            max-width: 150px;
            height: auto;
        }
        
    </style>
</head>
<body>
    
     <!-- Logo Section -->
    <div class="logo-container">
        <img src="images/logo.png" alt="Logo">
    </div>
    
    
      <form class="admin-login-form" action="" method="POST">
        <h2 class="admin-login-title">Login</h2>

        <label for="email">Email:</label>
        <input type="email" name="email" required>

        <label for="password">Password:</label>
        <input type="password" name="password" required>

        <button type="submit" name="login">Login</button>
    </form>   
  
        <?php if (isset($error)) { echo "<p class='error'>$error</p>"; } ?>
</body>
</html>
