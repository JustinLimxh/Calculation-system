<?php
session_start();
require_once 'config.php';
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if the admin is logged in
if (!isset($_SESSION['email'])) {
    header("Location: admin_login.html");
    exit();
}

// Check if approver ID is provided in the URL
if (isset($_GET['id'])) {
    $approver_id = $_GET['id'];
    $sql = "SELECT * FROM approver WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $approver_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $approver = $result->fetch_assoc();
    $stmt->close();

    if (!$approver) {
        echo "approver not found.";
        exit();
    }
} else {
    echo "Invalid approver ID.";
    exit();
}

// Fetch all parties and departments from the database
$parties_sql = "SELECT id, party_name FROM parties";
$parties_result = $conn->query($parties_sql);


// Handle form submission to update approver details
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $parties = $_POST['parties'];  // Party name

    // Check if new password is provided and matches the confirm password
    if (!empty($_POST['new_password']) && $_POST['new_password'] === $_POST['confirm_password']) {
        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);  // Hash the new password

        // Update approver details with new password
        $sql = "UPDATE approver SET name = ?, email = ?, parties = ?, password = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssi", $name, $email, $parties, $new_password, $_POST['id']);
    } else {
        // Update approver details without changing the password
        $sql = "UPDATE approver SET name = ?, email = ?, parties = ? = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssi", $name, $email, $parties, $_POST['id']);
    }

    if ($stmt->execute()) {
        $_SESSION['message'] = "approver details updated successfully!";
        $_SESSION['message_type'] = "success";
    } else {
        $_SESSION['message'] = "Error updating approver details.";
        $_SESSION['message_type'] = "error";
    }
    $stmt->close();
    header("Location: admin_edit_delete_approver.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Approver</title>
    <!-- Adding the logo as favicon -->
    <link rel="icon" type="image/jpeg" href="images/logo.png">
    <link rel="stylesheet" href="css/admin_top_nav.css">
    <link rel="stylesheet" href="css/admin_edit_approver.css">
    <script src="js/admin_top_nav.js"></script>
     <style>
        /* Override the default Bootstrap btn-primary color */
form .btn-primary {
    background-color: #102f53 !important; /* Custom blue color */
    color: white !important; /* Text color set to white */
    padding: 12px 20px !important; /* Add some padding for a bigger button */
    font-size: 16px !important; /* Increase font size for better readability */
    border: none !important; /* Remove border */
    border-radius: 5px !important; /* Ensure the button has rounded corners */
    transition: background-color 0.3s ease; /* Smooth transition for hover effect */
}

/* Button hover effect */
form .btn-primary:hover {
    background-color: #0e2744 !important; /* Darker shade of blue when hovering */
    color: white !important; /* Maintain white text color on hover */
}

/* Button focus effect */
form .btn-primary:focus {
    outline: none !important; /* Remove the default outline */
    box-shadow: 0 0 0 0.2rem rgba(16, 47, 83, 0.5) !important; /* Add custom blue shadow on focus */
}

    </style>
</head>
<body>
    <?php include 'admin_top_nav.php'; ?>
    
    <div class="container mt-5">
       <!-- Success/Error Message -->
        <?php if (isset($_SESSION['message'])): ?>
            <div class="alert <?php echo $_SESSION['message_type'] === 'success' ? 'alert-success' : 'alert-danger'; ?> alert-dismissible fade show" role="alert">
                <?php echo $_SESSION['message']; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?php
                    unset($_SESSION['message']);
                    unset($_SESSION['message_type']);
                ?>
            </div>
        <?php endif; ?>

        <form method="POST" class="card p-4 shadow">
            <h2 class="text-center mb-4">Edit Approver Details</h2>

            <input type="hidden" name="id" value="<?php echo $approver['id']; ?>">

            <div class="mb-3">
                <label for="name" class="form-label">Name</label>
                <input type="text" name="name" class="form-control" value="<?php echo htmlspecialchars($approver['name']); ?>" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" name="email" class="form-control" value="<?php echo htmlspecialchars($approver['email']); ?>" required>
            </div>

            <!-- Parties Dropdown -->
            <div class="mb-3">
                <label for="parties" class="form-label">Parties</label>
                <div class="select-container">
                    <select name="parties" class="form-select" required>
                        <option value="">Select Party</option>
                        <?php if ($parties_result->num_rows > 0): ?>
                            <?php while ($party = $parties_result->fetch_assoc()): ?>
                                <option value="<?php echo $party['party_name']; ?>" <?php echo ($party['party_name'] == $approver['parties']) ? 'selected' : ''; ?>>
                                    <?php echo htmlspecialchars($party['party_name']); ?>
                                </option>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <option value="">No parties available</option>
                        <?php endif; ?>
                    </select>
                </div>
            </div>

            <!-- Password Fields -->
            <div class="mb-3">
                <label for="new_password" class="form-label">New Password</label>
                <input type="password" name="new_password" class="form-control" placeholder="Enter new password">
            </div>

            <div class="mb-3">
                <label for="confirm_password" class="form-label">Confirm New Password</label>
                <input type="password" name="confirm_password" class="form-control" placeholder="Confirm new password">
            </div>

            <div class="text-center">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>
        </form>
    </div>

    <!-- Client-side validation to check if passwords match -->
    <script>
        document.querySelector('.approver-edit-form').addEventListener('submit', function(event) {
            const newPassword = document.querySelector('[name="new_password"]').value;
            const confirmPassword = document.querySelector('[name="confirm_password"]').value;

            // Check if both passwords match
            if (newPassword !== confirmPassword) {
                alert('The new password and confirm password do not match.');
                event.preventDefault(); // Prevent form submission
            }
        });
    </script>

</body>
</html>

