<?php
require 'vendor/autoload.php'; // Include PhpSpreadsheet library

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Database connection
require_once 'config.php';

// Modify the SQL query to fetch data including staff email and leave data
$sql = "SELECT la.admin_id, lt.annual_leave, lt.medical_leave, lt.unpaid_leave, 
        la.leave_type, la.start_date, la.end_date, la.reason, la.file_path, la.status 
        FROM admin_leave_applications la
        JOIN admin_leave_types lt ON la.admin_id = lt.admin_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Set header row
    $sheet->setCellValue('A1', 'Admin ID');
    $sheet->setCellValue('B1', 'Annual Leave');
    $sheet->setCellValue('C1', 'Medical Leave');
    $sheet->setCellValue('D1', 'Unpaid Leave');
    $sheet->setCellValue('E1', 'Leave Type');
    $sheet->setCellValue('F1', 'Start Date');
    $sheet->setCellValue('G1', 'End Date');
    $sheet->setCellValue('H1', 'Reason');
    $sheet->setCellValue('I1', 'File Path');
    $sheet->setCellValue('J1', 'Status');

    // Populate data rows
    $row = 2;
    while ($data = $result->fetch_assoc()) {
        $sheet->setCellValue('A' . $row, $data['admin_id']);
        $sheet->setCellValue('B' . $row, $data['annual_leave']);
        $sheet->setCellValue('C' . $row, $data['medical_leave']);
        $sheet->setCellValue('D' . $row, $data['unpaid_leave']);
        $sheet->setCellValue('E' . $row, $data['leave_type']);
        $sheet->setCellValue('F' . $row, $data['start_date']);
        $sheet->setCellValue('G' . $row, $data['end_date']);
        $sheet->setCellValue('H' . $row, $data['reason']);
        $sheet->setCellValue('I' . $row, $data['file_path']);
        $sheet->setCellValue('J' . $row, $data['status']);
        $row++;
    }

    // Set filename and download headers
    $filename = "admin_leave_applications_" . date('Ymd_His') . ".xlsx";
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');

    $writer = new Xlsx($spreadsheet);
    $writer->save('php://output');
    exit;
} else {
    echo "No records found.";
}
?>
