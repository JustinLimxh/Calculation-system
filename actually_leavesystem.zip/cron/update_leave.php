<?php

// Set the timezone to Malaysia
date_default_timezone_set('Asia/Kuala_Lumpur');

// Include the database configuration
if (!file_exists('/home/u337860726/domains/nasiandsambal.com/public_html/leavesystem/config.php')) {
    die("config.php file not found.");
}
include('/home/u337860726/domains/nasiandsambal.com/public_html/leavesystem/config.php');

// Ensure MySQL uses Malaysia Time
mysqli_query($conn, "SET time_zone = '+08:00'");

error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Log file for debugging
$logFile = '/home/u337860726/domains/nasiandsambal.com/public_html/leavesystem/cron/cron_log.txt';
$currentDateTime = date('Y-m-d H:i:s');
file_put_contents($logFile, "Script executed at $currentDateTime\n", FILE_APPEND);

// Verify database connection
if (!$conn) {
    $errorMessage = "Database connection not established.";
    file_put_contents($logFile, $errorMessage . "\n", FILE_APPEND);
    die($errorMessage);
}

// Get the current time
$current_time = time();

// Query to fetch staff and their leave details
$query = "
    SELECT 
        s.id AS staff_id, 
        s.created_at, 
        s.name,
        lt.id AS leave_id, 
        lt.`Annual Leave` AS annual_leave,
        lt.last_updated_date,
        lt.last_increment_date
    FROM 
        staff s
    LEFT JOIN 
        leave_types lt ON s.id = lt.staff_id
    WHERE 
        s.status = 'active'
";
$result = mysqli_query($conn, $query);

// Check if the query ran successfully
if (!$result) {
    $errorMessage = "Failed to execute staff query: " . mysqli_error($conn);
    file_put_contents($logFile, $errorMessage . "\n", FILE_APPEND);
    die($errorMessage);
}

// Process each staff record
while ($row = mysqli_fetch_assoc($result)) {
    $staff_id = $row['staff_id'];
    $leave_id = $row['leave_id'];
    $created_at = $row['created_at'];
    $annual_leave = $row['annual_leave'];
    $last_increment_date = $row['last_increment_date']; // Last increment timestamp

    // Log fetched staff details
    file_put_contents($logFile, "Processing staff ID $staff_id (Name: {$row['name']}, Created At: $created_at)\n", FILE_APPEND);

    // Ensure the account is at least one day old
    $created_at_date = new DateTime($created_at);
    $current_date_time = new DateTime();
    $account_age_days = $created_at_date->diff($current_date_time)->days;

    //put 1 to check 
    if ($account_age_days < 40) {
        // Log accounts that are not yet a day old
        file_put_contents($logFile, "Skipping staff ID $staff_id: Account less than 40 day old.\n", FILE_APPEND);
        continue; // Skip processing this account
    }

   // Check if at least 40 days have passed since the last increment
if ($leave_id) {
    if ($last_increment_date && strtotime($last_increment_date)) {
        $last_increment_time = strtotime($last_increment_date);
        $time_diff_seconds = $current_time - $last_increment_time;
        $time_diff_days = $time_diff_seconds / (3600 * 24); // Convert seconds to days

        // Round the time difference to the nearest 0.5 days
        $time_diff_days_rounded = round($time_diff_days * 2) / 2;

        // Debugging output for the time difference
        file_put_contents($logFile, "Staff ID $staff_id: Last increment date: $last_increment_date, Time difference: $time_diff_days_rounded days\n", FILE_APPEND);

        if ($time_diff_days_rounded < 40) {
            // Log that the leave has already been updated within the past 40 days
            $message = "Staff ID $staff_id was last incremented $time_diff_days_rounded days ago. No update needed.";
            file_put_contents($logFile, $message . "\n", FILE_APPEND);
            echo $message . "<br>";
            continue;
        }
    } else {
        // Handle null or invalid last_increment_date
        $message = "Staff ID $staff_id has no valid last increment date. Proceeding with update.";
        file_put_contents($logFile, $message . "\n", FILE_APPEND);
        echo $message . "<br>";
    }

    // Increment Annual Leave by 1
    $new_annual_leave = $annual_leave + 1;

    // Update the leave_types table with the new leave count and current date/time
    // Use NOW() to ensure that the database saves the time in Malaysia Time
    $update_query = "
        UPDATE leave_types 
        SET 
            `Annual Leave` = $new_annual_leave, 
            last_updated_date = NOW(),
            last_increment_date = NOW()
        WHERE id = $leave_id
    ";
    $update_result = mysqli_query($conn, $update_query);

    // Log the result of the update
    if ($update_result) {
        $successMessage = "Updated Annual Leave for staff ID $staff_id: $new_annual_leave";
        echo $successMessage . "<br>";
        file_put_contents($logFile, $successMessage . "\n", FILE_APPEND);
    } else {
        $errorMessage = "Failed to update Annual Leave for staff ID $staff_id: " . mysqli_error($conn);
        echo $errorMessage . "<br>";
        file_put_contents($logFile, $errorMessage . "\n", FILE_APPEND);
    }
} else {
    // Log that the leave_id is invalid
    $errorMessage = "Invalid leave ID for staff ID $staff_id. Skipping update.";
    file_put_contents($logFile, $errorMessage . "\n", FILE_APPEND);
}

/*
// Original hourly logic for reference
if ($leave_id) {
    if ($last_increment_date && strtotime($last_increment_date)) {
        $last_increment_time = strtotime($last_increment_date);
        $time_diff_seconds = $current_time - $last_increment_time;
        $time_diff_hours = $time_diff_seconds / 3600; // Convert seconds to hours

        // Round the time difference to the nearest 0.5 hours
        $time_diff_hours_rounded = round($time_diff_hours * 2) / 2;

        // Debugging output for the time difference
        file_put_contents($logFile, "Staff ID $staff_id: Last increment date: $last_increment_date, Time difference: $time_diff_hours_rounded hours\n", FILE_APPEND);

        if ($time_diff_hours_rounded < 1) {
            // Log that the leave has already been updated within the past hour
            $message = "Staff ID $staff_id was last incremented $time_diff_hours_rounded hours ago. No update needed.";
            file_put_contents($logFile, $message . "\n", FILE_APPEND);
            echo $message . "<br>";
            continue;
        }
    } else {
        // Handle null or invalid last_increment_date
        $message = "Staff ID $staff_id has no valid last increment date. Proceeding with update.";
        file_put_contents($logFile, $message . "\n", FILE_APPEND);
        echo $message . "<br>";
    }

    // Increment Annual Leave by 1
    $new_annual_leave = $annual_leave + 1;

    // Update the leave_types table with the new leave count and current date/time
    $update_query = "
        UPDATE leave_types 
        SET 
            `Annual Leave` = $new_annual_leave, 
            last_updated_date = NOW(),
            last_increment_date = NOW()
        WHERE id = $leave_id
    ";
    $update_result = mysqli_query($conn, $update_query);

    // Log the result of the update
    if ($update_result) {
        $successMessage = "Updated Annual Leave for staff ID $staff_id: $new_annual_leave";
        echo $successMessage . "<br>";
        file_put_contents($logFile, $successMessage . "\n", FILE_APPEND);
    } else {
        $errorMessage = "Failed to update Annual Leave for staff ID $staff_id: " . mysqli_error($conn);
        echo $errorMessage . "<br>";
        file_put_contents($logFile, $errorMessage . "\n", FILE_APPEND);
    }
} else {
    // Log that the leave_id is invalid
    $errorMessage = "Invalid leave ID for staff ID $staff_id. Skipping update.";
    file_put_contents($logFile, $errorMessage . "\n", FILE_APPEND);
}
*/

}

// Write last run time to file
$last_run_file = '/home/u337860726/domains/nasiandsambal.com/public_html/leavesystem/cron/last_run_time.txt';
file_put_contents($last_run_file, $currentDateTime);

$completionMessage = "Leave tracking automation completed at $currentDateTime.";
echo $completionMessage;
file_put_contents($logFile, $completionMessage . "\n", FILE_APPEND);
?>
