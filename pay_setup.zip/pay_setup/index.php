<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Responsive Header</title>
</head>

<body>

    <?php include 'include/header.php'; ?>

    <center>
        <h1>Welcome Wei Shan</h1>
    </center>
    <center>
        <h2>Welcome Wei Shan</h2>
    </center>
    <center>
        <h3>Welcome Wei Shan</h3>
    </center>
    <center>
        <h4>Welcome Wei Shan</h4>
    </center>
    <center>
        <h5>Welcome Wei Shan</h5>
    </center>
    <center>
        <h6>Welcome Wei Shan</h6>
    </center>
    <center>
        <h5>Welcome Wei Shan</h5>
    </center>
    <center>
        <h4>Welcome Wei Shan</h4>
    </center>
    <center>
        <h3>Welcome Wei Shan</h3>
    </center>
    <center>
        <h2>Welcome Wei Shan</h2>
    </center>
    <center>
        <h1>Welcome Wei Shan</h1>
    </center>

</body>

</html>