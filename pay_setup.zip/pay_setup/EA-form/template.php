<!DOCTYPE  html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="ms" lang="ms">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
      <title>Borang EA (C.P.8A - Pin. 2023)</title>
      <meta name="author" content="Administrator"/>
      <style type="text/css"> * {margin:0; padding:0; text-indent:0; }
         body { color: black; font-family:Arial, sans-serif; font-style: normal; font-weight: normal; text-decoration: none; font-size: 8pt; margin:5%; }
         p { color: black; font-family:Arial, sans-serif; font-style: normal; font-weight: normal; text-decoration: none; font-size: 8pt; margin:0pt; }
         h2 { color: black; font-family:Arial, sans-serif; font-style: normal; font-weight: bold; text-decoration: none; font-size: 12pt; }
         .h4 { color: #FFF; font-family:Arial, sans-serif; font-style: normal; font-weight: bold; text-decoration: none; font-size: 8pt; }
         .s1 { color: #FFF; font-family:Arial, sans-serif; font-style: normal; font-weight: bold; text-decoration: none; font-size: 8pt; }
         .h1 { color: black; font-family:Arial, sans-serif; font-style: normal; font-weight: bold; text-decoration: none; font-size: 18pt; vertical-align: -4pt; }
         .s2 { color: black; font-family:"Times New Roman", serif; font-style: normal; font-weight: normal; text-decoration: none; font-size: 9pt; }
         .h3 { color: #FFF; font-family:Arial, sans-serif; font-style: normal; font-weight: bold; text-decoration: none; font-size: 9pt; }
         .s3 { color: #FFF; font-family:Arial, sans-serif; font-style: normal; font-weight: bold; text-decoration: none; font-size: 8pt; }
         .s4 { color: black; font-family:Arial, sans-serif; font-style: normal; font-weight: bold; text-decoration: none; font-size: 8pt; }
         .s5 { color: black; font-family:Arial, sans-serif; font-style: normal; font-weight: normal; text-decoration: none; font-size: 8pt; }
         .s6 { color: black; font-family:Arial, sans-serif; font-style: normal; font-weight: bold; text-decoration: none; font-size: 7pt; }
         .s7 { color: black; font-family:Arial, sans-serif; font-style: normal; font-weight: bold; text-decoration: none; font-size: 8pt; }
         table, tbody {vertical-align: top; overflow: visible; }
      </style>
   </head>
   <body>
      <p style="padding-top: 3pt;text-indent: 0pt;line-height: 20pt;text-align: right; float: right;"><span class="h4" style=" background-color: #000;"> Penyata Gaji Pekerja SWASTA </span><span class="s1"> </span><span class="h1">EA</span></p>
      <p style="display:inline-block;padding-top: 6pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">(C.P.8A - Pin. 2023) </p><span style="display:inline-block;padding-left: 220px;text-align: center;"> MALAYSIA</span>
      <h2 style="padding-top: 2pt;padding-left: 201pt;text-indent: 0pt;text-align: left;">CUKAI PENDAPATAN</h2>
      <table style="width: 100%; border-collapse: collapse;">
         <tr>
         <td style="width: 33%; padding-left: 5pt; text-align: left;">
            <p>No. Siri.....................</p>
            <p style="padding-top: 2pt;">No. Majikan E <span class="s2">{{ eNo }}</span></p>
         </td>
         <td style="width: 34%; text-align: center;">
            <p style="padding-top: 3pt;">PENYATA SARAAN DARIPADA PENGGAJIAN</p>
            <p>BAGI TAHUN BERAKHIR 31 DISEMBER <span id="this-year" class="s2">{{ current_year }}</span></p>
         </td>
         <td style="width: 33%; text-align: right;">
            <p style="line-height: 8pt;">No. Pengenalan Cukai (TIN) Pekerja</p>
            <p class="s2">………………………………</p>
            <p class="s2" style="padding-top: 2pt;">LHDNM Negeri ….….…..…....</p>
         </td>
         </tr>
      </table>
   </div>

      <p style="padding-top: 5pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"><span class="h3" style=" background-color: #000;">    BORANG EA INI PERLU DISEDIAKAN UNTUK DISERAHKAN KEPADA PEKERJA BAGI TUJUAN CUKAI PENDAPATAN   </span></p>
   </div>
   <div style="text-align: center;">
      <p style="text-indent: 0pt;text-align: left;"><br/></p>
      <table style="border-collapse:collapse;margin-left:8.26002pt" cellspacing="0">
         <tr style="height:12pt">
            <td style="width:14pt" bgcolor="#000000">
               <p style="text-indent: 0pt;line-height: 9pt;text-align: center;"><span class="s3" style=" background-color: #000;"> A </span></p>
            </td>
            <td style="width:92pt" colspan="2">
               <p class="s4" style="padding-left: 6pt;text-indent: 0pt;line-height: 9pt;text-align: left;">BUTIRAN PEKERJA</p>
            </td>
            <td style="width:43pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:109pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">1.</p>
            </td>
            <td style="width:482pt" colspan="8">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Nama Penuh Pekerja / Pesara (Encik/Cik/Puan) ....................{{ name }}....................</p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">2.</p>
            </td>
            <td style="width:226pt" colspan="3">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Jawatan   ...................................................................</p>
            </td>
            <td style="width:21pt">
               <p class="s5" style="padding-top: 2pt;padding-right: 6pt;text-indent: 0pt;text-align: center;">3.</p>
            </td>
            <td style="width:109pt" colspan="2">
               <p class="s5" style="padding-top: 2pt;text-indent: 0pt;text-align: left;">No. Kakitangan / No. Gaji</p>
            </td>
            <td style="width:126pt" colspan="2">
               <p class="s5" style="padding-top: 2pt;padding-left: 2pt;text-indent: 0pt;text-align: left;">.......................{{ staff_id }}..........................</p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">4.</p>
            </td>
            <td style="width:226pt" colspan="3">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">No. K.P. Baru  ...................{{ ic }}................ </p>
            </td>
            <td style="width:21pt">
               <p class="s5" style="padding-top: 2pt;padding-right: 6pt;text-indent: 0pt;text-align: center;">5.</p>
            </td>
            <td style="width:109pt" colspan="2">
               <p class="s5" style="padding-top: 2pt;text-indent: 0pt;text-align: left;">No. Pasport</p>
            </td>
            <td style="width:126pt" colspan="2">
               <p class="s5" style="padding-top: 2pt;padding-left: 2pt;text-indent: 0pt;text-align: left;">.......................................................</p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">6.</p>
            </td>
            <td style="width:226pt" colspan="3">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">No. KWSP   ..........................{{ epfNo }}......................</p>
            </td>
            <td style="width:21pt">
               <p class="s5" style="padding-top: 2pt;padding-right: 6pt;text-indent: 0pt;text-align: center;">7.</p>
            </td>
            <td style="width:109pt" colspan="2">
               <p class="s5" style="padding-top: 2pt;text-indent: 0pt;text-align: left;">No. PERKESO</p>
            </td>
            <td style="width:126pt" colspan="2">
               <p class="s5" style="padding-top: 2pt;padding-left: 2pt;text-indent: 0pt;text-align: left;">................{{ icrecombined }}...............</p>
            </td>
         </tr>
         <tr style="height:13pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">8.</p>
            </td>
            <td style="width:117pt" colspan="2">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Bilangan anak yang layak</p>
            </td>
            <td style="width:109pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:21pt">
               <p class="s5" style="padding-top: 2pt;padding-right: 6pt;text-indent: 0pt;text-align: center;">9.</p>
            </td>
            <td style="width:160pt" colspan="3">
               <p class="s5" style="padding-top: 2pt;text-indent: 0pt;text-align: left;">Jika bekerja tidak genap setahun, nyatakan:</p>
            </td>
            <td style="width:75pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
         </tr>
         <tr style="height:16pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:226pt" colspan="3">
               <p class="s5" style="padding-top: 1pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">untuk pelepasan cukai  ..........................{{ children }}.....................</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 3pt;text-indent: 0pt;text-align: left;">(a)</p>
            </td>
            <td style="width:91pt">
               <p class="s5" style="padding-top: 3pt;padding-left: 3pt;text-indent: 0pt;text-align: left;">Tarikh mula bekerja</p>
            </td>
            <td style="width:126pt" colspan="2">
               <p class="s5" style="padding-top: 3pt;padding-left: 2pt;text-indent: 0pt;text-align: left;">.......................................................</p>
            </td>
         </tr>
         <tr style="height:20pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:74pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:43pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:109pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 2pt;text-indent: 0pt;text-align: left;">(b)</p>
            </td>
            <td style="width:91pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 3pt;text-indent: 0pt;text-align: left;">Tarikh berhenti kerja</p>
            </td>
            <td style="width:126pt" colspan="2">
               <p class="s5" style="padding-top: 2pt;padding-left: 2pt;text-indent: 0pt;text-align: left;">.......................................................</p>
            </td>
         </tr>

         <td style="width:21pt">
            <p style="text-indent: 0pt;text-align: left;"><br/></p>
         </td>

         <tr style="height:18pt">
            <td style="width:14pt">
               <p style="padding-top: 7pt;text-indent: 0pt;text-align: center;"><span class="s3" style=" background-color: #000;"> B </span></p>
            </td>
            <td style="width:283pt" colspan="6">
               <p class="s4" style="padding-top: 7pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">PENDAPATAN PENGGAJIAN, MANFAAT DAN TEMPAT KEDIAMAN</p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
         </tr>
         <tr style="height:13pt">
            <td style="width:514pt" colspan="10">
               <p class="s6" style="padding-left: 20pt;text-indent: 0pt;text-align: left;">(Tidak Termasuk Elaun / Perkuisit / Pemberian / Manfaat Yang Dikecualikan Cukai)                         <span class="s7">RM</span></p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">1.</p>
            </td>
            <td style="width:226pt" colspan="3">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">(a) Gaji kasar, upah atau gaji cuti (termasuk gaji lebih masa)</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 4pt;text-indent: 0pt;text-align: right;">{{ OT }}</p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:226pt" colspan="3">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">(b) Fi (termasuk fi pengarah), komisen atau bonus</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 4pt;text-indent: 0pt;text-align: right;">{{ Totalfees_comms_bonus }}</p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:407pt" colspan="7">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">(c) Tip kasar, perkuisit, penerimaan sagu hati atau elaun-elaun lain (Perihal pembayaran          )</p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 4pt;text-indent: 0pt;text-align: right;">{{ perq_allow_total }}</p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:247pt" colspan="4">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">(d) Cukai pendapatan yang dibayar oleh majikan bagi pihak pekerja</p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 4pt;text-indent: 0pt;text-align: right;">{{ totalEmployerContributions }}</p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:226pt" colspan="3">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">(e) Manfaat Skim Opsyen Saham Pekerja (ESOS)</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 4pt;text-indent: 0pt;text-align: right;">{{ stocks }}</p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:356pt" colspan="6">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">(f) Ganjaran bagi tempoh dari ............................................... hingga ...............................................</p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 4pt;text-indent: 0pt;text-align: right;">{{ gratuity }}</p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">2.</p>
            </td>
            <td style="width:356pt" colspan="6">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Butiran bayaran tunggakan dan lain-lain bagi tahun-tahun terdahulu dalam tahun semasa</p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:74pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Jenis pendapatan</p>
            </td>
            <td style="width:152pt" colspan="2">
               <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">(a) ......................................................</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:74pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:152pt" colspan="2">
               <p class="s5" style="padding-top: 2pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">(b) ......................................................</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 4pt;text-indent: 0pt;text-align: right;">{{ arrears_of_income }}</p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">3.</p>
            </td>
            <td style="width:407pt" colspan="7">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Manfaat berupa barangan (Nyatakan                                   )</p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 4pt;text-indent: 0pt;text-align: right;">{{ totalBik }}</p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">4.</p>
            </td>
            <td style="width:407pt" colspan="7">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Nilai tempat kediaman (Alamat                                      )</p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 4pt;text-indent: 0pt;text-align: center;">..............................</p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">5.</p>
            </td>
            <td style="width:356pt" colspan="6">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Bayaran balik daripada Kumpulan Wang Simpanan / Pencen yang tidak diluluskan</p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 4pt;text-indent: 0pt;text-align: center;">..............................</p>
            </td>
         </tr>
         <tr style="height:20pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">6.</p>
            </td>
            <td style="width:226pt" colspan="3">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Pampasan kerana kehilangan pekerjaan</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 4pt;text-indent: 0pt;text-align: center;">..............................</p>
            </td>
         </tr>

         <td style="width:21pt">
            <p style="text-indent: 0pt;text-align: left;"><br/></p>
         </td>

         <tr style="height:20pt">
            <td style="width:14pt">
               <p style="padding-top: 7pt;text-indent: 0pt;text-align: center;"><span class="s3" style=" background-color: #000;"> C </span></p>
            </td>
            <td style="width:135pt" colspan="3">
               <p class="s4" style="padding-top: 7pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">PENCEN DAN LAIN-LAIN</p>
            </td>
            <td style="width:109pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">1.</p>
            </td>
            <td style="width:74pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Pencen</p>
            </td>
            <td style="width:43pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:109pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 4pt;text-indent: 0pt;text-align: center;">..............................</p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">2.</p>
            </td>
            <td style="width:226pt" colspan="3">
               <p class="s5" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Anuiti atau bayaran berkala yang lain</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt;border-bottom-style:solid;border-bottom-width:1pt">
               <p class="s5" style="padding-top: 2pt;padding-left: 4pt;text-indent: 0pt;text-align: center;">..............................</p>
            </td>
         </tr>
         <tr style="height:15pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:74pt">
               <p class="s4" style="padding-top: 2pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">JUMLAH</p>
            </td>
            <td style="width:43pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:109pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt;border-top-style:solid;border-top-width:1pt;border-bottom-style:solid;border-bottom-width:1pt">
               <p style="text-indent: 0pt;text-align: right;">{{ total_income }}</p>
            </td>
         </tr>
         <tr style="height:25pt">
            <td style="width:14pt">
               <p style="padding-top: 3pt;text-indent: 0pt;text-align: left;"><br/></p>
               <p style="text-indent: 0pt;text-align: center;"><span class="s3" style=" background-color: #000;"> D </span></p>
            </td>
            <td style="width:92pt" colspan="2">
               <p style="padding-top: 3pt;text-indent: 0pt;text-align: left;"><br/></p>
               <p class="s4" style="padding-left: 6pt;text-indent: 0pt;text-align: left;">JUMLAH POTONGAN</p>
            </td>
            <td style="width:43pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:109pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt;border-top-style:solid;border-top-width:1pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">1.</p>
            </td>
            <td style="width:226pt" colspan="3">
               <p class="s5" style="padding-top: 1pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Potongan cukai bulanan (PCB) yang dibayar kepada LHDNM</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: right;">{{ pcb }}</p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">2.</p>
            </td>
            <td style="width:226pt" colspan="3">
               <p class="s5" style="padding-top: 1pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Arahan potongan CP38 yang dibayar kepada LHDNM</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: right;">{{ cp38 }}</p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">3.</p>
            </td>
            <td style="width:226pt" colspan="3">
               <p class="s5" style="padding-top: 1pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Zakat yang dibayar melalui potongan gaji</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: center;">..............................</p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">4.</p>
            </td>
            <td style="width:356pt" colspan="6">
               <p class="s5" style="padding-top: 1pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Derma / hadiah / sumbangan diluluskan yang dibayar melalui potongan gaji</p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: center;">..............................</p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">5.</p>
            </td>
            <td style="width:265pt" colspan="5">
               <p class="s5" style="padding-top: 1pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Jumlah tuntutan potongan oleh pekerja melalui Borang TP1 berkaitan:</p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:74pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">(a) Pelepasan</p>
            </td>
            <td style="width:43pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:109pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:142pt" colspan="2">
               <p class="s5" style="padding-top: 1pt;padding-left: 3pt;text-indent: 0pt;text-align: left;">RM .......................................................</p>
            </td>
            <td style="width:75pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:226pt" colspan="3">
               <p class="s5" style="padding-top: 1pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">(b) Zakat selain yang dibayar melalui potongan gaji bulanan</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:142pt" colspan="2">
               <p class="s5" style="padding-top: 1pt;padding-left: 3pt;text-indent: 0pt;text-align: left;">RM .......................................................</p>
            </td>
            <td style="width:75pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
         </tr>
         <tr style="height:19pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">6.</p>
            </td>
            <td style="width:226pt" colspan="3">
               <p class="s5" style="padding-top: 1pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Jumlah pelepasan bagi anak yang layak</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: center;">..............................</p>
            </td>
         </tr>

         <td style="width:21pt">
            <p style="text-indent: 0pt;text-align: left;"><br/></p>
         </td>

         <tr style="height:19pt">
            <td style="width:14pt">
               <p style="padding-top: 7pt;text-indent: 0pt;text-align: center;"><span class="s3" style=" background-color: #000;"> E </span></p>
            </td>
            <td style="width:500pt" colspan="9">
               <p class="s4" style="padding-top: 7pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">CARUMAN YANG DIBAYAR OLEH PEKERJA KEPADA KUMPULAN WANG SIMPANAN / PENCEN YANG DILULUSKAN DAN PERKESO</p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">1.</p>
            </td>
            <td style="width:482pt" colspan="8">
               <!--<p class="s5" style="padding-top: 1pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Nama Kumpulan Wang ................................................................................................................................................................................</p>-->
               <p class="s5" style="padding-top: 1pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Nama Kumpulan Wang KWSP : Kumpulan Wang Simpanan Pekerja</p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:265pt" colspan="5">
               <p class="s5" style="padding-top: 1pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">Amaun caruman yang wajib dibayar (nyatakan bahagian pekerja sahaja)</p>
            </td>
            <td style="width:91pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:51pt">
               <p class="s5" style="padding-top: 1pt;padding-right: 1pt;text-indent: 0pt;text-align: right;">RM</p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: right;">{{ epf }}</p>
            </td>
         </tr>
         <tr style="height:19pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 1pt;text-indent: 0pt;text-align: center;">2.</p>
            </td>
            <td style="width:356pt" colspan="6">
               <p class="s5" style="padding-top: 1pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">PERKESO: Amaun caruman yang wajib dibayar (nyatakan bahagian pekerja sahaja)</p>
            </td>
            <td style="width:51pt">
               <p class="s5" style="padding-top: 1pt;padding-right: 2pt;text-indent: 0pt;text-align: right;">RM</p>
            </td>
            <td style="width:75pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 4pt;text-indent: 0pt;text-align: right;">{{ socso }}</p>
            </td>
         </tr>

         <td style="width:21pt">
            <p style="text-indent: 0pt;text-align: left;"><br/></p>
         </td>

         <tr style="height:31pt">
            <td style="width:14pt">
               <p style="padding-top: 7pt;text-indent: 0pt;text-align: center;"><span class="s3" style=" background-color: #000;"> F </span></p>
            </td>
            <td style="width:374pt" colspan="7">
               <p class="s4" style="padding-top: 7pt;padding-left: 6pt;text-indent: 0pt;text-align: left;">JUMLAH ELAUN / PERKUISIT / PEMBERIAN / MANFAAT YANG DIKECUALIKAN CUKAI</p>
            </td>
            <td style="width:51pt;border-bottom-style:solid;border-bottom-width:1pt">
               <p class="s4" style="padding-top: 7pt;padding-right: 2pt;text-indent: 0pt;text-align: right;">RM</p>
            </td>
            <td style="width:75pt;border-bottom-style:solid;border-bottom-width:1pt">
               <p class="s5" style="padding-top: 7pt;padding-left: 4pt;text-indent: 0pt;text-align: center;">..............................</p>
            </td>
         </tr>

         <td style="width:21pt">
            <p style="text-indent: 0pt;text-align: left;"><br/></p>
         </td>

         <tr style="height:25pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:74pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:43pt;border-right-style:solid;border-right-width:1pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:109pt;border-top-style:solid;border-top-width:1pt;border-left-style:solid;border-left-width:1pt">
               <p style="padding-top: 3pt;text-indent: 0pt;text-align: left;"><br/></p>
               <p class="s5" style="padding-left: 5pt;text-indent: 0pt;text-align: left;">Nama Pegawai</p>
            </td>
            <td style="width:21pt;border-top-style:solid;border-top-width:1pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:235pt;border-top-style:solid;border-top-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="4">
               <p style="padding-top: 3pt;text-indent: 0pt;text-align: left;"><br/></p>
               <p class="s5" style="padding-left: 10pt;text-indent: 0pt;text-align: left;">....................................................................................................</p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:74pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:43pt;border-right-style:solid;border-right-width:1pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:109pt;border-left-style:solid;border-left-width:1pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Jawatan</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:235pt;border-right-style:solid;border-right-width:1pt" colspan="4">
               <p class="s5" style="padding-top: 1pt;padding-left: 10pt;text-indent: 0pt;text-align: left;">....................................................................................................</p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:74pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:43pt;border-right-style:solid;border-right-width:1pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:109pt;border-left-style:solid;border-left-width:1pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">Nama dan Alamat Majikan</p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:235pt;border-right-style:solid;border-right-width:1pt" colspan="4">
               <p class="s5" style="padding-top: 1pt;padding-left: 10pt;text-indent: 0pt;text-align: left;">....................................................................................................</p>
            </td>
         </tr>
         <tr style="height:14pt">
            <td style="width:14pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:18pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:74pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:43pt;border-right-style:solid;border-right-width:1pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:109pt;border-left-style:solid;border-left-width:1pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 5pt;text-indent: 0pt;text-align: left;"></p>
            </td>
            <td style="width:21pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:235pt;border-right-style:solid;border-right-width:1pt" colspan="4">
               <p class="s5" style="padding-top: 1pt;padding-left: 10pt;text-indent: 0pt;text-align: left;">....................................................................................................</p>
            </td>
         </tr>
         <tr style="height:25pt">
            <td style="width:149pt;border-right-style:solid;border-right-width:1pt" colspan="4">
               <p class="s5" style="padding-top: 1pt;padding-left: 2pt;text-indent: 0pt;text-align: left;">Tarikh: ...................................................</p>
            </td>
            <td style="width:109pt;border-left-style:solid;border-left-width:1pt;border-bottom-style:solid;border-bottom-width:1pt">
               <p class="s5" style="padding-top: 1pt;padding-left: 5pt;text-indent: 0pt;text-align: left;">No. Telefon Majikan</p>
            </td>
            <td style="width:21pt;border-bottom-style:solid;border-bottom-width:1pt">
               <p style="text-indent: 0pt;text-align: left;"><br/></p>
            </td>
            <td style="width:235pt;border-bottom-style:solid;border-bottom-width:1pt;border-right-style:solid;border-right-width:1pt" colspan="4">
               <p class="s5" style="padding-top: 1pt;padding-left: 10pt;text-indent: 0pt;text-align: left;">....................................................................................................</p>
            </td>
         </tr>
      </table>
   </body>
</html>