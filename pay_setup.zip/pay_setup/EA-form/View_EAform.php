<?php
// filepath: /C:/xampp/htdocs/pay_setup_helledition/generate pdf/download_payslip.php
require_once 'db.php'; // Database configuration
if (!isset($_GET['action']) || ($_GET['action'] != 'download' && $_GET['action'] != 'view')) {
    include 'header-pdf.php'; // Header for the site
}

// Step 3: Database Connection
$host = 'localhost';
$dbname = 'testsalary';
$username = 'root';
$password = '';
$tableName = 'ea_form'; // Replace with your table name 

// Fixed staff ID
$staffId = $_GET['id']; // Replace with the actual staff 

// Establish a PDO connection
$pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if (isset($_GET['action']) && ($_GET['action'] == 'download' || $_GET['action'] == 'view') && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $eaFormId = intval($_GET['id']);

    // Fetch the EA form from the database
    $sql = "SELECT staff_id, EAform, issue_date FROM ea_form WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':id', $eaFormId, PDO::PARAM_INT);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result && isset($result['EAform'])) {
        $fileContent = $result['EAform'];
        $staffID = $result['staff_id'];

        if ($_GET['action'] == 'download') {
            // Set headers to force download as a PDF
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="EAform_' . date('F Y', strtotime($result['issue_date'])) .'.pdf"');
            header('Content-Length: ' . strlen($fileContent));
        } else if ($_GET['action'] == 'view') {
            // Set headers to display the PDF in the browser
            header('Content-Type: application/pdf');
            header('Content-Disposition: inline; filename="EAform_' . date('F Y', strtotime($result['issue_date'])) .'.pdf"');
            header('Content-Length: ' . strlen($fileContent));
        }

        // Output the file
        echo $fileContent;
        exit;
    } else {
        echo "No EA form found for the given ID.";
    }
} else {
    // Fetch all EA forms for the given staff ID
    $sql = "SELECT id, issue_date FROM ea_form WHERE staff_id = :staff_id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':staff_id', $staffId, PDO::PARAM_INT);
    $stmt->execute();
    $eaForms = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($eaForms) {
        echo "<h1>Your EA Forms</h1>";
        echo "<style>
        h1 {
            text-align: center;
            margin-top: 20px;
        }

        .eaform-container {
            display: absolute;
            margin: 0 auto;
            flex-direction: column;
            justify-content: center;
            padding: 10px;

            text-align: center;

            width: 50%;
        }

        .eaform-individual-box {
            background-color: #ffffff;
            font-size: 20px;
            text-align: left;
            margin-top: 20px;
            border-radius: 10px;
            width: 100%;

            padding: 15px;
            min-width: 700px;
            box-shadow: 0 0 8px 0 rgba(0,0,0,0.2);

            transition-duration: 0.4s;
            position: relative;
        }

        .eaform-individual-box:hover {
            box-shadow: 0 0 8px 0 rgba(16, 47, 83, 0.50);
            transition-duration: 0.4s;
        }

        .eaform-btn-container {
            display: flex;
            justify-content: space-between;
            margin:20px;
        }

        .eaform-btn {
            padding: 10px;
            background-color: #ffffff;
            border: 2px solid #102f53;
            border-radius: 10px;
            text-align: center;
            cursor: pointer;
            width: 48%;
            color: #102f53;
            transition-duration: 0.4s;
            display: inline-block;

            margin:10px;
            height:100%;
        }

        .eaform-btn a {
            display: block;
            text-decoration: none;
            color: #333;
            font-weight: bold;
            width: 100%;
            height: 100%;
        }

        .eaform-btn:hover {
            background-color: #e0e0e0;
            transition-duration: 0.4s;
        }
        </style>";

        echo "<div class='eaform-container'>";

        foreach ($eaForms as $eaForm) {
            $eaFormId = $eaForm['id'];
            echo "
            <div class='eaform-individual-box'>
                <p style='margin:0 ;display:inline-block;'>EA Form " . date('Y', strtotime($eaForm['issue_date'])) . "</p>
                <div class='eaform-btn-container'>
                    <div class='eaform-btn'>
                        <a href='View_EAform.php?action=download&id=$eaFormId'>Download</a>
                    </div>
                    <div class='eaform-btn'>
                        <a href='View_EAform.php?action=view&id=$eaFormId' target='_blank'>View</a>
                    </div>
                </div>
            </div>
            ";
        }

        echo "</div>";
    } else {
        echo "<p>No EA forms found for Staff ID: $staffId</p>";
    }
}
?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const eaFormBoxes = document.querySelectorAll('.eaform-individual-box');

    eaFormBoxes.forEach(box => {
        const btnContainer = box.querySelector('.eaform-btn-container');
        btnContainer.style.maxHeight = '0';
        btnContainer.style.overflow = 'hidden';
        btnContainer.style.transition = 'max-height 0.4s ease-out';

        box.addEventListener('mouseenter', () => {
            btnContainer.style.maxHeight = btnContainer.scrollHeight + 'px';
        });

        box.addEventListener('mouseleave', () => {
            btnContainer.style.maxHeight = '0';
        });
    });
});
</script>
