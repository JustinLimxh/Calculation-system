<?php require 'vendor/autoload.php';
include ('db.php');

use Dompdf\Dompdf;
use Dompdf\Options;

$name = $_POST["name"];
$ic = $_POST["icNo"];
$ic = substr($ic, 0, 6) . '-' . substr($ic, 6, 2) . '-' . substr($ic, 8);
$epfNo = $_POST["epfNo"];
$children = $_POST["children"];
$staffId = $_POST['id'];  

$OTtotal = $_POST["overtime_pay"] + $_POST["basic_salary"];
$Totalfees_comms_bonus = $_POST["directorRemu"] + $_POST["commissionRemu"] + $_POST["bonusRemu"];
$perq_allow_total = $_POST['total_perq'] + $_POST['total_allowance'];

$total_income = $OTtotal + $Totalfees_comms_bonus + $perq_allow_total;

$totalEmployerContributions = $_POST["epfEmployerDeduct"] + $_POST["eisEmployerDeduct"] + $_POST["socsoEmployerDeduct"];
$stocks = $_POST["shareSchemePerk"];
$gratuity = $_POST["gratuityRemu"];
$arrears_of_income = $_POST["arrearsRemu"];
$totalBik = $_POST["total_bik"];
$epf = $_POST["epfEmployeeDeduct"];
$pcb = $_POST["pcb"];
$socso = $_POST["socsoEmployeeDeduct"]; 
$cp38 = $_POST["cp38Deduct"];
$currentYear = date("Y");

// Set options to enable CSS grid support
$options = new Options();
$options->set('isHtml5ParserEnabled', true);
$options->set('isRemoteEnabled', true);

$dompdf = new Dompdf($options);
$html = file_get_contents('template.php'); // Path to your HTML file

$html = str_replace("{{ staff_id }}", $staffId, $html);
$html = str_replace("{{ current_year }}", $currentYear, $html);
$html = str_replace("{{ name }}", $name, $html);
$html = str_replace("{{ ic }}", $ic, $html);

$eNo = $_POST["eNo"];
$html = str_replace("{{ eNo }}", $eNo, $html);


$ic = $_POST["icNo"];
$html = str_replace("{{ icrecombined }}", $ic, $html);

$html = str_replace("{{ epfNo }}", $epfNo, $html);
$html = str_replace("{{ children }}", $children, $html);

$html = str_replace("{{ OT }}", $OTtotal, $html);
$html = str_replace("{{ Totalfees_comms_bonus }}", $Totalfees_comms_bonus, $html);
$html = str_replace("{{ perq_allow_total }}", $perq_allow_total, $html);
$html = str_replace("{{ total_income }}", $total_income, $html);

$html = str_replace("{{ totalEmployerContributions }}", $totalEmployerContributions, $html);
$html = str_replace("{{ stocks }}", $stocks, $html);
$html = str_replace("{{ gratuity }}", $gratuity, $html);
$html = str_replace("{{ arrears_of_income }}", $arrears_of_income, $html);
$html = str_replace("{{ totalBik }}", $totalBik, $html);
$html = str_replace("{{ pcb }}", $pcb, $html);
$html = str_replace("{{ cp38 }}", $cp38, $html);
$html = str_replace("{{ epf }}", $epf, $html);
$html = str_replace("{{ socso }}", $socso, $html);

$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'portrait');

$dompdf->render();
$dompdf->stream("Borang_EA.pdf", ["Attachment" => 0]);

$issueDate = date('Y-m-d'); // Replace with the actual issue date

/**
 * Save the PDF file locally
 */
$output = $dompdf->output();
file_put_contents("file.pdf", $output);

// Define the staff ID
$staffId = $_POST['id'];    

// Generate the PDF file name using staff ID and name
$pdfFileName = $staffId . "_" . $name . "_EAform.pdf";

// Save PDF output to a file and variable
$pdfOutput = $dompdf->output();
$filePath = $pdfFileName; // Temporary file path
file_put_contents($filePath, $pdfOutput); // Save the file temporarily

// Step 2: Read the file as binary data
$fileData = file_get_contents($filePath); // Get the binary content of the file

// Step 3: Database Connection
$host = 'localhost';
$dbname = 'testsalary';
$username = 'root';
$password = '';
$tableName = 'ea_form'; // Replace with your table name
try {
    // Establish a PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    /*
    
    Remaining below is used to check whether EA form has been repeated as :

    1. If the EA form for the staff ID and issue date already exists, update the existing row. (as EA form is only each month)
    2. If the EA form for the staff ID and issue date does not exist, insert a new row. (as new month EA form is generated)

    */

    $sql = "SELECT id FROM ea_form WHERE staff_id = :staff_id AND DATE_FORMAT(issue_date, '%Y-%m') = DATE_FORMAT(:issue_date, '%Y-%m')";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':staff_id', $staffId, PDO::PARAM_INT);
    $stmt->bindValue(':issue_date', $issueDate, PDO::PARAM_STR);
    $stmt->execute();
    $existingRow = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existingRow) {
        // Update the existing row
        $sql = "UPDATE ea_form SET EAform = :EAform, issue_date = :issue_date WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':EAform', $pdfOutput, PDO::PARAM_STR);
        $stmt->bindValue(':issue_date', $issueDate, PDO::PARAM_STR);
        $stmt->bindValue(':id', $existingRow['id'], PDO::PARAM_INT);
        $stmt->execute();
        echo "EA form updated successfully for Staff ID $staffId.";
    } else {
        // Insert a new row
        $sql = "INSERT INTO ea_form (staff_id, EAform, issue_date) VALUES (:staff_id, :EAform, :issue_date)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':staff_id', $staffId, PDO::PARAM_INT);
        $stmt->bindValue(':EAform', $pdfOutput, PDO::PARAM_STR);
        $stmt->bindValue(':issue_date', $issueDate, PDO::PARAM_STR);
        $stmt->execute();
        echo "EA form saved successfully for Staff ID $staffId.";
    }
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

// Optional: Delete the temporary file
if (file_exists($filePath)) {
    unlink($filePath); // Remove the temporary file
}

?>
