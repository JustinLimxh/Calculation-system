<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PDF</title>
    <script src="script.js"></script>

    <style>

        #logo {
            display: block;
            margin-bottom:auto;
            margin-top:auto;
            margin: auto;

            width: 20%;
            height: 20%;

            animation: fadeInAnimation 0.5s infinite alternate;
            animation-timing-function: ease-in-out;
        }

        @keyframes fadeInAnimation {
            0% {
                opacity: 0;
            }

            100% {
                opacity: 0.7;
            }

            
        }
    </style>
</head>

<?php

        include ('db.php');
        // Include the database connection
        $conn = mysqli_connect("localhost", "root", "", "testsalary");

        if (!$conn) {
            die("Database connection failed: " . mysqli_connect_error());
        }

        $id = $_GET['id'];

        // Fetch salary data
        $sql = "SELECT st.*, 

        COALESCE(cinfo.eNo, 0) as eNo,

        COALESCE(sinfo.company_id, 0) as company_id,
        COALESCE(sinfo.icNo, 0) as icNo,
        COALESCE(sinfo.accNo, 0) as accNo,
        COALESCE(sinfo.pcbNo, 0) as pcbNo,
        COALESCE(sinfo.epfNo, 0) as epfNo,

        COALESCE(sbio.pcb, 0) as pcb,
        COALESCE(sbio.children_full_time, 0) as children_full_time,
        COALESCE(sbio.children_disabled, 0) as children_disabled,
        COALESCE(sbio.children_disabled_FT, 0) as children_disabled_FT,
        COALESCE(sbio.children_underage, 0) as children_underage,
        
        COALESCE(ot.overtime_pay, 0) as overtime_pay,

        COALESCE(sa.basic_salary, 0) as basic_salary, 
        COALESCE(sa.bank_number, 0) as bank_number, 

        COALESCE(al.attendance, 0) as attendance, 
        COALESCE(al.mobile, 0) as mobile, 
        COALESCE(al.childCare, 0) as childCare, 
        COALESCE(al.eduAllow, 0) as eduAllow, 
        COALESCE(al.houseAllow, 0) as houseAllow, 
        COALESCE(al.internAllow, 0) as internAllow, 
        COALESCE(al.mealAllow, 0) as mealAllow, 
        COALESCE(al.otherAllow, 0) as otherAllow, 
        COALESCE(al.parkingAllow, 0) as parkingAllow, 
        COALESCE(al.shiftAllow, 0) as shiftAllow, 
        COALESCE(al.travelOAllow, 0) as travelOAllow, 
        COALESCE(al.travelPAllow, 0) as travelPAllow,

        COALESCE(be.consumeDiscBik, 0) as consumeDiscBik, 
        COALESCE(be.dentalBik, 0) as dentalBik, 
        COALESCE(be.driverBik, 0) as driverBik, 
        COALESCE(be.fulfillDutiBik, 0) as fulfillDutiBik, 
        COALESCE(be.foodDrinkBik, 0) as foodDrinkBik, 
        COALESCE(be.garmentBik, 0) as garmentBik, 
        COALESCE(be.hElectrikBik, 0) as hElectrikBik, 
        COALESCE(be.hEntertainBik, 0) as hEntertainBik, 
        COALESCE(be.hFurniturBik, 0) as hFurniturBik, 
        COALESCE(be.hGardenBik, 0) as hGardenBik, 
        COALESCE(be.hKitchenBik, 0) as hKitchenBik, 
        COALESCE(be.hServantBik, 0) as hServantBik, 
        COALESCE(be.hTelephoneBik, 0) as hTelephoneBik, 
        COALESCE(be.hUtilitiBik, 0) as hUtilitiBik, 
        COALESCE(be.travelMalayBik, 0) as travelMalayBik, 
        COALESCE(be.travelOverBik, 0) as travelOverBik, 
        COALESCE(be.liviAccoBik, 0) as liviAccoBik, 
        COALESCE(be.medicalBik, 0) as medicalBik, 
        COALESCE(be.otherBik, 0) as otherBik, 
        COALESCE(be.clubMemberBik, 0) as clubMemberBik, 
        COALESCE(be.serviceDiscBik, 0) as serviceDiscBik, 
        COALESCE(be.transportBik, 0) as transportBik, 
        COALESCE(be.motorcarBik, 0) as motorcarBik,

        COALESCE(de.advPayDeduct, 0) as advPayDeduct,
        COALESCE(de.basicSuppDeduct, 0) as basicSuppDeduct,
        COALESCE(de.cp38Deduct, 0) as cp38Deduct,
        COALESCE(de.dentalDeduct, 0) as dentalDeduct,
        COALESCE(de.departureDeduct, 0) as departureDeduct,
        COALESCE(de.domTourisDeduct, 0) as domTourisDeduct,
        COALESCE(de.earlyDeduct, 0) as earlyDeduct,
        COALESCE(de.eduDeduct, 0) as eduDeduct,
        COALESCE(de.hrdfDeduct, 0) as hrdfDeduct,
        COALESCE(de.epfEmployeeDeduct, 0) as epfEmployeeDeduct,
        COALESCE(de.epfEmployerDeduct, 0) as epfEmployerDeduct,
        COALESCE(de.eisEmployeeDeduct, 0) as eisEmployeeDeduct,
        COALESCE(de.eisEmployerDeduct, 0) as eisEmployerDeduct,
        COALESCE(de.socsoEmployeeDeduct, 0) as socsoEmployeeDeduct,
        COALESCE(de.socsoEmployerDeduct, 0) as socsoEmployerDeduct,
        COALESCE(de.evDeduct, 0) as evDeduct,
        COALESCE(de.fatherDeduct, 0) as fatherDeduct,
        COALESCE(de.childCare, 0) as childCare,
        COALESCE(de.highEduDeduct, 0) as highEduDeduct,
        COALESCE(de.housLoanDeduct, 0) as housLoanDeduct,
        COALESCE(de.insuranceDeduct, 0) as insuranceDeduct,
        COALESCE(de.lifeInsDeduct, 0) as lifeInsDeduct,
        COALESCE(de.lifestyleDeduct, 0) as lifestyleDeduct,
        COALESCE(de.lifestyleCompDeduct, 0) as lifestyleCompDeduct,
        COALESCE(de.loanDeduct, 0) as loanDeduct,
        COALESCE(de.medicalDeduct, 0) as medicalDeduct,
        COALESCE(de.medicalParentDeduct, 0) as medicalParentDeduct,
        COALESCE(de.medicalSeriousDeduct, 0) as medicalSeriousDeduct,
        COALESCE(de.medicalTreatDeduct, 0) as medicalTreatDeduct,
        COALESCE(de.motherDeduct, 0) as motherDeduct,
        COALESCE(de.netSSPNDeduct, 0) as netSSPNDeduct,
        COALESCE(de.netSalaryDeduct, 0) as netSalaryDeduct,
        COALESCE(de.formerWifeDeduct, 0) as formerWifeDeduct,
        COALESCE(de.retiredDeduct, 0) as retiredDeduct,
        COALESCE(de.ptptnDeduct, 0) as ptptnDeduct,
        COALESCE(de.breastDeduct, 0) as breastDeduct,
        COALESCE(de.salaryAdjDeduct, 0) as salaryAdjDeduct,
        COALESCE(de.sportDeduct, 0) as sportDeduct,
        COALESCE(de.upskilDeduct, 0) as upskilDeduct,
        COALESCE(de.vaccineDeduct, 0) as vaccineDeduct,
        COALESCE(de.withTaxDeduct, 0) as withTaxDeduct,

        COALESCE(re.advPayRemu, 0) as advPayRemu,
        COALESCE(re.arrearsRemu, 0) as arrearsRemu,
        COALESCE(re.bonusRemu, 0) as bonusRemu,
        COALESCE(re.commissionRemu, 0) as commissionRemu,
        COALESCE(re.compensationRemu, 0) as compensationRemu,
        COALESCE(re.directorRemu, 0) as directorRemu,
        COALESCE(re.claimRemu, 0) as claimRemu,
        COALESCE(re.gratuityRemu, 0) as gratuityRemu,
        COALESCE(re.incentiveRemu, 0) as incentiveRemu,
        COALESCE(re.leavePayRemu, 0) as leavePayRemu,
        COALESCE(re.otNormRemu, 0) as otNormRemu,
        COALESCE(re.otPublicRemu, 0) as otPublicRemu,
        COALESCE(re.pcbPastRemu, 0) as pcbPastRemu,
        COALESCE(re.profitRemu, 0) as profitRemu,
        COALESCE(re.servRemu, 0) as servRemu,
        COALESCE(re.severanceRemu, 0) as severanceRemu,

        COALESCE(pe.mobilePerk, 0) as mobilePerk,
        COALESCE(pe.carPerk, 0) as carPerk,
        COALESCE(pe.creditcardPerk, 0) as creditcardPerk,
        COALESCE(pe.voucherPerk, 0) as voucherPerk,
        COALESCE(pe.houseUtilsPerk, 0) as houseUtilsPerk,
        COALESCE(pe.houseLoanPerk, 0) as houseLoanPerk,
        COALESCE(pe.parkingPerk, 0) as parkingPerk,
        COALESCE(pe.computerPerk, 0) as computerPerk,
        COALESCE(pe.proSubscriptPerk, 0) as proSubscriptPerk,
        COALESCE(pe.clubMemberPerk, 0) as clubMemberPerk,
        COALESCE(pe.roadtaxPerk, 0) as roadtaxPerk,
        COALESCE(pe.awardPerk, 0) as awardPerk,
        COALESCE(pe.shareSchemePerk, 0) as shareSchemePerk

        FROM staff st 
        LEFT JOIN salary sa ON st.id = sa.staff_id 
        LEFT JOIN allowance al ON st.id = al.staff_id 
        LEFT JOIN benefit be ON st.id = be.staff_id 
        LEFT JOIN deduction de ON st.id = de.staff_id 
        LEFT JOIN remuneration re ON st.id = re.staff_id
        LEFT JOIN perquisites pe ON st.id = pe.staff_id
        LEFT JOIN overtime ot ON st.id = ot.staff_id
        LEFT JOIN staff_bio sbio ON st.id = sbio.staff_id
        LEFT JOIN staffinfo sinfo ON st.id = sinfo.staff_id
        LEFT JOIN companyinfo cinfo ON sinfo.company_id = cinfo.id
        WHERE st.id = $id";

        $result = mysqli_query($conn, $sql);

        if (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {

                $allowanceSum = $row['attendance'] + $row['mobile'] + $row['childCare'] + $row['eduAllow'] + $row['houseAllow'] + $row['internAllow'] + $row['mealAllow'] + $row['otherAllow'] + $row['parkingAllow'] + $row['shiftAllow'] + $row['travelOAllow'] + $row['travelPAllow'];
                $bikSum = $row['consumeDiscBik'] + $row['dentalBik'] + $row['driverBik'] + $row['fulfillDutiBik'] + $row['foodDrinkBik'] + $row['garmentBik'] + $row['hElectrikBik'] + $row['hEntertainBik'] + $row['hFurniturBik'] + $row['hGardenBik'] + $row['hKitchenBik'] + $row['hServantBik'] + $row['hTelephoneBik'] + $row['hUtilitiBik'] + $row['travelMalayBik'] + $row['travelOverBik'] + $row['liviAccoBik'] + $row['medicalBik'] + $row['otherBik'] + $row['clubMemberBik'] + $row['serviceDiscBik'] + $row['transportBik'] + $row['motorcarBik'];
                $deductionSum = $row['advPayDeduct'] + $row['basicSuppDeduct'] + $row['cp38Deduct'] + $row['dentalDeduct'] + $row['departureDeduct'] + $row['domTourisDeduct'] + $row['earlyDeduct'] + $row['eduDeduct'] + $row['hrdfDeduct'] + $row['epfEmployeeDeduct'] + /*$row['epfEmployerDeduct'] +*/ $row['evDeduct'] + $row['fatherDeduct'] + $row['childCare'] + $row['highEduDeduct'] + $row['housLoanDeduct'] + $row['insuranceDeduct'] + $row['lifeInsDeduct'] + $row['lifestyleDeduct'] + $row['lifestyleCompDeduct'] + $row['loanDeduct'] + $row['medicalDeduct'] + $row['medicalParentDeduct'] + $row['medicalSeriousDeduct'] + $row['medicalTreatDeduct'] + $row['motherDeduct'] + $row['netSSPNDeduct'] + $row['netSalaryDeduct'] + $row['formerWifeDeduct'] + $row['retiredDeduct'] + $row['ptptnDeduct'] + $row['breastDeduct'] + $row['salaryAdjDeduct'] + $row['sportDeduct'] + $row['upskilDeduct'] + $row['vaccineDeduct'] + $row['withTaxDeduct']+ $row['eisEmployeeDeduct'] + /*$row['eisEmployerDeduct'] +*/ $row['socsoEmployeeDeduct'] /*+ $row['socsoEmployerDeduct']*/;
                $renumSum = $row['advPayRemu'] + $row['arrearsRemu'] + $row['bonusRemu'] + $row['commissionRemu'] + $row['compensationRemu'] + $row['directorRemu'] + $row['claimRemu'] + $row['gratuityRemu'] + $row['incentiveRemu'] + $row['leavePayRemu'] + $row['otNormRemu'] + $row['otPublicRemu'] + $row['pcbPastRemu'] + $row['profitRemu'] + $row['servRemu'] + $row['severanceRemu'];
                $perquisitesSum = $row['mobilePerk'] + $row['carPerk'] + $row['creditcardPerk'] + $row['voucherPerk'] + $row['houseUtilsPerk'] + $row['houseLoanPerk'] + $row['parkingPerk'] + $row['computerPerk'] + $row['proSubscriptPerk'] + $row['clubMemberPerk'] + $row['roadtaxPerk'] + $row['awardPerk'] + $row['shareSchemePerk'];
                $children = $row['children_full_time'] + $row['children_disabled'] + $row['children_disabled_FT'] + $row['children_underage'];

                echo "
                <tr>
                        <form id='autoSubmitForm' method='post' action='generate-pdf.php'>

                            <input type='hidden' name='eNo' id='eNo' value={$row['eNo']} required>
                            <input type='hidden' name='company_id' id='company_id' value={$row['company_id']} required> 
                            <input type='hidden' name='icNo' id='icNo' value='{$row['icNo']}' required>
                            <input type='hidden' name='accNo' id='accNo' value='{$row['accNo']}' required>
                            <input type='hidden' name='pcbNo' id='pcbNo' value='{$row['pcbNo']}' required>
                            <input type='hidden' name='epfNo' id='epfNo' value='{$row['epfNo']}' required>

                            <input type='hidden' name='overtime_pay' id='overtime_pay' value='{$row['overtime_pay']}' required>

                            <input type='hidden' name='period' id='period' value='' required>
                            <input type='hidden' name='date' id='date' value='' required>

                            <input type='hidden' name='name' id='name' value='{$row['name']}' required>
                            <input type='hidden' name='email' id='email' value={$row['email']} required>
                            
                            <input type='hidden' name='id' id='id' value={$id} required>

                            <input type='hidden' name='children_full_time' id='children_full_time' value={$row['children_full_time']} required>
                            <input type='hidden' name='children_disabled' id='children_disabled' value={$row['children_disabled']} required>
                            <input type='hidden' name='children_disabled_FT' id='children_disabled_FT' value={$row['children_disabled_FT']} required>
                            <input type='hidden' name='children_underage' id='children_underage' value={$row['children_underage']} required>
                            <input type='hidden' name='children' id='children' value={$children} required>
                            <input type='hidden' name='pcb' id='pcb' value={$row['pcb']} required>

                            <input type='hidden' name='bank_number' id='bank_number' value={$row['bank_number']} required>
                            <input type='hidden' name='basic_salary' id='basic_salary' value={$row['basic_salary']} required>
                            
                            <input type='hidden' name='attendance' id='attendance' value={$row['attendance']} required>
                            <input type='hidden' name='mobile' id='mobile' value={$row['mobile']} required>
                            <input type='hidden' name='childCare' id='childCare' value={$row['childCare']} required>
                            <input type='hidden' name='eduAllow' id='eduAllow' value={$row['eduAllow']} required>
                            <input type='hidden' name='houseAllow' id='houseAllow' value={$row['houseAllow']} required>
                            <input type='hidden' name='internAllow' id='internAllow' value={$row['internAllow']} required>
                            <input type='hidden' name='mealAllow' id='mealAllow' value={$row['mealAllow']} required>
                            <input type='hidden' name='otherAllow' id='otherAllow' value={$row['otherAllow']} required>
                            <input type='hidden' name='parkingAllow' id='parkingAllow' value={$row['parkingAllow']} required>
                            <input type='hidden' name='shiftAllow' id='shiftAllow' value={$row['shiftAllow']} required>
                            <input type='hidden' name='travelOAllow' id='travelOAllow' value={$row['travelOAllow']} required>
                            <input type='hidden' name='travelPAllow' id='travelPAllow' value={$row['travelPAllow']} required>
                            <input type='hidden' name='total_allowance' id='total_allowance' value={$allowanceSum} required>

                            <input type='hidden' name='consumeDiscBik' id='consumeDiscBik' value={$row['consumeDiscBik']} required>
                            <input type='hidden' name='dentalBik' id='dentalBik' value={$row['dentalBik']} required>
                            <input type='hidden' name='driverBik' id='driverBik' value={$row['driverBik']} required>
                            <input type='hidden' name='fulfillDutiBik' id='fulfillDutiBik' value={$row['fulfillDutiBik']} required>
                            <input type='hidden' name='foodDrinkBik' id='foodDrinkBik' value={$row['foodDrinkBik']} required>
                            <input type='hidden' name='garmentBik' id='garmentBik' value={$row['garmentBik']} required>
                            <input type='hidden' name='hElectrikBik' id='hElectrikBik' value={$row['hElectrikBik']} required>
                            <input type='hidden' name='hEntertainBik' id='hEntertainBik' value={$row['hEntertainBik']} required>
                            <input type='hidden' name='hFurniturBik' id='hFurniturBik' value={$row['hFurniturBik']} required>
                            <input type='hidden' name='hGardenBik' id='hGardenBik' value={$row['hGardenBik']} required>
                            <input type='hidden' name='hKitchenBik' id='hKitchenBik' value={$row['hKitchenBik']} required>
                            <input type='hidden' name='hServantBik' id='hServantBik' value={$row['hServantBik']} required>
                            <input type='hidden' name='hTelephoneBik' id='hTelephoneBik' value={$row['hTelephoneBik']} required>
                            <input type='hidden' name='hUtilitiBik' id='hUtilitiBik' value={$row['hUtilitiBik']} required>
                            <input type='hidden' name='travelMalayBik' id='travelMalayBik' value={$row['travelMalayBik']} required>
                            <input type='hidden' name='travelOverBik' id='travelOverBik' value={$row['travelOverBik']} required>
                            <input type='hidden' name='liviAccoBik' id='liviAccoBik' value={$row['liviAccoBik']} required>
                            <input type='hidden' name='medicalBik' id='medicalBik' value={$row['medicalBik']} required>
                            <input type='hidden' name='otherBik' id='otherBik' value={$row['otherBik']} required>
                            <input type='hidden' name='clubMemberBik' id='clubMemberBik' value={$row['clubMemberBik']} required>
                            <input type='hidden' name='serviceDiscBik' id='serviceDiscBik' value={$row['serviceDiscBik']} required>
                            <input type='hidden' name='transportBik' id='transportBik' value={$row['transportBik']} required>
                            <input type='hidden' name='motorcarBik' id='motorcarBik' value={$row['motorcarBik']} required>
                            <input type='hidden' name='total_bik' id='total_bik' value={$bikSum} required>

                            <input type='hidden' name='advPayDeduct' id='advPayDeduct' value={$row['advPayDeduct']} required>
                            <input type='hidden' name='basicSuppDeduct' id='basicSuppDeduct' value={$row['basicSuppDeduct']} required>
                            <input type='hidden' name='cp38Deduct' id='cp38Deduct' value={$row['cp38Deduct']} required>
                            <input type='hidden' name='dentalDeduct' id='dentalDeduct' value={$row['dentalDeduct']} required>
                            <input type='hidden' name='departureDeduct' id='departureDeduct' value={$row['departureDeduct']} required>
                            <input type='hidden' name='domTourisDeduct' id='domTourisDeduct' value={$row['domTourisDeduct']} required>
                            <input type='hidden' name='earlyDeduct' id='earlyDeduct' value={$row['earlyDeduct']} required>
                            <input type='hidden' name='eduDeduct' id='eduDeduct' value={$row['eduDeduct']} required>
                            <input type='hidden' name='hrdfDeduct' id='hrdfDeduct' value={$row['hrdfDeduct']} required>
                            <input type='hidden' name='epfEmployeeDeduct' id='epfEmployeeDeduct' value={$row['epfEmployeeDeduct']} required>
                            <input type='hidden' name='epfEmployerDeduct' id='epfEmployerDeduct' value={$row['epfEmployerDeduct']} required>
                            <input type='hidden' name='evDeduct' id='evDeduct' value={$row['evDeduct']} required>
                            <input type='hidden' name='fatherDeduct' id='fatherDeduct' value={$row['fatherDeduct']} required>
                            <input type='hidden' name='childCare' id='childCare' value={$row['childCare']} required>
                            <input type='hidden' name='highEduDeduct' id='highEduDeduct' value={$row['highEduDeduct']} required>
                            <input type='hidden' name='housLoanDeduct' id='housLoanDeduct' value={$row['housLoanDeduct']} required>
                            <input type='hidden' name='insuranceDeduct' id='insuranceDeduct' value={$row['insuranceDeduct']} required>
                            <input type='hidden' name='eisEmployeeDeduct' id='eisEmployeeDeduct' value={$row['eisEmployeeDeduct']} required>
                            <input type='hidden' name='eisEmployerDeduct' id='eisEmployerDeduct' value={$row['eisEmployerDeduct']} required>
                            <input type='hidden' name='socsoEmployeeDeduct' id='socsoEmployeeDeduct' value={$row['socsoEmployeeDeduct']} required>
                            <input type='hidden' name='socsoEmployerDeduct' id='socsoEmployerDeduct' value={$row['socsoEmployerDeduct']} required>
                            <input type='hidden' name='lifeInsDeduct' id='lifeInsDeduct' value={$row['lifeInsDeduct']} required>
                            <input type='hidden' name='lifestyleDeduct' id='lifestyleDeduct' value={$row['lifestyleDeduct']} required>
                            <input type='hidden' name='lifestyleCompDeduct' id='lifestyleCompDeduct' value={$row['lifestyleCompDeduct']} required>
                            <input type='hidden' name='loanDeduct' id='loanDeduct' value={$row['loanDeduct']} required>
                            <input type='hidden' name='medicalDeduct' id='medicalDeduct' value={$row['medicalDeduct']} required>
                            <input type='hidden' name='medicalParentDeduct' id='medicalParentDeduct' value={$row['medicalParentDeduct']} required>
                            <input type='hidden' name='medicalSeriousDeduct' id='medicalSeriousDeduct' value={$row['medicalSeriousDeduct']} required>
                            <input type='hidden' name='medicalTreatDeduct' id='medicalTreatDeduct' value={$row['medicalTreatDeduct']} required>
                            <input type='hidden' name='motherDeduct' id='motherDeduct' value={$row['motherDeduct']} required>
                            <input type='hidden' name='netSSPNDeduct' id='netSSPNDeduct' value={$row['netSSPNDeduct']} required>
                            <input type='hidden' name='netSalaryDeduct' id='netSalaryDeduct' value={$row['netSalaryDeduct']} required>
                            <input type='hidden' name='formerWifeDeduct' id='formerWifeDeduct' value={$row['formerWifeDeduct']} required>
                            <input type='hidden' name='retiredDeduct' id='retiredDeduct' value={$row['retiredDeduct']} required>
                            <input type='hidden' name='ptptnDeduct' id='ptptnDeduct' value={$row['ptptnDeduct']} required>
                            <input type='hidden' name='breastDeduct' id='breastDeduct' value={$row['breastDeduct']} required>
                            <input type='hidden' name='salaryAdjDeduct' id='salaryAdjDeduct' value={$row['salaryAdjDeduct']} required>
                            <input type='hidden' name='sportDeduct' id='sportDeduct' value={$row['sportDeduct']} required>
                            <input type='hidden' name='upskilDeduct' id='upskilDeduct' value={$row['upskilDeduct']} required>
                            <input type='hidden' name='vaccineDeduct' id='vaccineDeduct' value={$row['vaccineDeduct']} required>
                            <input type='hidden' name='withTaxDeduct' id='withTaxDeduct' value={$row['withTaxDeduct']} required>
                            <input type='hidden' name='total_deduct' id='total_deduct' value={$deductionSum} required>

                            <input type='hidden' name='advPayRemu' id='advPayRemu' value={$row['advPayRemu']} required>
                            <input type='hidden' name='arrearsRemu' id='arrearsRemu' value={$row['arrearsRemu']} required>
                            <input type='hidden' name='bonusRemu' id='bonusRemu' value={$row['bonusRemu']} required>
                            <input type='hidden' name='commissionRemu' id='commissionRemu' value={$row['commissionRemu']} required>
                            <input type='hidden' name='compensationRemu' id='compensationRemu' value={$row['compensationRemu']} required>
                            <input type='hidden' name='directorRemu' id='directorRemu' value={$row['directorRemu']} required>
                            <input type='hidden' name='claimRemu' id='claimRemu' value={$row['claimRemu']} required>
                            <input type='hidden' name='gratuityRemu' id='gratuityRemu' value={$row['gratuityRemu']} required>
                            <input type='hidden' name='incentiveRemu' id='incentiveRemu' value={$row['incentiveRemu']} required>
                            <input type='hidden' name='leavePayRemu' id='leavePayRemu' value={$row['leavePayRemu']} required>
                            <input type='hidden' name='otNormRemu' id='otNormRemu' value={$row['otNormRemu']} required>
                            <input type='hidden' name='otPublicRemu' id='otPublicRemu' value={$row['otPublicRemu']} required>
                            <input type='hidden' name='pcbPastRemu' id='pcbPastRemu' value={$row['pcbPastRemu']} required>
                            <input type='hidden' name='profitRemu' id='profitRemu' value={$row['profitRemu']} required>
                            <input type='hidden' name='servRemu' id='servRemu' value={$row['servRemu']} required>
                            <input type='hidden' name='severanceRemu' id='severanceRemu' value={$row['severanceRemu']} required>
                            <input type='hidden' name='total_remun' id='total_remun' value={$renumSum} required>

                            <input type='hidden' name='mobilePerk' id='mobilePerk' value={$row['mobilePerk']} required>
                            <input type='hidden' name='carPerk' id='carPerk' value={$row['carPerk']} required>
                            <input type='hidden' name='creditcardPerk' id='creditcardPerk' value={$row['creditcardPerk']} required>
                            <input type='hidden' name='voucherPerk' id='voucherPerk' value={$row['voucherPerk']} required>
                            <input type='hidden' name='houseUtilsPerk' id='houseUtilsPerk' value={$row['houseUtilsPerk']} required>
                            <input type='hidden' name='houseLoanPerk' id='houseLoanPerk' value={$row['houseLoanPerk']} required>
                            <input type='hidden' name='parkingPerk' id='parkingPerk' value={$row['parkingPerk']} required>
                            <input type='hidden' name='computerPerk' id='computerPerk' value={$row['computerPerk']} required>
                            <input type='hidden' name='proSubscriptPerk' id='proSubscriptPerk' value={$row['proSubscriptPerk']} required>
                            <input type='hidden' name='clubMemberPerk' id='clubMemberPerk' value={$row['clubMemberPerk']} required>
                            <input type='hidden' name='roadtaxPerk' id='roadtaxPerk' value={$row['roadtaxPerk']} required>
                            <input type='hidden' name='awardPerk' id='awardPerk' value={$row['awardPerk']} required>
                            <input type='hidden' name='shareSchemePerk' id='shareSchemePerk' value={$row['shareSchemePerk']} required>
                            <input type='hidden' name='total_perq' id='total_perq' value={$perquisitesSum} required>

                            <img src='../assets/logo.png' alt='logo'id='logo'>
                        
                        </form>
                    ";
                        
            }
        } else {
            echo "<tr>
                    <td colspan='4' style='text-align: center;'>No staff found</td>
                    </tr>";
        }

        mysqli_close($conn);
?>

<body>
<script>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('autoSubmitForm').submit();
        });
    </script>
</body>

</html>

<?php

// Include the database connection
include('db.php');

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

?>