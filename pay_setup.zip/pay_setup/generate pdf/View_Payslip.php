<?php
// filepath: /C:/xampp/htdocs/pay_setup_helledition/generate pdf/download_payslip.php
require_once 'db.php'; // Database configuration
if (!isset($_GET['action']) || ($_GET['action'] != 'download' && $_GET['action'] != 'view')) {
    include 'header-pdf.php'; // Header for the site
}

// Step 3: Database Connection
$host = 'localhost';
$dbname = 'testsalary';
$username = 'root';
$password = '';
$tableName = 'payslip'; // Replace with your table name 

// Fixed staff ID
$staffId = $_GET['id']; // Replace with the actual staff 

// Establish a PDO connection
$pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if (isset($_GET['action']) && ($_GET['action'] == 'download' || $_GET['action'] == 'view') && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $payslipId = intval($_GET['id']);

    // Fetch the payslip from the database
    $sql = "SELECT staff_id, payslip, issue_date FROM payslip WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':id', $payslipId, PDO::PARAM_INT);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result && isset($result['payslip'])) {
        $fileContent = $result['payslip'];
        $staffID = $result['staff_id'];

        if ($_GET['action'] == 'download') {
            // Set headers to force download as a PDF
            header('Content-Type: application/pdf');
            header('Content-Disposition: attachment; filename="payslip_' . date('F Y', strtotime($result['issue_date'])) . '.pdf"');
            header('Content-Length: ' . strlen($fileContent));
        } else if ($_GET['action'] == 'view') {
            // Set headers to display the PDF in the browser
            header('Content-Type: application/pdf');
            header('Content-Disposition: inline; filename="payslip_' . date('F Y', strtotime($result['issue_date'])) . '.pdf"');
            header('Content-Length: ' . strlen($fileContent));
        }

        // Output the file
        echo $fileContent;
        exit;
    } else {
        echo "No payslip found for the given ID.";
    }
} else {
    // Fetch all payslips for the given staff ID
    $sql = "SELECT id, issue_date FROM payslip WHERE staff_id = :staff_id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':staff_id', $staffId, PDO::PARAM_INT);
    $stmt->execute();
    $payslips = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($payslips) {
        echo "<h1>Your Payslips</h1>";
        echo "<style>
        h1 {
            text-align: center;
            margin-top: 20px;
        }

        .payslip-container {
            display: absolute;
            margin: 0 auto;
            flex-direction: column;
            justify-content: center;
            padding: 10px;

            text-align: center;

            width: 50%;
        }

        .payslip-individual-box {
            background-color: #ffffff;
            font-size: 20px;
            text-align: left;
            margin-top: 20px;
            border-radius: 10px;
            width: 100%;

            padding: 15px;
            min-width: 700px;
            box-shadow: 0 0 8px 0 rgba(0,0,0,0.2);

            transition-duration: 0.4s;
            position: relative;
        }

        .payslip-individual-box:hover {
            box-shadow: 0 0 8px 0 rgba(16, 47, 83, 0.50);
            transition-duration: 0.4s;
        }

        .payslip-btn-container {
            display: flex;
            justify-content: space-between;
            margin:20px;
        }

        .payslip-btn {
            padding: 10px;
            background-color: #ffffff;
            border: 2px solid #102f53;
            border-radius: 10px;
            text-align: center;
            cursor: pointer;
            width: 48%;
            color: #102f53;
            transition-duration: 0.4s;
            display: inline-block;

            margin:10px;
            height:100%;
        }

        .payslip-btn a {
            display: block;
            text-decoration: none;
            color: #333;
            font-weight: bold;
            width: 100%;
            height: 100%;
        }

        .payslip-btn:hover {
            background-color: #e0e0e0;
            transition-duration: 0.4s;
        }
        </style>";

        echo "<div class='payslip-container'>";

        foreach ($payslips as $payslip) {
            $payslipId = $payslip['id'];

            // Fetch basic salary for the payslip
            $sql = "SELECT basic_salary FROM payslip WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->bindValue(':id', $payslipId, PDO::PARAM_INT);
            $stmt->execute();
            $salaryResult = $stmt->fetch(PDO::FETCH_ASSOC);
            $basicSalary = $salaryResult ? $salaryResult['basic_salary'] : 'N/A';

            echo "
            <div class='payslip-individual-box'>
                <p style='margin:0 ;display:inline-block;'>" . date('F, Y', strtotime($payslip['issue_date'])) . "</p>
                <p style='margin:0 ;display:inline-block; float:right;text-align:right'>RM $basicSalary </p>
                <p style='color:gray;font-weight:normal;width:40%'>1st - 30th " . date('F', strtotime($payslip['issue_date'])) . "</p>
                <div class='payslip-btn-container'>
                    <div class='payslip-btn'>
                        <a href='View_Payslip.php?action=download&id=$payslipId'>Download</a>
                    </div>
                    <div class='payslip-btn'>
                        <a href='View_Payslip.php?action=view&id=$payslipId' target='_blank'>View</a>
                    </div>
                </div>
            </div>
            ";
        }

        echo "</div>";
    } else {
        echo "<p>No payslips found for Staff ID: $staffId</p>";
    }
}
?>
<script>
document.addEventListener('DOMContentLoaded', function() {
    const payslipBoxes = document.querySelectorAll('.payslip-individual-box');

    payslipBoxes.forEach(box => {
        const btnContainer = box.querySelector('.payslip-btn-container');
        btnContainer.style.maxHeight = '0';
        btnContainer.style.overflow = 'hidden';
        btnContainer.style.transition = 'max-height 0.4s ease-out';

        box.addEventListener('mouseenter', () => {
            btnContainer.style.maxHeight = btnContainer.scrollHeight + 'px';
        });

        box.addEventListener('mouseleave', () => {
            btnContainer.style.maxHeight = '0';
        });
    });
});
</script>