<?php
// filepath: /C:/xampp/htdocs/pay_setup_helledition/generate pdf/download_payslip.php
require_once 'db.php'; // Database configuration
if (!isset($_GET['action']) || $_GET['action'] != 'download') {
    include 'header-pdf.php'; // Header for the site
}

// Step 3: Database Connection
$host = 'localhost';
$dbname = 'testsalary';
$username = 'root';
$password = '';
$tableName = 'payslip'; // Replace with your table name 

// Fixed staff ID
$staffId = $_GET['id']; // Replace with the actual staff 

// Establish a PDO connection
$pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

if (isset($_GET['action']) && $_GET['action'] == 'download' && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $payslipId = intval($_GET['id']);

    // Fetch the payslip from the database
    $sql = "SELECT staff_id, payslip,issue_date FROM payslip WHERE id = :id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':id', $payslipId, PDO::PARAM_INT);
    $stmt->execute();

    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($result && isset($result['payslip'])) {
        $fileContent = $result['payslip'];
        $staffID = $result['staff_id'];

        // Set headers to force download as a PDF
        header('Content-Type: application/pdf');
        header('Content-Disposition: attachment; filename="payslip_' . htmlspecialchars($staffID) . '.pdf"');
        header('Content-Length: ' . strlen($fileContent));

        // Output the file
        echo $fileContent;
        exit;
    } else {
        echo "No payslip found for the given ID.";
    }
} else {
    // Fetch all payslips for the given staff ID
    $sql = "SELECT id , issue_date FROM payslip WHERE staff_id = :staff_id";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':staff_id', $staffId, PDO::PARAM_INT);
    $stmt->execute();
    $payslips = $stmt->fetchAll(PDO::FETCH_ASSOC);

    if ($payslips) {
        echo "<h1>Your Payslips</h1>";
        echo "<style>

        h1 {
            text-align: center;
            margin-top: 20px;
        }

        h4{
        
            font-weight: normal;
        }

        .payslip-individual-box {
            background-color:rgb(255, 255, 255);
            border: 1px solid black;
            padding: 10px;
            font-size: 30px;
            text-align: center;
            margin: 20px;

            border-radius: 10px;
        }

        .payslip-container {
            display: grid;
            grid-template-columns: auto auto auto;

            padding: 10px;
        }

        .payslip-container > div {
            background-color: #ffffff;
            border: 1px solid black;
            padding: 10px;
            font-size: 30px;
            text-align: center;
        }

        .payslip-btn {
            margin: 10px;
            padding: 10px;
            background-color: #ffffff;
            border: 2px solid #102f53;
            border-radius: 10px;

            text-align: center;

            cursor: pointer;
            width: 50%;

            color:#102f53;
            transition-duration:0.4s;
        }

        .payslip-btn a {
            display: block;
            text-decoration: none;
            color: #333;
            font-weight: bold;
            width: 100%;
            height: 100%;
        }

        .payslip-btn:hover {
            background-color: #e0e0e0;
            transition-duration:0.4s;
        }

        </style>";

        echo"<div class='payslip-container'>";

        foreach ($payslips as $payslip) {
            $payslipId = $payslip['id'];
            echo "
            <div class='payslip-individual-box'>
                <h4>" . date('F Y', strtotime($payslip['issue_date'])) . " </h4>
                <button class='payslip-btn'><a href='View_Payslip.php?action=download&id=$payslipId'>Download Payslip</a></button>
            </div>";
            }
        echo "</div>";
    } else {
        echo "<p>No payslips found for Staff ID: $staffId</p>";
    }
}
?>