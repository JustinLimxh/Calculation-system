document.addEventListener('DOMContentLoaded', function() {
    const periodElement = document.getElementById('period');
    const dateElement = document.getElementById('date');
    const date = new Date();

    // Format for period (Month Year)
    const periodOptions = { year: 'numeric', month: 'long' };
    const formattedPeriodDate = date.toLocaleDateString('en-US', periodOptions);
    periodElement.value = formattedPeriodDate;

    // Format for date (dd/Mon/yyyy)
    const day = String(date.getDate()).padStart(2, '0');
    const month = date.toLocaleString('en-US', { month: 'short' });
    const year = date.getFullYear();
    const formattedDate = `${day} ${month} ${year}`;
    dateElement.value = formattedDate;
});
