<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>

        body {
            margin: 0;
            background: #ffffff;
            font-family: 'Work Sans', sans-serif;
            font-weight: 800;

            overflow-x: hidden;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            display: flex;
            /* Use flexbox */
            align-items: center;
            /* Align items vertically */
            justify-content: space-between;
            /* Space between logo and nav */
        }

        header {
            background: #ffffff;
            padding: 10px 0;
            /* Add padding for spacing */
        }

        .logo img {
            width: 80px;
            /* Set an exact width */
            height: auto;
            /* Maintain aspect ratio */
            display: block;
        }

        nav ul {
            margin: 0;
            padding: 0;
            list-style: none;
            display: flex;
            /* Use flexbox for horizontal alignment */
        }

        nav li {
            margin-left: 50px;
            /* Adjust spacing between nav items */
        }

        nav a {
            color: #444;
            text-decoration: none;
            text-transform: uppercase;
            font-size: 14px;
            font-weight: 600;
        }

        nav a:hover {
            color: #000;
        }

        nav a::before {
            content: '';
            display: block;
            height: 5px;
            background-color: #ff0000;
            position: absolute;
            top: 0;
            width: 0%;
            transition: all ease-in-out 250ms;
        }

        nav a:hover::before {
            width: 5rem;
        }
    </style>
</head>

<body>
    <header>
        <div class="container">
            <h1 class="logo">
                <img src="../assets/logo.png" alt="Logo">
            </h1>

            <nav>
                <ul>
                    <li><a href="../index.php">Home</a></li>
                    <li><a href="../add_staff.php">Add Staff</a></li>
                    <li><a href="../payslip.php">Payslip</a></li>
                    <li><a href="../generate pdf/View_Payslip.php">View Payslip</a></li>
                    <li><a href="#">Contact</a></li>
                </ul>
            </nav>
        </div>
    </header>
</body>

</html>