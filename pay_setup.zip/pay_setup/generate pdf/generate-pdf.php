<?php

// Include the database connection
include('db.php');

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

require __DIR__ . "/vendor/autoload.php";

use Dompdf\Dompdf;
use Dompdf\Options;

$staffId = $_POST['id'];

$period = $_POST['period'];
$date = $_POST['date'];

$name = $_POST["name"];
$email = $_POST['email'];

$bankNum = $_POST["bank_number"];


//$html = '<h1 style="color: green">Example</h1>';
//$html .= "Hello <em>$name</em>";
//$html .= '<img src="example.png">';
//$html .= "Quantity: $quantity";

$options = new Options;
$options->setChroot(__DIR__);
$options->setIsRemoteEnabled(true);

$dompdf = new Dompdf($options);

$dompdf->setPaper("A4", "portrait");

$html = file_get_contents("template.html");


// Replace staff info placeholders
$html = str_replace(["{{ period }}", "{{ date }}" ,"{{ name }}", "{{ email }}" ], [$period , $date ,$name, $email], $html);

$basicSalary = $_POST["basic_salary"] ;
$overtimePay = $_POST["overtime_pay"] ;

$salaryInfo = [
    "Base Salary" =>  $basicSalary,
    "Overtime Pay" => $overtimePay
];

// Check if all salary values are zero
$allSalaryZero = true;
foreach ($salaryInfo as $value) {
    if ($value != 0) {
        $allSalaryZero = false;
        break;
    }
}

// Build the salary table dynamically if not all are zero
if (!$allSalaryZero) {
    $salaryRows = "";
    foreach ($salaryInfo as $key => $value) {
        if ($value != 0) {
            $salaryRows .= "<tr><td>" . ucfirst($key) . "</td><td style='text-align:right'>" . $value . "</td></tr>";
        }
    }
    $salaryTable = "
    <table>
        <thead>
            <tr>
                <th>Earnings</th>
                <th style='text-align: right;border-bottom: 1px solid black;'>Current Period (RM)</th>
            </tr>
        </thead>
        <tbody>
            $salaryRows
        </tbody>
    </table>";
    $html = str_replace("{{ salaryTable }}", $salaryTable, $html);
} else {
    // Remove the salary table placeholder if all salary values are zero
    $html = str_replace("{{ salaryTable }}", "", $html);
}

$allowances = [
    "Attendance Allowance" => $_POST["attendance"],
    "Mobile Allowance" => $_POST["mobile"],
    "Child Care Allowance" => $_POST["childCare"],
    "Education Allowance" => $_POST["eduAllow"],
    "House Allowance" => $_POST["houseAllow"],
    "Intern Allowance" => $_POST["internAllow"],
    "Meal Allowance" => $_POST["mealAllow"],
    "Other Allowance" => $_POST["otherAllow"],
    "Parking Allowance" => $_POST["parkingAllow"],
    "Shift Allowance" => $_POST["shiftAllow"],
    "Travel Allowance (Official)" => $_POST["travelOAllow"],
    "Travel Allowance (Personnel)" => $_POST["travelPAllow"]
];

$totalAllow = $_POST["total_allowance"];

if($basicSalary == 0){
    $totalEarnings = $basicSalary + $totalAllow ;
}else{
    $totalEarnings = $basicSalary + $totalAllow + $overtimePay;
}

// Check if all allowance values are zero
$allAllowancesZero = true;
foreach ($allowances as $value) {
    if ($value != 0) {
        $allAllowancesZero = false;
        break;
    }
}

// Build the allowance table dynamically if not all are zero
if (!$allAllowancesZero) {
    $allowanceRows = "";
    foreach ($allowances as $key => $value) {
        if ($value != 0) {
            $allowanceRows .= "<tr><td>" . ucfirst($key) . "</td><td style='text-align:right'>" . $value . "</td></tr>";
        }
    }
    $allowanceTable = "

    <table>
        <thead>
            <tr>
                <!--<th>Allowance Type</th>
                <th></th>-->
            </tr>
        </thead>
        <tbody>
            $allowanceRows
            <tr>
                <td style='font-weight:bold'> Total </td>
                <td style='font-weight:bold ; text-align:right'> $totalEarnings </td>
            </tr>
        </tbody>
    </table>";
    $html = str_replace("{{ allowanceTable }}", $allowanceTable, $html);
} else {
    // Remove the allowance table placeholder if all allowances are zero
    $html = str_replace("{{ allowanceTable }}", "", $html);
}

// Replace the total allowance placeholder
$html = str_replace("{{ total_allowance }}", $totalAllow, $html);



$bik = [
    "Consume Discount" => $_POST["consumeDiscBik"],
    "Dental" => $_POST["dentalBik"],
    "Driver" => $_POST["driverBik"],
    "Fulfill Duty" => $_POST["fulfillDutiBik"],
    "Food & Drink" => $_POST["foodDrinkBik"],
    "Garment" => $_POST["garmentBik"],
    "House Electrik" => $_POST["hElectrikBik"],
    "House Entertainment" => $_POST["hEntertainBik"],
    "House Furniture" => $_POST["hFurniturBik"],
    "House Garden" => $_POST["hGardenBik"],
    "House Kitchen" => $_POST["hKitchenBik"],
    "House Servant" => $_POST["hServantBik"],
    "House Telephone" => $_POST["hTelephoneBik"],
    "House Utility" => $_POST["hUtilitiBik"],
    "Travel (Malay)" => $_POST["travelMalayBik"],
    "Travel (Overseas)" => $_POST["travelOverBik"],
    "Living Accommodation" => $_POST["liviAccoBik"],
    "Medical" => $_POST["medicalBik"],
    "Other" => $_POST["otherBik"],
    "Club Membership" => $_POST["clubMemberBik"],
    "Service Discount" => $_POST["serviceDiscBik"],
    "Transport" => $_POST["transportBik"],
    "Motorcar" => $_POST["motorcarBik"]
];

$totalBik = $_POST["total_bik"];

// Check if all BIK values are zero
$allBikZero = true;
foreach ($bik as $value) {
    if ($value != 0) {
        $allBikZero = false;
        break;
    }
}

// Build the BIK table dynamically if not all are zero
if (!$allBikZero) {
    $bikRows = "";
    foreach ($bik as $key => $value) {
        if ($value != 0) {
            $bikRows .= "<tr><td>" . ucfirst($key) . "</td><td style='text-align:right'>" . $value . "</td></tr>";
        }
    }
    $bikTable = "
    <table>
        <thead>
            <tr>
                <th>BIK Type</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            $bikRows
            <tr>
                <td style='font-weight:bold'> Total </td>
                <td style='font-weight:bold ; text-align:right'> $totalBik </td>
            </tr>
        </tbody>
    </table>";
    $html = str_replace("{{ bikTable }}", $bikTable, $html);
} else {
    // Remove the BIK table placeholder if all BIK values are zero
    $html = str_replace("{{ bikTable }}", "", $html);
}

$deductions = [
    "Advance Payment Deduction" => $_POST["advPayDeduct"],
    "Basic Supplement Deduction" => $_POST["basicSuppDeduct"],
    "CP38 Deduction" => $_POST["cp38Deduct"],
    "Dental Deduction" => $_POST["dentalDeduct"],
    "Departure Deduction" => $_POST["departureDeduct"],
    "Domestic Tourism Deduction" => $_POST["domTourisDeduct"],
    "Early Deduction" => $_POST["earlyDeduct"],
    "Education Deduction" => $_POST["eduDeduct"],
    "HRDF Deduction" => $_POST["hrdfDeduct"],
    "EPF Employee Deduction" => $_POST["epfEmployeeDeduct"],
    "EPF Employer Deduction" => $_POST["epfEmployerDeduct"],
    "EIS Employee Deduction" => $_POST["eisEmployeeDeduct"],
    "EIS Employer Deduction" => $_POST["eisEmployerDeduct"],
    "Socso Employee Deduction" => $_POST["socsoEmployeeDeduct"],
    "Socso Employer Deduction" => $_POST["socsoEmployerDeduct"],
    "EV Deduction" => $_POST["evDeduct"],
    "Father Deduction" => $_POST["fatherDeduct"],
    "Child Care Deduction" => $_POST["childCare"],
    "Higher Education Deduction" => $_POST["highEduDeduct"],
    "House Loan Deduction" => $_POST["housLoanDeduct"],
    "Insurance Deduction" => $_POST["insuranceDeduct"],
    "Life Insurance Deduction" => $_POST["lifeInsDeduct"],
    "Lifestyle Deduction" => $_POST["lifestyleDeduct"],
    "Lifestyle Computer Deduction" => $_POST["lifestyleCompDeduct"],
    "Loan Deduction" => $_POST["loanDeduct"],
    "Medical Deduction" => $_POST["medicalDeduct"],
    "Medical Parent Deduction" => $_POST["medicalParentDeduct"],
    "Medical Serious Deduction" => $_POST["medicalSeriousDeduct"],
    "Medical Treatment Deduction" => $_POST["medicalTreatDeduct"],
    "Mother Deduction" => $_POST["motherDeduct"],
    "Net SSPN Deduction" => $_POST["netSSPNDeduct"],
    "Net Salary Deduction" => $_POST["netSalaryDeduct"],
    "Former Wife Deduction" => $_POST["formerWifeDeduct"],
    "Retired Deduction" => $_POST["retiredDeduct"],
    "PTPTN Deduction" => $_POST["ptptnDeduct"],
    "Breast Deduction" => $_POST["breastDeduct"],
    "Salary Adjustment Deduction" => $_POST["salaryAdjDeduct"],
    "Sport Deduction" => $_POST["sportDeduct"],
    "Upskilling Deduction" => $_POST["upskilDeduct"],
    "Vaccine Deduction" => $_POST["vaccineDeduct"],
    "Withholding Tax Deduction" => $_POST["withTaxDeduct"],
    "PCB Deduction" => $_POST["pcb"]
];

$totalDeduction = $_POST["total_deduct"];

// Check if all deduction values are zero
$allDeductionsZero = true;
foreach ($deductions as $value) {
    if ($value != 0) {
        $allDeductionsZero = false;
        break;
    }
}

// Build the deduction table dynamically if not all are zero
if (!$allDeductionsZero) {
    $deductionRows = "";
    foreach ($deductions as $key => $value) {
        if ($value != 0) {
            if($key != "EPF Employer Deduction" && $key != "EIS Employer Deduction" && $key != "Socso Employer Deduction"){
                $deductionRows .= "<tr><td>" . ucfirst($key) . "</td><td style='text-align:right'>" . $value . "</td></tr>";
            }
        }
    }
    $deductionTable = "
    <table>
        <thead>
            <tr>
                <th>Deduction Type</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            $deductionRows
            <tr>
                <td style='font-weight:bold'> Total </td>
                <td style='font-weight:bold ; text-align:right'> $totalDeduction </td>
            </tr>
        </tbody>
    </table>";
    $html = str_replace("{{ deductionTable }}", $deductionTable, $html);
} else {
    // Remove the deduction table placeholder if all deductions are zero
    $html = str_replace("{{ deductionTable }}", "", $html);
}

$perquisites = [
    "Mobile Perk" => $_POST["mobilePerk"],
    "Car Perk" => $_POST["carPerk"],
    "Credit Card Perk" => $_POST["creditcardPerk"],
    "Voucher Perk" => $_POST["voucherPerk"],
    "House Utilities Perk" => $_POST["houseUtilsPerk"],
    "House Loan Perk" => $_POST["houseLoanPerk"],
    "Parking Perk" => $_POST["parkingPerk"],
    "Computer Perk" => $_POST["computerPerk"],
    "Professional Subscription Perk" => $_POST["proSubscriptPerk"],
    "Club Membership Perk" => $_POST["clubMemberPerk"],
    "Road Tax Perk" => $_POST["roadtaxPerk"],
    "Award Perk" => $_POST["awardPerk"],
    "Share Scheme Perk" => $_POST["shareSchemePerk"]
];

$totalPerquisites = $_POST["total_perq"];

// Check if all perquisites values are zero
$allPerquisitesZero = true;
foreach ($perquisites as $value) {
    if ($value != 0) {
        $allPerquisitesZero = false;
        break;
    }
}

// Build the perquisites table dynamically if not all are zero
if (!$allPerquisitesZero) {
    $perquisitesRows = "";
    foreach ($perquisites as $key => $value) {
        if ($value != 0) {
            $perquisitesRows .= "<tr><td>" . ucfirst($key) . "</td><td style='text-align:right'>" . $value . "</td></tr>";
        }
    }
    $perquisitesTable = "
    <table>
        <thead>
            <tr>
                <th>Perquisite Type</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            $perquisitesRows
            <tr>
                <td style='font-weight:bold'> Total </td>
                <td style='font-weight:bold ; text-align:right'> $totalPerquisites </td>
            </tr>
        </tbody>
    </table>";
    $html = str_replace("{{ perquisitesTable }}", $perquisitesTable, $html);
} else {
    // Remove the perquisites table placeholder if all perquisites are zero
    $html = str_replace("{{ perquisitesTable }}", "", $html);
}

$remuneration = [
    "Advance Payment Remuneration" => $_POST["advPayRemu"],
    "Arrears Remuneration" => $_POST["arrearsRemu"],
    "Bonus Remuneration" => $_POST["bonusRemu"],
    "Commission Remuneration" => $_POST["commissionRemu"],
    "Compensation Remuneration" => $_POST["compensationRemu"],
    "Director Remuneration" => $_POST["directorRemu"],
    "Claim Remuneration" => $_POST["claimRemu"],
    "Gratuity Remuneration" => $_POST["gratuityRemu"],
    "Incentive Remuneration" => $_POST["incentiveRemu"],
    "Leave Pay Remuneration" => $_POST["leavePayRemu"],
    "OT Normal Remuneration" => $_POST["otNormRemu"],
    "OT Public Remuneration" => $_POST["otPublicRemu"],
    "PCB Past Remuneration" => $_POST["pcbPastRemu"],
    "Profit Remuneration" => $_POST["profitRemu"],
    "Service Remuneration" => $_POST["servRemu"],
    "Severance Remuneration" => $_POST["severanceRemu"]
];

$totalRemuneration = $_POST["total_remun"];

// Check if all remuneration values are zero
$allRemunerationZero = true;
foreach ($remuneration as $value) {
    if ($value != 0) {
        $allRemunerationZero = false;
        break;
    }
}

// Build the remuneration table dynamically if not all are zero
if (!$allRemunerationZero) {
    $remunerationRows = "";
    foreach ($remuneration as $key => $value) {
        if ($value != 0) {
            $remunerationRows .= "<tr><td>" . ucfirst($key) . "</td><td style='text-align:right'>" . $value . "</td></tr>";
        }
    }
    $remunerationTable = "
    <table>
        <thead>
            <tr>
                <th>Remuneration </th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            $remunerationRows
            <tr>
                <td style='font-weight:bold'> Total </td>
                <td style='font-weight:bold ; text-align:right'> $totalRemuneration </td>
            </tr>
        </tbody>
    </table>";
    $html = str_replace("{{ remunerationTable }}", $remunerationTable, $html);
} else {
    // Remove the remuneration table placeholder if all remuneration are zero
    $html = str_replace("{{ remunerationTable }}", "", $html);
}

$employerContributions = [
    "EPF Employer Contribution" => $_POST["epfEmployerDeduct"],
    "EIS Employer Contribution" => $_POST["eisEmployerDeduct"],
    "Socso Employer Contribution" => $_POST["socsoEmployerDeduct"]
];

$totalEmployerContributions = $_POST["epfEmployerDeduct"] + $_POST["eisEmployerDeduct"] + $_POST["socsoEmployerDeduct"];

// Check if all employer contribution values are zero
$allEmployerContributionsZero = true;
foreach ($employerContributions as $value) {
    if ($value != 0) {
        $allEmployerContributionsZero = false;
        break;
    }
}

// Build the employer contribution table dynamically if not all are zero
if (!$allEmployerContributionsZero) {
    $employerContributionsRows = "";
    foreach ($employerContributions as $key => $value) {
        if ($value != 0) {
            $employerContributionsRows .= "<tr><td>" . ucfirst($key) . "</td><td style='text-align:right'>" . $value . "</td></tr>";
        }
    }
    $employerContributionsTable = "
    <table>
        <thead>
            <tr>
                <th>Employer Contribution</th>
                <th></th>
            </tr>
        </thead>
        <tbody>
            $employerContributionsRows
            <tr>
                <td style='font-weight:bold'> Total </td>
                <td style='font-weight:bold ; text-align:right'> $totalEmployerContributions </td>
            </tr>
        </tbody>
    </table>";
    $html = str_replace("{{ employerContributionsTable }}", $employerContributionsTable, $html);
} else {
    // Remove the employer contributions table placeholder if all contributions are zero
    $html = str_replace("{{ employerContributionsTable }}", "", $html);
}


$netIncome = $totalEarnings - $totalDeduction + $totalRemuneration + $totalPerquisites + $totalBik;

$html = str_replace("{{ netIncome }}", $netIncome, $html);


$dompdf->loadHtml($html);
//$dompdf->loadHtmlFile("template.html");

$dompdf->render();

$dompdf->addInfo("Title", "An Example PDF"); // "add_info" in earlier versions of Dompdf

//remove this to straight up download pdf [["Attachment" => 0]]
$dompdf->stream("invoice.pdf", ["Attachment" => 0]);

$issueDate = date('Y-m-d'); // Replace with the actual issue date
/**
 * Save the PDF file locally
 */
$output = $dompdf->output();
file_put_contents("file.pdf", $output);

// Save PDF output to a file and variable
$pdfOutput = $dompdf->output();
$filePath = "file.pdf"; // Temporary file path
file_put_contents($filePath, $pdfOutput); // Save the file temporarily

// Step 2: Read the file as binary data
$fileData = file_get_contents($filePath); // Get the binary content of the file

// Step 3: Database Connection
$host = 'localhost';
$dbname = 'testsalary';
$username = 'root';
$password = '';
$tableName = 'payslip'; // Replace with your table name

try {
    // Establish a PDO connection
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    /*
    
    Remaining below is used to check whether payslip has been repeated as :

    1. If the payslip for the staff ID and issue date already exists, update the existing row. (as payslip is only each month)
    2. If the payslip for the staff ID and issue date does not exist, insert a new row. (as new month payslip is generated)

    */

    $sql = "SELECT id FROM payslip WHERE staff_id = :staff_id AND DATE_FORMAT(issue_date, '%Y-%m') = DATE_FORMAT(:issue_date, '%Y-%m')";
    $stmt = $pdo->prepare($sql);
    $stmt->bindValue(':staff_id', $staffId, PDO::PARAM_INT);
    $stmt->bindValue(':issue_date', $issueDate, PDO::PARAM_STR);
    $stmt->execute();
    $existingRow = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($existingRow) {
        // Update the existing row
        $sql = "UPDATE payslip SET payslip = :payslip, issue_date = :issue_date WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':payslip', $pdfOutput, PDO::PARAM_STR);
        $stmt->bindValue(':issue_date', $issueDate, PDO::PARAM_STR);
        $stmt->bindValue(':id', $existingRow['id'], PDO::PARAM_INT);
        $stmt->execute();
        echo "Payslip updated successfully for Staff ID $staffId.";
    } else {
        // Insert a new row
        $sql = "INSERT INTO payslip (staff_id, payslip, issue_date) VALUES (:staff_id, :payslip, :issue_date)";
        $stmt = $pdo->prepare($sql);
        $stmt->bindValue(':staff_id', $staffId, PDO::PARAM_INT);
        $stmt->bindValue(':payslip', $pdfOutput, PDO::PARAM_STR);
        $stmt->bindValue(':issue_date', $issueDate, PDO::PARAM_STR);
        $stmt->execute();
        echo "Payslip saved successfully for Staff ID $staffId.";
    }
} catch (PDOException $e) {
    echo "Database error: " . $e->getMessage();
} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}

// Optional: Delete the temporary file
if (file_exists($filePath)) {
    unlink($filePath); // Remove the temporary file
}


?>