Install dompdf in project file:

composer require dompdf/dompdf