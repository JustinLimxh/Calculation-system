<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Staff</title>
    <style>
        body {
            margin: 0;
            background: #ffffff;
            font-family: 'Work Sans', sans-serif;
            font-weight: 800;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        header {
            background: #ffffff;
            padding: 10px 0;
        }

        .logo img {
            width: 80px;
            height: auto;
            display: block;
        }

        nav ul {
            margin: 0;
            padding: 0;
            list-style: none;
            display: flex;
        }

        nav li {
            margin-left: 50px;
        }

        nav a {
            color: #444;
            text-decoration: none;
            text-transform: uppercase;
            font-size: 14px;
            font-weight: 600;
        }

        nav a:hover {
            color: #000;
        }

        nav a::before {
            content: '';
            display: block;
            height: 5px;
            background-color: #ff0000;
            position: absolute;
            top: 0;
            width: 0%;
            transition: all ease-in-out 250ms;
        }

        nav a:hover::before {
            width: 100%;
        }

        /* Additional styling for the form */
        .form-container {
            max-width: 500px;
            /* Set a maximum width for the form */
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #333;
        }

        .form-group {
            margin-bottom: 20px;
            /* Adjusted margin for better spacing between fields */
        }

        label {
            display: block;
            font-weight: bold;
            margin-bottom: 8px;
            /* Adjusted margin for better spacing */
            padding-left: 5px;
            /* Adjusted padding for label */
        }

        input[type="text"],
        input[type="email"],
        input[type="password"] {
            width: 90%;
            /* Ensures input fields fill their container width */
            padding: 12px;
            /* Adjusted padding for input fields */
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            margin-top: 5px;
            /* Space between label and input */
        }

        input[type="submit"] {
            width: 50%;
            padding: 12px;
            /* Adjusted padding for submit button */
            background-color: #55d6aa;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
            margin: 20px auto;
            /* Centers the button by setting auto margins */
            display: block;
            /* Makes the button a block element */
        }

        input[type="submit"]:hover {
            background-color: #45b28d;
        }

        .error {
            color: red;
            font-size: 14px;
            margin-top: 5px;
        }
    </style>
</head>

<body>

    <?php include 'include/header.php'; ?>

    <div class="form-container">
        <h2>Add Staff</h2>
        <form id="addStaffForm" method="POST" action="process/process_add_staff.php">
            <div class="form-group">
                <label for="name">Name</label>
                <input type="text" id="name" name="name" required>
                <div class="error" id="nameError"></div>
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
                <div class="error" id="emailError"></div>
            </div>
            <div class="form-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
                <div class="error" id="passwordError"></div>
            </div>
            <div class="form-group">
                <label for="confirmPassword">Confirm Password</label>
                <input type="password" id="confirmPassword" name="confirmPassword" required>
                <div class="error" id="confirmPasswordError"></div>
            </div>

            <input type="submit" value="Add Staff">
        </form>
    </div>
</body>


</html>