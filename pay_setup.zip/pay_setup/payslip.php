<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff List</title>
    <style>
        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ccc;
        }

        th {
            background-color: #f4f4f4;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        h2 {
            text-align: center;
            margin-top: 20px;
        }

        .view-button {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
            text-decoration: none;
        }

        .view-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>

<body>
    <?php include 'include/header.php'; ?>

    <h2>Staff List</h2>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Include the database connection
            $conn = mysqli_connect("localhost", "root", "", "testSalary");

            if (!$conn) {
                die("Database connection failed: " . mysqli_connect_error());
            }

            // Fetch staff data
            $sql = "SELECT id, name, email FROM staff";
            $result = mysqli_query($conn, $sql);

            if (mysqli_num_rows($result) > 0) {
                while ($row = mysqli_fetch_assoc($result)) {
                    echo "<tr>
                            <td>{$row['id']}</td>
                            <td>{$row['name']}</td>
                            <td>{$row['email']}</td>
                            <td><a href='view_staff.php?id={$row['id']}' class='view-button'>View</a> 
                            <a style='background-color:purple' target='blank' href='./generate pdf/form.php?id={$row['id']}' class='view-button'>Generate Payslip</a></td>
                          </tr>";
                }
            } else {
                echo "<tr>
                        <td colspan='4' style='text-align: center;'>No staff found</td>
                      </tr>";
            }

            mysqli_close($conn);
            ?>
        </tbody>
    </table>
</body>

</html>