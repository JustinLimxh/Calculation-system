-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 07, 2025 at 09:41 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testsalary`
--
CREATE DATABASE IF NOT EXISTS `testsalary` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `testsalary`;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
-- Creation: Jan 07, 2025 at 04:16 AM
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `entity` enum('Fairwork','SPX') NOT NULL,
  `status` varchar(10) DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `admin`:
--

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `entity`, `status`) VALUES
(4, 'faker', 'faker@gmail.com', '$2y$10$FcAFYxbAnOVBVhHYXabBS.wm.sH0/SYDwmlmHv9iRX3z3jV81gA1C', 'Fairwork', 'active'),
(7, '123', '123@gmail.com', '$2y$10$YAzTaEgJbSOd9xaL.3qWiO/Ijwq4FK5ayB77hieRuDHKKK.hENky6', 'SPX', 'active'),
(8, 'satish', 'satish@gmail.com', '$2y$10$Az4EofgP/vPtDDDoTPXJF.DtpjsMx3KdKiOmtN2pAD6WpQhdTjZs6', 'Fairwork', 'active'),
(9, '2', '2@gmail.com', '$2y$10$ewvln7wG/gSs/2yo1V0lWOta4y1X9eiOVh8Nwswe.L5bwN.ncuGIi', 'SPX', 'active'),
(10, '1', '1@gmail.com', '$2y$10$PUMKHg/Boi/lAeC/qa.2SeWEPi1aM86ROQ.yh0NzyDhomiTXO6mQm', 'Fairwork', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `allowance`
--
-- Creation: Jan 07, 2025 at 05:06 AM
-- Last update: Jan 07, 2025 at 08:23 AM
--

DROP TABLE IF EXISTS `allowance`;
CREATE TABLE `allowance` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `attendance` decimal(10,2) DEFAULT 0.00,
  `mobile` decimal(10,2) DEFAULT 0.00,
  `childCare` decimal(10,2) DEFAULT 0.00,
  `eduAllow` decimal(10,2) DEFAULT 0.00,
  `houseAllow` decimal(10,2) DEFAULT 0.00,
  `internAllow` decimal(10,2) DEFAULT 0.00,
  `mealAllow` decimal(10,2) DEFAULT 0.00,
  `otherAllow` decimal(10,2) DEFAULT 0.00,
  `parkingAllow` decimal(10,2) DEFAULT 0.00,
  `shiftAllow` decimal(10,2) DEFAULT 0.00,
  `travelOAllow` decimal(10,2) DEFAULT 0.00,
  `travelPAllow` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `allowance`:
--   `staff_id`
--       `staff` -> `id`
--

--
-- Dumping data for table `allowance`
--

INSERT INTO `allowance` (`id`, `staff_id`, `attendance`, `mobile`, `childCare`, `eduAllow`, `houseAllow`, `internAllow`, `mealAllow`, `otherAllow`, `parkingAllow`, `shiftAllow`, `travelOAllow`, `travelPAllow`, `created_at`, `updated_at`) VALUES
(1, 3, '222.00', '0.00', '1000.00', '7777.00', '10000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2025-01-07 05:04:43', '2025-01-07 05:49:01'),
(10, 49, '0.00', '1000.00', '100.00', '0.00', '1000.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2025-01-07 05:24:37', '2025-01-07 05:41:26'),
(12, 52, '200.00', '100.00', '0.00', '12345.00', '0.00', '999.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '2025-01-07 06:14:33', '2025-01-07 06:28:39'),
(13, 6, '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '0.00', '100.00', '0.00', '0.00', '0.00', '0.00', '2025-01-07 08:23:21', '2025-01-07 08:23:21');

-- --------------------------------------------------------

--
-- Table structure for table `benefit`
--
-- Creation: Jan 07, 2025 at 04:25 AM
--

DROP TABLE IF EXISTS `benefit`;
CREATE TABLE `benefit` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `consumeDiscBik` decimal(10,2) DEFAULT 0.00,
  `dentalBik` decimal(10,2) DEFAULT 0.00,
  `driverBik` decimal(10,2) DEFAULT 0.00,
  `fulfillDutiBik` decimal(10,2) DEFAULT 0.00,
  `foodDrinkBik` decimal(10,2) DEFAULT 0.00,
  `garmentBik` decimal(10,2) DEFAULT 0.00,
  `hElectrikBik` decimal(10,2) DEFAULT 0.00,
  `hEntertainBik` decimal(10,2) DEFAULT 0.00,
  `hFurniturBik` decimal(10,2) DEFAULT 0.00,
  `hGardenBik` decimal(10,2) DEFAULT 0.00,
  `hKitchenBik` decimal(10,2) DEFAULT 0.00,
  `hServantBik` decimal(10,2) DEFAULT 0.00,
  `hTelephoneBik` decimal(10,2) DEFAULT 0.00,
  `hUtilitiBik` decimal(10,2) DEFAULT 0.00,
  `travelMalayBik` decimal(10,2) DEFAULT 0.00,
  `travelOverBik` decimal(10,2) DEFAULT 0.00,
  `liviAccoBik` decimal(10,2) DEFAULT 0.00,
  `medicalBik` decimal(10,2) DEFAULT 0.00,
  `otherBik` decimal(10,2) DEFAULT 0.00,
  `clubMemberBik` decimal(10,2) DEFAULT 0.00,
  `serviceDiscBik` decimal(10,2) DEFAULT 0.00,
  `transportBik` decimal(10,2) DEFAULT 0.00,
  `motorcarBik` decimal(10,2) DEFAULT 0.00,
  `workAccidentBik` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `benefit`:
--   `staff_id`
--       `staff` -> `id`
--

-- --------------------------------------------------------

--
-- Table structure for table `deduction`
--
-- Creation: Jan 07, 2025 at 04:16 AM
-- Last update: Jan 07, 2025 at 06:29 AM
--

DROP TABLE IF EXISTS `deduction`;
CREATE TABLE `deduction` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `advPayDeduct` decimal(10,2) DEFAULT 0.00,
  `basicSuppDeduct` decimal(10,2) DEFAULT 0.00,
  `cp38Deduct` decimal(10,2) DEFAULT 0.00,
  `dentalDeduct` decimal(10,2) DEFAULT 0.00,
  `departureDeduct` decimal(10,2) DEFAULT 0.00,
  `domTourisDeduct` decimal(10,2) DEFAULT 0.00,
  `earlyDeduct` decimal(10,2) DEFAULT 0.00,
  `eduDeduct` decimal(10,2) DEFAULT 0.00,
  `hrdfDeduct` decimal(10,2) DEFAULT 0.00,
  `epfEmployeeDeduct` decimal(10,2) DEFAULT 0.00,
  `epfEmployerDeduct` decimal(10,2) DEFAULT 0.00,
  `evDeduct` decimal(10,2) DEFAULT 0.00,
  `fatherDeduct` decimal(10,2) DEFAULT 0.00,
  `childCare` decimal(10,2) DEFAULT 0.00,
  `highEduDeduct` decimal(10,2) DEFAULT 0.00,
  `housLoanDeduct` decimal(10,2) DEFAULT 0.00,
  `insuranceDeduct` decimal(10,2) DEFAULT 0.00,
  `lifeInsDeduct` decimal(10,2) DEFAULT 0.00,
  `lifestyleDeduct` decimal(10,2) DEFAULT 0.00,
  `lifestyleCompDeduct` decimal(10,2) DEFAULT 0.00,
  `loanDeduct` decimal(10,2) DEFAULT 0.00,
  `medicalDeduct` decimal(10,2) DEFAULT 0.00,
  `medicalParentDeduct` decimal(10,2) DEFAULT 0.00,
  `medicalSeriousDeduct` decimal(10,2) DEFAULT 0.00,
  `medicalTreatDeduct` decimal(10,2) DEFAULT 0.00,
  `motherDeduct` decimal(10,2) DEFAULT 0.00,
  `netSSPNDeduct` decimal(10,2) DEFAULT 0.00,
  `netSalaryDeduct` decimal(10,2) DEFAULT 0.00,
  `formerWifeDeduct` decimal(10,2) DEFAULT 0.00,
  `retiredDeduct` decimal(10,2) DEFAULT 0.00,
  `ptptnDeduct` decimal(10,2) DEFAULT 0.00,
  `breastDeduct` decimal(10,2) DEFAULT 0.00,
  `salaryAdjDeduct` decimal(10,2) DEFAULT 0.00,
  `sportDeduct` decimal(10,2) DEFAULT 0.00,
  `upskilDeduct` decimal(10,2) DEFAULT 0.00,
  `vaccineDeduct` decimal(10,2) DEFAULT 0.00,
  `withTaxDeduct` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `deduction`:
--   `staff_id`
--       `staff` -> `id`
--

-- --------------------------------------------------------

--
-- Table structure for table `parties`
--
-- Creation: Jan 07, 2025 at 04:16 AM
--

DROP TABLE IF EXISTS `parties`;
CREATE TABLE `parties` (
  `id` int(11) NOT NULL,
  `party_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `parties`:
--

--
-- Dumping data for table `parties`
--

INSERT INTO `parties` (`id`, `party_name`) VALUES
(1, 'internal'),
(2, 'SPX'),
(6, 'shopee'),
(7, 'CIMB');

-- --------------------------------------------------------

--
-- Table structure for table `perquisites`
--
-- Creation: Jan 07, 2025 at 04:16 AM
-- Last update: Jan 07, 2025 at 06:29 AM
--

DROP TABLE IF EXISTS `perquisites`;
CREATE TABLE `perquisites` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `mobilePerk` decimal(10,2) DEFAULT 0.00,
  `carPerk` decimal(10,2) DEFAULT 0.00,
  `creditcardPerk` decimal(10,2) DEFAULT 0.00,
  `voucherPerk` decimal(10,2) DEFAULT 0.00,
  `houseUtilsPerk` decimal(10,2) DEFAULT 0.00,
  `houseLoanPerk` decimal(10,2) DEFAULT 0.00,
  `parkingPerk` decimal(10,2) DEFAULT 0.00,
  `computerPerk` decimal(10,2) DEFAULT 0.00,
  `proSubscriptPerk` decimal(10,2) DEFAULT 0.00,
  `clubMemberPerk` decimal(10,2) DEFAULT 0.00,
  `roadtaxPerk` decimal(10,2) DEFAULT 0.00,
  `awardPerk` decimal(10,2) DEFAULT 0.00,
  `shareSchemePerk` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `perquisites`:
--   `staff_id`
--       `staff` -> `id`
--

-- --------------------------------------------------------

--
-- Table structure for table `remuneration`
--
-- Creation: Jan 07, 2025 at 04:16 AM
-- Last update: Jan 07, 2025 at 06:29 AM
--

DROP TABLE IF EXISTS `remuneration`;
CREATE TABLE `remuneration` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `advPayRemu` decimal(10,2) DEFAULT 0.00,
  `arrearsRemu` decimal(10,2) DEFAULT 0.00,
  `bonusRemu` decimal(10,2) DEFAULT 0.00,
  `commissionRemu` decimal(10,2) DEFAULT 0.00,
  `compensationRemu` decimal(10,2) DEFAULT 0.00,
  `directorRemu` decimal(10,2) DEFAULT 0.00,
  `claimRemu` decimal(10,2) DEFAULT 0.00,
  `gratuityRemu` decimal(10,2) DEFAULT 0.00,
  `incentiveRemu` decimal(10,2) DEFAULT 0.00,
  `leavePayRemu` decimal(10,2) DEFAULT 0.00,
  `otNormRemu` decimal(10,2) DEFAULT 0.00,
  `otOffRemu` decimal(10,2) DEFAULT 0.00,
  `otPublicRemu` decimal(10,2) DEFAULT 0.00,
  `pcbPastRemu` decimal(10,2) DEFAULT 0.00,
  `profitRemu` decimal(10,2) DEFAULT 0.00,
  `servRemu` decimal(10,2) DEFAULT 0.00,
  `severanceRemu` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `remuneration`:
--   `staff_id`
--       `staff` -> `id`
--

-- --------------------------------------------------------

--
-- Table structure for table `salary`
--
-- Creation: Jan 07, 2025 at 04:32 AM
-- Last update: Jan 07, 2025 at 07:59 AM
--

DROP TABLE IF EXISTS `salary`;
CREATE TABLE `salary` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `basic_salary` int(11) NOT NULL,
  `bank_type` varchar(50) NOT NULL,
  `bank_number` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `salary`:
--   `staff_id`
--       `staff` -> `id`
--

--
-- Dumping data for table `salary`
--

INSERT INTO `salary` (`id`, `staff_id`, `basic_salary`, `bank_type`, `bank_number`) VALUES
(3, 2, 12345, 'Bank Islam', 2),
(4, 49, 2314, 'Bank Islam', 972314),
(5, 52, 21324, 'Public Bank', 6),
(6, 3, 233132313, 'Malayan Banking', 2147483647);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--
-- Creation: Jan 07, 2025 at 04:16 AM
--

DROP TABLE IF EXISTS `staff`;
CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `entity` varchar(255) NOT NULL,
  `parties` varchar(255) NOT NULL DEFAULT 'internal'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `staff`:
--

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`id`, `name`, `email`, `password`, `entity`, `parties`) VALUES
(2, 'satish ', 'satish@gmail.com', '$2y$10$XmSlFF7VLZt/Lv059iwX8OpUSeRH4ikNk99l/SBRTfl80j6YfkidK', 'Fairwork', 'internal'),
(3, '2', '2@gmail.com', '$2y$10$z49.LIWhulGudmb56JKSqex799cWhM25VqPP1T3N1EZLTUbhsiLYm', 'SPX', 'internal'),
(6, '22', '22@gmail.com', '$2y$10$4mfTE82F1uap0uSrxexD0.1lsgzh84dcPPTVe7C.ZIw.PJMsJ6ty2', 'SPX', 'internal'),
(7, 'faker', 'faker@gmail.com', '$2y$10$OZ9IGLEYjfyBQZeJAI0B1OHnzf2B2zYhta2cyBAiuyiPoG9qKOMEy', 'Fairwork', 'internal'),
(46, 'qwerty', ' syah@gmail.com', '$2y$10$jue8ZOUEsNd8bSi8HZog8u4ewlGp9gtoW9CUwbN/KoaiZzn7uaJrq', 'SPX', 'internal'),
(47, 'q', 'q@gmail.com', '$2y$10$aSGYQeEIR7AsxObqBZ0ose83LUVvchAATPLqDDLEisevVKZCL7A.e', 'Fairwork', 'internal'),
(48, 'w', 'w@gmail.com', '$2y$10$kp4Hal8vQPPxcLwrC68nb.YIt7SDnQJnswKIjWeNL.pwvt.lApEQi', 'SPX', 'internal'),
(49, 'e', 'e@gmail.com', '$2y$10$0ZAuvWbspHBFIHIj9pSQlu5oAj8SNJeb7LzQrlUTV7eGBQrByLo.u', 'SPX', 'internal'),
(50, 'r', 'r@gmail.com', '$2y$10$b2IJYzIuKzxbzsqQRurlgeAOzIQGdzrYh1.y9s/aOsiC0HWuVqSF2', 'Fairwork', 'internal'),
(51, 't', 't@gmail.com', '$2y$10$freqBKFsfdgZUZzs.qDE0.6sqfGZOUQPRUaE1ZqjqiF8hruDdkREe', 'SPX', 'internal'),
(52, 'qwe', 'qwe@gmail.com', '$2y$10$Vkq44P0wPxtSybjLtHKHIeNJetI9ihXqyKvhAQjDElq21K2mqnJR2', 'Fairwork', 'shopee');

-- --------------------------------------------------------

--
-- Table structure for table `super_admin`
--
-- Creation: Jan 07, 2025 at 04:16 AM
--

DROP TABLE IF EXISTS `super_admin`;
CREATE TABLE `super_admin` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- RELATIONSHIPS FOR TABLE `super_admin`:
--

--
-- Dumping data for table `super_admin`
--

INSERT INTO `super_admin` (`id`, `email`, `password`) VALUES
(1, 'lim@gmail.com', '$2y$10$7CrwrZu0LCSrShyxShpbNOWhOUPsu.sGIRX6uSqEFc8u3BLKtuFx2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `allowance`
--
ALTER TABLE `allowance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_staff_id_allowance` (`staff_id`);

--
-- Indexes for table `benefit`
--
ALTER TABLE `benefit`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_staff_id_benefits` (`staff_id`);

--
-- Indexes for table `deduction`
--
ALTER TABLE `deduction`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_staff_id_deduction` (`staff_id`);

--
-- Indexes for table `parties`
--
ALTER TABLE `parties`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `perquisites`
--
ALTER TABLE `perquisites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_staff_id_prereq` (`staff_id`);

--
-- Indexes for table `remuneration`
--
ALTER TABLE `remuneration`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_staff_id_renumeration` (`staff_id`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_staff_id_salary` (`staff_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `super_admin`
--
ALTER TABLE `super_admin`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `allowance`
--
ALTER TABLE `allowance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `benefit`
--
ALTER TABLE `benefit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `deduction`
--
ALTER TABLE `deduction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `parties`
--
ALTER TABLE `parties`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `perquisites`
--
ALTER TABLE `perquisites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `remuneration`
--
ALTER TABLE `remuneration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `salary`
--
ALTER TABLE `salary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;

--
-- AUTO_INCREMENT for table `super_admin`
--
ALTER TABLE `super_admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `allowance`
--
ALTER TABLE `allowance`
  ADD CONSTRAINT `fk_staff_id_allowance` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `benefit`
--
ALTER TABLE `benefit`
  ADD CONSTRAINT `fk_staff_id_benefits` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `deduction`
--
ALTER TABLE `deduction`
  ADD CONSTRAINT `fk_staff_id_deduction` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `perquisites`
--
ALTER TABLE `perquisites`
  ADD CONSTRAINT `fk_staff_id_prereq` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `remuneration`
--
ALTER TABLE `remuneration`
  ADD CONSTRAINT `fk_staff_id_renumeration` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `salary`
--
ALTER TABLE `salary`
  ADD CONSTRAINT `fk_staff_id_salary` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
