-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 26, 2024 at 01:19 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `testsalary`
--

-- --------------------------------------------------------

--
-- Table structure for table `allowance`
--

CREATE TABLE `allowance` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `attendance` decimal(10,2) DEFAULT 0.00,
  `mobile` decimal(10,2) DEFAULT 0.00,
  `childCare` decimal(10,2) DEFAULT 0.00,
  `eduAllow` decimal(10,2) DEFAULT 0.00,
  `houseAllow` decimal(10,2) DEFAULT 0.00,
  `internAllow` decimal(10,2) DEFAULT 0.00,
  `mealAllow` decimal(10,2) DEFAULT 0.00,
  `otherAllow` decimal(10,2) DEFAULT 0.00,
  `parkingAllow` decimal(10,2) DEFAULT 0.00,
  `shiftAllow` decimal(10,2) DEFAULT 0.00,
  `travelOAllow` decimal(10,2) DEFAULT 0.00,
  `travelPAllow` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- --------------------------------------------------------

--
-- Table structure for table `benefit`
--

CREATE TABLE `benefit` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `consumeDiscBik` decimal(10,2) DEFAULT 0.00,
  `dentalBik` decimal(10,2) DEFAULT 0.00,
  `driverBik` decimal(10,2) DEFAULT 0.00,
  `fulfillDutiBik` decimal(10,2) DEFAULT 0.00,
  `foodDrinkBik` decimal(10,2) DEFAULT 0.00,
  `garmentBik` decimal(10,2) DEFAULT 0.00,
  `hElectrikBik` decimal(10,2) DEFAULT 0.00,
  `hEntertainBik` decimal(10,2) DEFAULT 0.00,
  `hFurniturBik` decimal(10,2) DEFAULT 0.00,
  `hGardenBik` decimal(10,2) DEFAULT 0.00,
  `hKitchenBik` decimal(10,2) DEFAULT 0.00,
  `hServantBik` decimal(10,2) DEFAULT 0.00,
  `hTelephoneBik` decimal(10,2) DEFAULT 0.00,
  `hUtilitiBik` decimal(10,2) DEFAULT 0.00,
  `travelMalayBik` decimal(10,2) DEFAULT 0.00,
  `travelOverBik` decimal(10,2) DEFAULT 0.00,
  `liviAccoBik` decimal(10,2) DEFAULT 0.00,
  `medicalBik` decimal(10,2) DEFAULT 0.00,
  `otherBik` decimal(10,2) DEFAULT 0.00,
  `clubMemberBik` decimal(10,2) DEFAULT 0.00,
  `serviceDiscBik` decimal(10,2) DEFAULT 0.00,
  `treansportBik` decimal(10,2) DEFAULT 0.00,
  `motorcarBik` decimal(10,2) DEFAULT 0.00,
  `workAccidentBik` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;


-- --------------------------------------------------------

--
-- Table structure for table `deduction`
--

CREATE TABLE `deduction` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `advPayDeduct` decimal(10,2) DEFAULT 0.00,
  `basicSuppDeduct` decimal(10,2) DEFAULT 0.00,
  `cp38Deduct` decimal(10,2) DEFAULT 0.00,
  `dentalDeduct` decimal(10,2) DEFAULT 0.00,
  `departureDeduct` decimal(10,2) DEFAULT 0.00,
  `domTourisDeduct` decimal(10,2) DEFAULT 0.00,
  `earlyDeduct` decimal(10,2) DEFAULT 0.00,
  `eduDeduct` decimal(10,2) DEFAULT 0.00,
  `hrdfDeduct` decimal(10,2) DEFAULT 0.00,
  `epfEmployeeDeduct` decimal(10,2) DEFAULT 0.00,
  `epfEmployerDeduct` decimal(10,2) DEFAULT 0.00,
  `evDeduct` decimal(10,2) DEFAULT 0.00,
  `fatherDeduct` decimal(10,2) DEFAULT 0.00,
  `childCare` decimal(10,2) DEFAULT 0.00,
  `highEduDeduct` decimal(10,2) DEFAULT 0.00,
  `housLoanDeduct` decimal(10,2) DEFAULT 0.00,
  `insuranceDeduct` decimal(10,2) DEFAULT 0.00,
  `lifeInsDeduct` decimal(10,2) DEFAULT 0.00,
  `lifestyleDeduct` decimal(10,2) DEFAULT 0.00,
  `lifestyleCompDeduct` decimal(10,2) DEFAULT 0.00,
  `loanDeduct` decimal(10,2) DEFAULT 0.00,
  `medicalDeduct` decimal(10,2) DEFAULT 0.00,
  `medicalParentDeduct` decimal(10,2) DEFAULT 0.00,
  `medicalSeriousDeduct` decimal(10,2) DEFAULT 0.00,
  `medicalTreatDeduct` decimal(10,2) DEFAULT 0.00,
  `motherDeduct` decimal(10,2) DEFAULT 0.00,
  `netSSPNDeduct` decimal(10,2) DEFAULT 0.00,
  `netSalaryDeduct` decimal(10,2) DEFAULT 0.00,
  `formerWifeDeduct` decimal(10,2) DEFAULT 0.00,
  `retiredDeduct` decimal(10,2) DEFAULT 0.00,
  `ptptnDeduct` decimal(10,2) DEFAULT 0.00,
  `breastDeduct` decimal(10,2) DEFAULT 0.00,
  `salaryAdjDeduct` decimal(10,2) DEFAULT 0.00,
  `sportDeduct` decimal(10,2) DEFAULT 0.00,
  `upskilDeduct` decimal(10,2) DEFAULT 0.00,
  `vaccineDeduct` decimal(10,2) DEFAULT 0.00,
  `withTaxDeduct` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- --------------------------------------------------------

--
-- Table structure for table `perquisites`
--

CREATE TABLE `perquisites` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `mobilePerk` decimal(10,2) DEFAULT 0.00,
  `carPerk` decimal(10,2) DEFAULT 0.00,
  `creditcardPerk` decimal(10,2) DEFAULT 0.00,
  `voucherPerk` decimal(10,2) DEFAULT 0.00,
  `houseUtilsPerk` decimal(10,2) DEFAULT 0.00,
  `houseLoanPerk` decimal(10,2) DEFAULT 0.00,
  `parkingPerk` decimal(10,2) DEFAULT 0.00,
  `computerPerk` decimal(10,2) DEFAULT 0.00,
  `proSubscriptPerk` decimal(10,2) DEFAULT 0.00,
  `clubMemberPerk` decimal(10,2) DEFAULT 0.00,
  `roadtaxPerk` decimal(10,2) DEFAULT 0.00,
  `awardPerk` decimal(10,2) DEFAULT 0.00,
  `shareSchemePerk` decimal(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- --------------------------------------------------------

--
-- Table structure for table `remuneration`
--

CREATE TABLE `remuneration` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `advPayRemu` decimal(10,2) DEFAULT 0.00,
  `arrearsRemu` decimal(10,2) DEFAULT 0.00,
  `bonusRemu` decimal(10,2) DEFAULT 0.00,
  `commissionRemu` decimal(10,2) DEFAULT 0.00,
  `compensationRemu` decimal(10,2) DEFAULT 0.00,
  `directorRemu` decimal(10,2) DEFAULT 0.00,
  `claimRemu` decimal(10,2) DEFAULT 0.00,
  `gratuityRemu` decimal(10,2) DEFAULT 0.00,
  `incentiveRemu` decimal(10,2) DEFAULT 0.00,
  `leavePayRemu` decimal(10,2) DEFAULT 0.00,
  `otNormRemu` decimal(10,2) DEFAULT 0.00,
  `otOffRemu` decimal(10,2) DEFAULT 0.00,
  `otPublicRemu` decimal(10,2) DEFAULT 0.00,
  `pcbPastRemu` decimal(10,2) DEFAULT 0.00,
  `profitRemu` decimal(10,2) DEFAULT 0.00,
  `servRemu` decimal(10,2) DEFAULT 0.00,
  `severanceRemu` decimal(10,2) DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



-- --------------------------------------------------------

--
-- Table structure for table `salary`
--

CREATE TABLE `salary` (
  `id` int(11) NOT NULL,
  `staff_id` int(11) NOT NULL,
  `bank_type` varchar(50) NOT NULL,
  `bank_number` varchar(50) NOT NULL,
  `basic_salary` decimal(10,2) NOT NULL
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



--
-- Indexes for dumped tables
--

--
-- Indexes for table `allowance`
--
ALTER TABLE `allowance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_id` (`staff_id`);

--
-- Indexes for table `benefit`
--
ALTER TABLE `benefit`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_id` (`staff_id`);

--
-- Indexes for table `deduction`
--
ALTER TABLE `deduction`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_id` (`staff_id`);

--
-- Indexes for table `perquisites`
--
ALTER TABLE `perquisites`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_id` (`staff_id`);

--
-- Indexes for table `remuneration`
--
ALTER TABLE `remuneration`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_id` (`staff_id`);

--
-- Indexes for table `salary`
--
ALTER TABLE `salary`
  ADD PRIMARY KEY (`id`),
  ADD KEY `staff_id` (`staff_id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `allowance`
--
ALTER TABLE `allowance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `benefit`
--
ALTER TABLE `benefit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `deduction`
--
ALTER TABLE `deduction`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `perquisites`
--
ALTER TABLE `perquisites`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `remuneration`
--
ALTER TABLE `remuneration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `salary`
--
ALTER TABLE `salary`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `staff`
--
ALTER TABLE `staff`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `allowance`
--
ALTER TABLE `allowance`
  ADD CONSTRAINT `allowance_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `benefit`
--
ALTER TABLE `benefit`
  ADD CONSTRAINT `benefit_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `deduction`
--
ALTER TABLE `deduction`
  ADD CONSTRAINT `deduction_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `perquisites`
--
ALTER TABLE `perquisites`
  ADD CONSTRAINT `perquisites_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `remuneration`
--
ALTER TABLE `remuneration`
  ADD CONSTRAINT `remuneration_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `salary`
--
ALTER TABLE `salary`
  ADD CONSTRAINT `salary_ibfk_1` FOREIGN KEY (`staff_id`) REFERENCES `staff` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
