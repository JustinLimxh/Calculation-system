<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Details</title>
    <link rel="stylesheet" href="css/modals.css">

</head>

<body>
    <style>
        .wrapper{
            display: flex;
            justify-content: center;
            
            margin:10%;
            margin-top: 0%;
        }

        /* width */
        ::-webkit-scrollbar {
            width: 8px;
            height: 5px;
        }

        /* Track */
        ::-webkit-scrollbar-track {
            background: transparent;
            box-shadow: inset 0 0 100px #dddddd;
            border-radius: 4px;
            border-left: 1.5px solid transparent;
            border-right: 1.5px solid transparent;
        }

        /* Handle */
        ::-webkit-scrollbar-thumb {
            background:rgb(107, 107, 107);
            border-radius: 4px;
        }
    </style>

    <?php include 'include/header.php'; ?>

    <div class = "wrapper">
    <!-- Staff Details Container -->
    <div class = "staff-summary">
    <div class="staff-details-container">
        <?php
        // Include database connection
        $conn = mysqli_connect("localhost", "root", "", "testSalary");

        if (!$conn) {
            die("Database connection failed: " . mysqli_connect_error());
        }

        // Initialize variables
        $totalAccountedEPF = 0;
        $employeeEPF = 0;
        $employerEPF = 0;

        $totalAccountedEIS = 0;
        $employeeEIS = 0;
        $employerEIS = 0;

        $totalAccountedSocso = 0;
        $employeeSocso = 0;
        $employerSocso = 0;

        $totalBik = 0 ;
        $totalSalary = 0;
        $benefitsTotal = 0;
        $allowancesTotal = 0;
        $deductionsTotal = 0;
        $remunerationTotal = 0;
        $perquisitesTotal = 0;

        // Function to ensure numeric values
        function getNumericAmount($amount)
        {
            return is_numeric($amount) ? floatval($amount) : 0;
        }

        // Fetch staff details
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']); // Make sure ID is an integer

            // Fetch staff details using prepared statements
            $sql = "SELECT * FROM staff WHERE id = ?";
            if ($stmt = $conn->prepare($sql)) {
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($row = $result->fetch_assoc()) {
                    echo "<span class='reload' onclick='submitForms(); location.reload()'> &#x21bb; all</span>";

                    echo "
                    <script>
                        function submitForms() {
                            var forms = ['epfForm', 'eisForm', 'socsoForm'];
                            forms.forEach(function(formId) {
                                var form = document.getElementById(formId);
                                var formData = new FormData(form);
                                var xhr = new XMLHttpRequest();
                                xhr.open('POST', form.action, true);
                                xhr.onload = function () {
                                    if (xhr.status === 200) {
                                        console.log(formId + ' submitted successfully');
                                    } else {
                                        console.error('Error submitting ' + formId);
                                    }
                                };
                                xhr.send(formData);
                            });
                        }

                        window.onload = function() {
                            submitForms();
                        };
                    </script>
                    ";

                    echo "<h2>Staff Details</h2>";
                    echo "<p>Name: " . htmlspecialchars($row['name']) . "</p>";
                    echo "<p>Email: " . htmlspecialchars($row['email']) . "</p>";

                    // Fetch the current salary for the staff member
                    $sql_salary = "SELECT * FROM salary WHERE staff_id = ?";
                    if ($stmt_salary = $conn->prepare($sql_salary)) {
                        $stmt_salary->bind_param("i", $id);
                        $stmt_salary->execute();
                        $result_salary = $stmt_salary->get_result();

                        if ($salary_row = $result_salary->fetch_assoc()) {
                            $current_salary = $salary_row['basic_salary'];
                            // Add base salary to total salary
                            $totalSalary += getNumericAmount($current_salary);
                            echo "<p>Base Salary: RM " . htmlspecialchars($current_salary) . "</p>";
                        } else {
                            $current_salary = "Not available";
                            echo "<p>Base Salary: Not available</p>";
                        }
                    }

                    $query_staff_bio = "SELECT * FROM staff_bio WHERE staff_id = ?";
                    if ($stmt_bio = $conn->prepare($query_staff_bio)) {
                        $stmt_bio->bind_param("i", $id);
                        $stmt_bio->execute();
                        $result_bio = $stmt_bio->get_result();

                        if ($bio_row = $result_bio->fetch_assoc()) {
                            foreach ($bio_row as $key => $value) {
                                if ($value > 0 && $key !== 'staff_id' && $key !== 'id') { 
                                    echo "<p>" . ucfirst(str_replace('_', ' ', $key)) . ": " . htmlspecialchars($value) . "</p>";
                                }
                            }
                        } else {
                            echo "<p>No bio details available for this staff.</p>";
                        }
                        $stmt_bio->close();
                    }

                    // Fetch Benefits
                    $query_benefits = "SELECT * FROM benefit WHERE staff_id = ?";
                    if ($stmt_benefits = $conn->prepare($query_benefits)) {
                        $stmt_benefits->bind_param("i", $id);
                        $stmt_benefits->execute();
                        $result_benefits = $stmt_benefits->get_result();
                        while ($benefit = $result_benefits->fetch_assoc()) {
                            foreach ($benefit as $benefit_type => $amount) {
                                if ($benefit_type !== 'staff_id') {
                                    $benefitsTotal += getNumericAmount($amount);
                                }
                            }
                        }
                    }

                    //$grossIncome = $current_salary ;

                    // Fetch Allowances
                    $query_allowances = "SELECT * FROM allowance WHERE staff_id = ?";
                    if ($stmt_allowances = $conn->prepare($query_allowances)) {
                        $stmt_allowances->bind_param("i", $id);
                        $stmt_allowances->execute();
                        $result_allowances = $stmt_allowances->get_result();
                        while ($allowance = $result_allowances->fetch_assoc()) {
                            foreach ($allowance as $allowance_type => $amount) {
                                if ($allowance_type !== 'staff_id' && $allowance_type !== 'id') {

                                    /*if($allowance_type== 'internAllow'){
                                        $grossIncome += getNumericAmount($amount);
                                    }*/

                                    $allowancesTotal += getNumericAmount($amount);

                                    if($allowance_type !== 'travelOAllow' && $allowance_type !== 'travelPAllow' ){
                                        $totalAccountedEPF += getNumericAmount($amount);
                                        $totalAccountedEIS += getNumericAmount($amount);
                                }
                            }
                            }
                        }
                    }

                    // Fetch Deductions
                    $query_deductions = "SELECT * FROM deduction WHERE staff_id = ?";
                    if ($stmt_deductions = $conn->prepare($query_deductions)) {
                        $stmt_deductions->bind_param("i", $id);
                        $stmt_deductions->execute();
                        $result_deductions = $stmt_deductions->get_result();
                        while ($deduction = $result_deductions->fetch_assoc()) {
                            foreach ($deduction as $deduction_type => $amount) {
                                if ($deduction_type !== 'staff_id') {
                                    $deductionsTotal += getNumericAmount($amount);

                                    if($deduction_type == 'epfEmployeeDeduct'){
                                        $employeeEPF += getNumericAmount($amount);
                                    }

                                    if($deduction_type == 'epfEmployerDeduct'){
                                        $employerEPF += getNumericAmount($amount);
                                    }

                                    if($deduction_type == 'eisEmployeeDeduct'){
                                        $employeeEIS += getNumericAmount($amount);
                                    }

                                    if($deduction_type == 'eisEmployerDeduct'){
                                        $employerEIS += getNumericAmount($amount);
                                    }

                                    if($deduction_type == 'socsoEmployeeDeduct'){
                                        $employeeSocso += getNumericAmount($amount);
                                    }

                                    if($deduction_type == 'socsoEmployerDeduct'){
                                        $employerSocso += getNumericAmount($amount);
                                    }
                                
                            }
                        }
                        }
                    }

                    // Fetch Remuneration
                    $query_remuneration = "SELECT * FROM remuneration WHERE staff_id = ?";
                    if ($stmt_remuneration = $conn->prepare($query_remuneration)) {
                        $stmt_remuneration->bind_param("i", $id);
                        $stmt_remuneration->execute();
                        $result_remuneration = $stmt_remuneration->get_result();
                        while ($remuneration = $result_remuneration->fetch_assoc()) {
                            foreach ($remuneration as $remuneration_type => $amount) {
                                if ($remuneration_type !== 'staff_id') {
                                    $remunerationTotal += getNumericAmount($amount);
                                    if($remuneration_type == 'commisionRemu' || $remuneration_type == 'bonusRemu' || $remuneration_type == 'incentiveRemu'|| $remuneration_type == 'arrearsRemu'){
                                        $totalAccountedEPF += getNumericAmount($amount);
                                    }

                                    if( $remuneration_type == 'bonusRemu' || $remuneration_type = 'gratuityRemu'){
                                        $totalAccountedEIS += getNumericAmount($amount);
                                }}
                            }
                        }
                    }

                    // Fetch Perquisites
                    $query_perquisites = "SELECT * FROM perquisites WHERE staff_id = ?";
                    if ($stmt_perquisites = $conn->prepare($query_perquisites)) {
                        $stmt_perquisites->bind_param("i", $id);
                        $stmt_perquisites->execute();
                        $result_perquisites = $stmt_perquisites->get_result();
                        while ($perquisite = $result_perquisites->fetch_assoc()) {
                            foreach ($perquisite as $perk_type => $amount) {
                                if ($perk_type !== 'staff_id') {
                                    $perquisitesTotal += getNumericAmount($amount);
                                }
                            }
                        }
                    }

                    // Calculate and display total salary
                    //$totalSalary += $benefitsTotal + $allowancesTotal + $remunerationTotal + $perquisitesTotal - $deductionsTotal;
                    
                    echo "
                    </div>
                    <div class='staff-details-container'>";

                    echo "<h3>Total Breakdown</h3>";
                    //echo "<p>Total Salary: RM " . htmlspecialchars($totalSalary) . "</p>";

                    $sqlOT = "SELECT normal_hours , rest_hours , holiday_hours , overtime_pay FROM overtime WHERE staff_id = ?";
                    if ($stmtOT = $conn->prepare($sqlOT)) {
                        $stmtOT->bind_param("i", $id);
                        $stmtOT->execute();
                        $resultOT = $stmtOT->get_result();
                        if ($rowOT = $resultOT->fetch_assoc()) {

                            $normal_hours = $rowOT['normal_hours'];
                            $rest_hours = $rowOT['rest_hours'];
                            $holiday_hours = $rowOT['holiday_hours'];

                            $ORP = round($current_salary / 26, 2) ;
                            $HRP = round($ORP / 8 , 2) ;
                            
                            $totalNHOW = 0;
                            $totalRHOW = 0;
                            $totalHHOW = 0;

                            if($normal_hours > 0 ){
                                $totalNHOW += round(($normal_hours * $HRP * 1.5),2);
                            }

                            if($rest_hours > 0 && $rest_hours <= 4){
                                $totalRHOW += round(($ORP * 0.5),2);
                            }elseif ($rest_hours > 3 && $rest_hours <= 8) {
                                $totalRHOW += round(($ORP * 1),2);
                            }elseif ($rest_hours > 8) {
                                $totalRHOW += round(($ORP * 1),2);
                                $totalRHOW += round((($rest_hours - 8) * $HRP * 2),2);
                            }

                            if($holiday_hours > 0 && $holiday_hours <= 8){
                                $totalHHOW += round(($ORP * 2),2);
                            }elseif ($holiday_hours > 8) {
                                $totalHHOW += round(($ORP * 2),2);
                                $totalHHOW += round((($holiday_hours-8) * $HRP * 3),2);


                            }

                            $totalOT = round($totalNHOW + $totalRHOW + $totalHHOW , 2);
                            

                            echo "<p> Normal Hours: " . htmlspecialchars($normal_hours) . " - $totalNHOW </p>";
                            echo "<p> Rest Hours: " . htmlspecialchars($rest_hours) . " - $totalRHOW </p>";
                            echo "<p> Holiday Hours: " . htmlspecialchars($holiday_hours) . " - $totalHHOW </p>";

                            echo "<p>Total Overtime Pay : RM " . htmlspecialchars($totalOT) . "</p>";
                            echo"<p>Gross Income : RM ". ($current_salary + $totalOT) ."</p>";

                            echo "<p>Total Benefits: RM " . htmlspecialchars($benefitsTotal) . "</p>";
                            echo "<p>Total Allowances: RM " . htmlspecialchars($allowancesTotal) . "</p>";
                            echo "<p>Total Deductions: RM " . htmlspecialchars($deductionsTotal) . "</p>";
                            echo "<p>Total Remuneration: RM " . htmlspecialchars($remunerationTotal) . "</p>";
                            echo "<p>Total Perquisites: RM " . htmlspecialchars($perquisitesTotal) . "</p>";


                        } else {
                            $totalOT = 0;
                            echo "<p>Total Overtime: RM 0</p>";
                            echo"<p>{$rowOT['normal_hours']}</p>";

                            echo "<p>Total Benefits: RM " . htmlspecialchars($benefitsTotal) . "</p>";
                            echo "<p>Total Allowances: RM " . htmlspecialchars($allowancesTotal) . "</p>";
                            echo "<p>Total Deductions: RM " . htmlspecialchars($deductionsTotal) . "</p>";
                            echo "<p>Total Remuneration: RM " . htmlspecialchars($remunerationTotal) . "</p>";
                            echo "<p>Total Perquisites: RM " . htmlspecialchars($perquisitesTotal) . "</p>";
                        }
                    }

                    echo "
                    </div>
                    <div class='staff-details-container'>";

                    include 'process/process_EPF.php';
                    include 'process/process_EIS.php';

                    $totalAccountedEPF += $current_salary;
                    $totalAccountedEIS += $current_salary;
                    $totalAccountedSocso = $totalAccountedEIS;

                    echo"
                    <!-- Form to pass totalAccountedEPF to another file -->
                    
                    <form id='epfForm' method='post' action='process/process_EPF.php?submitted=true'>
                        <input type='hidden' name='staff_id' value='{$_GET['id']}'/>
                        <input type='hidden' name='totalAccountedEPF' value='{$totalAccountedEPF}'/>
                        <input class='reload' type='submit' value='&#x21bb; Update EPF' style='background: none; border: none;'/>
                    </form>
                    
                    <h3>Total Income commit to EPF : RM " . $totalAccountedEPF . "</h3>
                    <p> Employee EPF : RM " . $employeeEPF . "</p>
                    <p> Employer EPF : RM " . $employerEPF . "</p>
                    
                    </div>
                    
                    <div class='staff-details-container'>

                    <form id='eisForm' method='post' action='process/process_EIS.php'>
                        <input type='hidden' name='staff_id' value='{$_GET['id']}'/>
                        <input type='hidden' name='totalAccountedEIS' value='{$totalAccountedEIS}'/>
                        <input class = 'reload' type='submit' value='&#x21bb; Update EIS' style='background: none; border: none;    '/>
                    </form>
                    
                    <h3>Total Income commit to EIS : RM " . $totalAccountedEIS . "</h3>
                    <p> Employee EIS : RM " . $employeeEIS . "</p>
                    <p> Employer EIS : RM " . $employerEIS . "</p>
                    
                    </div>
                    
                    <div class='staff-details-container'>
                    
                    <form id='socsoForm' method='post' action='process/process_SOCSO.php'>
                        <input type='hidden' name='staff_id' value='{$_GET['id']}'/>
                        <input type='hidden' name='totalAccountedSocso' value='{$totalAccountedSocso}'/>
                        <input class = 'reload' type='submit' value='&#x21bb; Update SOCSO' style='background: none; border: none;    '/>
                    </form>

                    <h3>Total Income commit to SOCSO : RM " . $totalAccountedSocso . "</h3>
                    <p> Employee SOCSO : RM " . $employeeSocso . "</p>
                    <p> Employer SOCSO : RM " . $employerSocso . "</p>
                    

                    
                    ";

                    

                    
                    
                
                } else {
                    echo "<p class='not-found'>Staff not found.</p>";
                }

                $stmt->close();
            } else {
                echo "<p class='invalid-request'>Invalid request.</p>";
            }
        } else {
            echo "<p class='invalid-request'>Invalid request.</p>";
        }

        echo "</div> </div>";
        mysqli_close($conn);
        ?>
    <div class= "all-modals">

            <!-- Modal for staff details -->
        <button  class="ModalBtns" id="DetailsBtn">Update Details</button>
        
        <!-- The Modal -->
        <div id="DetailsModal" class="modal">
        <div id="detailsModal-resized" >

        <!-- Modal content -->
        <div class="modal-content">
            <!-- Details Section -->
            <div class="details-section">
                <!-- Salary Container -->
                <div class="details-container">
                <span class="close">&times;</span>
                    <center>
                        <h3>Details</h3>
                    </center>

                    <embed style="margin-bottom: 200px; overflow-x: hidden;" type="text/html" src="update-details.php" width="100%" height="80%">

                    <!-- in case of existing bank type, set the value and add the selected class -->
                    <?php if (isset($existingBankType)): ?>
                        <script>
                        document.getElementById('bankType').value = '<?php echo $existingBankType; ?>';
                        let buttons = document.querySelectorAll('.bank-btn');
                        buttons.forEach(button => {
                            if (button.innerText === '<?php echo $existingBankType; ?>') {
                                button.classList.add('selected');
                            }
                        });
                        </script>
                    <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
        <!-- Modal for salary -->
        <button  class="ModalBtns" id="SalaryBtn">Update Salary</button>
        
        <!-- The Modal -->
        <div id="SalaryModal" class="modal">

        <!-- Modal content -->
        <div class="modal-content">
            <!-- Details Section -->
            <div class="details-section">
                <!-- Salary Container -->
                <div class="details-container">
                <span class="close">&times;</span>
                    <center>
                        <h3>Salary</h3>
                    </center>
                    <form action="process/process_salary.php" method="POST">
                        <input type="hidden" name="staff_id" value="<?php echo $_GET['id'] ?>">

                        <label for="bankType">Bank Type</label>
                        <div class="bank-type-buttons">
                        <button type="button" class="bank-btn" onclick="setBankType('Malayan Banking')">
                            Malayan Banking
                        </button>
                        <button type="button" class="bank-btn" onclick="setBankType('Bank Islam')">
                            Bank Islam
                        </button>
                        <button type="button" class="bank-btn" onclick="setBankType('Public Bank')">
                            Public Bank
                        </button>
                        <button type="button" class="bank-btn" onclick="setBankType('CIMB Bank')">
                            CIMB Bank
                        </button>
                    </div>

                    <input type="hidden" id="bankType" name="bankType" value="">

                    <!-- in case of existing bank type, set the value and add the selected class -->
                    <?php if (isset($existingBankType)): ?>
                        <script>
                        document.getElementById('bankType').value = '<?php echo $existingBankType; ?>';
                        let buttons = document.querySelectorAll('.bank-btn');
                        buttons.forEach(button => {
                            if (button.innerText === '<?php echo $existingBankType; ?>') {
                                button.classList.add('selected');
                            }
                        });
                        </script>
                    <?php endif; ?>

                        <label for="bankNumber">Bank Number</label>
                        <input type="text" id="bankNumber" name="bankNumber" value="<?php echo isset($existingBankNumber) ? htmlspecialchars($existingBankNumber) : ''; ?>" placeholder="Enter Bank Number">

                        <label for="basicSalary">Basic Salary</label>
                        <input step="0.01" type="number" id="basicSalary" name="basicSalary" value="<?php echo isset($existingBasicSalary) ? htmlspecialchars($existingBasicSalary) : ''; ?>" placeholder="Enter Basic Salary">

                        <input type="submit" value="Save Salary">
                    </form>

                    </div>
                    <div class="details-container" style="margin-top: 20px;">
                    <span class="reload">&#x21bb;</span>


                    <?php
                    // Include database connection
                    $conn = mysqli_connect("localhost", "root", "", "testSalary");

                    if (!$conn) {
                        die("Database connection failed: " . mysqli_connect_error());
                    }

                    // Fetch Salary Details
                    if (isset($id)) {
                        $stmt_salary = $conn->prepare("SELECT basic_salary, bank_type, bank_number FROM salary WHERE staff_id = ? AND basic_salary > 0.00");
                        if (!$stmt_salary) {
                            die("Prepare statement failed: " . $conn->error);
                        }
                        $stmt_salary->bind_param("i", $id);
                        $stmt_salary->execute();
                        $result_salary = $stmt_salary->get_result();

                        $existingBasicSalary = '';
                        $existingBankType = '';
                        $existingBankNumber = '';

                        if ($salary_row = $result_salary->fetch_assoc()) {
                            $existingBasicSalary = $salary_row['basic_salary'];
                            $existingBankType = $salary_row['bank_type'];
                            $existingBankNumber = $salary_row['bank_number'];

                            echo "<p>Current Basic Salary: " . htmlspecialchars($existingBasicSalary) . "</p>";
                            echo "<p>Bank Type: " . htmlspecialchars($existingBankType) . "</p>";
                            echo "<p>Bank Number: " . htmlspecialchars($existingBankNumber) . "</p>";
                        } else {
                            echo "<p>No salary details available for this staff.</p>";
                        }

                        $stmt_salary->close(); // Close the prepared statement
                    } else {
                        echo "<p>Invalid Staff ID.</p>";
                    }

                    // Close the connection at the end of the script
                    mysqli_close($conn);
                    ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for salary -->
    <button  class="ModalBtns" id="OvertimeBtn">Update Overtime</button>
        
        <!-- The Modal -->
        <div id="OvertimeModal" class="modal">

        <!-- Modal content -->
        <div class="modal-content">
            <!-- Details Section -->
            <div class="details-section">
                <!-- Salary Container -->
                <div class="details-container">
                <span class="close">&times;</span>
                    <center>
                        <h3>Overtime</h3>
                    </center>
                    <form id="otForm" action="process/process_overtime.php" method="POST">
                    <input type="hidden" name="staff_id" value="<?php echo $_GET['id'] ?>">

                        <label for="bankNumber">Normal Hours</label>
                        <input type="number" id="normal_hours" name="normal_hours" value="">

                        <label for="bankNumber">Rest Hours</label>
                        <input type="number" id="rest_hours" name="rest_hours" value="">

                        <label for="bankNumber">Public Holidy Hours</label>
                        <input type="number" id="holiday_hours" name="holiday_hours" value="">
                        
                        <input type="hidden" name="current_salary" value="<?php echo $current_salary ?>">

                        <input type="submit" value="Save Overtime">
                    </form>

                    </div>
                    <div class="details-container" style="margin-top: 20px;">
                    <span class="reload">&#x21bb;</span>


                    <?php
                    // Include database connection
                    $conn = mysqli_connect("localhost", "root", "", "testSalary");

                    if (!$conn) {
                        die("Database connection failed: " . mysqli_connect_error());
                    }

                    // Fetch Overtime Details
                    if (isset($id)) {
                        $stmt_overtime = $conn->prepare("SELECT normal_hours, rest_hours, holiday_hours FROM overtime WHERE staff_id = ?");
                        if (!$stmt_overtime) {
                            die("Prepare statement failed: " . $conn->error);
                        }
                        $stmt_overtime->bind_param("i", $id);
                        $stmt_overtime->execute();
                        $result_overtime = $stmt_overtime->get_result();

                        $normal_hours = 0;
                        $rest_hours = 0;
                        $holiday_hours = 0;

                        if ($overtime_row = $result_overtime->fetch_assoc()) {
                            $normal_hours = $overtime_row['normal_hours'];
                            $rest_hours = $overtime_row['rest_hours'];
                            $holiday_hours = $overtime_row['holiday_hours'];

                            echo "<p>Normal Hours: " . htmlspecialchars($normal_hours) . "</p>";
                            echo "<p>Rest Hours: " . htmlspecialchars($rest_hours) . "</p>";
                            echo "<p>Holiday Hours: " . htmlspecialchars($holiday_hours) . "</p>";
                        } else {
                            echo "<p>No overtime details available for this staff.</p>";
                        }

                        $stmt_overtime->close(); // Close the prepared statement
                    } else {
                        echo "<p>Invalid Staff ID.</p>";
                    }

                    // Close the connection at the end of the script
                    mysqli_close($conn);
                    ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Allowance -->
    <button class="ModalBtns" id="AllowanceBtn">Update Allowance</button>
            
        <!-- The Modal -->
        <div id="AllowanceModal" class="modal">

            <!-- Modal content -->
            <div class="modal-content">
            
            <!-- Allowance Container -->
            <a id="current-scroller" href='#current-values'>View current Allowance</a>
            <div class="details-container">
            <span class="close">&times;</span>
            <center>
                <h3>Allowance</h3>
            </center>

            <form action="process/process_allowance.php" method="POST">
                <input type="hidden" name="staff_id" value="<?php echo $_GET['id'] ?>" />
                <label for="allowanceType">Allowance Type</label>

            <section class="btn-container">
                <div class="button-group" data-group-id="allowanceType">
                    <button type="button" class="options-btn" data-value="attendance">Attendance</button>
                    <button type="button" class="options-btn" data-value="mobile">Mobile Phone</button>
                    <button type="button" class="options-btn" data-value="childCare">Child Care</button>
                    <button type="button" class="options-btn" data-value="eduAllow">Education</button>
                    <button type="button" class="options-btn" data-value="houseAllow">Housing</button>
                    <button type="button" class="options-btn" data-value="internAllow">Internship</button>
                    <button type="button" class="options-btn" data-value="mealAllow">Meal</button>
                    <button type="button" class="options-btn" data-value="otherAllow">Other</button>
                    <button type="button" class="options-btn" data-value="parkingAllow">Parking</button>
                    <button type="button" class="options-btn" data-value="shiftAllow">Shift</button>
                    <button type="button" class="options-btn" data-value="travelOAllow">Travel (Official)</button>
                    <button type="button" class="options-btn" data-value="travelPAllow">Travel (Personnel)</button>
                </div>
            </section>

                <input type="hidden" id="allowanceType" name="allowanceType" value="">    

                <!-- Unique Amount input field for Allowance -->
                <div id="allowanceAmountField" style="display:show;">
                    <label class="allowanceLabel" for="allowanceAmount">Amount</label>
                    <input step="0.01" type="number" class="amountContainer" id="allowanceAmount" name="amount" value="<?php echo isset($existingAllowanceAmount) ? htmlspecialchars($existingAllowanceAmount) : ''; ?>" placeholder="Enter Amount">
                </div>

                <input type="submit" value="Save Allowance">
            </form>

            </div>
            
            <div class="details-container" style="margin-top: 20px;">
            <span class="reload">&#x21bb;</span>


            <?php
            // Include database connection
            $conn = mysqli_connect("localhost", "root", "", "testsalary");

            if (!$conn) {
                die("Database connection failed: " . mysqli_connect_error());
            }

            // Fetch Allowance Details
            if (isset($id)) {
                // Fetch all allowance data for the staff
                $stmt_allowance = $conn->prepare("SELECT attendance, mobile, childCare, eduAllow, houseAllow, internAllow, mealAllow, otherAllow, parkingAllow, shiftAllow, travelOAllow, travelPAllow 
                                      FROM allowance WHERE staff_id = ?");
                if (!$stmt_allowance) {
                    die("Prepare statement failed: " . $conn->error);
                }
                $stmt_allowance->bind_param("i", $id);
                $stmt_allowance->execute();
                $result_allowance = $stmt_allowance->get_result();

                $allowances = [
                    'attendance' => 0,
                    'mobile' => 0,
                    'childCare' => 0,
                    'eduAllow' => 0,
                    'houseAllow' => 0,
                    'internAllow' => 0,
                    'mealAllow' => 0,
                    'otherAllow' => 0,
                    'parkingAllow' => 0,
                    'shiftAllow' => 0,
                    'travelOAllow' => 0,
                    'travelPAllow' => 0
                ];

                if ($allowance_row = $result_allowance->fetch_assoc()) {
                    // Store all allowance values that are greater than 0
                    foreach ($allowance_row as $allowance_type => $amount) {
                        if ($amount > 0) {
                            $allowances[$allowance_type] = $amount;
                        }
                    }

                    // Display only the allowances that have a value > 0.00
                    foreach ($allowances as $allowance_type => $amount) {
                        if ($amount > 0) {
                            echo "<p id='current-values'><strong>" . ucfirst(str_replace('Allow', ' Allowance', $allowance_type)) . ":</strong> " . htmlspecialchars($amount) . "</p>";
                        }
                    }
                } else {
                    echo "<p>No allowance details found in the database for this staff.</p>";
                }

                $stmt_allowance->close(); // Close the prepared statement
            } else {
                echo "<p>Invalid Staff ID.</p>";
            }

            // Close the connection at the end of the script
            mysqli_close($conn);
            ?>
                
                </div>
            </div>
        </div>
    

    <!-- Modal for Benefit in Kind -->
    <button  class="ModalBtns" id="BikBtn">Update BIK</button>

        <!-- The Modal -->
        <div id="BikModal" class="modal">
            <!-- Modal content -->
            <div class="modal-content">
            <a id="current-scroller" href='#current-values-BIK'>View current Benefits</a>
            <!-- Details Section -->
            <div class="details-section">
                <!-- Salary Container -->
                <div class="details-container">
                <span class="close">&times;</span>
                    <center>
                        <h3>Benefit-In-Kind</h3>
                    </center>
                    <form action="process/process_bik.php" method="POST">
                    <input type="hidden" name="staff_id" value="<?php echo $_GET['id'] ?>">
                        <label for="bikType">Benefit-In-Kind Type</label>
                        <section class="btn-container">
                                <div class="button-group" data-group-id="bikType">
                                    <button type="button" class="options-btn" data-value="consumeDiscBik">Consumable Discount</button>
                                    <button type="button" class="options-btn" data-value="dentalBik">Dental</button>
                                    <button type="button" class="options-btn" data-value="driverBik">Driver</button>
                                    <button type="button" class="options-btn" data-value="fulfillDutiBik">Employee to Fulfill Duties</button>
                                    <button type="button" class="options-btn" data-value="foodDrinkBik">Food & Drinks</button>
                                    <button type="button" class="options-btn" data-value="garmentBik">Garments</button>
                                    <button type="button" class="options-btn" data-value="hElectrikBik">Household Electric Bill</button>
                                    <button type="button" class="options-btn" data-value="hEntertainBik">Household Entertainment & Recreational</button>
                                    <button type="button" class="options-btn" data-value="hFurniturBik">Household Furniture & Fittings</button>
                                    <button type="button" class="options-btn" data-value="hGardenBik">Household Gardener</button>
                                    <button type="button" class="options-btn" data-value="hKitchenBik">Household Kitchen Equipment</button>
                                    <button type="button" class="options-btn" data-value="hServantBik">Household Servant/Guard</button>
                                    <button type="button" class="options-btn" data-value="hTelephoneBik">Household Telephone Bill</button>
                                    <button type="button" class="options-btn" data-value="hUtilitiBik">Household Utilities</button>
                                    <button type="button" class="options-btn" data-value="travelMalayBik">Leave Passage Travel (Malaysia)</button>
                                    <button type="button" class="options-btn" data-value="travelOverBik">Leave Passage Travel (Overseas)</button>
                                    <button type="button" class="options-btn" data-value="liviAccoBik">Living Accommodation</button>
                                    <button type="button" class="options-btn" data-value="medicalBik">Medical</button>
                                    <button type="button" class="options-btn" data-value="clubMemberBik">Recreational Club Membership</button>
                                    <button type="button" class="options-btn" data-value="serviceDiscBik">Service Discount</button>
                                    <button type="button" class="options-btn" data-value="transportBik">Transportation</button>
                                    <button type="button" class="options-btn" data-value="motorcarBik">Vehicle/Motorcar</button>
                                    <button type="button" class="options-btn" data-value="workAccidentBik">Workplace Accident</button>
                                    <button type="button" class="options-btn" data-value="otherBik">Other</button>
                                </div>
                            <input type="hidden" id="bikType" name="bikType" value="">
                        </section>
                    </section>  

                    
                    <!-- Add the motor car details section -->
                    <div id="motorCarDetails" style="display: none;">
                        <div style="display: flex; flex-direction: column; width: 80%; margin: 0 auto; text-align: left;">
                            <label for="type">Type:</label>
                            <input style="float:left; text-align:center" type="text" id="type" name="type" require>
                            <label for="year">Year:</label>
                            <input style="text-align:center" type="number" id="year" name="year" require>
                            <label for="model">Model:</label>
                            <input style="text-align:center" type="text" id="model" name="model" require>
                        </div>
                    </div>

                    <!-- Unique Amount input field for BIK -->
                    <div id="bikAmountField">
                        <label for="bikAmount">Amount</label>
                        <input step="0.01" type="number" class="amountContainer" id="bikAmount" name="amount" placeholder="Enter Amount">
                    </div>

                    <input type="submit" value="Save Benefit-In-Kind">
                    </form>

                    </div>
                    <div id="current-values-BIK" class="details-container" style="margin-top: 20px;">
                        <span class="reload">&#x21bb;</span>

                    
                    <?php
                    // Include database connection
                    $conn = mysqli_connect("localhost", "root", "", "testsalary");

                    if (!$conn) {
                        die("Database connection failed: " . mysqli_connect_error());
                    }

                    // Fetch Benefit-In-Kind Details from 'benefit' table
                    if (isset($id)) {
                        // Query to fetch all BIK data from the 'benefit' table
                        $stmt_bik = $conn->prepare("SELECT consumeDiscBik, dentalBik, driverBik, fulfillDutiBik, foodDrinkBik, garmentBik, hElectrikBik, hEntertainBik, hFurniturBik, hGardenBik, hKitchenBik, hServantBik, hTelephoneBik, hUtilitiBik, travelMalayBik, travelOverBik, liviAccoBik, medicalBik, otherBik, clubMemberBik, serviceDiscBik ,transportBik, motorcarBik, workAccidentBik FROM benefit WHERE staff_id = ?");
                        if (!$stmt_bik) {
                            die("Prepare statement failed: " . $conn->error);
                        }
                        $stmt_bik->bind_param("i", $id);
                        $stmt_bik->execute();
                        $result_bik = $stmt_bik->get_result();

                        // Mapping the database column names to user-friendly labels
                        $bikLabels = [
                            'consumeDiscBik' => 'Consumable Discount',
                            'dentalBik' => 'Dental',
                            'driverBik' => 'Driver',
                            'fulfillDutiBik' => 'Employee to Fulfill Duties',
                            'foodDrinkBik' => 'Food & Drinks',
                            'garmentBik' => 'Garments',
                            'hElectrikBik' => 'Household Electric Bill',
                            'hEntertainBik' => 'Household Entertainment & Recreational',
                            'hFurniturBik' => 'Household Furniture & Fittings',
                            'hGardenBik' => 'Household Gardener',
                            'hKitchenBik' => 'Household Kitchen Equipment',
                            'hServantBik' => 'Household Servant/Guard',
                            'hTelephoneBik' => 'Household Telephone Bill',
                            'hUtilitiBik' => 'Household Utilities',
                            'travelMalayBik' => 'Leave Passage Travel (Malaysia)',
                            'travelOverBik' => 'Leave Passage Travel (Overseas)',
                            'liviAccoBik' => 'Living Accommodation',
                            'medicalBik' => 'Medical',
                            'otherBik' => 'Other',
                            'clubMemberBik' => 'Recreational Club Membership',
                            'serviceDiscBik' => 'Service Discount',
                            'transportBik' => 'Transportation',
                            'motorcarBik' => 'Vehicle/Motorcar',
                            'workAccidentBik' => 'Workplace Accident'
                        ];

                        $biks = [];

                        if ($bik_row = $result_bik->fetch_assoc()) {
                            // Store all BIK values that are greater than 0
                            foreach ($bik_row as $bik_type => $amount) {
                                if ($amount > 0) {
                                    $biks[$bik_type] = $amount;
                                }
                            }

                            // Display only the BIKs that have a value > 0.00
                            foreach ($biks as $bik_type => $amount) {
                                if ($amount > 0) {
                                    // Display the friendly name using the label
                                    echo "<p><strong>" . $bikLabels[$bik_type] . ":</strong> " . htmlspecialchars($amount) . "</p>";
                                }
                            }
                        } else {
                            echo "<p>No Benefit-In-Kind details found for this staff.</p>";
                        }

                        $stmt_bik->close(); // Close the prepared statement
                    } else {
                        echo "<p>Invalid Staff ID.</p>";
                    }

                  ?>

                    
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for salary -->
    <button  class="ModalBtns" id="DeductionBtn">Update Deduction</button>

    <!-- The Modal -->
    <div id="DeductionModal" class="modal">

        <!-- Modal content -->
        <div class="modal-content">
        <a id="current-scroller" href='#current-values-deduc'>View current Deduction</a>
            <!-- Details Section -->
            <div class="details-section">
            <!-- Deduction Container -->
            <div class="details-container">
            <span class="close">&times;</span>
                <center>
                    <h3>Deduction</h3>
                </center>
                <form action="process/process_deduct.php" method="POST">
                <input type="hidden" name="staff_id" value="<?php echo $_GET['id'] ?>">
                    <label for="deductionType">Deduction Type</label>
                    <section class="btn-container">
                        <div class="button-group" data-group-id="deductionType">
                            <button type="button" class="options-btn" data-value="advPayDeduct">Advance Payment</button>
                            <button type="button" class="options-btn" data-value="basicSuppDeduct">Basic Supporting Equipment</button>
                            <button type="button" class="options-btn" data-value="cp38Deduct">CP38 (Tax Deduction Order)</button>
                            <button type="button" class="options-btn" data-value="dentalDeduct">Dental Examination</button>
                            <button type="button" class="options-btn" data-value="departureDeduct">Departure Levy (Pilgrimage)</button>
                            <button type="button" class="options-btn" data-value="domTourisDeduct">Domestic Tourism Expenditure</button>
                            <button type="button" class="options-btn" data-value="earlyDeduct">Early Intervention (Learning Disabilities)</button>
                            <button type="button" class="options-btn" data-value="eduDeduct">Education & Medical Insurance</button>
                            <button type="button" class="options-btn" data-value="hrdfDeduct">Employer HRDF Levy (Custom)</button>
                            <button type="button" class="options-btn" data-value="evDeduct">EV Charging</button>
                            <button type="button" class="options-btn" data-value="fatherDeduct">Father Relief</button>
                            <button type="button" class="options-btn" data-value="childCare">Child Care Centre Fees</button>
                            <button type="button" class="options-btn" data-value="highEduDeduct">Higher Education Fees</button>
                            <button type="button" class="options-btn" data-value="housLoanDeduct">Interest on Housing Loan</button>
                            <button type="button" class="options-btn" data-value="insuranceDeduct">Levy Insurance</button>
                            <button type="button" class="options-btn" data-value="lifeInsDeduct">Life Insurance</button>
                            <button type="button" class="options-btn" data-value="lifestyleDeduct">Lifestyle Relief</button>
                            <button type="button" class="options-btn" data-value="lifestyleCompDeduct">Lifestyle Relief (Computer)</button>
                            <button type="button" class="options-btn" data-value="loanDeduct">Loan</button>
                            <button type="button" class="options-btn" data-value="medicalDeduct">Medical Examination</button>
                            <button type="button" class="options-btn" data-value="medicalParentDeduct">Medical Examination (Parent)</button>
                            <button type="button" class="options-btn" data-value="medicalSeriousDeduct">Medical Expenses on Serious Disease</button>
                            <button type="button" class="options-btn" data-value="medicalTreatDeduct">Medical Treatment, Special Needs, or Carer Expenses of Parents</button>
                            <button type="button" class="options-btn" data-value="motherDeduct">Mother Relief</button>
                            <button type="button" class="options-btn" data-value="netSSPNDeduct">Net Deposit in SSPN</button>
                            <button type="button" class="options-btn" data-value="netSalaryDeduct">Net Salary</button>
                            <button type="button" class="options-btn" data-value="formerWifeDeduct">Payment of Alimony to Former Wife</button>
                            <button type="button" class="options-btn" data-value="retiredDeduct">Private Retirement Scheme</button>
                            <button type="button" class="options-btn" data-value="ptptnDeduct">PTPTN Repayment</button>
                            <button type="button" class="options-btn" data-value="breastDeduct">Purchase of Breastfeeding Equipment</button>
                            <button type="button" class="options-btn" data-value="salaryAdjDeduct">Salary Adjustment</button>
                            <button type="button" class="options-btn" data-value="sportDeduct">Sport Relief</button>
                            <button type="button" class="options-btn" data-value="upskilDeduct">Upskilling Course Fees</button>
                            <button type="button" class="options-btn" data-value="vaccineDeduct">Vaccination Expenses</button>
                            <button type="button" class="options-btn" data-value="withTaxDeduct">Withholding Tax</button>
                        </div>
                        <input type="hidden" id="deductionType" name="deductionType" value="">
                    </section>

                    <!-- Unique Amount input field for Deduction -->
                    <div id="deductionAmountField">
                        <label for="deductionAmount">Amount</label>
                        <input step="0.01" type="number" class="amountContainer" id="deductionAmount" name="amount" placeholder="Enter Amount">
                    </div>

                    <input type="submit" value="Save Deduction">
                </form>

                </div>
                
                <div class="details-container" style="margin-top: 20px;">
                <span class="reload">&#x21bb;</span>

                <?php
                // Include database connection
                $conn = mysqli_connect("localhost", "root", "", "testsalary");

                if (!$conn) {   
                    die("Database connection failed: " . mysqli_connect_error());
                }

                // Fetch Deduction Details from 'deduction' table
                if (isset($id)) {
                    // Query to fetch all Deduction data from the 'deduction' table
                    $stmt_deduct = $conn->prepare("SELECT advPayDeduct, basicSuppDeduct, cp38Deduct, dentalDeduct, departureDeduct, domTourisDeduct, earlyDeduct, eduDeduct, hrdfDeduct, epfEmployeeDeduct, epfEmployerDeduct, evDeduct, fatherDeduct, childCare, highEduDeduct, housLoanDeduct, insuranceDeduct, lifeInsDeduct, lifestyleDeduct, lifestyleCompDeduct, loanDeduct, medicalDeduct, medicalParentDeduct, medicalSeriousDeduct, medicalTreatDeduct, motherDeduct, netSSPNDeduct, netSalaryDeduct, formerWifeDeduct, retiredDeduct, ptptnDeduct, breastDeduct, salaryAdjDeduct, sportDeduct, upskilDeduct, vaccineDeduct, withTaxDeduct FROM deduction WHERE staff_id = ?");
                    if (!$stmt_deduct) {
                        die("Prepare statement failed: " . $conn->error);
                    }
                    $stmt_deduct->bind_param("i", $id);
                    $stmt_deduct->execute();
                    $result_deduct = $stmt_deduct->get_result();

                    // Mapping the database column names to user-friendly labels
                    $deductionLabels = [
                        'advPayDeduct' => 'Advance Payment',
                        'basicSuppDeduct' => 'Basic Supporting Equipment',
                        'cp38Deduct' => 'CP38 (Tax Deduction Order)',
                        'dentalDeduct' => 'Dental Examination',
                        'departureDeduct' => 'Departure Levy (Pilgrimage)',
                        'domTourisDeduct' => 'Domestic Tourism Expenditure',
                        'earlyDeduct' => 'Early Intervention (Learning Disabilities)',
                        'eduDeduct' => 'Education & Medical Insurance',
                        'hrdfDeduct' => 'Employer HRDF Levy (Custom)',
                        'epfEmployeeDeduct' => 'EPF Employee Contribution',
                        'epfEmployerDeduct' => 'EPF Employer Contribution',
                        'evDeduct' => 'EV Charging',
                        'fatherDeduct' => 'Father Relief',
                        'childCare' => 'Child Care Centre Fees',
                        'highEduDeduct' => 'Higher Education Fees',
                        'housLoanDeduct' => 'Interest on Housing Loan',
                        'insuranceDeduct' => 'Levy Insurance',
                        'lifeInsDeduct' => 'Life Insurance',
                        'lifestyleDeduct' => 'Lifestyle Relief',
                        'lifestyleCompDeduct' => 'Lifestyle Relief (Computer)',
                        'loanDeduct' => 'Loan',
                        'medicalDeduct' => 'Medical Examination',
                        'medicalParentDeduct' => 'Medical Examination (Parent)',
                        'medicalSeriousDeduct' => 'Medical Expenses on Serious Disease',
                        'medicalTreatDeduct' => 'Medical Treatment, Special Needs, or Carer Expenses of Parents',
                        'motherDeduct' => 'Mother Relief',
                        'netSSPNDeduct' => 'Net Deposit in SSPN',
                        'netSalaryDeduct' => 'Net Salary',
                        'formerWifeDeduct' => 'Payment of Alimony to Former Wife',
                        'retiredDeduct' => 'Private Retirement Scheme',
                        'ptptnDeduct' => 'PTPTN Repayment',
                        'breastDeduct' => 'Purchase of Breastfeeding Equipment',
                        'salaryAdjDeduct' => 'Salary Adjustment',
                        'sportDeduct' => 'Sport Relief',
                        'upskilDeduct' => 'Upskilling Course Fees',
                        'vaccineDeduct' => 'Vaccination Expenses',
                        'withTaxDeduct' => 'Withholding Tax'
                    ];

                    $deductions = [];

                    if ($deduct_row = $result_deduct->fetch_assoc()) {
                        // Store all deduction values that are greater than 0
                        foreach ($deduct_row as $deduct_type => $amount) {
                            if ($amount > 0) {
                                $deductions[$deduct_type] = $amount;
                            }
                        }

                        // Display only the deductions that have a value > 0.00
                        foreach ($deductions as $deduct_type => $amount) {
                            if ($amount > 0) {
                                // Display the friendly name using the label
                                echo "<p id='current-values-deduc'><strong>" . $deductionLabels[$deduct_type] . ":</strong> " . htmlspecialchars($amount) . "</p>";
                            }
                        }
                    } else {
                        echo "<p id='current-values-deduc' >No Deduction details found for this staff.</p>";
                    }

                    $stmt_deduct->close(); // Close the prepared statement
                } else {
                    echo "<p>Invalid Staff ID.</p>";
                }

                // Close the connection at the end of the script
                mysqli_close($conn);
                ?>



                    </div>
                </div>
            </div>
        </div>

    <!-- Modal for renumeration -->
    <button  class="ModalBtns" id="RenumBtn">Update Renumeration</button>

        <!-- The Modal -->
        <div id="RenumModal" class="modal">

            <!-- Modal content -->
            <div class="modal-content">
            <a id="current-scroller" href='#current-values-renum'>View current Renumeration</a>
            <!-- Details Section -->
            <div class="details-section">
                <!-- Salary Container -->
                <div class="details-container">
                <span class="close">&times;</span>
                    <center>
                        <h3>Remuneration</h3>
                    </center>
                    <form action="process/process_remuneration.php" method="POST">
                    <input type="hidden" name="staff_id" value="<?php echo $_GET['id'] ?>">
                        <label for="remunerationType">Remuneration Type</label>
                        <section class="btn-container">
                            <div class="button-group" data-group-id="remunerationType">
                                <button type="button" class="options-btn" data-value="advPayRemu">Advance Payment</button>
                                <button type="button" class="options-btn" data-value="arrearsRemu">Arrears of Wages</button>
                                <button type="button" class="options-btn" data-value="bonusRemu">Bonus</button>
                                <button type="button" class="options-btn" data-value="commissionRemu">Commission</button>
                                <button type="button" class="options-btn" data-value="compensationRemu">Compensation</button>
                                <button type="button" class="options-btn" data-value="directorRemu">Director's Fee</button>
                                <button type="button" class="options-btn" data-value="claimRemu">Expenses Claims</button>
                                <button type="button" class="options-btn" data-value="gratuityRemu">Gratuity (End of Service Period)</button>
                                <button type="button" class="options-btn" data-value="incentiveRemu">Incentive</button>
                                <button type="button" class="options-btn" data-value="leavePayRemu">Leave Pay</button>
                                <button type="button" class="options-btn" data-value="otNormRemu">Overtime (Normal)</button>
                                <button type="button" class="options-btn" data-value="otOffRemu">Overtime (Offday)</button>
                                <button type="button" class="options-btn" data-value="otPublicRemu">Overtime (Public Holiday)</button>
                                <button type="button" class="options-btn" data-value="pcbPastRemu">PCB Borne By Employer In Previous Year</button>
                                <button type="button" class="options-btn" data-value="profitRemu">Profit Sharing</button>
                                <button type="button" class="options-btn" data-value="servRemu">Service Charges (Incl. Tips)</button>
                                <button type="button" class="options-btn" data-value="severanceRemu">Severance</button>
                            </div>
                            <input type="hidden" id="remunerationType" name="remunerationType" value="">
                        </section>

                        <!-- Unique Amount input field for Remuneration -->
                        <div id="remunerationAmountField">
                            <label for="remunerationAmount">Amount</label>
                            <input step="0.01" type="number" class="amountContainer" id="remunerationAmount" name="amount" placeholder="Enter Amount">
                        </div>

                        <input type="submit" value="Save Remuneration">
                    </form>

                    </div>
                    <div class="details-container" style="margin-top: 20px;">
                    <span class="reload">&#x21bb;</span>

                    <?php
                    // Include database connection
                    $conn = mysqli_connect("localhost", "root", "", "testsalary");

                    if (!$conn) {
                        die("Database connection failed: " . mysqli_connect_error());
                    }

                    // Fetch Remuneration Details from 'remuneration' table
                    if (isset($id)) {
                        // Query to fetch all remuneration data from the 'remuneration' table
                        $stmt_remu = $conn->prepare("SELECT advPayRemu, arrearsRemu, bonusRemu, commissionRemu, compensationRemu, directorRemu, claimRemu, gratuityRemu, incentiveRemu, leavePayRemu, otNormRemu, otOffRemu, otPublicRemu, pcbPastRemu, profitRemu, servRemu, severanceRemu FROM remuneration WHERE staff_id = ?");
                        if (!$stmt_remu) {
                            die("Prepare statement failed: " . $conn->error);
                        }
                        $stmt_remu->bind_param("i", $id);
                        $stmt_remu->execute();
                        $result_remu = $stmt_remu->get_result();

                        // Mapping the database column names to user-friendly labels
                        $remunerationLabels = [
                            'advPayRemu' => 'Advance Payment',
                            'arrearsRemu' => 'Arrears of Wages',
                            'bonusRemu' => 'Bonus',
                            'commissionRemu' => 'Commission',
                            'compensationRemu' => 'Compensation',
                            'directorRemu' => 'Director\'s Fee',
                            'claimRemu' => 'Expenses Claims',
                            'gratuityRemu' => 'Gratuity (End of Service Period)',
                            'incentiveRemu' => 'Incentive',
                            'leavePayRemu' => 'Leave Pay',
                            'otNormRemu' => 'Overtime (Normal)',
                            'otOffRemu' => 'Overtime (Offday)',
                            'otPublicRemu' => 'Overtime (Public Holiday)',
                            'pcbPastRemu' => 'PCB Borne By Employer In Previous Year',
                            'profitRemu' => 'Profit Sharing',
                            'servRemu' => 'Service Charges (Incl. Tips)',
                            'severanceRemu' => 'Severance'
                        ];

                        $remunerations = [];

                        if ($remu_row = $result_remu->fetch_assoc()) {
                            // Store all remuneration values that are greater than 0
                            foreach ($remu_row as $remu_type => $amount) {
                                if ($amount > 0) {
                                    $remunerations[$remu_type] = $amount;
                                }
                            }

                            // Display only the remunerations that have a value > 0.00
                            foreach ($remunerations as $remu_type => $amount) {
                                if ($amount > 0) {
                                    // Display the friendly name using the label
                                    echo "<p id='current-values-renum'><strong>" . $remunerationLabels[$remu_type] . ":</strong> " . htmlspecialchars($amount) . "</p>";
                                }
                            }
                        } else {
                            echo "<p id='current-values-renum'>No Remuneration details found for this staff.</p>";
                        }

                        $stmt_remu->close(); // Close the prepared statement
                    } else {
                        echo "<p id='current-values-renum'>Invalid Staff ID.</p>";
                    }

                    // Close the connection at the end of the script
                    mysqli_close($conn);
                    ?>

                    </div>
                </div>
            </div>
        </div>

    <!-- Modal for Prerequisites -->
    <button  class="ModalBtns" id="PrequisitesBtn">Update Prequisites</button>

        <!-- The Modal -->
        <div id="PrequisitesModal" class="modal">

        <!-- Modal content -->
        <div class="modal-content">
        <a id="current-scroller" href='#current-values-prereq'>View current Prerequisites</a>

        <div class="details-container">
        <span class="close">&times;</span>
            <center>
                <h3>Perquisites</h3>
            </center>
            <form action="process/process_perquisites.php" method="POST">
            <input type="hidden" name="staff_id" id="staff_id" value="<?php echo $_GET['id'] ?>">
                <label for="perquisitesType">Perquisites Type</label>
                <section class="btn-container">
                    <div class="button-group" data-group-id="perquisitesType">
                        <button type="button" class="options-btn" data-value="mobilePerk">Mobile Phone</button>
                        <button type="button" class="options-btn" data-value="carPerk">Car Maintenance</button>
                        <button type="button" class="options-btn" data-value="creditcardPerk">Credit Card (Personal Use)</button>
                        <button type="button" class="options-btn" data-value="voucherPerk">Gift Voucher</button>
                        <button type="button" class="options-btn" data-value="houseUtilsPerk">Household Utilities</button>
                        <button type="button" class="options-btn" data-value="houseLoanPerk">Housing Loan Interest</button>
                        <button type="button" class="options-btn" data-value="parkingPerk">Parking Fees</button>
                        <button type="button" class="options-btn" data-value="computerPerk">Personal Computer</button>
                        <button type="button" class="options-btn" data-value="proSubscriptPerk">Professional Subscriptions</button>
                        <button type="button" class="options-btn" data-value="clubMemberPerk">Recreational Club Membership</button>
                        <button type="button" class="options-btn" data-value="roadtaxPerk">Road Tax</button>
                        <button type="button" class="options-btn" data-value="awardPerk">Service Excellence, Innovation or Productivity Award</button>
                        <button type="button" class="options-btn" data-value="shareSchemePerk">Share Option Scheme</button>
                    </div>
                    <input type="hidden" id="perquisitesType" name="perquisitesType" value="">
                </section>

                <!-- Unique Amount input field for Perquisites -->
                <div id="perquisitesAmountField">
                    <label for="perquisitesAmount">Amount</label>
                    <input step="0.01" type="number" class="amountContainer" id="perquisitesAmount" name="amount" placeholder="Enter Amount" required>
                </div>

                <input type="submit" value="Save Perquisites">
            </form>

            </div>
            <div class="details-container" style="margin-top: 20px;">
            <span class="reload">&#x21bb;</span>

            <?php
            // Include database connection
            $conn = mysqli_connect("localhost", "root", "", "testsalary");

            if (!$conn) {
                die("Database connection failed: " . mysqli_connect_error());
            }

            // Fetch Perquisites Details from 'perquisites' table
            if (isset($id)) {
                // Query to fetch all perquisites data from the 'perquisites' table
                $stmt_perk = $conn->prepare("SELECT mobilePerk, carPerk, creditcardPerk, voucherPerk, houseUtilsPerk, houseLoanPerk, parkingPerk, computerPerk, proSubscriptPerk, clubMemberPerk, roadtaxPerk, awardPerk, shareSchemePerk FROM perquisites WHERE staff_id = ?");
                if (!$stmt_perk) {
                    die("Prepare statement failed: " . $conn->error);
                }
                $stmt_perk->bind_param("i", $id);
                $stmt_perk->execute();
                $result_perk = $stmt_perk->get_result();

                // Mapping the database column names to user-friendly labels
                $perquisitesLabels = [
                    'mobilePerk' => 'Mobile Phone',
                    'carPerk' => 'Car Maintenance',
                    'creditcardPerk' => 'Credit Card (Personal Use)',
                    'voucherPerk' => 'Gift Voucher',
                    'houseUtilsPerk' => 'Household Utilities',
                    'houseLoanPerk' => 'Housing Loan Interest',
                    'parkingPerk' => 'Parking Fees',
                    'computerPerk' => 'Personal Computer',
                    'proSubscriptPerk' => 'Professional Subscriptions',
                    'clubMemberPerk' => 'Recreational Club Membership',
                    'roadtaxPerk' => 'Road Tax',
                    'awardPerk' => 'Service Excellence, Innovation or Productivity Award',
                    'shareSchemePerk' => 'Share Option Scheme'
                ];

                $perquisites = [];

                if ($perk_row = $result_perk->fetch_assoc()) {
                    // Store all perquisites values that are greater than 0
                    foreach ($perk_row as $perk_type => $amount) {
                        if ($amount > 0) {
                            $perquisites[$perk_type] = $amount;
                        }
                    }

                    // Display only the perquisites that have a value > 0.00
                    foreach ($perquisites as $perk_type => $amount) {
                        if ($amount > 0) {
                            // Display the friendly name using the label
                            echo "<p id='current-values-prereq'><strong>" . $perquisitesLabels[$perk_type] . ":</strong> " . htmlspecialchars($amount) . "</p>";
                        }
                    }
                } else {
                    echo "<p id='current-values-prereq'>No Perquisites details found for this staff.</p>";
                }

                $stmt_perk->close(); // Close the prepared statement
            } else {
                echo "<p id='current-values-prereq' >Invalid Staff ID.</p>";
            }
            

            // Close the connection at the end of the script
            mysqli_close($conn);
            ?>

            <script src="modals.js"></script>
            </div>
        </div>
    </div>
    </div>
</body>

</html>