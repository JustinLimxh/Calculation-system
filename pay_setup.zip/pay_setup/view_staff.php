<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Details</title>
    <link rel="stylesheet" href="css/modals.css">

</head>

<body>
    <?php include 'include/header.php'; ?>

    <!-- Staff Details Container -->
    <div class="staff-details-container">
        <?php
        // Include database connection
        $conn = mysqli_connect("localhost", "root", "", "testSalary");

        if (!$conn) {
            die("Database connection failed: " . mysqli_connect_error());
        }

        // Initialize variables
        $totalSalary = 0;
        $benefitsTotal = 0;
        $allowancesTotal = 0;
        $deductionsTotal = 0;
        $remunerationTotal = 0;
        $perquisitesTotal = 0;

        // Function to ensure numeric values
        function getNumericAmount($amount)
        {
            return is_numeric($amount) ? floatval($amount) : 0;
        }

        // Fetch staff details
        if (isset($_GET['id'])) {
            $id = intval($_GET['id']); // Make sure ID is an integer

            // Fetch staff details using prepared statements
            $sql = "SELECT * FROM staff WHERE id = ?";
            if ($stmt = $conn->prepare($sql)) {
                $stmt->bind_param("i", $id);
                $stmt->execute();
                $result = $stmt->get_result();

                if ($row = $result->fetch_assoc()) {
                    echo "<h2>Staff Details</h2>";
                    echo "<p>Name: " . htmlspecialchars($row['name']) . "</p>";
                    echo "<p>Email: " . htmlspecialchars($row['email']) . "</p>";

                    // Fetch the current salary for the staff member
                    $sql_salary = "SELECT * FROM salary WHERE staff_id = ?";
                    if ($stmt_salary = $conn->prepare($sql_salary)) {
                        $stmt_salary->bind_param("i", $id);
                        $stmt_salary->execute();
                        $result_salary = $stmt_salary->get_result();

                        if ($salary_row = $result_salary->fetch_assoc()) {
                            $current_salary = $salary_row['basic_salary'];
                            // Add base salary to total salary
                            $totalSalary += getNumericAmount($current_salary);
                            echo "<p>Base Salary: " . htmlspecialchars($current_salary) . "</p>";
                        } else {
                            $current_salary = "Not available";
                            echo "<p>Base Salary: Not available</p>";
                        }
                    }

                    // Fetch Benefits
                    $query_benefits = "SELECT * FROM benefit WHERE staff_id = ?";
                    if ($stmt_benefits = $conn->prepare($query_benefits)) {
                        $stmt_benefits->bind_param("i", $id);
                        $stmt_benefits->execute();
                        $result_benefits = $stmt_benefits->get_result();
                        while ($benefit = $result_benefits->fetch_assoc()) {
                            foreach ($benefit as $benefit_type => $amount) {
                                if ($benefit_type !== 'staff_id') {
                                    $benefitsTotal += getNumericAmount($amount);
                                }
                            }
                        }
                        echo "<p>Total Benefits: " . htmlspecialchars($benefitsTotal) . "</p>";
                    }

                    // Fetch Allowances
                    $query_allowances = "SELECT * FROM allowance WHERE staff_id = ?";
                    if ($stmt_allowances = $conn->prepare($query_allowances)) {
                        $stmt_allowances->bind_param("i", $id);
                        $stmt_allowances->execute();
                        $result_allowances = $stmt_allowances->get_result();
                        while ($allowance = $result_allowances->fetch_assoc()) {
                            foreach ($allowance as $allowance_type => $amount) {
                                if ($allowance_type !== 'staff_id') {
                                    $allowancesTotal += getNumericAmount($amount);
                                }
                            }
                        }
                        echo "<p>Total Allowances: " . htmlspecialchars($allowancesTotal) . "</p>";
                    }

                    // Fetch Deductions
                    $query_deductions = "SELECT * FROM deduction WHERE staff_id = ?";
                    if ($stmt_deductions = $conn->prepare($query_deductions)) {
                        $stmt_deductions->bind_param("i", $id);
                        $stmt_deductions->execute();
                        $result_deductions = $stmt_deductions->get_result();
                        while ($deduction = $result_deductions->fetch_assoc()) {
                            foreach ($deduction as $deduction_type => $amount) {
                                if ($deduction_type !== 'staff_id') {
                                    $deductionsTotal += getNumericAmount($amount);
                                }
                            }
                        }
                        echo "<p>Total Deductions: " . htmlspecialchars($deductionsTotal) . "</p>";
                    }

                    // Fetch Remuneration
                    $query_remuneration = "SELECT * FROM remuneration WHERE staff_id = ?";
                    if ($stmt_remuneration = $conn->prepare($query_remuneration)) {
                        $stmt_remuneration->bind_param("i", $id);
                        $stmt_remuneration->execute();
                        $result_remuneration = $stmt_remuneration->get_result();
                        while ($remuneration = $result_remuneration->fetch_assoc()) {
                            foreach ($remuneration as $remuneration_type => $amount) {
                                if ($remuneration_type !== 'staff_id') {
                                    $remunerationTotal += getNumericAmount($amount);
                                }
                            }
                        }
                        echo "<p>Total Remuneration: " . htmlspecialchars($remunerationTotal) . "</p>";
                    }

                    // Fetch Perquisites
                    $query_perquisites = "SELECT * FROM perquisites WHERE staff_id = ?";
                    if ($stmt_perquisites = $conn->prepare($query_perquisites)) {
                        $stmt_perquisites->bind_param("i", $id);
                        $stmt_perquisites->execute();
                        $result_perquisites = $stmt_perquisites->get_result();
                        while ($perquisite = $result_perquisites->fetch_assoc()) {
                            foreach ($perquisite as $perk_type => $amount) {
                                if ($perk_type !== 'staff_id') {
                                    $perquisitesTotal += getNumericAmount($amount);
                                }
                            }
                        }
                        echo "<p>Total Perquisites: " . htmlspecialchars($perquisitesTotal) . "</p>";
                    }

                    // Calculate and display total salary
                    $totalSalary += $benefitsTotal + $allowancesTotal + $remunerationTotal + $perquisitesTotal - $deductionsTotal;
                    echo "<h3>Total Salary Breakdown</h3>";
                    echo "<p>Total Salary: " . htmlspecialchars($totalSalary) . "</p>";
                } else {
                    echo "<p class='not-found'>Staff not found.</p>";
                }

                $stmt->close();
            } else {
                echo "<p class='invalid-request'>Invalid request.</p>";
            }
        } else {
            echo "<p class='invalid-request'>Invalid request.</p>";
        }

        mysqli_close($conn);
        ?>


    </div>
        <!-- Modal for salary -->
        <button  class="ModalBtns" id="SalaryBtn">Open Salary Modal</button>
        
        <!-- The Modal -->
        <div id="SalaryModal" class="modal">

        <!-- Modal content -->
        <div class="modal-content">
            <!-- Details Section -->
            <div class="details-section">
                <!-- Salary Container -->
                <div class="details-container">
                <span class="close">&times;</span>
                    <center>
                        <h3>Salary</h3>
                    </center>
                    <form action="process/process_salary.php" method="POST">
                        <input type="hidden" name="staff_id" value="<?php echo $row['id'] ?>">

                        <label for="bankType">Bank Type</label>
                        <div class="bank-type-buttons">
                        <button type="button" class="bank-btn" onclick="setBankType('Malayan Banking')">
                            Malayan Banking
                        </button>
                        <button type="button" class="bank-btn" onclick="setBankType('Bank Islam')">
                            Bank Islam
                        </button>
                        <button type="button" class="bank-btn" onclick="setBankType('Public Bank')">
                            Public Bank
                        </button>
                        <button type="button" class="bank-btn" onclick="setBankType('CIMB Bank')">
                            CIMB Bank
                        </button>
                    </div>

                    <input type="hidden" id="bankType" name="bankType" value="">

                    <!-- in case of existing bank type, set the value and add the selected class -->
                    <?php if (isset($existingBankType)): ?>
                        <script>
                        document.getElementById('bankType').value = '<?php echo $existingBankType; ?>';
                        let buttons = document.querySelectorAll('.bank-btn');
                        buttons.forEach(button => {
                            if (button.innerText === '<?php echo $existingBankType; ?>') {
                                button.classList.add('selected');
                            }
                        });
                        </script>
                    <?php endif; ?>

                        <label for="bankNumber">Bank Number</label>
                        <input type="text" id="bankNumber" name="bankNumber" value="<?php echo isset($existingBankNumber) ? htmlspecialchars($existingBankNumber) : ''; ?>" placeholder="Enter Bank Number">

                        <label for="basicSalary">Basic Salary</label>
                        <input type="number" id="basicSalary" name="basicSalary" value="<?php echo isset($existingBasicSalary) ? htmlspecialchars($existingBasicSalary) : ''; ?>" placeholder="Enter Basic Salary">

                        <input type="submit" value="Save Salary">
                    </form>


                    <?php
                    // Include database connection
                    $conn = mysqli_connect("localhost", "root", "", "testSalary");

                    if (!$conn) {
                        die("Database connection failed: " . mysqli_connect_error());
                    }

                    // Fetch Salary Details
                    if (isset($id)) {
                        $stmt_salary = $conn->prepare("SELECT basic_salary, bank_type, bank_number FROM salary WHERE staff_id = ? AND basic_salary > 0.00");
                        if (!$stmt_salary) {
                            die("Prepare statement failed: " . $conn->error);
                        }
                        $stmt_salary->bind_param("i", $id);
                        $stmt_salary->execute();
                        $result_salary = $stmt_salary->get_result();

                        $existingBasicSalary = '';
                        $existingBankType = '';
                        $existingBankNumber = '';

                        if ($salary_row = $result_salary->fetch_assoc()) {
                            $existingBasicSalary = $salary_row['basic_salary'];
                            $existingBankType = $salary_row['bank_type'];
                            $existingBankNumber = $salary_row['bank_number'];

                            echo "<p>Current Basic Salary: " . htmlspecialchars($existingBasicSalary) . "</p>";
                            echo "<p>Bank Type: " . htmlspecialchars($existingBankType) . "</p>";
                            echo "<p>Bank Number: " . htmlspecialchars($existingBankNumber) . "</p>";
                        } else {
                            echo "<p>No salary details available for this staff.</p>";
                        }

                        $stmt_salary->close(); // Close the prepared statement
                    } else {
                        echo "<p>Invalid Staff ID.</p>";
                    }

                    // Close the connection at the end of the script
                    mysqli_close($conn);
                    ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Allowance -->
    <button class="ModalBtns" id="AllowanceBtn">Open Allowance Modal</button>
            
        <!-- The Modal -->
        <div id="AllowanceModal" class="modal">

            <!-- Modal content -->
            <div class="modal-content">
            <!-- Allowance Container -->
            <div class="details-container">
            <span class="close">&times;</span>
            <center>
                <h3>Allowance</h3>
            </center>

            <form action="process/process_allowance.php" method="POST">
                <input type="hidden" name="staff_id" value="<?php echo $row['id'] ?>" />
                <label for="allowanceType">Allowance Type</label>

                <section class="btn-container">
                    <div class="allowance-type-buttons">
                        <button type="button" class="allowance-btn" onclick="setAllowanceType('attendance')">
                            Attendance
                        </button>
                        <button type="button" class="allowance-btn" onclick="setAllowanceType('mobile')">
                            Mobile Phone
                        </button>
                        <button type="button" class="allowance-btn" onclick="setAllowanceType('childCare')">
                            Child Care
                        </button>
                        <button type="button" class="allowance-btn" onclick="setAllowanceType('eduAllow')">
                            Education
                        </button>
                        <button type="button" class="allowance-btn" onclick="setAllowanceType('houseAllow')">
                            Housing
                        </button>
                        <button type="button" class="allowance-btn" onclick="setAllowanceType('internAllow')">
                            Internship
                        </button>
                        <button type="button" class="allowance-btn" onclick="setAllowanceType('mealAllow')">
                            Meal
                        </button>
                        <button type="button" class="allowance-btn" onclick="setAllowanceType('otherAllow')">
                            Other
                        </button>
                        <button type="button" class="allowance-btn" onclick="setAllowanceType('parkingAllow')">
                            Parking
                        </button>
                        <button type="button" class="allowance-btn" onclick="setAllowanceType('shiftAllow')">
                            Shift
                        </button>
                        <button type="button" class="allowance-btn" onclick="setAllowanceType('travelOAllow')">
                            Travel (Official)
                        </button>
                        <button type="button" class="allowance-btn" onclick="setAllowanceType('travelPAllow')">
                            Travel (Personnel)
                        </button>
                    </div>
                </section>

                <input type="hidden" id="allowanceType" name="allowanceType" value="">    

                <script>
                <?php if (isset($existingAllowanceType)): ?>
                    document.getElementById('allowanceType').value = '<?php echo $existingAllowanceType; ?>';
                    let buttons = document.querySelectorAll('.allowance-btn');
                    buttons.forEach(button => {
                        if (button.innerText.trim() === '<?php echo $existingAllowanceType; ?>') {
                            button.classList.add('selected');
                        }
                    });
                    <?php endif; ?>
                </script>

                <!-- Unique Amount input field for Allowance -->
                <div id="allowanceAmountField" style="display:show;">
                    <label class="allowanceLabel" for="allowanceAmount">Amount</label>
                    <input type="number" id="allowanceAmount" name="amount" value="<?php echo isset($existingAllowanceAmount) ? htmlspecialchars($existingAllowanceAmount) : ''; ?>" placeholder="Enter Amount">
                </div>

                <input type="submit" value="Save Allowance">
            </form>

            <?php
            // Include database connection
            $conn = mysqli_connect("localhost", "root", "", "testsalary");

            if (!$conn) {
                die("Database connection failed: " . mysqli_connect_error());
            }

            // Fetch Allowance Details
            if (isset($id)) {
                // Fetch all allowance data for the staff
                $stmt_allowance = $conn->prepare("SELECT attendance, mobile, childCare, eduAllow, houseAllow, internAllow, mealAllow, otherAllow, parkingAllow, shiftAllow, travelOAllow, travelPAllow 
                                      FROM allowance WHERE staff_id = ?");
                if (!$stmt_allowance) {
                    die("Prepare statement failed: " . $conn->error);
                }
                $stmt_allowance->bind_param("i", $id);
                $stmt_allowance->execute();
                $result_allowance = $stmt_allowance->get_result();

                $allowances = [
                    'attendance' => 0,
                    'mobile' => 0,
                    'childCare' => 0,
                    'eduAllow' => 0,
                    'houseAllow' => 0,
                    'internAllow' => 0,
                    'mealAllow' => 0,
                    'otherAllow' => 0,
                    'parkingAllow' => 0,
                    'shiftAllow' => 0,
                    'travelOAllow' => 0,
                    'travelPAllow' => 0
                ];

                if ($allowance_row = $result_allowance->fetch_assoc()) {
                    // Store all allowance values that are greater than 0
                    foreach ($allowance_row as $allowance_type => $amount) {
                        if ($amount > 0) {
                            $allowances[$allowance_type] = $amount;
                        }
                    }

                    // Display only the allowances that have a value > 0.00
                    foreach ($allowances as $allowance_type => $amount) {
                        if ($amount > 0) {
                            echo "<p><strong>" . ucfirst(str_replace('Allow', ' Allowance', $allowance_type)) . ":</strong> " . htmlspecialchars($amount) . "</p>";
                        }
                    }
                } else {
                    echo "<p>No allowance details found in the database for this staff.</p>";
                }

                $stmt_allowance->close(); // Close the prepared statement
            } else {
                echo "<p>Invalid Staff ID.</p>";
            }

            // Close the connection at the end of the script
            mysqli_close($conn);
            ?>

            <script>
                function showAllowanceField() {
                    var allowanceType = document.getElementById("allowanceType").value;
                    var allowanceAmountField = document.getElementById("allowanceAmountField");

                    if (allowanceType !== "") {
                        allowanceAmountField.style.display = "block"; // Show the amount input field
                    } else {
                        allowanceAmountField.style.display = "none"; // Hide the amount input field if no selection is made
                    }
                }
            </script>
                
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for Benefit in Kind -->
    <button  class="ModalBtns" id="BikBtn">Open BIK Modal</button>

        <!-- The Modal -->
        <div id="BikModal" class="modal">

            <!-- Modal content -->
            <div class="modal-content">
            <!-- Details Section -->
            <div class="details-section">
                <!-- Salary Container -->
                <div class="details-container">
                <span class="close">&times;</span>
                    <center>
                        <h3>Benefit-In-Kind</h3>
                    </center>
                    <form action="process/process_bik.php" method="POST">
                    <input type="hidden" name="staff_id" value="<?php echo $row['id'] ?>">
                        <label for="bikType">Benefit-In-Kind Type</label>
                        <select id="bikType" name="bikType" onchange="showBikAmountField()">
                            <option value="">Select Benefit-In-Kind Type</option>
                            <option value="consumeDiscBik">Consumable Discount</option>
                            <option value="dentalBik">Dental</option>
                            <option value="driverBik">Driver</option>
                            <option value="fulfillDutiBik">Employee to Fulfill Duties</option>
                            <option value="foodDrinkBik">Food & Drinks</option>
                            <option value="garmentBik">Garments</option>
                            <option value="hElectrikBik">Household Electric Bill</option>
                            <option value="hEntertainBik">Household Entertainment & Recreational</option>
                            <option value="hFurniturBik">Household Furniture & Fittings</option>
                            <option value="hGardenBik">Household Gardener</option>
                            <option value="hKitchenBik">Household Kitchen Equipment</option>
                            <option value="hServantBik">Household Servant/Guard</option>
                            <option value="hTelephoneBik">Household Telephone Bill</option>
                            <option value="hUtilitiBik">Household Utilities</option>
                            <option value="travelMalayBik">Leave Passage Travel (Malaysia)</option>
                            <option value="travelOverBik">Leave Passage Travel (Overseas)</option>
                            <option value="liviAccoBik">Living Accommodation</option>
                            <option value="medicalBik">Medical</option>
                            <option value="otherBik">Other</option>
                            <option value="clubMemberBik">Recreational Club Membership</option>
                            <option value="serviceDiscBik">Service Discount</option>
                            <option value="transportBik">Transportation</option>
                            <option value="motorcarBik">Vehicle/Motorcar</option>
                            <option value="workAccidentBik">Workplace Accident</option>
                        </select>

                        <!-- Unique Amount input field for BIK -->
                        <div id="bikAmountField" style="display:none;">
                            <label for="bikAmount">Amount</label>
                            <input type="number" id="bikAmount" name="amount" placeholder="Enter Amount">
                        </div>

                        <input type="submit" value="Save Benefit-In-Kind">
                    </form>

                    <script>
                        function showBikAmountField() {
                            var bikType = document.getElementById("bikType").value;
                            var bikAmountField = document.getElementById("bikAmountField");

                            if (bikType !== "") {
                                bikAmountField.style.display = "block"; // Show the amount input field
                            } else {
                                bikAmountField.style.display = "none"; // Hide the amount input field if no selection is made
                            }
                        }
                    </script>

                    <?php
                    // Include database connection
                    $conn = mysqli_connect("localhost", "root", "", "testsalary");

                    if (!$conn) {
                        die("Database connection failed: " . mysqli_connect_error());
                    }

                    // Fetch Benefit-In-Kind Details from 'benefit' table
                    if (isset($id)) {
                        // Query to fetch all BIK data from the 'benefit' table
                        $stmt_bik = $conn->prepare("SELECT consumeDiscBik, dentalBik, driverBik, fulfillDutiBik, foodDrinkBik, garmentBik, hElectrikBik, hEntertainBik, hFurniturBik, hGardenBik, hKitchenBik, hServantBik, hTelephoneBik, hUtilitiBik, travelMalayBik, travelOverBik, liviAccoBik, medicalBik, otherBik, clubMemberBik, serviceDiscBik ,transportBik, motorcarBik, workAccidentBik FROM benefit WHERE staff_id = ?");
                        if (!$stmt_bik) {
                            die("Prepare statement failed: " . $conn->error);
                        }
                        $stmt_bik->bind_param("i", $id);
                        $stmt_bik->execute();
                        $result_bik = $stmt_bik->get_result();

                        // Mapping the database column names to user-friendly labels
                        $bikLabels = [
                            'consumeDiscBik' => 'Consumable Discount',
                            'dentalBik' => 'Dental',
                            'driverBik' => 'Driver',
                            'fulfillDutiBik' => 'Employee to Fulfill Duties',
                            'foodDrinkBik' => 'Food & Drinks',
                            'garmentBik' => 'Garments',
                            'hElectrikBik' => 'Household Electric Bill',
                            'hEntertainBik' => 'Household Entertainment & Recreational',
                            'hFurniturBik' => 'Household Furniture & Fittings',
                            'hGardenBik' => 'Household Gardener',
                            'hKitchenBik' => 'Household Kitchen Equipment',
                            'hServantBik' => 'Household Servant/Guard',
                            'hTelephoneBik' => 'Household Telephone Bill',
                            'hUtilitiBik' => 'Household Utilities',
                            'travelMalayBik' => 'Leave Passage Travel (Malaysia)',
                            'travelOverBik' => 'Leave Passage Travel (Overseas)',
                            'liviAccoBik' => 'Living Accommodation',
                            'medicalBik' => 'Medical',
                            'otherBik' => 'Other',
                            'clubMemberBik' => 'Recreational Club Membership',
                            'serviceDiscBik' => 'Service Discount',
                            'transportBik' => 'Transportation',
                            'motorcarBik' => 'Vehicle/Motorcar',
                            'workAccidentBik' => 'Workplace Accident'
                        ];

                        $biks = [];

                        if ($bik_row = $result_bik->fetch_assoc()) {
                            // Store all BIK values that are greater than 0
                            foreach ($bik_row as $bik_type => $amount) {
                                if ($amount > 0) {
                                    $biks[$bik_type] = $amount;
                                }
                            }

                            // Display only the BIKs that have a value > 0.00
                            foreach ($biks as $bik_type => $amount) {
                                if ($amount > 0) {
                                    // Display the friendly name using the label
                                    echo "<p><strong>" . $bikLabels[$bik_type] . ":</strong> " . htmlspecialchars($amount) . "</p>";
                                }
                            }
                        } else {
                            echo "<p>No Benefit-In-Kind details found for this staff.</p>";
                        }

                        $stmt_bik->close(); // Close the prepared statement
                    } else {
                        echo "<p>Invalid Staff ID.</p>";
                    }

                    // Close the connection at the end of the script
                    mysqli_close($conn);
                    ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal for salary -->
    <button  class="ModalBtns" id="DeductionBtn">Open Deduction Modal</button>

    <!-- The Modal -->
    <div id="DeductionModal" class="modal">

        <!-- Modal content -->
        <div class="modal-content">
            <!-- Details Section -->
            <div class="details-section">
            <!-- Deduction Container -->
            <div class="details-container">
            <span class="close">&times;</span>
                <center>
                    <h3>Deduction</h3>
                </center>
                <form action="process/process_deduct.php" method="POST">
                <input type="hidden" name="staff_id" value="<?php echo $row['id'] ?>">
                    <label for="deductionType">Deduction Type</label>
                    <select id="deductionType" name="deductionType" onchange="showDeductionField()">
                        <option value="">Select Deduction Type</option>
                        <option value="advPayDeduct">Advance Payment</option>
                        <option value="basicSuppDeduct">Basic Supporting Equipment</option>
                        <option value="cp38Deduct">CP38(Tax Deduction Order)</option>
                        <option value="dentalDeduct">Dental Examination</option>
                        <option value="departureDeduct">Departure Levy(Pilgrimage)</option>
                        <option value="domTourisDeduct">Domestic Tourism Expenditure</option>
                        <option value="earlyDeduct">Early Intervention(Learning Disabilities)</option>
                        <option value="eduDeduct">Education & Medical Insurance</option>
                        <option value="hrdfDeduct">Employer HRDF Levy(Custom)</option>
                        <option value="epfEmployeeDeduct">EPF Employee Contribution</option>
                        <option value="epfEmployerDeduct">EPF Employer Contribution</option>
                        <option value="evDeduct">EV Charging</option>
                        <option value="fatherDeduct">Father Relief</option>
                        <option value="childCare">Child Care Centre Fees</option>
                        <option value="highEduDeduct">Higher Education Fees</option>
                        <option value="housLoanDeduct">Interest On Housing Loan</option>
                        <option value="insuranceDeduct">Levy Insurance</option>
                        <option value="lifeInsDeduct">Life Insurance</option>
                        <option value="lifestyleDeduct">Lifestyle Relief</option>
                        <option value="lifestyleCompDeduct">Lifestyle Relief(Computer)</option>
                        <option value="loanDeduct">Loan</option>
                        <option value="medicalDeduct">Medical Examination</option>
                        <option value="medicalParentDeduct">Medical Examination Parent</option>
                        <option value="medicalSeriousDeduct">Medical Expenses On Serious Disease</option>
                        <option value="medicalTreatDeduct">Medical Treatment, Special Needs, or Carer Expenses of Parents</option>
                        <option value="motherDeduct">Mother Relief</option>
                        <option value="netSSPNDeduct">Net Deposit in SSPN</option>
                        <option value="netSalaryDeduct">Net Salary</option>
                        <option value="formerWifeDeduct">Payment of Alimony to Former Wife</option>
                        <option value="retiredDeduct">Private Retirement Scheme</option>
                        <option value="ptptnDeduct">PTPTN Repayment</option>
                        <option value="breastDeduct">Purchase of Breastfeeding Equipment</option>
                        <option value="salaryAdjDeduct">Salary Adjustment</option>
                        <option value="sportDeduct">Sport Relief</option>
                        <option value="upskilDeduct">Upskiling Course Fees</option>
                        <option value="vaccineDeduct">Vaccination Expenses</option>
                        <option value="withTaxDeduct">Withholding Tax</option>
                    </select>

                    <!-- Unique Amount input field for Deduction -->
                    <div id="deductionAmountField" style="display:none;">
                        <label for="deductionAmount">Amount</label>
                        <input type="number" id="deductionAmount" name="amount" placeholder="Enter Amount">
                    </div>

                    <input type="submit" value="Save Deduction">
                </form>

                <script>
                    function showDeductionField() {
                        var deductionType = document.getElementById("deductionType").value;
                        var deductionAmountField = document.getElementById("deductionAmountField");

                        if (deductionType !== "") {
                            deductionAmountField.style.display = "block"; // Show the amount input field
                        } else {
                            deductionAmountField.style.display = "none"; // Hide the amount input field if no selection is made
                        }
                    }
                </script>

                <?php
                // Include database connection
                $conn = mysqli_connect("localhost", "root", "", "testsalary");

                if (!$conn) {
                    die("Database connection failed: " . mysqli_connect_error());
                }

                // Fetch Deduction Details from 'deduction' table
                if (isset($id)) {
                    // Query to fetch all Deduction data from the 'deduction' table
                    $stmt_deduct = $conn->prepare("SELECT advPayDeduct, basicSuppDeduct, cp38Deduct, dentalDeduct, departureDeduct, domTourisDeduct, earlyDeduct, eduDeduct, hrdfDeduct, epfEmployeeDeduct, epfEmployerDeduct, evDeduct, fatherDeduct, childCare, highEduDeduct, housLoanDeduct, insuranceDeduct, lifeInsDeduct, lifestyleDeduct, lifestyleCompDeduct, loanDeduct, medicalDeduct, medicalParentDeduct, medicalSeriousDeduct, medicalTreatDeduct, motherDeduct, netSSPNDeduct, netSalaryDeduct, formerWifeDeduct, retiredDeduct, ptptnDeduct, breastDeduct, salaryAdjDeduct, sportDeduct, upskilDeduct, vaccineDeduct, withTaxDeduct FROM deduction WHERE staff_id = ?");
                    if (!$stmt_deduct) {
                        die("Prepare statement failed: " . $conn->error);
                    }
                    $stmt_deduct->bind_param("i", $id);
                    $stmt_deduct->execute();
                    $result_deduct = $stmt_deduct->get_result();

                    // Mapping the database column names to user-friendly labels
                    $deductionLabels = [
                        'advPayDeduct' => 'Advance Payment',
                        'basicSuppDeduct' => 'Basic Supporting Equipment',
                        'cp38Deduct' => 'CP38 (Tax Deduction Order)',
                        'dentalDeduct' => 'Dental Examination',
                        'departureDeduct' => 'Departure Levy (Pilgrimage)',
                        'domTourisDeduct' => 'Domestic Tourism Expenditure',
                        'earlyDeduct' => 'Early Intervention (Learning Disabilities)',
                        'eduDeduct' => 'Education & Medical Insurance',
                        'hrdfDeduct' => 'Employer HRDF Levy (Custom)',
                        'epfEmployeeDeduct' => 'EPF Employee Contribution',
                        'epfEmployerDeduct' => 'EPF Employer Contribution',
                        'evDeduct' => 'EV Charging',
                        'fatherDeduct' => 'Father Relief',
                        'childCare' => 'Child Care Centre Fees',
                        'highEduDeduct' => 'Higher Education Fees',
                        'housLoanDeduct' => 'Interest on Housing Loan',
                        'insuranceDeduct' => 'Levy Insurance',
                        'lifeInsDeduct' => 'Life Insurance',
                        'lifestyleDeduct' => 'Lifestyle Relief',
                        'lifestyleCompDeduct' => 'Lifestyle Relief (Computer)',
                        'loanDeduct' => 'Loan',
                        'medicalDeduct' => 'Medical Examination',
                        'medicalParentDeduct' => 'Medical Examination (Parent)',
                        'medicalSeriousDeduct' => 'Medical Expenses on Serious Disease',
                        'medicalTreatDeduct' => 'Medical Treatment, Special Needs, or Carer Expenses of Parents',
                        'motherDeduct' => 'Mother Relief',
                        'netSSPNDeduct' => 'Net Deposit in SSPN',
                        'netSalaryDeduct' => 'Net Salary',
                        'formerWifeDeduct' => 'Payment of Alimony to Former Wife',
                        'retiredDeduct' => 'Private Retirement Scheme',
                        'ptptnDeduct' => 'PTPTN Repayment',
                        'breastDeduct' => 'Purchase of Breastfeeding Equipment',
                        'salaryAdjDeduct' => 'Salary Adjustment',
                        'sportDeduct' => 'Sport Relief',
                        'upskilDeduct' => 'Upskilling Course Fees',
                        'vaccineDeduct' => 'Vaccination Expenses',
                        'withTaxDeduct' => 'Withholding Tax'
                    ];

                    $deductions = [];

                    if ($deduct_row = $result_deduct->fetch_assoc()) {
                        // Store all deduction values that are greater than 0
                        foreach ($deduct_row as $deduct_type => $amount) {
                            if ($amount > 0) {
                                $deductions[$deduct_type] = $amount;
                            }
                        }

                        // Display only the deductions that have a value > 0.00
                        foreach ($deductions as $deduct_type => $amount) {
                            if ($amount > 0) {
                                // Display the friendly name using the label
                                echo "<p><strong>" . $deductionLabels[$deduct_type] . ":</strong> " . htmlspecialchars($amount) . "</p>";
                            }
                        }
                    } else {
                        echo "<p>No Deduction details found for this staff.</p>";
                    }

                    $stmt_deduct->close(); // Close the prepared statement
                } else {
                    echo "<p>Invalid Staff ID.</p>";
                }

                // Close the connection at the end of the script
                mysqli_close($conn);
                ?>



                    </div>
                </div>
            </div>
        </div>

    <!-- Modal for renumeration -->
    <button  class="ModalBtns" id="RenumBtn">Open Renumeration Modal</button>

        <!-- The Modal -->
        <div id="RenumModal" class="modal">

            <!-- Modal content -->
            <div class="modal-content">
            <!-- Details Section -->
            <div class="details-section">
                <!-- Salary Container -->
                <div class="details-container">
                <span class="close">&times;</span>
                    <center>
                        <h3>Remuneration</h3>
                    </center>
                    <form action="process/process_remuneration.php" method="POST">
                    <input type="hidden" name="staff_id" value="<?php echo $row['id'] ?>">
                        <label for="remunerationType">Remuneration Type</label>
                        <select id="remunerationType" name="remunerationType" onchange="showRemunerationField()">
                            <option value="">Select Remuneration Type</option>
                            <option value="advPayRemu">Advance Payment</option>
                            <option value="arrearsRemu">Arrears of Wages</option>
                            <option value="bonusRemu">Bonus</option>
                            <option value="commissionRemu">Commission</option>
                            <option value="compensationRemu">Compensation</option>
                            <option value="directorRemu">Director's Fee</option>
                            <option value="claimRemu">Expenses Claims</option>
                            <option value="gratuityRemu">Gratuity (End of Service Period)</option>
                            <option value="incentiveRemu">Incentive</option>
                            <option value="leavePayRemu">Leave Pay</option>
                            <option value="otNormRemu">Overtime (Normal)</option>
                            <option value="otOffRemu">Overtime (Offday)</option>
                            <option value="otPublicRemu">Overtime (Public Holiday)</option>
                            <option value="pcbPastRemu">PCB Borne By Employer In Previous Year</option>
                            <option value="profitRemu">Profit Sharing</option>
                            <option value="servRemu">Service Charges (Incl. Tips)</option>
                            <option value="severanceRemu">Severance</option>
                        </select>

                        <!-- Unique Amount input field for Remuneration -->
                        <div id="remunerationAmountField" style="display:none;">
                            <label for="remunerationAmount">Amount</label>
                            <input type="number" id="remunerationAmount" name="amount" placeholder="Enter Amount">
                        </div>

                        <input type="submit" value="Save Remuneration">
                    </form>

                    <script>
                        function showRemunerationField() {
                            var remunerationType = document.getElementById("remunerationType").value;
                            var remunerationAmountField = document.getElementById("remunerationAmountField");

                            if (remunerationType !== "") {
                                remunerationAmountField.style.display = "block"; // Show the amount input field
                            } else {
                                remunerationAmountField.style.display = "none"; // Hide the amount input field if no selection is made
                            }
                        }
                    </script>

                    <?php
                    // Include database connection
                    $conn = mysqli_connect("localhost", "root", "", "testsalary");

                    if (!$conn) {
                        die("Database connection failed: " . mysqli_connect_error());
                    }

                    // Fetch Remuneration Details from 'remuneration' table
                    if (isset($id)) {
                        // Query to fetch all remuneration data from the 'remuneration' table
                        $stmt_remu = $conn->prepare("SELECT advPayRemu, arrearsRemu, bonusRemu, commissionRemu, compensationRemu, directorRemu, claimRemu, gratuityRemu, incentiveRemu, leavePayRemu, otNormRemu, otOffRemu, otPublicRemu, pcbPastRemu, profitRemu, servRemu, severanceRemu FROM remuneration WHERE staff_id = ?");
                        if (!$stmt_remu) {
                            die("Prepare statement failed: " . $conn->error);
                        }
                        $stmt_remu->bind_param("i", $id);
                        $stmt_remu->execute();
                        $result_remu = $stmt_remu->get_result();

                        // Mapping the database column names to user-friendly labels
                        $remunerationLabels = [
                            'advPayRemu' => 'Advance Payment',
                            'arrearsRemu' => 'Arrears of Wages',
                            'bonusRemu' => 'Bonus',
                            'commissionRemu' => 'Commission',
                            'compensationRemu' => 'Compensation',
                            'directorRemu' => 'Director\'s Fee',
                            'claimRemu' => 'Expenses Claims',
                            'gratuityRemu' => 'Gratuity (End of Service Period)',
                            'incentiveRemu' => 'Incentive',
                            'leavePayRemu' => 'Leave Pay',
                            'otNormRemu' => 'Overtime (Normal)',
                            'otOffRemu' => 'Overtime (Offday)',
                            'otPublicRemu' => 'Overtime (Public Holiday)',
                            'pcbPastRemu' => 'PCB Borne By Employer In Previous Year',
                            'profitRemu' => 'Profit Sharing',
                            'servRemu' => 'Service Charges (Incl. Tips)',
                            'severanceRemu' => 'Severance'
                        ];

                        $remunerations = [];

                        if ($remu_row = $result_remu->fetch_assoc()) {
                            // Store all remuneration values that are greater than 0
                            foreach ($remu_row as $remu_type => $amount) {
                                if ($amount > 0) {
                                    $remunerations[$remu_type] = $amount;
                                }
                            }

                            // Display only the remunerations that have a value > 0.00
                            foreach ($remunerations as $remu_type => $amount) {
                                if ($amount > 0) {
                                    // Display the friendly name using the label
                                    echo "<p><strong>" . $remunerationLabels[$remu_type] . ":</strong> " . htmlspecialchars($amount) . "</p>";
                                }
                            }
                        } else {
                            echo "<p>No Remuneration details found for this staff.</p>";
                        }

                        $stmt_remu->close(); // Close the prepared statement
                    } else {
                        echo "<p>Invalid Staff ID.</p>";
                    }

                    // Close the connection at the end of the script
                    mysqli_close($conn);
                    ?>

                    </div>
                </div>
            </div>
        </div>

    <!-- Modal for Prerequisites -->
    <button  class="ModalBtns" id="PrequisitesBtn">Open Prequisites Modal</button>

        <!-- The Modal -->
        <div id="PrequisitesModal" class="modal">

        <!-- Modal content -->
        <div class="modal-content">

        <div class="details-container">
        <span class="close">&times;</span>
            <center>
                <h3>Perquisites</h3>
            </center>
            <form action="process/process_perquisites.php" method="POST">
            <input type="hidden" name="staff_id" value="<?php echo $row['id'] ?>">
                <label for="perquisitesType">Perquisites Type</label>
                <select id="perquisitesType" name="perquisitesType" onchange="showPerquisitesField()">
                    <option value="">Select Perquisites Type</option>
                    <option value="mobilePerk">Mobile Phone</option>
                    <option value="carPerk">Car Maintenance</option>
                    <option value="creditcardPerk">Credit Card (Personal Use)</option>
                    <option value="voucherPerk">Gift Voucher</option>
                    <option value="houseUtilsPerk">Household Utilities</option>
                    <option value="houseLoanPerk">Housing Loan Interest</option>
                    <option value="parkingPerk">Parking Fees</option>
                    <option value="computerPerk">Personal Computer</option>
                    <option value="proSubscriptPerk">Professional Subscriptions</option>
                    <option value="clubMemberPerk">Recreational Club Membership</option>
                    <option value="roadtaxPerk">Road Tax</option>
                    <option value="awardPerk">Service Excellence, Innovation or Productivity Award</option>
                    <option value="shareSchemePerk">Share Option Scheme</option>
                </select>

                <!-- Unique Amount input field for Perquisites -->
                <div id="perquisitesAmountField" style="display:none;">
                    <label for="perquisitesAmount">Amount</label>
                    <input type="number" id="perquisitesAmount" name="amount" placeholder="Enter Amount" required>
                </div>

                <input type="submit" value="Save Perquisites">
            </form>

            <script>
                function showPerquisitesField() {
                    var perquisitesType = document.getElementById("perquisitesType").value;
                    var perquisitesAmountField = document.getElementById("perquisitesAmountField");

                    // Show or hide the amount input field based on the selection
                    perquisitesAmountField.style.display = perquisitesType !== "" ? "block" : "none";
                }
            </script>

            <?php
            // Include database connection
            $conn = mysqli_connect("localhost", "root", "", "testsalary");

            if (!$conn) {
                die("Database connection failed: " . mysqli_connect_error());
            }

            // Fetch Perquisites Details from 'perquisites' table
            if (isset($id)) {
                // Query to fetch all perquisites data from the 'perquisites' table
                $stmt_perk = $conn->prepare("SELECT mobilePerk, carPerk, creditcardPerk, voucherPerk, houseUtilsPerk, houseLoanPerk, parkingPerk, computerPerk, proSubscriptPerk, clubMemberPerk, roadtaxPerk, awardPerk, shareSchemePerk FROM perquisites WHERE staff_id = ?");
                if (!$stmt_perk) {
                    die("Prepare statement failed: " . $conn->error);
                }
                $stmt_perk->bind_param("i", $id);
                $stmt_perk->execute();
                $result_perk = $stmt_perk->get_result();

                // Mapping the database column names to user-friendly labels
                $perquisitesLabels = [
                    'mobilePerk' => 'Mobile Phone',
                    'carPerk' => 'Car Maintenance',
                    'creditcardPerk' => 'Credit Card (Personal Use)',
                    'voucherPerk' => 'Gift Voucher',
                    'houseUtilsPerk' => 'Household Utilities',
                    'houseLoanPerk' => 'Housing Loan Interest',
                    'parkingPerk' => 'Parking Fees',
                    'computerPerk' => 'Personal Computer',
                    'proSubscriptPerk' => 'Professional Subscriptions',
                    'clubMemberPerk' => 'Recreational Club Membership',
                    'roadtaxPerk' => 'Road Tax',
                    'awardPerk' => 'Service Excellence, Innovation or Productivity Award',
                    'shareSchemePerk' => 'Share Option Scheme'
                ];

                $perquisites = [];

                if ($perk_row = $result_perk->fetch_assoc()) {
                    // Store all perquisites values that are greater than 0
                    foreach ($perk_row as $perk_type => $amount) {
                        if ($amount > 0) {
                            $perquisites[$perk_type] = $amount;
                        }
                    }

                    // Display only the perquisites that have a value > 0.00
                    foreach ($perquisites as $perk_type => $amount) {
                        if ($amount > 0) {
                            // Display the friendly name using the label
                            echo "<p><strong>" . $perquisitesLabels[$perk_type] . ":</strong> " . htmlspecialchars($amount) . "</p>";
                        }
                    }
                } else {
                    echo "<p>No Perquisites details found for this staff.</p>";
                }

                $stmt_perk->close(); // Close the prepared statement
            } else {
                echo "<p>Invalid Staff ID.</p>";
            }

            // Close the connection at the end of the script
            mysqli_close($conn);
            ?>

            <script src="modals.js"></script>

        </div>
    </div>
</body>

</html>