<?php
// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve and sanitize POST data
    $disabledIndividual = isset($_POST['disabledIndividual']) ? (int)$_POST['disabledIndividual'] : 0;
    $maritalStatus = isset($_POST['maritalStatus']) ? htmlspecialchars($_POST['maritalStatus']) : '';
    $disabledHusbandWife = isset($_POST['disabledHusbandWife']) ? (int)$_POST['disabledHusbandWife'] : 0;
    $unChild = isset($_POST['unChild']) ? (int)$_POST['unChild'] : 0;
    $ftChild = isset($_POST['ftChild']) ? (int)$_POST['ftChild'] : 0;
    $dipChild = isset($_POST['dipChild']) ? (int)$_POST['dipChild'] : 0;
    $degChild = isset($_POST['degChild']) ? (int)$_POST['degChild'] : 0;
    $disChild = isset($_POST['disChild']) ? (int)$_POST['disChild'] : 0;
    $dis2Child = isset($_POST['dis2Child']) ? (int)$_POST['dis2Child'] : 0;
    $accumulatedRemuneration = isset($_POST['accumulatedRemuneration']) ? (float)$_POST['accumulatedRemuneration'] : 0.0;
    $accumulatedEpf = isset($_POST['accumulatedEpf']) ? (float)$_POST['accumulatedEpf'] : 0.0;
    $accumulatedPcb = isset($_POST['accumulatedPcb']) ? (float)$_POST['accumulatedPcb'] : 0.0;
    $accumulatedEis = isset($_POST['accumulatedEis']) ? (float)$_POST['accumulatedEis'] : 0.0;
    $accumulatedSocso = isset($_POST['accumulatedSocso']) ? (float)$_POST['accumulatedSocso'] : 0.0;
    $pcb = isset($_POST['pcb']) ? (float)$_POST['pcb'] : 0.0;
    $annualTax = isset($_POST['annual_tax']) ? (float)$_POST['annual_tax'] : 0.0;

    // Echo the values
    echo "Disabled Individual: $disabledIndividual<br>";
    echo "Marital Status: $maritalStatus<br>";
    echo "Disabled Spouse: $disabledHusbandWife<br>";
    echo "Under Aged Child: $unChild<br>";
    echo "Above 18 Full-time Study: $ftChild<br>";
    echo "Diploma Level: $dipChild<br>";
    echo "Degree Level: $degChild<br>";
    echo "Disabled Child: $disChild<br>";
    echo "Disabled and Study in IPT: $dis2Child<br>";
    echo "Accumulated Remuneration: $accumulatedRemuneration<br>";
    echo "Accumulated EPF: $accumulatedEpf<br>";
    echo "Accumulated PCB: $accumulatedPcb<br>";
    echo "Accumulated EIS: $accumulatedEis<br>";
    echo "Accumulated SOCSO: $accumulatedSocso<br>";
    echo "PCB: $pcb<br>";
    echo "Annual Tax: $annualTax<br>";
}
?>

<?php
include 'db.php';

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if($disabledIndividual == 6000){
    $disabledIndividual = 1;
}else{
    $disabledIndividual = 0;
}

if($disabledHusbandWife == 5000){
    $disabledHusbandWife = 1;
}else{
    $disabledHusbandWife = 0;
}

$staffId = $_POST['staff_id'];

$sql = "SELECT * FROM staff_bio WHERE staff_id = $staffId";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    
    // Update existing record
    $sql = "UPDATE staff_bio SET 
            spouse_status = '$maritalStatus',
            spouse_disabled = $disabledHusbandWife,
            children_full_time = $ftChild,
            children_disabled = $disChild,
            children_disabled_FT = $dis2Child,
            children_underage = $unChild,
            accum_Renum = $accumulatedRemuneration,
            accum_EPF = $accumulatedEpf,
            accum_PCB = $accumulatedPcb,
            accum_EIS = $accumulatedEis,
            accum_SOCSO = $accumulatedSocso,
            disable = $disabledIndividual
            WHERE staff_id = $staffId";
} else {
    // Insert new record
    $sql = "INSERT INTO staff_bio (staff_id, spouse_status, spouse_disabled, children_full_time, children_disabled, children_disabled_FT, children_underage, accum_Renum, accum_EPF, accum_PCB, accum_EIS, accum_SOCSO, disable) 
            VALUES ($staffId, '$maritalStatus', $disabledHusbandWife, $ftChild, $disChild, $dis2Child, $unChild, $accumulatedRemuneration, $accumulatedEpf, $accumulatedPcb, $accumulatedEis, $accumulatedSocso, $disabledIndividual)";
}

if ($conn->query($sql) === TRUE) {
    echo "
    
    <script>
        alert('Record updated/inserted successfully');
        history.back();
    </script>
    
    ";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>