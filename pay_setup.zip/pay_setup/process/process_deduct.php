<?php
// Include your database connection
include('db.php'); // Adjust the path based on where your db.php is located

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $deductionType = $_POST['deductionType']; // The type of deduction (e.g., 'advPayDeduct')
    $amount = $_POST['amount'];

    // Start session to get the staff ID (ensure staff is logged in)
    session_start();
    $staffId = $_POST['staff_id']; // Get the staff_id from the form submission

    // Check if all necessary fields are filled
    if (!empty($deductionType) && !empty($amount)) {

        // Ensure the amount is a valid number
        if (!filter_var($amount, FILTER_VALIDATE_FLOAT)) {
            echo "<script>
                alert('Invalid amount. Please enter a valid number.');
                window.history.back();
            </script>";
            exit();
        }

        // Ensure the deduction type exists as a column in the `deduction` table
        $validDeductionTypes = [
            'advPayDeduct',
            'basicSuppDeduct',
            'cp38Deduct',
            'dentalDeduct',
            'departureDeduct',
            'domTourisDeduct',
            'earlyDeduct',
            'eduDeduct',
            'hrdfDeduct',
            'epfEmployeeDeduct',
            'epfEmployerDeduct',
            'evDeduct',
            'fatherDeduct',
            'childCare',
            'highEduDeduct',
            'housLoanDeduct',
            'insuranceDeduct',
            'lifeInsDeduct',
            'lifestyleDeduct',
            'lifestyleCompDeduct',
            'loanDeduct',
            'medicalDeduct',
            'medicalParentDeduct',
            'medicalSeriousDeduct',
            'medicalTreatDeduct',
            'motherDeduct',
            'netSSPNDeduct',
            'netSalaryDeduct',
            'formerWifeDeduct',
            'retiredDeduct',
            'ptptnDeduct',
            'breastDeduct',
            'salaryAdjDeduct',
            'sportDeduct',
            'upskilDeduct',
            'vaccineDeduct',
            'withTaxDeduct'
        ];

        if (!in_array($deductionType, $validDeductionTypes)) {
            echo "<script>
                alert('Invalid deduction type.');
                window.history.back();
            </script>";
            exit();
        }

        // Check if the deduction record already exists in the `deduction` table for this type and staff
        $sql_check = "SELECT * FROM deduction WHERE staff_id = ? AND {$deductionType} IS NOT NULL";
        if ($stmt_check = $conn->prepare($sql_check)) {
            $stmt_check->bind_param("i", $staffId);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();

            if ($result_check->num_rows > 0) {
                // Record exists, update the existing deduction record
                $sql_update = "UPDATE deduction SET {$deductionType} = ? WHERE staff_id = ?";
                if ($stmt_update = $conn->prepare($sql_update)) {
                    $stmt_update->bind_param("di", $amount, $staffId);
                    if ($stmt_update->execute()) {
                        echo "<script>
                            alert('Deduction updated successfully.');
                            window.history.back(); // Go back to the previous page
                        </script>";
                    } else {
                        echo "<script>
                            alert('Error updating deduction: " . $stmt_update->error . "');
                            window.history.back();
                        </script>";
                    }
                    $stmt_update->close();
                } else {
                    echo "<script>
                        alert('Error preparing the update query: " . $conn->error . "');
                        window.history.back();
                    </script>";
                }
            } else {
                // No record found, insert a new deduction record
                $sql_insert = "INSERT INTO deduction (staff_id, {$deductionType}) VALUES (?, ?)";
                if ($stmt_insert = $conn->prepare($sql_insert)) {
                    $stmt_insert->bind_param("id", $staffId, $amount);
                    if ($stmt_insert->execute()) {
                        echo "<script>
                            alert('Deduction added successfully.');
                            window.history.back(); // Go back to the previous page
                        </script>";
                    } else {
                        echo "<script>
                            alert('Error inserting deduction: " . $stmt_insert->error . "');
                            window.history.back();
                        </script>";
                    }
                    $stmt_insert->close();
                } else {
                    echo "<script>
                        alert('Error preparing the insert query: " . $conn->error . "');
                        window.history.back();
                    </script>";
                }
            }

            $stmt_check->close();
        } else {
            echo "<script>
                alert('Error preparing the check query: " . $conn->error . "');
                window.history.back();
            </script>";
        }
    } else {
        echo "<script>
            alert('Please fill in all fields.');
            window.history.back();
        </script>";
    }
}

// Close database connection
$conn->close();
