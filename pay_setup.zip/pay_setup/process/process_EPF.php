<?php include('db.php'); // Adjust the path based on where your db.php is located ?>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $totalAccountedEPF = is_numeric($_POST['totalAccountedEPF']) ? (float)$_POST['totalAccountedEPF'] : 0;
    $staffId = $_POST['staff_id'];

    // Define EPF contribution rates based on the provided table
    $epfRates = [
        ['max' => 10, 'epf' => 3, 'epfCon' => 3],
        ['max' => 20, 'epf' => 5, 'epfCon' => 6],
        ['max' => 40, 'epf' => 7, 'epfCon' => 8],
        ['max' => 60, 'epf' => 9, 'epfCon' => 11],
        ['max' => 80, 'epf' => 11, 'epfCon' => 13],
        ['max' => 100, 'epf' => 14, 'epfCon' => 16],
        ['max' => 120, 'epf' => 16, 'epfCon' => 19],
        ['max' => 140, 'epf' => 18, 'epfCon' => 21],
        ['max' => 160, 'epf' => 20, 'epfCon' => 24],
        ['max' => 180, 'epf' => 22, 'epfCon' => 26],
        ['max' => 200, 'epf' => 25, 'epfCon' => 29],
        ['max' => 220, 'epf' => 27, 'epfCon' => 32],
        ['max' => 240, 'epf' => 29, 'epfCon' => 34],
        ['max' => 260, 'epf' => 31, 'epfCon' => 37],
        ['max' => 280, 'epf' => 33, 'epfCon' => 39],
        ['max' => 300, 'epf' => 36, 'epfCon' => 42],
        ['max' => 320, 'epf' => 38, 'epfCon' => 45],
        ['max' => 340, 'epf' => 40, 'epfCon' => 47],
        ['max' => 360, 'epf' => 42, 'epfCon' => 50],
        ['max' => 380, 'epf' => 44, 'epfCon' => 52],
        ['max' => 400, 'epf' => 47, 'epfCon' => 55],
        ['max' => 420, 'epf' => 49, 'epfCon' => 58],
        ['max' => 440, 'epf' => 51, 'epfCon' => 60],
        ['max' => 460, 'epf' => 53, 'epfCon' => 63],
        ['max' => 480, 'epf' => 55, 'epfCon' => 65],
        ['max' => 500, 'epf' => 58, 'epfCon' => 68],
        ['max' => 520, 'epf' => 60, 'epfCon' => 71],
        ['max' => 540, 'epf' => 62, 'epfCon' => 73],
        ['max' => 560, 'epf' => 64, 'epfCon' => 76],
        ['max' => 580, 'epf' => 66, 'epfCon' => 78],
        ['max' => 600, 'epf' => 69, 'epfCon' => 81],
        ['max' => 620, 'epf' => 71, 'epfCon' => 84],
        ['max' => 640, 'epf' => 73, 'epfCon' => 86],
        ['max' => 660, 'epf' => 75, 'epfCon' => 89],
        ['max' => 680, 'epf' => 77, 'epfCon' => 91],
        ['max' => 700, 'epf' => 80, 'epfCon' => 94],
        ['max' => 720, 'epf' => 82, 'epfCon' => 97],
        ['max' => 740, 'epf' => 84, 'epfCon' => 99],
        ['max' => 760, 'epf' => 86, 'epfCon' => 102],
        ['max' => 780, 'epf' => 88, 'epfCon' => 104],
        ['max' => 800, 'epf' => 91, 'epfCon' => 107],
        ['max' => 820, 'epf' => 93, 'epfCon' => 110],
        ['max' => 840, 'epf' => 95, 'epfCon' => 112],
        ['max' => 860, 'epf' => 97, 'epfCon' => 115],
        ['max' => 880, 'epf' => 99, 'epfCon' => 117],
        ['max' => 900, 'epf' => 102, 'epfCon' => 120],
        ['max' => 920, 'epf' => 104, 'epfCon' => 123],
        ['max' => 940, 'epf' => 106, 'epfCon' => 125],
        ['max' => 960, 'epf' => 108, 'epfCon' => 128],
        ['max' => 980, 'epf' => 110, 'epfCon' => 130],
        ['max' => 1000, 'epf' => 113, 'epfCon' => 133],
        ['max' => 1020, 'epf' => 115, 'epfCon' => 136],
        ['max' => 1040, 'epf' => 117, 'epfCon' => 138],
        ['max' => 1060, 'epf' => 119, 'epfCon' => 141],
        ['max' => 1080, 'epf' => 121, 'epfCon' => 143],
        ['max' => 1100, 'epf' => 124, 'epfCon' => 146],
        ['max' => 1120, 'epf' => 126, 'epfCon' => 149],
        ['max' => 1140, 'epf' => 128, 'epfCon' => 151],
        ['max' => 1160, 'epf' => 130, 'epfCon' => 154],
        ['max' => 1180, 'epf' => 132, 'epfCon' => 156],
        ['max' => 1200, 'epf' => 135, 'epfCon' => 159],
        ['max' => 1220, 'epf' => 137, 'epfCon' => 162],
        ['max' => 1240, 'epf' => 139, 'epfCon' => 164],
        ['max' => 1260, 'epf' => 141, 'epfCon' => 167],
        ['max' => 1280, 'epf' => 143, 'epfCon' => 169],
        ['max' => 1300, 'epf' => 146, 'epfCon' => 172],
        ['max' => 1320, 'epf' => 148, 'epfCon' => 175],
        ['max' => 1340, 'epf' => 150, 'epfCon' => 177],
        ['max' => 1360, 'epf' => 152, 'epfCon' => 180],
        ['max' => 1380, 'epf' => 154, 'epfCon' => 182],
        ['max' => 1400, 'epf' => 157, 'epfCon' => 185],
        ['max' => 1420, 'epf' => 159, 'epfCon' => 188],
        ['max' => 1440, 'epf' => 161, 'epfCon' => 190],
        ['max' => 1460, 'epf' => 163, 'epfCon' => 193],
        ['max' => 1480, 'epf' => 165, 'epfCon' => 195],
        ['max' => 1500, 'epf' => 168, 'epfCon' => 198],
        ['max' => 1520, 'epf' => 170, 'epfCon' => 201],
        ['max' => 1540, 'epf' => 172, 'epfCon' => 203],
        ['max' => 1560, 'epf' => 174, 'epfCon' => 206],
        ['max' => 1580, 'epf' => 176, 'epfCon' => 208],
        ['max' => 1600, 'epf' => 179, 'epfCon' => 211],
        ['max' => 1620, 'epf' => 181, 'epfCon' => 214],
        ['max' => 1640, 'epf' => 183, 'epfCon' => 216],
        ['max' => 1660, 'epf' => 185, 'epfCon' => 219],
        ['max' => 1680, 'epf' => 187, 'epfCon' => 221],
        ['max' => 1700, 'epf' => 190, 'epfCon' => 224],
        ['max' => 1720, 'epf' => 192, 'epfCon' => 227],
        ['max' => 1740, 'epf' => 194, 'epfCon' => 229],
        ['max' => 1760, 'epf' => 196, 'epfCon' => 232],
        ['max' => 1780, 'epf' => 198, 'epfCon' => 234],
        ['max' => 1800, 'epf' => 201, 'epfCon' => 237],
        ['max' => 1820, 'epf' => 203, 'epfCon' => 240],
        ['max' => 1840, 'epf' => 205, 'epfCon' => 242],
        ['max' => 1860, 'epf' => 207, 'epfCon' => 245],
        ['max' => 1880, 'epf' => 209, 'epfCon' => 247],
        ['max' => 1900, 'epf' => 212, 'epfCon' => 250],
        ['max' => 1920, 'epf' => 214, 'epfCon' => 253],
        ['max' => 1940, 'epf' => 216, 'epfCon' => 255],
        ['max' => 1960, 'epf' => 218, 'epfCon' => 258],
        ['max' => 1980, 'epf' => 220, 'epfCon' => 260],
        ['max' => 2000, 'epf' => 223, 'epfCon' => 263],
        ['max' => 2020, 'epf' => 225, 'epfCon' => 266],
        ['max' => 2040, 'epf' => 227, 'epfCon' => 268],
        ['max' => 2060, 'epf' => 229, 'epfCon' => 271],
        ['max' => 2080, 'epf' => 231, 'epfCon' => 273],
        ['max' => 2100, 'epf' => 234, 'epfCon' => 276],
        ['max' => 2120, 'epf' => 236, 'epfCon' => 279],
        ['max' => 2140, 'epf' => 238, 'epfCon' => 281],
        ['max' => 2160, 'epf' => 240, 'epfCon' => 284],
        ['max' => 2180, 'epf' => 242, 'epfCon' => 286],
        ['max' => 2200, 'epf' => 245, 'epfCon' => 289],
        ['max' => 2220, 'epf' => 247, 'epfCon' => 292],
        ['max' => 2240, 'epf' => 249, 'epfCon' => 294],
        ['max' => 2260, 'epf' => 251, 'epfCon' => 297],
        ['max' => 2280, 'epf' => 253, 'epfCon' => 299],
        ['max' => 2300, 'epf' => 256, 'epfCon' => 302],
        ['max' => 2320, 'epf' => 258, 'epfCon' => 305],
        ['max' => 2340, 'epf' => 260, 'epfCon' => 307],
        ['max' => 2360, 'epf' => 262, 'epfCon' => 310],
        ['max' => 2380, 'epf' => 264, 'epfCon' => 312],
        ['max' => 2400, 'epf' => 267, 'epfCon' => 315],
        ['max' => 2420, 'epf' => 269, 'epfCon' => 318],
        ['max' => 2440, 'epf' => 271, 'epfCon' => 320],
        ['max' => 2460, 'epf' => 273, 'epfCon' => 323],
        ['max' => 2480, 'epf' => 275, 'epfCon' => 325],
        ['max' => 2500, 'epf' => 278, 'epfCon' => 328],
        ['max' => 2520, 'epf' => 280, 'epfCon' => 331],
        ['max' => 2540, 'epf' => 282, 'epfCon' => 333],
        ['max' => 2560, 'epf' => 284, 'epfCon' => 336],
        ['max' => 2580, 'epf' => 286, 'epfCon' => 338],
        ['max' => 2600, 'epf' => 289, 'epfCon' => 341],
        ['max' => 2620, 'epf' => 291, 'epfCon' => 344],
        ['max' => 2640, 'epf' => 293, 'epfCon' => 346],
        ['max' => 2660, 'epf' => 295, 'epfCon' => 349],
        ['max' => 2680, 'epf' => 297, 'epfCon' => 351],
        ['max' => 2700, 'epf' => 300, 'epfCon' => 354],
        ['max' => 2720, 'epf' => 302, 'epfCon' => 357],
        ['max' => 2740, 'epf' => 304, 'epfCon' => 359],
        ['max' => 2760, 'epf' => 306, 'epfCon' => 362],
        ['max' => 2780, 'epf' => 308, 'epfCon' => 364],
        ['max' => 2800, 'epf' => 311, 'epfCon' => 367],
        ['max' => 2820, 'epf' => 313, 'epfCon' => 370],
        ['max' => 2840, 'epf' => 315, 'epfCon' => 372],
        ['max' => 2860, 'epf' => 317, 'epfCon' => 375],
        ['max' => 2880, 'epf' => 319, 'epfCon' => 377],
        ['max' => 2900, 'epf' => 322, 'epfCon' => 380],
        ['max' => 2920, 'epf' => 324, 'epfCon' => 383],
        ['max' => 2940, 'epf' => 326, 'epfCon' => 385],
        ['max' => 2960, 'epf' => 328, 'epfCon' => 388],
        ['max' => 2980, 'epf' => 330, 'epfCon' => 390],
        ['max' => 3000, 'epf' => 333, 'epfCon' => 393],
        ['max' => 3020, 'epf' => 335, 'epfCon' => 396],
        ['max' => 3040, 'epf' => 337, 'epfCon' => 398],
        ['max' => 3060, 'epf' => 339, 'epfCon' => 401],
        ['max' => 3080, 'epf' => 341, 'epfCon' => 403],
        ['max' => 3100, 'epf' => 344, 'epfCon' => 406],
        ['max' => 3120, 'epf' => 346, 'epfCon' => 409],
        ['max' => 3140, 'epf' => 348, 'epfCon' => 411],
        ['max' => 3160, 'epf' => 350, 'epfCon' => 414],
        ['max' => 3180, 'epf' => 352, 'epfCon' => 416],
        ['max' => 3200, 'epf' => 355, 'epfCon' => 419],
        ['max' => 3220, 'epf' => 357, 'epfCon' => 422],
        ['max' => 3240, 'epf' => 359, 'epfCon' => 424],
        ['max' => 3260, 'epf' => 361, 'epfCon' => 427],
        ['max' => 3280, 'epf' => 363, 'epfCon' => 429],
        ['max' => 3300, 'epf' => 366, 'epfCon' => 432],
        ['max' => 3320, 'epf' => 368, 'epfCon' => 435],
        ['max' => 3340, 'epf' => 370, 'epfCon' => 437],
        ['max' => 3360, 'epf' => 372, 'epfCon' => 440],
        ['max' => 3380, 'epf' => 374, 'epfCon' => 442],
        ['max' => 3400, 'epf' => 377, 'epfCon' => 445],
        ['max' => 3420, 'epf' => 379, 'epfCon' => 448],
        ['max' => 3440, 'epf' => 381, 'epfCon' => 450],
        ['max' => 3460, 'epf' => 383, 'epfCon' => 453],
        ['max' => 3480, 'epf' => 385, 'epfCon' => 455],
        ['max' => 3500, 'epf' => 388, 'epfCon' => 458],
        ['max' => 3520, 'epf' => 390, 'epfCon' => 461],
        ['max' => 3540, 'epf' => 392, 'epfCon' => 463],
        ['max' => 3560, 'epf' => 394, 'epfCon' => 466],
        ['max' => 3580, 'epf' => 396, 'epfCon' => 468],
        ['max' => 3600, 'epf' => 399, 'epfCon' => 471],
        ['max' => 3620, 'epf' => 401, 'epfCon' => 474],
        ['max' => 3640, 'epf' => 403, 'epfCon' => 476],
        ['max' => 3660, 'epf' => 405, 'epfCon' => 479],
        ['max' => 3680, 'epf' => 407, 'epfCon' => 481],
        ['max' => 3700, 'epf' => 410, 'epfCon' => 484],
        ['max' => 3720, 'epf' => 412, 'epfCon' => 487],
        ['max' => 3740, 'epf' => 414, 'epfCon' => 489],
        ['max' => 3760, 'epf' => 416, 'epfCon' => 492],
        ['max' => 3780, 'epf' => 418, 'epfCon' => 494],
        ['max' => 3800, 'epf' => 421, 'epfCon' => 497],
        ['max' => 3820, 'epf' => 423, 'epfCon' => 500],
        ['max' => 3840, 'epf' => 425, 'epfCon' => 502],
        ['max' => 3860, 'epf' => 427, 'epfCon' => 505],
        ['max' => 3880, 'epf' => 429, 'epfCon' => 507],
        ['max' => 3900, 'epf' => 432, 'epfCon' => 510],
        ['max' => 3920, 'epf' => 434, 'epfCon' => 513],
        ['max' => 3940, 'epf' => 436, 'epfCon' => 515],
        ['max' => 3960, 'epf' => 438, 'epfCon' => 518],
        ['max' => 3980, 'epf' => 440, 'epfCon' => 520],
        ['max' => 4000, 'epf' => 443, 'epfCon' => 523],
        ['max' => 4020, 'epf' => 445, 'epfCon' => 526],
        ['max' => 4040, 'epf' => 447, 'epfCon' => 528],
        ['max' => 4060, 'epf' => 449, 'epfCon' => 531],
        ['max' => 4080, 'epf' => 451, 'epfCon' => 533],
        ['max' => 4100, 'epf' => 454, 'epfCon' => 536],
        ['max' => 4120, 'epf' => 456, 'epfCon' => 539],
        ['max' => 4140, 'epf' => 458, 'epfCon' => 541],
        ['max' => 4160, 'epf' => 460, 'epfCon' => 544],
        ['max' => 4180, 'epf' => 462, 'epfCon' => 546],
        ['max' => 4200, 'epf' => 465, 'epfCon' => 549],
        ['max' => 4220, 'epf' => 467, 'epfCon' => 552],
        ['max' => 4240, 'epf' => 469, 'epfCon' => 554],
        ['max' => 4260, 'epf' => 471, 'epfCon' => 557],
        ['max' => 4280, 'epf' => 473, 'epfCon' => 559],
        ['max' => 4300, 'epf' => 476, 'epfCon' => 562],
        ['max' => 4320, 'epf' => 478, 'epfCon' => 565],
        ['max' => 4340, 'epf' => 480, 'epfCon' => 567],
        ['max' => 4360, 'epf' => 482, 'epfCon' => 570],
        ['max' => 4380, 'epf' => 484, 'epfCon' => 572],
        ['max' => 4400, 'epf' => 487, 'epfCon' => 575],
        ['max' => 4420, 'epf' => 489, 'epfCon' => 578],
        ['max' => 4440, 'epf' => 491, 'epfCon' => 580],
        ['max' => 4460, 'epf' => 493, 'epfCon' => 583],
        ['max' => 4480, 'epf' => 495, 'epfCon' => 585],
        ['max' => 4500, 'epf' => 498, 'epfCon' => 588],
        ['max' => 4520, 'epf' => 500, 'epfCon' => 591],
        ['max' => 4540, 'epf' => 502, 'epfCon' => 593],
        ['max' => 4560, 'epf' => 504, 'epfCon' => 596],
        ['max' => 4580, 'epf' => 506, 'epfCon' => 598],
        ['max' => 4600, 'epf' => 509, 'epfCon' => 601],
        ['max' => 4620, 'epf' => 511, 'epfCon' => 604],
        ['max' => 4640, 'epf' => 513, 'epfCon' => 606],
        ['max' => 4660, 'epf' => 515, 'epfCon' => 609],
        ['max' => 4680, 'epf' => 517, 'epfCon' => 611],
        ['max' => 4700, 'epf' => 520, 'epfCon' => 614],
        ['max' => 4720, 'epf' => 522, 'epfCon' => 617],
        ['max' => 4740, 'epf' => 524, 'epfCon' => 619],
        ['max' => 4760, 'epf' => 526, 'epfCon' => 622],
        ['max' => 4780, 'epf' => 528, 'epfCon' => 624],
        ['max' => 4800, 'epf' => 531, 'epfCon' => 627],
        ['max' => 4820, 'epf' => 533, 'epfCon' => 630],
        ['max' => 4840, 'epf' => 535, 'epfCon' => 632],
        ['max' => 4860, 'epf' => 537, 'epfCon' => 635],
        ['max' => 4880, 'epf' => 539, 'epfCon' => 637],
        ['max' => 4900, 'epf' => 542, 'epfCon' => 640],
        ['max' => 4920, 'epf' => 544, 'epfCon' => 643],
        ['max' => 4940, 'epf' => 546, 'epfCon' => 645],
        ['max' => 4960, 'epf' => 548, 'epfCon' => 648],
        ['max' => 4980, 'epf' => 550, 'epfCon' => 650],
        ['max' => 5000, 'epf' => 561, 'epfCon' => 612],
        ['max' => 5100, 'epf' => 572, 'epfCon' => 624],
        ['max' => 5200, 'epf' => 583, 'epfCon' => 636],
        ['max' => 5300, 'epf' => 594, 'epfCon' => 648],
        ['max' => 5400, 'epf' => 605, 'epfCon' => 660],
        ['max' => 5500, 'epf' => 616, 'epfCon' => 672],
        ['max' => 5600, 'epf' => 627, 'epfCon' => 684],
        ['max' => 5700, 'epf' => 638, 'epfCon' => 696],
        ['max' => 5800, 'epf' => 649, 'epfCon' => 708],
        ['max' => 5900, 'epf' => 660, 'epfCon' => 720],
        ['max' => 6000, 'epf' => 671, 'epfCon' => 732],
        ['max' => 6100, 'epf' => 682, 'epfCon' => 744],
        ['max' => 6200, 'epf' => 693, 'epfCon' => 756],
        ['max' => 6300, 'epf' => 704, 'epfCon' => 768],
        ['max' => 6400, 'epf' => 715, 'epfCon' => 780],
        ['max' => 6500, 'epf' => 726, 'epfCon' => 792],
        ['max' => 6600, 'epf' => 737, 'epfCon' => 804],
        ['max' => 6700, 'epf' => 748, 'epfCon' => 816],
        ['max' => 6800, 'epf' => 759, 'epfCon' => 828],
        ['max' => 6900, 'epf' => 770, 'epfCon' => 840],
        ['max' => 7000, 'epf' => 781, 'epfCon' => 852],
        ['max' => 7100, 'epf' => 792, 'epfCon' => 864],
        ['max' => 7200, 'epf' => 803, 'epfCon' => 876],
        ['max' => 7300, 'epf' => 814, 'epfCon' => 888],
        ['max' => 7400, 'epf' => 825, 'epfCon' => 900],
        ['max' => 7500, 'epf' => 836, 'epfCon' => 912],
        ['max' => 7600, 'epf' => 847, 'epfCon' => 924],
        ['max' => 7700, 'epf' => 858, 'epfCon' => 936],
        ['max' => 7800, 'epf' => 869, 'epfCon' => 948],
        ['max' => 7900, 'epf' => 880, 'epfCon' => 960],
        ['max' => 8000, 'epf' => 891, 'epfCon' => 972],
        ['max' => 8100, 'epf' => 902, 'epfCon' => 984],
        ['max' => 8200, 'epf' => 913, 'epfCon' => 996],
        ['max' => 8300, 'epf' => 924, 'epfCon' => 1008],
        ['max' => 8400, 'epf' => 935, 'epfCon' => 1020],
        ['max' => 8500, 'epf' => 946, 'epfCon' => 1032],
        ['max' => 8600, 'epf' => 957, 'epfCon' => 1044],
        ['max' => 8700, 'epf' => 968, 'epfCon' => 1056],
        ['max' => 8800, 'epf' => 979, 'epfCon' => 1068],
        ['max' => 8900, 'epf' => 990, 'epfCon' => 1080],
        ['max' => 9000, 'epf' => 1001, 'epfCon' => 1092],
        ['max' => 9100, 'epf' => 1012, 'epfCon' => 1104],
        ['max' => 9200, 'epf' => 1023, 'epfCon' => 1116],
        ['max' => 9300, 'epf' => 1034, 'epfCon' => 1128],
        ['max' => 9400, 'epf' => 1045, 'epfCon' => 1140],
        ['max' => 9500, 'epf' => 1056, 'epfCon' => 1152],
        ['max' => 9600, 'epf' => 1067, 'epfCon' => 1164],
        ['max' => 9700, 'epf' => 1078, 'epfCon' => 1176],
        ['max' => 9800, 'epf' => 1089, 'epfCon' => 1188],
        ['max' => 9900, 'epf' => 1100, 'epfCon' => 1200],
        ['max' => 10000, 'epf' => 1111, 'epfCon' => 1212],
        ['max' => 10100, 'epf' => 1122, 'epfCon' => 1224],
        ['max' => 10200, 'epf' => 1133, 'epfCon' => 1236],
        ['max' => 10300, 'epf' => 1144, 'epfCon' => 1248],
        ['max' => 10400, 'epf' => 1155, 'epfCon' => 1260],
        ['max' => 10500, 'epf' => 1166, 'epfCon' => 1272],
        ['max' => 10600, 'epf' => 1177, 'epfCon' => 1284],
        ['max' => 10700, 'epf' => 1188, 'epfCon' => 1296],
        ['max' => 10800, 'epf' => 1199, 'epfCon' => 1308],
        ['max' => 10900, 'epf' => 1210, 'epfCon' => 1320],
        ['max' => 11000, 'epf' => 1221, 'epfCon' => 1332],
        ['max' => 11100, 'epf' => 1232, 'epfCon' => 1344],
        ['max' => 11200, 'epf' => 1243, 'epfCon' => 1356],
        ['max' => 11300, 'epf' => 1254, 'epfCon' => 1368],
        ['max' => 11400, 'epf' => 1265, 'epfCon' => 1380],
        ['max' => 11500, 'epf' => 1276, 'epfCon' => 1392],
        ['max' => 11600, 'epf' => 1287, 'epfCon' => 1404],
        ['max' => 11700, 'epf' => 1298, 'epfCon' => 1416],
        ['max' => 11800, 'epf' => 1309, 'epfCon' => 1428],
        ['max' => 11900, 'epf' => 1320, 'epfCon' => 1440],
        ['max' => 12000, 'epf' => 1331, 'epfCon' => 1452],
        ['max' => 12100, 'epf' => 1342, 'epfCon' => 1464],
        ['max' => 12200, 'epf' => 1353, 'epfCon' => 1476],
        ['max' => 12300, 'epf' => 1364, 'epfCon' => 1488],
        ['max' => 12400, 'epf' => 1375, 'epfCon' => 1500],
        ['max' => 12500, 'epf' => 1386, 'epfCon' => 1512],
        ['max' => 12600, 'epf' => 1397, 'epfCon' => 1524],
        ['max' => 12700, 'epf' => 1408, 'epfCon' => 1536],
        ['max' => 12800, 'epf' => 1419, 'epfCon' => 1548],
        ['max' => 12900, 'epf' => 1430, 'epfCon' => 1560],
        ['max' => 13000, 'epf' => 1441, 'epfCon' => 1572],
        ['max' => 13100, 'epf' => 1452, 'epfCon' => 1584],
        ['max' => 13200, 'epf' => 1463, 'epfCon' => 1596],
        ['max' => 13300, 'epf' => 1474, 'epfCon' => 1608],
        ['max' => 13400, 'epf' => 1485, 'epfCon' => 1620],
        ['max' => 13500, 'epf' => 1496, 'epfCon' => 1632],
        ['max' => 13600, 'epf' => 1507, 'epfCon' => 1644],
        ['max' => 13700, 'epf' => 1518, 'epfCon' => 1656],
        ['max' => 13800, 'epf' => 1529, 'epfCon' => 1668],
        ['max' => 13900, 'epf' => 1540, 'epfCon' => 1680],
        ['max' => 14000, 'epf' => 1551, 'epfCon' => 1692],
        ['max' => 14100, 'epf' => 1562, 'epfCon' => 1704],
        ['max' => 14200, 'epf' => 1573, 'epfCon' => 1716],
        ['max' => 14300, 'epf' => 1584, 'epfCon' => 1728],
        ['max' => 14400, 'epf' => 1595, 'epfCon' => 1740],
        ['max' => 14500, 'epf' => 1606, 'epfCon' => 1752],
        ['max' => 14600, 'epf' => 1617, 'epfCon' => 1764],
        ['max' => 14700, 'epf' => 1628, 'epfCon' => 1776],
        ['max' => 14800, 'epf' => 1639, 'epfCon' => 1788],
        ['max' => 14900, 'epf' => 1650, 'epfCon' => 1800],
        ['max' => 15000, 'epf' => 1661, 'epfCon' => 1812],
        ['max' => 15100, 'epf' => 1672, 'epfCon' => 1824],
        ['max' => 15200, 'epf' => 1683, 'epfCon' => 1836],
        ['max' => 15300, 'epf' => 1694, 'epfCon' => 1848],
        ['max' => 15400, 'epf' => 1705, 'epfCon' => 1860],
        ['max' => 15500, 'epf' => 1716, 'epfCon' => 1872],
        ['max' => 15600, 'epf' => 1727, 'epfCon' => 1884],
        ['max' => 15700, 'epf' => 1738, 'epfCon' => 1896],
        ['max' => 15800, 'epf' => 1749, 'epfCon' => 1908],
        ['max' => 15900, 'epf' => 1760, 'epfCon' => 1920],
        ['max' => 16000, 'epf' => 1771, 'epfCon' => 1932],
        ['max' => 16100, 'epf' => 1782, 'epfCon' => 1944],
        ['max' => 16200, 'epf' => 1793, 'epfCon' => 1956],
        ['max' => 16300, 'epf' => 1804, 'epfCon' => 1968],
        ['max' => 16400, 'epf' => 1815, 'epfCon' => 1980],
        ['max' => 16500, 'epf' => 1826, 'epfCon' => 1992],
        ['max' => 16600, 'epf' => 1837, 'epfCon' => 2004],
        ['max' => 16700, 'epf' => 1848, 'epfCon' => 2016],
        ['max' => 16800, 'epf' => 1859, 'epfCon' => 2028],
        ['max' => 16900, 'epf' => 1870, 'epfCon' => 2040],
        ['max' => 17000, 'epf' => 1881, 'epfCon' => 2052],
        ['max' => 17100, 'epf' => 1892, 'epfCon' => 2064],
        ['max' => 17200, 'epf' => 1903, 'epfCon' => 2076],
        ['max' => 17300, 'epf' => 1914, 'epfCon' => 2088],
        ['max' => 17400, 'epf' => 1925, 'epfCon' => 2100],
        ['max' => 17500, 'epf' => 1936, 'epfCon' => 2112],
        ['max' => 17600, 'epf' => 1947, 'epfCon' => 2124],
        ['max' => 17700, 'epf' => 1958, 'epfCon' => 2136],
        ['max' => 17800, 'epf' => 1969, 'epfCon' => 2148],
        ['max' => 17900, 'epf' => 1980, 'epfCon' => 2160],
        ['max' => 18000, 'epf' => 1991, 'epfCon' => 2172],
        ['max' => 18100, 'epf' => 2002, 'epfCon' => 2184],
        ['max' => 18200, 'epf' => 2013, 'epfCon' => 2196],
        ['max' => 18300, 'epf' => 2024, 'epfCon' => 2208],
        ['max' => 18400, 'epf' => 2035, 'epfCon' => 2220],
        ['max' => 18500, 'epf' => 2046, 'epfCon' => 2232],
        ['max' => 18600, 'epf' => 2057, 'epfCon' => 2244],
        ['max' => 18700, 'epf' => 2068, 'epfCon' => 2256],
        ['max' => 18800, 'epf' => 2079, 'epfCon' => 2268],
        ['max' => 18900, 'epf' => 2090, 'epfCon' => 2280],
        ['max' => 19000, 'epf' => 2101, 'epfCon' => 2292],
        ['max' => 19100, 'epf' => 2112, 'epfCon' => 2304],
        ['max' => 19200, 'epf' => 2123, 'epfCon' => 2316],
        ['max' => 19300, 'epf' => 2134, 'epfCon' => 2328],
        ['max' => 19400, 'epf' => 2145, 'epfCon' => 2340],
        ['max' => 19500, 'epf' => 2156, 'epfCon' => 2352],
        ['max' => 19600, 'epf' => 2167, 'epfCon' => 2364],
        ['max' => 19700, 'epf' => 2178, 'epfCon' => 2376],
        ['max' => 19800, 'epf' => 2189, 'epfCon' => 2388],
        ['max' => 19900, 'epf' => 2200, 'epfCon' => 2400],
        ['max' => PHP_INT_MAX, 'epf' => function($totalAccountedEPF) { return ceil($totalAccountedEPF * 0.11); }, 'epfCon' => function($totalAccountedEPF) { return ceil($totalAccountedEPF * 0.12); }]
    ];

    // Calculate EPF contributions based on the totalAccountedEPF
    $employeeEPF = 0;
    $employerEPF = 0;
    foreach ($epfRates as $rate) {
        if ($totalAccountedEPF <= $rate['max']) {
            if (is_callable($rate['epf'])) {
                $employeeEPF = $rate['epf']($totalAccountedEPF);
                $employerEPF = $rate['epfCon']($totalAccountedEPF);
            } else {
                $employeeEPF = $rate['epf'];
                $employerEPF = $rate['epfCon'];
            }
            break;
        }
    }

    // Check if a record already exists for the given staff_id
    $sql_check_existing = "SELECT COUNT(*) FROM deduction WHERE staff_id = ?";
    if ($stmt_check_existing = $conn->prepare($sql_check_existing)) {
        $stmt_check_existing->bind_param("i", $staffId);
        $stmt_check_existing->execute();
        $stmt_check_existing->bind_result($count);
        $stmt_check_existing->fetch();
        $stmt_check_existing->close();

        if ($count > 0) {
            // Update existing record
            $sql_update_deduction = "UPDATE deduction SET epfEmployeeDeduct = ?, epfEmployerDeduct = ? WHERE staff_id = ?";
            if ($stmt_update_deduction = $conn->prepare($sql_update_deduction)) {
                $stmt_update_deduction->bind_param("ddi", $employeeEPF, $employerEPF, $staffId);
                if ($stmt_update_deduction->execute()) {
                    echo "
                    
                    <script>
                        alert('EPF contributions updated successfully in deduction table.');
                        location.replace('../view_staff.php?id=$staffId');
                    </script>
                    
                    ";

                } else {
                    echo "
                    <script>
                        alert('Error updating EPF contributions in deduction table: ' . $stmt_update_deduction->error);
                        location.history.back();
                    </script>
                    
                    ";
                }
                $stmt_update_deduction->close();
            } else {
                echo "<p>Error preparing update statement: " . $conn->error . "</p>
                window.history.back();";
            }
        } else {
            // Insert new record
            $sql_insert_deduction = "INSERT INTO deduction (staff_id, epfEmployeeDeduct, epfEmployerDeduct) VALUES (?, ?, ?)";
            if ($stmt_insert_deduction = $conn->prepare($sql_insert_deduction)) {
                $stmt_insert_deduction->bind_param("idd", $staffId, $employeeEPF, $employerEPF);
                if ($stmt_insert_deduction->execute()) {
                    echo "<script>
                        alert('Error updating EPF contributions in deduction table: ' . $stmt_insert_deduction->error);
                        location.history.back();
                    </script>";
                } else {
                    echo "<script>
                        alert('Error updating EPF contributions in deduction table: ' . $stmt_insert_deduction->error);
                        location.history.back();
                    </script>";
                }
                $stmt_insert_deduction->close();
            } else {
                echo "
                <script>
                    alert('Error preparing insert statement: ' . $conn->error);
                    window.history.back();
                </script>";
            }
        }
    } else {
        echo "<script>
            alert('Error preparing check statement: ' . $conn->error);
            window.history.back();
            </script>";
    }
}
?>