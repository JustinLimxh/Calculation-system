<?php
// Include your database connection
include('db.php'); // Adjust the path based on where your db.php is located

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Start session to get the staff ID
    session_start();
    $staffId = $_SESSION['staff_id'] ?? 1; // Default to 1 if staff_id is not set in the session

    // Get form data
    $bankType = $_POST['bankType'] ?? '';
    $bankNumber = $_POST['bankNumber'] ?? '';
    $basicSalary = $_POST['basicSalary'] ?? 0.00;

    // Validate input
    if (empty($bankType) || empty($bankNumber) || empty($basicSalary)) {
        echo "<script>
            alert('Please fill in all fields.');
            window.history.back();
        </script>";
        exit();
    }

    // Check if the basic salary is a valid number
    if (!filter_var($basicSalary, FILTER_VALIDATE_FLOAT)) {
        echo "<script>
            alert('Invalid salary amount. Please enter a valid number.');
            window.history.back();
        </script>";
        exit();
    }

    // Check if the bank number is valid (you can add more specific validation)
    if (!preg_match("/^\d+$/", $bankNumber)) {
        echo "<script>
            alert('Invalid bank number. Please enter a valid number.');
            window.history.back();
        </script>";
        exit();
    }

    // Use prepared statements to check if the salary record already exists
    $sql_check = "SELECT * FROM salary WHERE staff_id = ?";
    if ($stmt_check = $conn->prepare($sql_check)) {
        $stmt_check->bind_param("i", $staffId);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

        if ($result_check->num_rows > 0) {
            // Update existing salary record
            $sql_update = "UPDATE salary SET bank_type = ?, bank_number = ?, basic_salary = ? WHERE staff_id = ?";
            if ($stmt_update = $conn->prepare($sql_update)) {
                $stmt_update->bind_param("ssdi", $bankType, $bankNumber, $basicSalary, $staffId);
                if ($stmt_update->execute()) {
                    echo "<script>
                        alert('Salary information updated successfully.');
                        window.history.back();
                    </script>";
                } else {
                    echo "<script>
                        alert('Error updating salary information: " . $stmt_update->error . "');
                        window.history.back();
                    </script>";
                }
                $stmt_update->close();
            } else {
                echo "<script>
                    alert('Error preparing the update query: " . $conn->error . "');
                    window.history.back();
                </script>";
            }
        } else {
            // Insert new salary record if no record exists for the given staff ID
            $sql_insert = "INSERT INTO salary (staff_id, bank_type, bank_number, basic_salary) VALUES (?, ?, ?, ?)";
            if ($stmt_insert = $conn->prepare($sql_insert)) {
                $stmt_insert->bind_param("issd", $staffId, $bankType, $bankNumber, $basicSalary);
                if ($stmt_insert->execute()) {
                    echo "<script>
                        alert('Salary information saved successfully.');
                        window.history.back();
                    </script>";
                } else {
                    echo "<script>
                        alert('Error saving salary information: " . $stmt_insert->error . "');
                        window.history.back();
                    </script>";
                }
                $stmt_insert->close();
            } else {
                echo "<script>
                    alert('Error preparing the insert query: " . $conn->error . "');
                    window.history.back();
                </script>";
            }
        }

        $stmt_check->close();
    } else {
        echo "<script>
            alert('Error preparing the check query: " . $conn->error . "');
            window.history.back();
        </script>";
    }
}

// Close database connection
$conn->close();
