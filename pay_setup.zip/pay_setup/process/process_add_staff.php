<?php
// Include the database connection
include('db.php');

if (!$conn) {
    die("Database connection failed: " . mysqli_connect_error());
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Capture and sanitize the form data
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    // Validation
    $errors = [];

    if (empty($name)) {
        $errors[] = "Name is required.";
    }

    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "A valid email is required.";
    }

    if (empty($password)) {
        $errors[] = "Password is required.";
    }

    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match.";
    }

    if (empty($errors)) {
        // Check if email already exists using a prepared statement
        $checkEmailQuery = "SELECT id FROM staff WHERE email = ?";
        $stmt = $conn->prepare($checkEmailQuery);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $errors[] = "Email already exists.";
        }

        $stmt->close();

        if (empty($errors)) {
            // Hash the password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Insert into database using a prepared statement
            $insertQuery = "INSERT INTO staff (name, email, password) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($insertQuery);
            $stmt->bind_param("sss", $name, $email, $hashedPassword);

            if ($stmt->execute()) {
                echo "<script>
                    alert('Staff added successfully!');
                    window.location.href = '../add_staff.php';
                </script>";
            } else {
                echo "<script>
                    alert('Error adding staff: " . $stmt->error . "');
                    window.location.href = '../add_staff.php';
                </script>";
            }

            $stmt->close();
        }
    }

    if (!empty($errors)) {
        foreach ($errors as $error) {
            echo "<script>
                alert('$error');
                window.history.back();
            </script>";
        }
    }
}

mysqli_close($conn);
