<?php 
include('db.php'); // Adjust the path based on where your db.php is located 

// Ensure the database connection is established
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $totalAccountedSOCSO = is_numeric($_POST['totalAccountedSocso']) ? (float)$_POST['totalAccountedSocso'] : 0;
    $staffId = $_POST['staff_id'];

    // Define SOCSO contribution rates based on the provided table
    $socsoRates = [
        ['max' => 0.01, 'socso' => 0.10, 'socsoCon' => 0.40],
        ['max' => 30.01, 'socso' => 0.20, 'socsoCon' => 0.70],
        ['max' => 50.01, 'socso' => 0.30, 'socsoCon' => 1.10],
        ['max' => 70.01, 'socso' => 0.40, 'socsoCon' => 1.50],
        ['max' => 100.01, 'socso' => 0.60, 'socsoCon' => 2.10],
        ['max' => 140.01, 'socso' => 0.85, 'socsoCon' => 2.95],
        ['max' => 200.01, 'socso' => 1.25, 'socsoCon' => 4.35],
        ['max' => 300.01, 'socso' => 1.75, 'socsoCon' => 6.15],
        ['max' => 400.01, 'socso' => 2.25, 'socsoCon' => 7.85],
        ['max' => 500.01, 'socso' => 2.75, 'socsoCon' => 9.65],
        ['max' => 600.01, 'socso' => 3.25, 'socsoCon' => 11.35],
        ['max' => 700.01, 'socso' => 3.75, 'socsoCon' => 13.15],
        ['max' => 800.01, 'socso' => 4.25, 'socsoCon' => 14.85],
        ['max' => 900.01, 'socso' => 4.75, 'socsoCon' => 16.65],
        ['max' => 1000.01, 'socso' => 5.25, 'socsoCon' => 18.35],
        ['max' => 1100.01, 'socso' => 5.75, 'socsoCon' => 20.15],
        ['max' => 1200.01, 'socso' => 6.25, 'socsoCon' => 21.85],
        ['max' => 1300.01, 'socso' => 6.75, 'socsoCon' => 23.65],
        ['max' => 1400.01, 'socso' => 7.25, 'socsoCon' => 25.35],
        ['max' => 1500.01, 'socso' => 7.75, 'socsoCon' => 27.15],
        ['max' => 1600.01, 'socso' => 8.25, 'socsoCon' => 28.85],
        ['max' => 1700.01, 'socso' => 8.75, 'socsoCon' => 30.65],
        ['max' => 1800.01, 'socso' => 9.25, 'socsoCon' => 32.35],
        ['max' => 1900.01, 'socso' => 9.75, 'socsoCon' => 34.15],
        ['max' => 2000.01, 'socso' => 10.25, 'socsoCon' => 35.85],
        ['max' => 2100.01, 'socso' => 10.75, 'socsoCon' => 37.65],
        ['max' => 2200.01, 'socso' => 11.25, 'socsoCon' => 39.35],
        ['max' => 2300.01, 'socso' => 11.75, 'socsoCon' => 41.15],
        ['max' => 2400.01, 'socso' => 12.25, 'socsoCon' => 42.85],
        ['max' => 2500.01, 'socso' => 12.75, 'socsoCon' => 44.65],
        ['max' => 2600.01, 'socso' => 13.25, 'socsoCon' => 46.35],
        ['max' => 2700.01, 'socso' => 13.75, 'socsoCon' => 48.15],
        ['max' => 2800.01, 'socso' => 14.25, 'socsoCon' => 49.85],
        ['max' => 2900.01, 'socso' => 14.75, 'socsoCon' => 51.65],
        ['max' => 3000.01, 'socso' => 15.25, 'socsoCon' => 53.35],
        ['max' => 3100.01, 'socso' => 15.75, 'socsoCon' => 55.15],
        ['max' => 3200.01, 'socso' => 16.25, 'socsoCon' => 56.85],
        ['max' => 3300.01, 'socso' => 16.75, 'socsoCon' => 58.65],
        ['max' => 3400.01, 'socso' => 17.25, 'socsoCon' => 60.35],
        ['max' => 3500.01, 'socso' => 17.75, 'socsoCon' => 62.15],
        ['max' => 3600.01, 'socso' => 18.25, 'socsoCon' => 63.85],
        ['max' => 3700.01, 'socso' => 18.75, 'socsoCon' => 65.65],
        ['max' => 3800.01, 'socso' => 19.25, 'socsoCon' => 67.35],
        ['max' => 3900.01, 'socso' => 19.75, 'socsoCon' => 69.15],
        ['max' => 4000.01, 'socso' => 20.25, 'socsoCon' => 70.85],
        ['max' => 4100.01, 'socso' => 20.75, 'socsoCon' => 72.65],
        ['max' => 4200.01, 'socso' => 21.25, 'socsoCon' => 74.35],
        ['max' => 4300.01, 'socso' => 21.75, 'socsoCon' => 76.15],
        ['max' => 4400.01, 'socso' => 22.25, 'socsoCon' => 77.85],
        ['max' => 4500.01, 'socso' => 22.75, 'socsoCon' => 79.65],
        ['max' => 4600.01, 'socso' => 23.25, 'socsoCon' => 81.35],
        ['max' => 4700.01, 'socso' => 23.75, 'socsoCon' => 83.15],
        ['max' => 4800.01, 'socso' => 24.25, 'socsoCon' => 84.85],
        ['max' => 4900.01, 'socso' => 24.75, 'socsoCon' => 86.65],
        ['max' => 5000.01, 'socso' => 25.25, 'socsoCon' => 88.35],
        ['max' => 5100.01, 'socso' => 25.75, 'socsoCon' => 90.15],
        ['max' => 5200.01, 'socso' => 26.25, 'socsoCon' => 91.85],
        ['max' => 5300.01, 'socso' => 26.75, 'socsoCon' => 93.65],
        ['max' => 5400.01, 'socso' => 27.25, 'socsoCon' => 95.35],
        ['max' => 5500.01, 'socso' => 27.75, 'socsoCon' => 97.15],
        ['max' => 5600.01, 'socso' => 28.25, 'socsoCon' => 98.85],
        ['max' => 5700.01, 'socso' => 28.75, 'socsoCon' => 100.65],
        ['max' => 5800.01, 'socso' => 29.25, 'socsoCon' => 102.35],
        ['max' => PHP_FLOAT_MAX, 'socso' => 29.25, 'socsoCon' => 102.35]
    ];

    

    // Calculate SOCSO contributions based on the totalAccountedSOCSO
    $employeeSOCSO = 0;
    $employerSOCSO = 0;
    foreach ($socsoRates as $rate) {
        if ($totalAccountedSOCSO <= $rate['max']) {
            $employeeSOCSO = $rate['socso'];
            $employerSOCSO = $rate['socsoCon'];
            break;
        }
    }

    // Check if a record already exists for the given staff_id
    $sql_check_existing = "SELECT COUNT(*) FROM deduction WHERE staff_id = ?";
    if ($stmt_check_existing = $conn->prepare($sql_check_existing)) {
        $stmt_check_existing->bind_param("i", $staffId);
        $stmt_check_existing->execute();
        $stmt_check_existing->bind_result($count);
        $stmt_check_existing->fetch();
        $stmt_check_existing->close();

        if ($count > 0) {
            // Update existing record
            $sql_update_deduction = "UPDATE deduction SET socsoEmployeeDeduct = ?, socsoEmployerDeduct = ? WHERE staff_id = ?";
            if ($stmt_update_deduction = $conn->prepare($sql_update_deduction)) {
                $stmt_update_deduction->bind_param("ddi", $employeeSOCSO, $employerSOCSO, $staffId);
                if ($stmt_update_deduction->execute()) {
                    echo "
                    <script>
                        alert('SOCSO contributions updated successfully in deduction table.');
                        location.replace('../view_staff.php?id=$staffId');
                    </script>
                    ";
                } else {
                    echo "
                    <script>
                        alert('Error updating SOCSO contributions in deduction table: ' . $stmt_update_deduction->error);
                        window.history.back();
                    </script>
                    ";
                }
                $stmt_update_deduction->close();
            } else {
                echo "<p>Error preparing update statement: " . $conn->error . "</p>
                <script>window.history.back();</script>";
            }
        } else {
            // Insert new record
            $sql_insert_deduction = "INSERT INTO deduction (staff_id, socsoEmployeeDeduct, socsoEmployerDeduct) VALUES (?, ?, ?)";
            if ($stmt_insert_deduction = $conn->prepare($sql_insert_deduction)) {
                $stmt_insert_deduction->bind_param("idd", $staffId, $employeeSOCSO, $employerSOCSO);
                        alert('Error updating SOCSO contributions in deduction table.');
                    echo "<script>
                        alert('SOCSO contributions added successfully in deduction table.');
                        location.replace('../view_staff.php?id=$staffId');
                    </script>";
                } else {
                    echo "<script>
                        alert('Error updating SOCSO contributions in deduction table: ' . $stmt_insert_deduction->error);
                    alert('Error preparing insert statement.');
                    </script>";
                }
                $stmt_insert_deduction->close();
            }} else {
                echo "
                <script>
            alert('Error preparing check statement.');
                    window.history.back();
                </script>";
            }
        }
     else {
        echo "<script>
            alert('Error preparing check statement: ' . $conn->error);
            window.history.back();
            </script>";
    }

?>
