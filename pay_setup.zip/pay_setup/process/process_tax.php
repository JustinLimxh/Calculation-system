<?php
// Check if the request method is POST
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Retrieve and sanitize POST data
    $pcb = isset($_POST['pcb']) ? (float)$_POST['pcb'] : 0.0;
    $annualTax = isset($_POST['annual_tax']) ? (float)$_POST['annual_tax'] : 0.0;
}
?>

<?php
include 'db.php';

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$staffId = $_POST['staff_id'];

$sql = "SELECT * FROM staff_bio WHERE staff_id = $staffId";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Update existing record
    $sql = "UPDATE staff_bio SET 
            pcb = $pcb,
            annual_tax = $annualTax
            WHERE staff_id = $staffId";
} else {
    // Insert new record
    $sql = "INSERT INTO staff_bio (staff_id, pcb, annual_tax) 
            VALUES ($staffId, $pcb, $annualTax)";
}

if ($conn->query($sql) === TRUE) {
    echo "<script>
    
    alert('Record updated successfully!');
    history.back();

    </script>";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>
