<?php
// Include your database connection
include('db.php'); // Adjust the path based on where your db.php is located

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $remunerationType = $_POST['remunerationType']; // The type of remuneration (e.g., 'advPayRemu')
    $amount = $_POST['amount'];

    // Start session to get the staff ID (ensure staff is logged in)
    session_start();
    $staffId = isset($_SESSION['staff_id']) ? $_SESSION['staff_id'] : 1; // Default to 1 for now

    // Check if all necessary fields are filled
    if (!empty($remunerationType) && !empty($amount)) {

        // Ensure the amount is a valid number
        if (!filter_var($amount, FILTER_VALIDATE_FLOAT)) {
            showErrorAndRedirect('Invalid amount. Please enter a valid number.');
        }

        // Ensure the remuneration type exists as a valid column in the `remuneration` table
        $validRemunerationTypes = [
            'advPayRemu',
            'arrearsRemu',
            'bonusRemu',
            'commissionRemu',
            'compensationRemu',
            'directorRemu',
            'claimRemu',
            'gratuityRemu',
            'incentiveRemu',
            'leavePayRemu',
            'otNormRemu',
            'otOffRemu',
            'otPublicRemu',
            'pcbPastRemu',
            'profitRemu',
            'servRemu',
            'severanceRemu'
        ];

        // Check if remunerationType is valid
        if (!in_array($remunerationType, $validRemunerationTypes)) {
            showErrorAndRedirect('Invalid remuneration type.');
        }

        // Prepare the SQL query to check if the record already exists
        $sql_check = "SELECT * FROM remuneration WHERE staff_id = ? AND {$remunerationType} IS NOT NULL";
        if ($stmt_check = $conn->prepare($sql_check)) {
            $stmt_check->bind_param("i", $staffId);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();

            if ($result_check->num_rows > 0) {
                // Record exists, update the existing remuneration record
                $sql_update = "UPDATE remuneration SET {$remunerationType} = ? WHERE staff_id = ?";
                if ($stmt_update = $conn->prepare($sql_update)) {
                    $stmt_update->bind_param("di", $amount, $staffId);
                    if ($stmt_update->execute()) {
                        showErrorAndRedirect('Remuneration updated successfully.');
                    } else {
                        showErrorAndRedirect('Error updating remuneration: ' . $stmt_update->error);
                    }
                    $stmt_update->close();
                } else {
                    showErrorAndRedirect('Error preparing the update query: ' . $conn->error);
                }
            } else {
                // No record found, insert a new remuneration record
                $sql_insert = "INSERT INTO remuneration (staff_id, {$remunerationType}) VALUES (?, ?)";
                if ($stmt_insert = $conn->prepare($sql_insert)) {
                    $stmt_insert->bind_param("id", $staffId, $amount);
                    if ($stmt_insert->execute()) {
                        showErrorAndRedirect('Remuneration added successfully.');
                    } else {
                        showErrorAndRedirect('Error inserting remuneration: ' . $stmt_insert->error);
                    }
                    $stmt_insert->close();
                } else {
                    showErrorAndRedirect('Error preparing the insert query: ' . $conn->error);
                }
            }

            $stmt_check->close();
        } else {
            showErrorAndRedirect('Error preparing the check query: ' . $conn->error);
        }
    } else {
        showErrorAndRedirect('Please fill in all fields.');
    }
}

// Helper function for error handling and redirect
function showErrorAndRedirect($message) {
    echo "<script>
        alert('$message');
        window.history.back();
    </script>";
    exit();
}

// Close database connection
$conn->close();
?>
