<?php
// Include your database connection file
include('db.php'); // Adjust the path based on where your db.php is located

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $bikType = $_POST['bikType'];
    $amount = $_POST['amount'];

    // Example: Get the staff ID from session or other methods (Ensure staff is logged in)
    session_start();
    $staffId = $_POST['staff_id']; // Get the staff_id from the form submission

    // for motor car
    $type = $_POST['type']; // get the type of motor car
    $year = $_POST['year']; // get the year of motor car
    $model = $_POST['model']; // get the model of motor car

    // Helper function for displaying alerts
    function showAlertAndGoBack($message)
    {
        echo "<script>
            alert('$message');
            window.history.back();
        </script>";
        exit();
    }

    // Check if all necessary fields are filled
    if (!empty($bikType) && !empty($amount)) {

        // Ensure amount is a valid number
        if (!filter_var($amount, FILTER_VALIDATE_FLOAT)) {
            showAlertAndGoBack('Invalid amount. Please enter a valid number.');
        }

        // Define valid benefit types
        $valid_benefit_types = [
            'consumeDiscBik',
            'dentalBik',
            'driverBik',
            'fulfillDutiBik',
            'foodDrinkBik',
            'garmentBik',
            'hElectrikBik',
            'hEntertainBik',
            'hFurniturBik',
            'hGardenBik',
            'hKitchenBik',
            'hServantBik',
            'hTelephoneBik',
            'hUtilitiBik',
            'travelMalayBik',
            'travelOverBik',
            'liviAccoBik',
            'medicalBik',
            'otherBik',
            'clubMemberBik',
            'serviceDiscBik',
            'transportBik',
            'motorcarBik',
            'workAccidentBik',
        ];

        // Ensure the benefit type is valid
        if (in_array($bikType, $valid_benefit_types)) {
            // Check if the benefit already exists in the `benefit` table
            $sql_check = "SELECT * FROM benefit WHERE staff_id = ?";
            if ($stmt_check = $conn->prepare($sql_check)) {
                $stmt_check->bind_param("i", $staffId);
                $stmt_check->execute();
                $result_check = $stmt_check->get_result();

                if ($result_check->num_rows == 0) {
                    // for any unique value , due to it will get stuck at update error (etc: motorcarBik)
                    // Insert a new record with default values if no record exists
                    $sql_insert = "INSERT INTO benefit (staff_id) VALUES (?)";
                    if ($stmt_insert = $conn->prepare($sql_insert)) {
                        $stmt_insert->bind_param("i", $staffId);
                        $stmt_insert->execute();
                        $stmt_insert->close();
                    }
                }
        
                // Apply the conditions for both BIKs
                if ($bikType == 'motorcarBik') {
                    if ($amount < 50000) {
                        $motorcarBik = 1200;
                        $petrolBik = 600;
                    } elseif ($amount > 50000 && $amount <= 75000) {
                        $motorcarBik = 2400;
                        $petrolBik = 900;
                    } elseif ($amount > 75000 && $amount <= 100000) {
                        $motorcarBik = 3600;
                        $petrolBik = 1200;
                    } elseif ($amount > 100000 && $amount <= 150000) {
                        $motorcarBik = 5000;
                        $petrolBik = 1500;
                    } elseif ($amount > 150000 && $amount <= 200000) {
                        $motorcarBik = 7000;
                        $petrolBik = 1800;
                    } elseif ($amount > 200000 && $amount <= 250000) {
                        $motorcarBik = 9000;
                        $petrolBik = 2100;
                    } elseif ($amount > 250000 && $amount <= 350000) {
                        $motorcarBik = 15000;
                        $petrolBik = 2400;
                    } elseif ($amount > 350000 && $amount <= 500000) {
                        $motorcarBik = 21250;
                        $petrolBik = 2700;
                    } elseif ($amount > 500000) {
                        $motorcarBik = 25000;
                        $petrolBik = 3000;
                    }
                    $sql_update = "UPDATE benefit SET motorcarBik = ?, petrolBik = ? WHERE staff_id = ?";
                    if ($stmt_update = $conn->prepare($sql_update)) {
                        $stmt_update->bind_param("dii", $motorcarBik, $petrolBik, $staffId);
                        $stmt_update->execute();
                        $stmt_update->close();
                    }
                } else {
                    if ($bikType == 'hGardenBik') {
                        $hGardenBik = $amount * 3600;
                        $sql_update = "UPDATE benefit SET hGardenBik = ? WHERE staff_id = ?";
                        if ($stmt_update = $conn->prepare($sql_update)) {
                            $stmt_update->bind_param("di", $hGardenBik, $staffId);
                            $stmt_update->execute();
                            $stmt_update->close();
                        }
                    } elseif ($bikType == 'hServantBik') {
                        $hServantBik = $amount * 4600;
                        $sql_update = "UPDATE benefit SET hServantBik = ? WHERE staff_id = ?";
                        if ($stmt_update = $conn->prepare($sql_update)) {
                            $stmt_update->bind_param("di", $hServantBik, $staffId);
                            $stmt_update->execute();
                            $stmt_update->close();
                        }
                    } else {
                        $sql_update = "UPDATE benefit SET `$bikType` = ? WHERE staff_id = ?";
                        if ($stmt_update = $conn->prepare($sql_update)) {
                            $stmt_update->bind_param("di", $amount, $staffId);
                            $stmt_update->execute();
                            $stmt_update->close();
                        }
                    }
                }

                if ($result_check->num_rows > 0) {
                    // Update the existing benefit in the `benefit` table
                    if ($bikType == 'motorcarBik' ) {
                        if ($amount < 50000) {
                            $motorcarBik = 1200;
                            $petrolBik = 600;
                        } elseif ($amount > 50000 && $amount <= 75000) {
                            $motorcarBik = 2400;
                            $petrolBik = 900;
                        } elseif ($amount > 75000 && $amount <= 100000) {
                            $motorcarBik = 3600;
                            $petrolBik = 1200;
                        } elseif ($amount > 100000 && $amount <= 150000) {
                            $motorcarBik = 5000;
                            $petrolBik = 1500;
                        } elseif ($amount > 150000 && $amount <= 200000) {
                            $motorcarBik = 7000;
                            $petrolBik = 1800;
                        } elseif ($amount > 200000 && $amount <= 250000) {
                            $motorcarBik = 9000;
                            $petrolBik = 2100;
                        } elseif ($amount > 250000 && $amount <= 350000) {
                            $motorcarBik = 15000;
                            $petrolBik = 2400;
                        } elseif ($amount > 350000 && $amount <= 500000) {
                            $motorcarBik = 21250;
                            $petrolBik = 2700;
                        } elseif ($amount > 500000) {
                            $motorcarBik = 25000;
                            $petrolBik = 3000;
                        }
                        $sql_update = "UPDATE benefit SET motorcarBik = ?, petrolBik = ? WHERE staff_id = ?";
                        if ($stmt_update = $conn->prepare($sql_update)) {
                            $stmt_update->bind_param("dii", $motorcarBik, $petrolBik, $staffId);
                        }
                    } else {
                        $sql_update = "UPDATE benefit SET `$bikType` = ? WHERE staff_id = ?";
                        if ($stmt_update = $conn->prepare($sql_update)) {
                            $stmt_update->bind_param("di", $amount, $staffId);
                        }
                    }
                    
                    if($bikType == 'hGardenBik') {
                        $hGardenBik = $amount * 3600;
                        $sql_update = "UPDATE benefit SET hGardenBik = ? WHERE staff_id = ?";
                        if ($stmt_update = $conn->prepare($sql_update)) {
                            $stmt_update->bind_param("di", $hGardenBik, $staffId);
                        }
                    }

                    if($bikType == 'hServantBik') {
                        $hServantBik = $amount * 4800;
                        $sql_update = "UPDATE benefit SET hServantBik = ? WHERE staff_id = ?";
                        if ($stmt_update = $conn->prepare($sql_update)) {
                            $stmt_update->bind_param("di", $hServantBik, $staffId);
                        }
                    }

                    if ($stmt_update->execute()) {
                        if ($bikType == 'motorcarBik') {
                            handleMotorcar($conn, $staffId, $type, $year, $model);
                        }
                        showAlertAndGoBack('Benefit updated successfully.');
                        } else {
                            showAlertAndGoBack('Error updating benefit: ' . $stmt_update->error);
                        }
                        $stmt_update->close();
                    } else {
                        showAlertAndGoBack('Error preparing the update query: ' . $conn->error);
                    }

                    
                } else {
                    // Insert the benefit if the staff does not exist in the `benefit` table
                    $sql_insert = "INSERT INTO benefit (staff_id, `$bikType`) VALUES (?, ?)";
                    if ($stmt_insert = $conn->prepare($sql_insert)) {
                        $stmt_insert->bind_param("id", $staffId, $amount);
                        if ($stmt_insert->execute()) {

                            if ($bikType == 'motorcarBik') {
                                handleMotorcar($conn, $staffId, $type, $year, $model);
                            }

                            showAlertAndGoBack('Benefit inserted successfully.');
                            echo "<script> location.reload();</script>";
                        } else {
                            showAlertAndGoBack('Error inserting benefit: ' . $stmt_insert->error);
                        }
                        $stmt_insert->close();
                    } else {
                        showAlertAndGoBack('Error preparing the insert query: ' . $conn->error);
                    }
                }

                $stmt_check->close();
            } else {
                showAlertAndGoBack('Error preparing the check query: ' . $conn->error);
            }
        } else {
            showAlertAndGoBack('Invalid benefit type selected.');
        }
    } else {
        showAlertAndGoBack('Please fill in all fields.');
    }


function handleMotorcar($conn, $staffId, $type, $year, $model) {
    $sql_check_motorcar = "SELECT * FROM motorcar WHERE staff_id = ?";
    if ($stmt_check_motorcar = $conn->prepare($sql_check_motorcar)) {
        $stmt_check_motorcar->bind_param("i", $staffId);
        $stmt_check_motorcar->execute();
        $result_check_motorcar = $stmt_check_motorcar->get_result();

        if ($result_check_motorcar->num_rows > 0) {
            // Update the existing motorcar record
            $sql_update_motorcar = "UPDATE motorcar SET `type` = ?, `year` = ?, `model` = ? WHERE staff_id = ?";
            if ($stmt_update_motorcar = $conn->prepare($sql_update_motorcar)) {
                $stmt_update_motorcar->bind_param("sisi", $type, $year, $model, $staffId);
                $stmt_update_motorcar->execute();
                $stmt_update_motorcar->close();
            }
        } else {
            // Insert a new motorcar record
            $sql_insert_motorcar = "INSERT INTO motorcar (staff_id, `type`, `year`, `model`) VALUES (?, ?, ?, ?)";
            if ($stmt_insert_motorcar = $conn->prepare($sql_insert_motorcar)) {
                $stmt_insert_motorcar->bind_param("isis", $staffId, $type, $year, $model);
                $stmt_insert_motorcar->execute();
                $stmt_insert_motorcar->close();
            }
        }
        $stmt_check_motorcar->close();
    }
}

// Close database connection
$conn->close();
