<?php
// Include your database connection
include('db.php'); // Adjust the path based on where your db.php is located

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Start session to get the staff ID
    session_start();
    $staffId = $_POST['staff_id']; // Get the staff_id from the form submissions

    // Get form data
    $normal_hours = $_POST['normal_hours'] ?? 0;
    $rest_hours = $_POST['rest_hours'] ?? 0;
    $holiday_hours = $_POST['holiday_hours'] ?? 0;
    $current_salary = $_POST['current_salary'] ?? 0;

    
    $ORP = round(($current_salary / 26), 2) ;
    $HRP = round(($ORP / 8 ), 2) ;
    
    $totalNHOW = 0;
    $totalRHOW = 0;
    $totalHHOW = 0;

    if($normal_hours > 0 ){
        $totalNHOW += round(($normal_hours * $HRP * 1.5),2);
    }

    if($rest_hours > 0 && $rest_hours <= 4){
        $totalRHOW += round(($ORP * 0.5),2);
    }elseif ($rest_hours > 3 && $rest_hours <= 8) {
        $totalRHOW += round(($ORP * 1),2);
    }elseif ($rest_hours > 8) {
        $totalRHOW += round(($ORP * 1),2);
        $totalRHOW += round((($rest_hours - 8) * $HRP * 2),2);
    }

    if($holiday_hours > 0 && $holiday_hours <= 8){
        $totalHHOW += round(($ORP * 2),2);
    }elseif ($holiday_hours > 8) {
        $totalHHOW += round(($ORP * 2),2);
        $totalHHOW += round((($holiday_hours-8) * $HRP * 3),2);


    }

    $totalOT = round($totalNHOW + $totalRHOW + $totalHHOW , 2);

    // Validate input
    if (!isset($normal_hours) || !isset($rest_hours) || !isset($holiday_hours)) {
        echo "<script>
            alert('Please fill in all fields.');
            window.history.back();
        </script>";
        exit();
    }

    // Use prepared statements to check if the overtime record already exists
    $sql_check = "SELECT * FROM overtime WHERE staff_id = ?";
    if ($stmt_check = $conn->prepare($sql_check)) {
        $stmt_check->bind_param("i", $staffId);
        $stmt_check->execute();
        $result_check = $stmt_check->get_result();

    if ($result_check->num_rows > 0) {
        // Update existing overtime record
        $sql_update = "UPDATE overtime SET normal_hours = ?, rest_hours = ?, holiday_hours = ?, overtime_pay = ? WHERE staff_id = ?";
        if ($stmt_update = $conn->prepare($sql_update)) {
            $stmt_update->bind_param("dddii", $normal_hours, $rest_hours, $holiday_hours, $totalOT, $staffId);
            if ($stmt_update->execute()) {
                echo "<script>
                    alert('Overtime information updated successfully.');
                    location.replace('../view_staff.php?id=$staffId');
                </script>";
            } else {
                echo "<script>
                    alert('Error updating overtime information: " . $stmt_update->error . "');
                    window.history.back();
                </script>";
            }
                $stmt_update->close();
            } else {
                echo "<script>
                    alert('Error preparing the update query: " . $conn->error . "');
                    window.history.back();
                </script>";
            }
        } else {
            // Insert new overtime record if no record exists for the given staff ID
            $sql_insert = "INSERT INTO overtime (staff_id, normal_hours, rest_hours, holiday_hours, overtime_pay) VALUES (?, ?, ?, ?, ?)";
            if ($stmt_insert = $conn->prepare($sql_insert)) {
                $stmt_insert->bind_param("idddd", $staffId, $normal_hours, $rest_hours, $holiday_hours, $totalOT);
                if ($stmt_insert->execute()) {
                    echo "<script>
                        alert('Overtime information saved successfully.');
                        window.history.back();
                    </script>";
                } else {
                    echo "<script>
                        alert('Error saving overtime information: " . $stmt_insert->error . "');
                        
                    </script>";
                }
                $stmt_insert->close();
            } else {
                echo "<script>
                    alert('Error preparing the insert query: " . $conn->error . "');
                    window.history.back();
                </script>";
            }
        }

        $stmt_check->close();
    } else {
        echo "<script>
            alert('Error preparing the check query: " . $conn->error . "');
            window.history.back();
        </script>";
    }

}
?>