<?php include('db.php'); // Adjust the path based on where your db.php is located ?>

<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $totalAccountedEIS = is_numeric($_POST['totalAccountedEIS']) ? (float)$_POST['totalAccountedEIS'] : 0;
    $staffId = $_POST['staff_id'];

    // Define EIS contribution rates based on the provided table
    $eisRates = [
        ['max' => 0, 'eis' => 0, 'eisCon' => 0],
        ['max' => 30, 'eis' => 0, 'eisCon' => 0],
        ['max' => 50, 'eis' => 0, 'eisCon' => 0],
        ['max' => 70, 'eis' => 0, 'eisCon' => 0],
        ['max' => 100, 'eis' => 0, 'eisCon' => 0],
        ['max' => 140, 'eis' => 0, 'eisCon' => 0],
        ['max' => 200, 'eis' => 0, 'eisCon' => 0],
        ['max' => 300, 'eis' => 0, 'eisCon' => 0],
        ['max' => 400, 'eis' => 0, 'eisCon' => 0],
        ['max' => 500, 'eis' => 1, 'eisCon' => 1],
        ['max' => 600, 'eis' => 1, 'eisCon' => 1],
        ['max' => 700, 'eis' => 1, 'eisCon' => 1],
        ['max' => 800, 'eis' => 1, 'eisCon' => 1],
        ['max' => 900, 'eis' => 1, 'eisCon' => 1],
        ['max' => 1000, 'eis' => 2, 'eisCon' => 2],
        ['max' => 1100, 'eis' => 2, 'eisCon' => 2],
        ['max' => 1200, 'eis' => 2, 'eisCon' => 2],
        ['max' => 1300, 'eis' => 2, 'eisCon' => 2],
        ['max' => 1400, 'eis' => 2, 'eisCon' => 2],
        ['max' => 1500, 'eis' => 3, 'eisCon' => 3],
        ['max' => 1600, 'eis' => 3, 'eisCon' => 3],
        ['max' => 1700, 'eis' => 3, 'eisCon' => 3],
        ['max' => 1800, 'eis' => 3, 'eisCon' => 3],
        ['max' => 1900, 'eis' => 3, 'eisCon' => 3],
        ['max' => 2000, 'eis' => 4, 'eisCon' => 4],
        ['max' => 2100, 'eis' => 4, 'eisCon' => 4],
        ['max' => 2200, 'eis' => 4, 'eisCon' => 4],
        ['max' => 2300, 'eis' => 4, 'eisCon' => 4],
        ['max' => 2400, 'eis' => 4, 'eisCon' => 4],
        ['max' => 2500, 'eis' => 5, 'eisCon' => 5],
        ['max' => 2600, 'eis' => 5, 'eisCon' => 5],
        ['max' => 2700, 'eis' => 5, 'eisCon' => 5],
        ['max' => 2800, 'eis' => 5, 'eisCon' => 5],
        ['max' => 2900, 'eis' => 5, 'eisCon' => 5],
        ['max' => 3000, 'eis' => 6, 'eisCon' => 6],
        ['max' => 3100, 'eis' => 6, 'eisCon' => 6],
        ['max' => 3200, 'eis' => 6, 'eisCon' => 6],
        ['max' => 3300, 'eis' => 6, 'eisCon' => 6],
        ['max' => 3400, 'eis' => 6, 'eisCon' => 6],
        ['max' => 3500, 'eis' => 7, 'eisCon' => 7],
        ['max' => 3600, 'eis' => 7, 'eisCon' => 7],
        ['max' => 3700, 'eis' => 7, 'eisCon' => 7],
        ['max' => 3800, 'eis' => 7, 'eisCon' => 7],
        ['max' => 3900, 'eis' => 7, 'eisCon' => 7],
        ['max' => 4000, 'eis' => 8, 'eisCon' => 8],
        ['max' => 4100, 'eis' => 8, 'eisCon' => 8],
        ['max' => 4200, 'eis' => 8, 'eisCon' => 8],
        ['max' => 4300, 'eis' => 8, 'eisCon' => 8],
        ['max' => 4400, 'eis' => 8, 'eisCon' => 8],
        ['max' => 4500, 'eis' => 9, 'eisCon' => 9],
        ['max' => 4600, 'eis' => 9, 'eisCon' => 9],
        ['max' => 4700, 'eis' => 9, 'eisCon' => 9],
        ['max' => 4800, 'eis' => 9, 'eisCon' => 9],
        ['max' => 4900, 'eis' => 9, 'eisCon' => 9],
        ['max' => 5000, 'eis' => 10, 'eisCon' => 10],
        ['max' => 5100, 'eis' => 10, 'eisCon' => 10],
        ['max' => 5200, 'eis' => 10, 'eisCon' => 10],
        ['max' => 5300, 'eis' => 10, 'eisCon' => 10],
        ['max' => 5400, 'eis' => 10, 'eisCon' => 10],
        ['max' => 5500, 'eis' => 11, 'eisCon' => 11],
        ['max' => 5600, 'eis' => 11, 'eisCon' => 11],
        ['max' => 5700, 'eis' => 11, 'eisCon' => 11],
        ['max' => 5800, 'eis' => 11, 'eisCon' => 11],
        ['max' => 5900, 'eis' => 11, 'eisCon' => 11],
        ['max' => PHP_INT_MAX, 'eis' => function($totalAccountedEIS) { return ceil($totalAccountedEIS * 0.005); }, 'eisCon' => function($totalAccountedEIS) { return ceil($totalAccountedEIS * 0.005); }]
    ];

    // Calculate EIS contributions based on the totalAccountedEIS
    $employeeEIS = 0;
    $employerEIS = 0;
    foreach ($eisRates as $rate) {
        if ($totalAccountedEIS <= $rate['max']) {
            if (is_callable($rate['eis'])) {
                $employeeEIS = $rate['eis']($totalAccountedEIS);
                $employerEIS = $rate['eisCon']($totalAccountedEIS);
            } else {
                $employeeEIS = $rate['eis'];
                $employerEIS = $rate['eisCon'];
            }
            break;
        }
    }

    // Check if a record already exists for the given staff_id
    $sql_check_existing = "SELECT COUNT(*) FROM deduction WHERE staff_id = ?";
    if ($stmt_check_existing = $conn->prepare($sql_check_existing)) {
        $stmt_check_existing->bind_param("i", $staffId);
        $stmt_check_existing->execute();
        $stmt_check_existing->bind_result($count);
        $stmt_check_existing->fetch();
        $stmt_check_existing->close();

        if ($count > 0) {
            // Update existing record
            $sql_update_deduction = "UPDATE deduction SET eisEmployeeDeduct = ?, eisEmployerDeduct = ? WHERE staff_id = ?";
            if ($stmt_update_deduction = $conn->prepare($sql_update_deduction)) {
                $stmt_update_deduction->bind_param("ddi", $employeeEIS, $employerEIS, $staffId);
                if ($stmt_update_deduction->execute()) {
                    echo "
                    
                    <script>
                        alert('EIS contributions updated successfully in deduction table.');
                        location.replace('../view_staff.php?id=$staffId');
                    </script>
                    
                    ";

                } else {
                    echo "
                    <script>
                        alert('Error updating EIS contributions in deduction table: ' . $stmt_update_deduction->error);
                        location.history.back();
                    </script>
                    
                    ";
                }
                $stmt_update_deduction->close();
            } else {
                echo "<p>Error preparing update statement: " . $conn->error . "</p>
                window.history.back();";
            }
        } else {
            // Insert new record
            $sql_insert_deduction = "INSERT INTO deduction (staff_id, eisEmployeeDeduct, eisEmployerDeduct) VALUES (?, ?, ?)";
            if ($stmt_insert_deduction = $conn->prepare($sql_insert_deduction)) {
                $stmt_insert_deduction->bind_param("idd", $staffId, $employeeEIS, $employerEIS);
                if ($stmt_insert_deduction->execute()) {
                    echo "<script>
                        alert('EIS contributions added successfully in deduction table.');
                        location.replace('../view_staff.php?id=$staffId');
                    </script>";
                } else {
                    echo "<script>
                        alert('Error updating EIS contributions in deduction table: ' . $stmt_insert_deduction->error);
                        location.history.back();
                    </script>";
                }
                $stmt_insert_deduction->close();
            } else {
                echo "
                <script>
                    alert('Error preparing insert statement: ' . $conn->error);
                    window.history.back();
                </script>";
            }
        }
    } else {
        echo "<script>
            alert('Error preparing check statement: ' . $conn->error);
            window.history.back();
            </script>";
    }
}
?>