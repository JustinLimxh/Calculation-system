function setBankType(bankName) {
    // Set the value of the hidden input to the selected bank
    document.getElementById('bankType').value = bankName;

    // Optionally, you can add a class to highlight the selected button
    let buttons = document.querySelectorAll('.bank-btn');
    buttons.forEach(button => button.classList.remove('selected'));
    event.target.classList.add('selected');
}

function setAllowanceType(allowanceType) {
    // Set the value of the hidden input to the selected allowance type
    document.getElementById('allowanceType').value = allowanceType;

    // Highlight the selected button
    let buttons = document.querySelectorAll('.allowance-btn');
    buttons.forEach(button => button.classList.remove('selected'));
    event.target.classList.add('selected');
}

// Function to dynamically handle multiple modals
document.addEventListener('DOMContentLoaded', function () {
    // Get all buttons that open modals
    const buttons = document.querySelectorAll('button[id$="Btn"]'); // Select buttons ending with 'Btn'

    buttons.forEach(button => {
        button.addEventListener('click', function () {
            const modalId = button.id.replace('Btn', 'Modal'); // Replace 'Btn' with 'Modal' to get the modal ID
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = "block";
            }
        });
    });

    // Get all modals
    const modals = document.querySelectorAll('.modal');

    modals.forEach(modal => {
        // Close modal when clicking on the close span
        const closeBtn = modal.querySelector('.close');
        if (closeBtn) {
            closeBtn.addEventListener('click', function () {
                modal.style.display = "none";
            });
        }

        // Close modal when clicking outside the modal content
        window.addEventListener('click', function (event) {
            if (event.target === modal) {
                modal.style.display = "none";
            }
        });
    });
});
