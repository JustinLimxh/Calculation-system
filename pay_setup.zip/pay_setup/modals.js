function setBankType(bankName) {
    // Set the value of the hidden input to the selected bank
    document.getElementById('bankType').value = bankName;

    // Optionally, you can add a class to highlight the selected button
    let buttons = document.querySelectorAll('.bank-btn');
    buttons.forEach(button => button.classList.remove('selected'));
    event.target.classList.add('selected');
}


// to show unique motorcar inputs when motorcar is selected
document.addEventListener('DOMContentLoaded', function() {
    const motorCarButton = document.querySelector('button[data-value="motorcarBik"]');
    const motorCarDetails = document.getElementById('motorCarDetails');

    motorCarButton.addEventListener('click', function() {
        motorCarDetails.style.display = 'block';
    });

    const otherButtons = document.querySelectorAll('button.options-btn:not([data-value="motorcarBik"])');
    otherButtons.forEach(button => {
        button.addEventListener('click', function() {
            motorCarDetails.style.display = 'none';
        });
    });
});

// Handle button clicks for all groups dynamically
document.addEventListener('DOMContentLoaded', function() {
    const motorCarButton = document.querySelector('button[data-value="motorcarBik"]');
    const motorCarDetails = document.getElementById('motorCarDetails');
    const bikForm = document.querySelector('form[action="process/process_bik.php"]');
    const bikTypeInput = document.getElementById('bikType');

    motorCarButton.addEventListener('click', function() {
        motorCarDetails.style.display = 'block';
        bikTypeInput.value = 'motorcarBik';
        document.getElementById('type').setAttribute('required', 'required');
        document.getElementById('year').setAttribute('required', 'required');
        document.getElementById('model').setAttribute('required', 'required');
    });

    const otherButtons = document.querySelectorAll('button.options-btn:not([data-value="motorcarBik"])');
    otherButtons.forEach(button => {
        button.addEventListener('click', function() {
            motorCarDetails.style.display = 'none';
            bikTypeInput.value = button.getAttribute('data-value');
            document.getElementById('type').removeAttribute('required');
            document.getElementById('year').removeAttribute('required');
            document.getElementById('model').removeAttribute('required');
        });
    });

    bikForm.addEventListener('submit', function(event) {
        if (bikTypeInput.value === 'motorcarBik') {
            if (!document.getElementById('type').value || !document.getElementById('year').value || !document.getElementById('car_model').value) {
                event.preventDefault();
                alert('Please fill in all motor car details.');
            }
        }
    });
});

// Handle button clicks for all groups dynamically
document.addEventListener("click", function (event) {
    // Check if the clicked element is a button within a button group
    if (event.target.tagName === "BUTTON" && event.target.closest(".button-group")) {
        const button = event.target;
        const group = button.closest(".button-group");
        const groupId = group.getAttribute("data-group-id");
        const hiddenInput = document.querySelector(`#${groupId}`);
        const value = button.getAttribute("data-value");

        // Update the hidden input's value
        if (hiddenInput) {
            hiddenInput.value = value;
        }

        // Update button states
        Array.from(group.querySelectorAll("button")).forEach(btn => {
            btn.classList.remove("selected");
        });
        button.classList.add("selected");
    }
});

// Initialize selected state on page load (optional)
function initializeSelections() {
    document.querySelectorAll(".button-group").forEach(group => {
        const groupId = group.getAttribute("data-group-id");
        const hiddenInput = document.querySelector(`#${groupId}`);
        const selectedValue = hiddenInput ? hiddenInput.value : null;

        if (selectedValue) {
            const button = group.querySelector(`button[data-value="${selectedValue}"]`);
            if (button) {
                button.classList.add("selected");
            }
        }
    });
}

// Run initialization after the page loads
document.addEventListener("DOMContentLoaded", initializeSelections);


// Function to dynamically handle multiple modals
document.addEventListener('DOMContentLoaded', function () {
    // Get all buttons that open modals
    const buttons = document.querySelectorAll('button[id$="Btn"]'); // Select buttons ending with 'Btn'

    buttons.forEach(button => {
        button.addEventListener('click', function () {
            const modalId = button.id.replace('Btn', 'Modal'); // Replace 'Btn' with 'Modal' to get the modal ID
            const modal = document.getElementById(modalId);
            if (modal) {
                modal.style.display = "block";
            }
        });
    });

    // Get all modals
    const modals = document.querySelectorAll('.modal');

    modals.forEach(modal => {
        // Close modal when clicking on the close span
        const closeBtn = modal.querySelector('.close');
        if (closeBtn) {
            closeBtn.addEventListener('click', function () {
                modal.style.display = "none";
            });
        }

        // Close modal when clicking outside the modal content
        window.addEventListener('click', function (event) {
            if (event.target === modal) {
                modal.style.display = "none";
            }
        });
    });

    modals.forEach(modal => {
        // Close modal when clicking on the close span
        const reloadBtn = modal.querySelector('.reload');
        if (reloadBtn) {
            reloadBtn.addEventListener('click', function () {
                location.reload();
            });
        }

        // Close modal when clicking outside the modal content
        window.addEventListener('click', function (event) {
            if (event.target === modal) {
                history.back();
                location.reload();
            }
        });
    });
});
